package com.example

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

enum class MacroMode(val label: String, val description: String) {
    HOLD_TO_REPEAT("Hold to Repeat", "Rapidly clicks target 'a' while holding button 'A'"),
    TAP_TO_REPEAT("Tap to Repeat", "Tap button 'A' once to start/stop continuous rapid clicks")
}

data class MacroPreset(
    val name: String,
    val description: String,
    val intervalMs: Int,
    val mode: MacroMode
)

val MACRO_PRESETS = listOf(
    MacroPreset("Ultra Rapid Fire", "For single-shot DMRs & rapid triggers", 15, MacroMode.HOLD_TO_REPEAT),
    MacroPreset("Turbo Skill Spam", "For MOBA skill spam & fast buying", 35, MacroMode.HOLD_TO_REPEAT),
    MacroPreset("Balanced Auto-Click", "For RPGs, idle games & farming", 60, MacroMode.TAP_TO_REPEAT),
    MacroPreset("Safe Rhythm", "For rhythm & casual precision taps", 120, MacroMode.TAP_TO_REPEAT)
)

data class MacroState(
    val mode: MacroMode = MacroMode.HOLD_TO_REPEAT,
    val intervalMs: Int = 30,
    val pressDurationMs: Long = 10L,
    val overlayAlpha: Float = 0.85f,
    val isOverlayServiceRunning: Boolean = false,
    val isTerminalExpanded: Boolean = false,
    val isTriggerAVisible: Boolean = true,
    val isPointeraVisible: Boolean = true,
    val isClickingActive: Boolean = false,
    val targetX: Float = 500f,
    val targetY: Float = 800f,
    val triggerX: Float = 200f,
    val triggerY: Float = 800f,
    val totalClicksCount: Long = 0L,
    val lastClickTimestamp: Long = 0L,
    val isAccessibilityEnabled: Boolean = false
)

object MacroManager {
    private val _state = MutableStateFlow(MacroState())
    val state: StateFlow<MacroState> = _state.asStateFlow()

    fun updateMode(mode: MacroMode) {
        _state.update { it.copy(mode = mode) }
    }

    fun updateInterval(intervalMs: Int) {
        _state.update { it.copy(intervalMs = intervalMs.coerceIn(10, 200)) }
    }

    fun updateAlpha(alpha: Float) {
        _state.update { it.copy(overlayAlpha = alpha.coerceIn(0.1f, 1.0f)) }
    }

    fun setOverlayServiceRunning(running: Boolean) {
        _state.update { it.copy(isOverlayServiceRunning = running) }
    }

    fun setTerminalExpanded(expanded: Boolean) {
        _state.update { it.copy(isTerminalExpanded = expanded) }
    }

    fun setTriggerAVisible(visible: Boolean) {
        _state.update { it.copy(isTriggerAVisible = visible) }
    }

    fun setPointeraVisible(visible: Boolean) {
        _state.update { it.copy(isPointeraVisible = visible) }
    }

    fun updateTargetPosition(x: Float, y: Float) {
        _state.update { it.copy(targetX = x, targetY = y) }
    }

    fun updateTriggerPosition(x: Float, y: Float) {
        _state.update { it.copy(triggerX = x, triggerY = y) }
    }

    fun setClickingActive(active: Boolean) {
        _state.update { it.copy(isClickingActive = active) }
    }

    fun incrementClickCount() {
        _state.update { 
            it.copy(
                totalClicksCount = it.totalClicksCount + 1,
                lastClickTimestamp = System.currentTimeMillis()
            ) 
        }
    }

    fun resetClickCount() {
        _state.update { it.copy(totalClicksCount = 0) }
    }

    fun setAccessibilityEnabled(enabled: Boolean) {
        _state.update { it.copy(isAccessibilityEnabled = enabled) }
    }

    fun applyPreset(preset: MacroPreset) {
        _state.update {
            it.copy(
                mode = preset.mode,
                intervalMs = preset.intervalMs
            )
        }
    }
}
