package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Editorial Aesthetic Palette
val EditorialNoir = Color(0xFF0B0D0E)
val EditorialCard = Color(0xFF16181A)
val EditorialSurface = Color(0xFF1A1C1E)
val EditorialBorder = Color(0xFF2D3135)
val EditorialBorderSubtle = Color(0xFF3D4146)
val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF00363D)
val TextEditorialPrimary = Color(0xFFE2E2E2)
val TextEditorialMuted = Color(0xFF909499)
val TextEditorialMono = Color(0xFF565B61)

// Backward compatibility mappings
val RedMagicCrimson = Color(0xFFFF2A55)
val RedMagicDarkCrimson = Color(0xFFC70039)
val CyberCyan = ElectricCyan
val TurboAmber = Color(0xFFFFD166)
val ObsidianDark = EditorialNoir
val CarbonSurface = EditorialSurface
val CarbonCard = EditorialCard
val CarbonBorder = EditorialBorder
val TextPrimary = TextEditorialPrimary
val TextSecondary = TextEditorialMuted
val AccentGreen = Color(0xFF2EC4B6)


