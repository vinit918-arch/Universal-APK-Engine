package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme =
  darkColorScheme(
    primary = ElectricCyan,
    onPrimary = ElectricCyanDark,
    secondary = ElectricCyan,
    onSecondary = EditorialNoir,
    tertiary = TurboAmber,
    background = EditorialNoir,
    surface = EditorialSurface,
    surfaceVariant = EditorialCard,
    outline = EditorialBorder,
    onBackground = TextEditorialPrimary,
    onSurface = TextEditorialPrimary,
    onSurfaceVariant = TextEditorialMuted
  )

private val LightColorScheme = DarkColorScheme

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
