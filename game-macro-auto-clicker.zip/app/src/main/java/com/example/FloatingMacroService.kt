package com.example

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

class FloatingMacroService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager

    // Floating Views
    private var miniCrosshairView: View? = null
    private var terminalWindowView: View? = null
    private var triggerAView: View? = null
    private var targetAPointerView: View? = null

    // Layout Params
    private lateinit var miniParams: WindowManager.LayoutParams
    private lateinit var terminalParams: WindowManager.LayoutParams
    private lateinit var triggerAParams: WindowManager.LayoutParams
    private lateinit var targetAParams: WindowManager.LayoutParams

    companion object {
        private const val TAG = "FloatingMacroService"
        private const val CHANNEL_ID = "macro_overlay_channel"
        private const val NOTIFICATION_ID = 9001
        const val ACTION_STOP_SERVICE = "ACTION_STOP_SERVICE"

        fun startService(context: Context) {
            val intent = Intent(context, FloatingMacroService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, FloatingMacroService::class.java)
            context.stopService(intent)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification())

        MacroManager.setOverlayServiceRunning(true)

        initLayouts()
        setupStateObservers()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        MacroManager.setOverlayServiceRunning(false)
        MacroManager.setClickingActive(false)
        serviceScope.cancel()

        removeAllOverlays()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Game Macro Overlay HUD",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Running gaming macro auto-clicker overlay HUD"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val appIntent = Intent(this, MainActivity::class.java)
        val pendingAppIntent = PendingIntent.getActivity(
            this, 0, appIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, FloatingMacroService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val pendingStopIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Game Macro Engine Active")
            .setContentText("Macro HUD overlay is active. Tap to configure.")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingAppIntent)
            .addAction(0, "Close HUD", pendingStopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun getOverlayType(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).roundToInt()
    }

    private fun dpToPx(dp: Float): Float {
        return dp * resources.displayMetrics.density
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initLayouts() {
        val displayMetrics = resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels
        val screenHeight = displayMetrics.heightPixels

        // 1. Mini Crosshair Trigger Params
        miniParams = WindowManager.LayoutParams(
            dpToPx(56),
            dpToPx(56),
            getOverlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenWidth * 0.85f).toInt()
            y = (screenHeight * 0.35f).toInt()
        }

        // 2. Terminal Window Params
        terminalParams = WindowManager.LayoutParams(
            (screenWidth * 0.90f).coerceAtMost(dpToPx(380).toFloat()).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            getOverlayType(),
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        // 3. Master Button 'A' Params
        triggerAParams = WindowManager.LayoutParams(
            dpToPx(72),
            dpToPx(72),
            getOverlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenWidth * 0.20f).toInt()
            y = (screenHeight * 0.65f).toInt()
        }
        MacroManager.updateTriggerPosition(
            triggerAParams.x + dpToPx(36).toFloat(),
            triggerAParams.y + dpToPx(36).toFloat()
        )

        // 4. Target Pointer 'a' Params
        targetAParams = WindowManager.LayoutParams(
            dpToPx(64),
            dpToPx(64),
            getOverlayType(),
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = (screenWidth * 0.65f).toInt()
            y = (screenHeight * 0.65f).toInt()
        }
        MacroManager.updateTargetPosition(
            targetAParams.x + dpToPx(32).toFloat(),
            targetAParams.y + dpToPx(32).toFloat()
        )

        buildMiniCrosshairView()
        buildTerminalView()
        buildTriggerAView()
        buildTargetAPointerView()

        // Initial view attachment
        safeAddView(miniCrosshairView, miniParams)
        safeAddView(triggerAView, triggerAParams)
        safeAddView(targetAPointerView, targetAParams)
    }

    // ==========================================
    // 1. Mini Crosshair Widget (Floating Icon)
    // ==========================================
    @SuppressLint("ClickableViewAccessibility")
    private fun buildMiniCrosshairView() {
        val view = object : View(this) {
            private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E60B0D0E")
                style = Paint.Style.FILL
            }
            private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#2D3135")
                style = Paint.Style.STROKE
                strokeWidth = dpToPx(1.5f).toFloat()
            }
            private val cyanPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#00E5FF")
                style = Paint.Style.STROKE
                strokeWidth = dpToPx(2).toFloat()
                strokeCap = Paint.Cap.ROUND
            }
            private val centerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#00E5FF")
                style = Paint.Style.FILL
            }

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val cx = width / 2f
                val cy = height / 2f
                val radius = (width.coerceAtMost(height) / 2f) - dpToPx(3)

                // Background & Outer Ring
                canvas.drawCircle(cx, cy, radius, bgPaint)
                canvas.drawCircle(cx, cy, radius, borderPaint)

                // Crosshair Reticles
                val reticleLen = dpToPx(7).toFloat()
                canvas.drawLine(cx, cy - radius, cx, cy - radius + reticleLen, cyanPaint)
                canvas.drawLine(cx, cy + radius, cx, cy + radius - reticleLen, cyanPaint)
                canvas.drawLine(cx - radius, cy, cx - radius + reticleLen, cy, cyanPaint)
                canvas.drawLine(cx + radius, cy, cx + radius - reticleLen, cy, cyanPaint)

                // Center Pinpoint
                canvas.drawCircle(cx, cy, dpToPx(3.5f).toFloat(), centerDotPaint)
            }
        }

        var startX = 0
        var startY = 0
        var touchDownX = 0f
        var touchDownY = 0f
        var isClick = true

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = miniParams.x
                    startY = miniParams.y
                    touchDownX = event.rawX
                    touchDownY = event.rawY
                    isClick = true
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchDownX).toInt()
                    val dy = (event.rawY - touchDownY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        isClick = false
                    }
                    miniParams.x = startX + dx
                    miniParams.y = startY + dy
                    safeUpdateView(miniCrosshairView, miniParams)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (isClick) {
                        // Open Macro Settings Terminal
                        openTerminal()
                    }
                    true
                }
                else -> false
            }
        }

        miniCrosshairView = view
    }

    // ==========================================
    // 2. Master Button 'A' (Capital A) Overlay
    // ==========================================
    @SuppressLint("ClickableViewAccessibility")
    private fun buildTriggerAView() {
        val view = object : FrameLayout(this) {
            private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.FILL
            }
            private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = dpToPx(2.5f).toFloat()
            }
            private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.WHITE
                textSize = dpToPx(24).toFloat()
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
            }

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val state = MacroManager.state.value
                val isActive = state.isClickingActive

                val cx = width / 2f
                val cy = height / 2f
                val radius = (width / 2f) - dpToPx(4)

                // Dynamic coloring based on active firing state
                if (isActive) {
                    bgPaint.color = Color.parseColor("#EE00E5FF")
                    ringPaint.color = Color.parseColor("#FFFFFFFF")
                    textPaint.color = Color.parseColor("#00363D")
                } else {
                    bgPaint.color = Color.parseColor("#DD0B0D0E")
                    ringPaint.color = Color.parseColor("#FF00E5FF")
                    textPaint.color = Color.parseColor("#FF00E5FF")
                }

                canvas.drawCircle(cx, cy, radius, bgPaint)
                canvas.drawCircle(cx, cy, radius, ringPaint)

                val textY = cy - ((textPaint.descent() + textPaint.ascent()) / 2)
                canvas.drawText("A", cx, textY, textPaint)
            }
        }
        view.setWillNotDraw(false)

        var startX = 0
        var startY = 0
        var touchDownX = 0f
        var touchDownY = 0f
        var isDragging = false
        var downTime = 0L

        view.setOnTouchListener { v, event ->
            val currentState = MacroManager.state.value
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = triggerAParams.x
                    startY = triggerAParams.y
                    touchDownX = event.rawX
                    touchDownY = event.rawY
                    downTime = System.currentTimeMillis()
                    isDragging = false

                    if (currentState.mode == MacroMode.HOLD_TO_REPEAT) {
                        MacroManager.setClickingActive(true)
                    }
                    v.invalidate()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchDownX).toInt()
                    val dy = (event.rawY - touchDownY).toInt()

                    // If dragged more than 15px, initiate repositioning
                    if (abs(dx) > 15 || abs(dy) > 15) {
                        isDragging = true
                        if (currentState.mode == MacroMode.HOLD_TO_REPEAT && currentState.isClickingActive) {
                            MacroManager.setClickingActive(false)
                        }
                        triggerAParams.x = startX + dx
                        triggerAParams.y = startY + dy
                        safeUpdateView(triggerAView, triggerAParams)

                        MacroManager.updateTriggerPosition(
                            triggerAParams.x + dpToPx(36).toFloat(),
                            triggerAParams.y + dpToPx(36).toFloat()
                        )
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (currentState.mode == MacroMode.HOLD_TO_REPEAT) {
                        MacroManager.setClickingActive(false)
                    } else if (currentState.mode == MacroMode.TAP_TO_REPEAT) {
                        if (!isDragging && (System.currentTimeMillis() - downTime < 400)) {
                            // Toggle rapid click state
                            MacroManager.setClickingActive(!currentState.isClickingActive)
                        }
                    }
                    v.invalidate()
                    true
                }
                else -> false
            }
        }

        triggerAView = view
    }

    // ==========================================
    // 3. Target Pointer 'a' (Small a) Overlay
    // ==========================================
    @SuppressLint("ClickableViewAccessibility")
    private fun buildTargetAPointerView() {
        val view = object : FrameLayout(this) {
            private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#990B0D0E")
                style = Paint.Style.FILL
            }
            private val reticlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#00E5FF")
                style = Paint.Style.STROKE
                strokeWidth = dpToPx(1.5f).toFloat()
            }
            private val centerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#00E5FF")
                style = Paint.Style.FILL
            }
            private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = Color.parseColor("#E2E2E2")
                textSize = dpToPx(16).toFloat()
                textAlign = Paint.Align.CENTER
                typeface = Typeface.create(Typeface.SERIF, Typeface.BOLD_ITALIC)
            }

            override fun onDraw(canvas: Canvas) {
                super.onDraw(canvas)
                val state = MacroManager.state.value
                val cx = width / 2f
                val cy = height / 2f
                val radius = (width / 2f) - dpToPx(4)

                // Background Disc
                canvas.drawCircle(cx, cy, radius, bgPaint)

                // Reticle Ring
                if (state.isClickingActive) {
                    reticlePaint.color = Color.parseColor("#FFFFFFFF")
                    reticlePaint.strokeWidth = dpToPx(2.5f).toFloat()
                } else {
                    reticlePaint.color = Color.parseColor("#FF00E5FF")
                    reticlePaint.strokeWidth = dpToPx(1.5f).toFloat()
                }
                canvas.drawCircle(cx, cy, radius, reticlePaint)
                canvas.drawCircle(cx, cy, radius * 0.5f, reticlePaint)

                // Crosshair lines
                canvas.drawLine(cx, 0f, cx, height.toFloat(), reticlePaint)
                canvas.drawLine(0f, cy, width.toFloat(), cy, reticlePaint)

                // Center Pinpoint
                canvas.drawCircle(cx, cy, dpToPx(3).toFloat(), centerDotPaint)

                // Label 'a'
                val textY = cy - ((textPaint.descent() + textPaint.ascent()) / 2)
                canvas.drawText("a", cx + dpToPx(12), textY - dpToPx(8), textPaint)
            }
        }
        view.setWillNotDraw(false)

        var startX = 0
        var startY = 0
        var touchDownX = 0f
        var touchDownY = 0f

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = targetAParams.x
                    startY = targetAParams.y
                    touchDownX = event.rawX
                    touchDownY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchDownX).toInt()
                    val dy = (event.rawY - touchDownY).toInt()
                    targetAParams.x = startX + dx
                    targetAParams.y = startY + dy
                    safeUpdateView(targetAPointerView, targetAParams)

                    // Target coordinate is the exact center of pointer 'a'
                    val centerX = targetAParams.x + dpToPx(32).toFloat()
                    val centerY = targetAParams.y + dpToPx(32).toFloat()
                    MacroManager.updateTargetPosition(centerX, centerY)
                    true
                }
                else -> true
            }
        }

        targetAPointerView = view
    }

    // ==========================================
    // 4. Expanded Macro Settings Terminal Window
    // ==========================================
    @SuppressLint("SetTextI18n")
    private fun buildTerminalView() {
        val rootLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#F50B0D0E"))
            setPadding(dpToPx(16), dpToPx(14), dpToPx(16), dpToPx(16))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        // Header Row: Title + Close Button 'X'
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val titleTv = TextView(this).apply {
            text = "MACRO TERMINAL HUD"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 14f
            isAllCaps = true
            paint.isFakeBoldText = true
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val closeBtn = Button(this).apply {
            text = "✕"
            setTextColor(Color.parseColor("#E2E2E2"))
            setBackgroundColor(Color.parseColor("#2D3135"))
            textSize = 14f
            setPadding(dpToPx(10), dpToPx(2), dpToPx(10), dpToPx(2))
            layoutParams = LinearLayout.LayoutParams(dpToPx(38), dpToPx(38)).apply {
                marginStart = dpToPx(6)
            }
            setOnClickListener {
                closeTerminal()
            }
        }

        val exitBtn = Button(this).apply {
            text = "OFF"
            setTextColor(Color.parseColor("#FF2A55"))
            setBackgroundColor(Color.parseColor("#16181A"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(dpToPx(44), dpToPx(38)).apply {
                marginStart = dpToPx(6)
            }
            setOnClickListener {
                stopSelf()
            }
        }

        headerRow.addView(titleTv)
        headerRow.addView(exitBtn)
        headerRow.addView(closeBtn)
        rootLayout.addView(headerRow)

        // Mode Selector: "Hold to Repeat" vs "Tap to Repeat"
        val modeLabel = TextView(this).apply {
            text = "TRIGGER MODE:"
            setTextColor(Color.parseColor("#909499"))
            textSize = 12f
            setPadding(0, dpToPx(10), 0, dpToPx(4))
        }
        rootLayout.addView(modeLabel)

        val modeBtnRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val holdBtn = Button(this).apply {
            text = "Hold to Repeat"
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(40), 1f).apply {
                marginEnd = dpToPx(4)
            }
        }

        val tapBtn = Button(this).apply {
            text = "Tap to Repeat"
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, dpToPx(40), 1f).apply {
                marginStart = dpToPx(4)
            }
        }

        fun updateModeButtons(mode: MacroMode) {
            if (mode == MacroMode.HOLD_TO_REPEAT) {
                holdBtn.setBackgroundColor(Color.parseColor("#00E5FF"))
                holdBtn.setTextColor(Color.parseColor("#00363D"))
                tapBtn.setBackgroundColor(Color.parseColor("#16181A"))
                tapBtn.setTextColor(Color.parseColor("#909499"))
            } else {
                holdBtn.setBackgroundColor(Color.parseColor("#16181A"))
                holdBtn.setTextColor(Color.parseColor("#909499"))
                tapBtn.setBackgroundColor(Color.parseColor("#00E5FF"))
                tapBtn.setTextColor(Color.parseColor("#00363D"))
            }
        }

        holdBtn.setOnClickListener {
            MacroManager.updateMode(MacroMode.HOLD_TO_REPEAT)
            updateModeButtons(MacroMode.HOLD_TO_REPEAT)
        }

        tapBtn.setOnClickListener {
            MacroManager.updateMode(MacroMode.TAP_TO_REPEAT)
            updateModeButtons(MacroMode.TAP_TO_REPEAT)
        }

        updateModeButtons(MacroManager.state.value.mode)
        modeBtnRow.addView(holdBtn)
        modeBtnRow.addView(tapBtn)
        rootLayout.addView(modeBtnRow)

        // Speed Slider Section
        val speedTv = TextView(this).apply {
            val ms = MacroManager.state.value.intervalMs
            val cps = (1000f / ms).roundToInt()
            text = "TAP SPEED: ${ms}ms ($cps CPS / ${cps}X)"
            setTextColor(Color.parseColor("#00E5FF"))
            textSize = 12f
            setPadding(0, dpToPx(12), 0, dpToPx(2))
        }
        rootLayout.addView(speedTv)

        val speedSeekBar = SeekBar(this).apply {
            max = 190 // 10ms to 200ms
            progress = MacroManager.state.value.intervalMs - 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val ms = progress + 10
                    val cps = (1000f / ms).roundToInt()
                    speedTv.text = "TAP SPEED: ${ms}ms ($cps CPS / ${cps}X)"
                    if (fromUser) {
                        MacroManager.updateInterval(ms)
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        rootLayout.addView(speedSeekBar)

        // Transparency / Visibility Slider
        val alphaTv = TextView(this).apply {
            val alphaPercent = (MacroManager.state.value.overlayAlpha * 100).toInt()
            text = "OVERLAY VISIBILITY: $alphaPercent%"
            setTextColor(Color.parseColor("#E2E2E2"))
            textSize = 12f
            setPadding(0, dpToPx(8), 0, dpToPx(2))
        }
        rootLayout.addView(alphaTv)

        val alphaSeekBar = SeekBar(this).apply {
            max = 90 // 10% to 100%
            progress = ((MacroManager.state.value.overlayAlpha * 100) - 10).toInt().coerceIn(0, 90)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val alpha = (progress + 10) / 100f
                    alphaTv.text = "OVERLAY VISIBILITY: ${(alpha * 100).toInt()}%"
                    if (fromUser) {
                        MacroManager.updateAlpha(alpha)
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        rootLayout.addView(alphaSeekBar)

        // Toggles Row: Master 'A' & Target 'a'
        val togglesRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, dpToPx(8), 0, dpToPx(4))
        }

        val toggleASwitch = Switch(this).apply {
            text = "Button 'A'"
            setTextColor(Color.parseColor("#E2E2E2"))
            isChecked = MacroManager.state.value.isTriggerAVisible
            setOnCheckedChangeListener { _, isChecked ->
                MacroManager.setTriggerAVisible(isChecked)
            }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val toggleaSwitch = Switch(this).apply {
            text = "Pointer 'a'"
            setTextColor(Color.parseColor("#E2E2E2"))
            isChecked = MacroManager.state.value.isPointeraVisible
            setOnCheckedChangeListener { _, isChecked ->
                MacroManager.setPointeraVisible(isChecked)
            }
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        togglesRow.addView(toggleASwitch)
        togglesRow.addView(toggleaSwitch)
        rootLayout.addView(togglesRow)

        // Coordinate Monitor
        val coordsTv = TextView(this).apply {
            val state = MacroManager.state.value
            text = "Target 'a': (${state.targetX.toInt()}, ${state.targetY.toInt()}) | Trigger 'A': (${state.triggerX.toInt()}, ${state.triggerY.toInt()})"
            setTextColor(Color.parseColor("#909499"))
            textSize = 10f
            setPadding(0, dpToPx(4), 0, 0)
        }
        rootLayout.addView(coordsTv)

        terminalWindowView = rootLayout
    }

    private fun openTerminal() {
        MacroManager.setTerminalExpanded(true)
        safeRemoveView(miniCrosshairView)
        safeAddView(terminalWindowView, terminalParams)
    }

    private fun closeTerminal() {
        MacroManager.setTerminalExpanded(false)
        safeRemoveView(terminalWindowView)
        safeAddView(miniCrosshairView, miniParams)
    }

    private fun setupStateObservers() {
        serviceScope.launch {
            MacroManager.state.collectLatest { state ->
                // Update Alpha
                triggerAView?.alpha = state.overlayAlpha
                targetAPointerView?.alpha = state.overlayAlpha

                // Update Visibility
                triggerAView?.visibility = if (state.isTriggerAVisible) View.VISIBLE else View.GONE
                targetAPointerView?.visibility = if (state.isPointeraVisible) View.VISIBLE else View.GONE

                // Trigger re-draws for active color states
                triggerAView?.invalidate()
                targetAPointerView?.invalidate()
            }
        }
    }

    private fun safeAddView(view: View?, params: WindowManager.LayoutParams) {
        if (view == null) return
        try {
            if (view.parent == null) {
                windowManager.addView(view, params)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error adding view to WindowManager: ${e.message}", e)
        }
    }

    private fun safeUpdateView(view: View?, params: WindowManager.LayoutParams) {
        if (view == null) return
        try {
            if (view.parent != null) {
                windowManager.updateViewLayout(view, params)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error updating view in WindowManager: ${e.message}", e)
        }
    }

    private fun safeRemoveView(view: View?) {
        if (view == null) return
        try {
            if (view.parent != null) {
                windowManager.removeView(view)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing view from WindowManager: ${e.message}", e)
        }
    }

    private fun removeAllOverlays() {
        safeRemoveView(miniCrosshairView)
        safeRemoveView(terminalWindowView)
        safeRemoveView(triggerAView)
        safeRemoveView(targetAPointerView)
    }
}
