package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("ZeroKey", appName)
  }

  @Test
  fun `clipboard protector operations`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val protector = ClipboardProtector(context)

    protector.captureSensitiveCopy("PIN", "1234", 30_000L)
    assertTrue("Purge should be pending after sensitive copy", protector.isWipeActive())

    protector.executePurge()
    assertEquals(false, protector.isWipeActive())
    protector.destroy()
  }
}
