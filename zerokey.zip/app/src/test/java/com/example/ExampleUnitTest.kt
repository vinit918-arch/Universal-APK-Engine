package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class KeyScramblerTest {

    private val scrambler = KeyScrambler()

    @Test
    fun getScrambledDigits_containsAllDigitsExactlyOnce() {
        val scrambled = scrambler.getScrambledDigits()
        assertEquals("Should contain exactly 10 digits", 10, scrambled.size)

        val set = scrambled.toSet()
        assertEquals("Should contain 10 distinct digits", 10, set.size)
        for (i in 0..9) {
            assertTrue("Must contain digit $i", set.contains(i))
        }
    }

    @Test
    fun getScrambledDigits_producesVaryingPermutations() {
        // Run multiple iterations: at least some permutations should differ from default [0..9]
        var differentFromOriginal = false
        val original = intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)

        for (i in 0 until 20) {
            val scrambled = scrambler.getScrambledDigits()
            if (!scrambled.contentEquals(original)) {
                differentFromOriginal = true
                break
            }
        }
        assertTrue("Fisher-Yates shuffle must randomize digit order", differentFromOriginal)
    }

    @Test
    fun shuffle_preservesElements() {
        val array = intArrayOf(5, 4, 3, 2, 1)
        scrambler.shuffle(array)
        assertEquals(5, array.size)
        assertTrue(array.contains(1))
        assertTrue(array.contains(2))
        assertTrue(array.contains(3))
        assertTrue(array.contains(4))
        assertTrue(array.contains(5))
    }
}
