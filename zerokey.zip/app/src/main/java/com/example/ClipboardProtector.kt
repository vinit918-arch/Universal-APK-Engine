package com.example

import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PersistableBundle
import android.util.Log

/**
 * ClipboardProtector: Safeguards sensitive credentials, tokens, and passwords from clipboard snooping.
 *
 * Captures sensitive copy operations, tags them as sensitive for the Android 13+ UI concealing system,
 * and automatically executes an irreversible clipboard wipe after a strict 30-second timeout window.
 *
 * Implements strict memory-leak prevention via application-context scoping and lifecycle-safe
 * handler detachment.
 */
class ClipboardProtector(context: Context) {

    companion object {
        private const val TAG = "ClipboardProtector"
        const val DEFAULT_TIMEOUT_MILLIS: Long = 30_000L // 30 seconds
    }

    // Retain only the application context to completely prevent Activity/Service retention leaks
    private val appContext: Context = context.applicationContext
    private val clipboardManager: ClipboardManager? =
        appContext.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var isWipePending = false
    private var pendingWipeTimestamp: Long = 0L

    var onClipboardWipedListener: (() -> Unit)? = null
    var onWipeScheduledListener: ((timeoutMillis: Long) -> Unit)? = null

    private val wipeRunnable = Runnable {
        executePurge()
    }

    /**
     * Copies sensitive text into the system clipboard, marks it as sensitive (concealed on API 33+),
     * and arms a 30-second automatic purge timer.
     *
     * @param label A non-sensitive descriptive label (e.g. "PIN", "Password")
     * @param sensitiveText The sensitive string to copy
     * @param timeoutMillis Duration in milliseconds before wiping (defaults to 30,000ms / 30s)
     * @return true if successfully copied, false otherwise
     */
    fun captureSensitiveCopy(
        label: CharSequence = "Sensitive Data",
        sensitiveText: CharSequence,
        timeoutMillis: Long = DEFAULT_TIMEOUT_MILLIS
    ): Boolean {
        val cm = clipboardManager ?: run {
            Log.e(TAG, "ClipboardManager is not available on this device.")
            return false
        }

        return try {
            val clipData = ClipData.newPlainText(label, sensitiveText)

            // On Android 13 (API 33)+, flag the clip as sensitive to conceal clipboard UI popups
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val bundle = PersistableBundle().apply {
                    putBoolean(ClipDescription.EXTRA_IS_SENSITIVE, true)
                }
                clipData.description.extras = bundle
            }

            cm.setPrimaryClip(clipData)
            scheduleClipboardWipe(timeoutMillis)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to copy sensitive content securely: ${e.message}", e)
            false
        }
    }

    /**
     * Schedules a deferred purge of the primary clipboard after [timeoutMillis].
     * Any existing pending wipe timer is reset.
     */
    fun scheduleClipboardWipe(timeoutMillis: Long = DEFAULT_TIMEOUT_MILLIS) {
        cancelPendingWipe()

        isWipePending = true
        pendingWipeTimestamp = System.currentTimeMillis() + timeoutMillis

        mainHandler.postDelayed(wipeRunnable, timeoutMillis)
        onWipeScheduledListener?.invoke(timeoutMillis)
        Log.d(TAG, "Sensitive clipboard purge scheduled in ${timeoutMillis / 1000}s.")
    }

    /**
     * Executes the actual purge of the primary clipboard by clearing or setting empty data.
     */
    fun executePurge() {
        isWipePending = false
        pendingWipeTimestamp = 0L
        mainHandler.removeCallbacks(wipeRunnable)

        val cm = clipboardManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                // API 28+ native clipboard clear API
                cm.clearPrimaryClip()
            } else {
                // Fallback: overwrite with an empty, non-sensitive clip
                val emptyClip = ClipData.newPlainText("", "")
                cm.setPrimaryClip(emptyClip)
            }
            Log.i(TAG, "Primary clipboard successfully purged.")
            onClipboardWipedListener?.invoke()
        } catch (e: Exception) {
            Log.e(TAG, "Error executing clipboard purge: ${e.message}", e)
            // Fallback attempt
            try {
                cm.setPrimaryClip(ClipData.newPlainText("", ""))
            } catch (ignored: Exception) {
            }
        }
    }

    /**
     * Cancels any pending scheduled clipboard wipe timer.
     */
    fun cancelPendingWipe() {
        if (isWipePending) {
            mainHandler.removeCallbacks(wipeRunnable)
            isWipePending = false
            pendingWipeTimestamp = 0L
        }
    }

    /**
     * Returns true if an auto-wipe countdown is currently active.
     */
    fun isWipeActive(): Boolean = isWipePending

    /**
     * Returns the remaining time in milliseconds before the clipboard is automatically purged,
     * or 0 if no wipe is pending.
     */
    fun getRemainingTimeMillis(): Long {
        if (!isWipePending) return 0L
        val remaining = pendingWipeTimestamp - System.currentTimeMillis()
        return if (remaining > 0) remaining else 0L
    }

    /**
     * Detaches all handler callbacks and listeners to completely eliminate memory leaks.
     * Must be called in IME onDestroy() or hosting lifecycle teardown.
     */
    fun destroy() {
        cancelPendingWipe()
        onClipboardWipedListener = null
        onWipeScheduledListener = null
    }
}
