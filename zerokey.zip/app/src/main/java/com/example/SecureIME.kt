package com.example

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.content.res.ColorStateList
import android.inputmethodservice.InputMethodService
import android.os.Build
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.view.inputmethod.InputMethodManager
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * SecureIME: Production-grade, zero-permission Android Input Method Editor.
 *
 * Security Core:
 * - Operates STRICTLY without android.permission.INTERNET (guaranteed zero network exfiltration).
 * - Enforces IME_FLAG_NO_PERSONALIZED_LEARNING on all input fields to block OS/vendor keylogging.
 * - Detects password/PIN input types and renders a dynamically scrambled numeric keypad via [KeyScrambler]
 *   utilizing the Fisher-Yates Shuffle algorithm to thwart shoulder-surfing and touch coordinate loggers.
 * - Integrates [ClipboardProtector] with an automatic 30-second clipboard wipe timer.
 * - Safely handles InputConnection lifecycles with zero memory leaks.
 */
class SecureIME : InputMethodService() {

    enum class KeyboardLayoutMode {
        QWERTY,
        SCRAMBLED_PIN,
        SYMBOLS
    }

    private lateinit var keyScrambler: KeyScrambler
    private lateinit var clipboardProtector: ClipboardProtector

    // UI Root and Sub-containers
    private var rootLayout: LinearLayout? = null
    private var securityHeaderLayout: LinearLayout? = null
    private var keyboardContainer: FrameLayout? = null

    // Layout views
    private var qwertyView: View? = null
    private var scrambledPinView: View? = null
    private var symbolsView: View? = null

    // UI State
    private var currentMode: KeyboardLayoutMode = KeyboardLayoutMode.QWERTY
    private var isShifted: Boolean = false
    private var isCapsLock: Boolean = false
    private var lastShiftPressTime: Long = 0L

    // Security Status UI elements
    private var statusBadgeTextView: TextView? = null
    private var modeIndicatorTextView: TextView? = null

    // Cached EditorInfo
    private var activeEditorInfo: EditorInfo? = null

    override fun onCreate() {
        super.onCreate()
        keyScrambler = KeyScrambler()
        clipboardProtector = ClipboardProtector(this)
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setBackgroundColor(COLOR_KEYBOARD_BG)
        }
        rootLayout = root

        // 1. Build Top Security Header Toolbar
        val header = createSecurityHeader()
        securityHeaderLayout = header
        root.addView(header)

        // 2. Build Container for Dynamic Keypads
        val container = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        keyboardContainer = container
        root.addView(container)

        // Initialize and bind initial layout
        updateKeyboardLayout()

        return root
    }

    override fun onStartInputView(info: EditorInfo, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        activeEditorInfo = info

        // 1. CRITICAL: Automatically force IME_FLAG_NO_PERSONALIZED_LEARNING to block OS/dictionary logging
        info.imeOptions = info.imeOptions or EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING

        // 2. Inspect inputType for sensitive flags
        val variation = info.inputType and InputType.TYPE_MASK_VARIATION
        val inputClass = info.inputType and InputType.TYPE_MASK_CLASS

        val isPasswordVariation = variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD ||
                variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD

        val isNumericClass = inputClass == InputType.TYPE_CLASS_NUMBER ||
                inputClass == InputType.TYPE_CLASS_PHONE

        // 3. Dynamically switch layout: Render Scrambled PIN for passwords & numeric fields, otherwise QWERTY
        currentMode = if (isPasswordVariation || isNumericClass) {
            KeyboardLayoutMode.SCRAMBLED_PIN
        } else {
            KeyboardLayoutMode.QWERTY
        }

        // Reset transient states
        isShifted = false
        isCapsLock = false

        updateKeyboardLayout()
        updateHeaderStatus()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        // Reset sensitive states on view finish
        if (finishingInput) {
            isShifted = false
            isCapsLock = false
            activeEditorInfo = null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        // Release background handlers and prevent memory leaks
        clipboardProtector.destroy()
        rootLayout = null
        securityHeaderLayout = null
        keyboardContainer = null
        qwertyView = null
        scrambledPinView = null
        symbolsView = null
    }

    /**
     * Updates and mounts the appropriate keypad view inside the container based on [currentMode].
     */
    private fun updateKeyboardLayout() {
        val container = keyboardContainer ?: return
        container.removeAllViews()

        val keypadView = when (currentMode) {
            KeyboardLayoutMode.SCRAMBLED_PIN -> {
                // Generates freshly shuffled digits on EVERY draw
                createScrambledPinKeypad()
            }
            KeyboardLayoutMode.QWERTY -> {
                createQwertyKeypad()
            }
            KeyboardLayoutMode.SYMBOLS -> {
                createSymbolsKeypad()
            }
        }

        container.addView(keypadView)
        updateHeaderStatus()
    }

    /**
     * Constructs the top security status and quick-action toolbar.
     */
    private fun createSecurityHeader(): LinearLayout {
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(42)
            )
            setBackgroundColor(COLOR_HEADER_BG)
            setPadding(dpToPx(8), 0, dpToPx(8), 0)
        }

        // ZeroKey Shield Badge
        val shieldBadge = TextView(this).apply {
            text = "🛡️ ZeroKey"
            setTextColor(COLOR_ACCENT_GREEN)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dpToPx(6), dpToPx(3), dpToPx(6), dpToPx(3))
            background = createBadgeDrawable(COLOR_BADGE_BG, COLOR_ACCENT_GREEN)
        }
        header.addView(shieldBadge)

        // Mode Status Tag (NO-LEARN)
        val modeTag = TextView(this).apply {
            text = "NO-LOGGING"
            setTextColor(COLOR_TEXT_SECONDARY)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = dpToPx(6)
            }
            layoutParams = lp
            setPadding(dpToPx(5), dpToPx(2), dpToPx(5), dpToPx(2))
            background = createBadgeDrawable(COLOR_KEY_BG, COLOR_TEXT_SECONDARY)
        }
        modeIndicatorTextView = modeTag
        header.addView(modeTag)

        // Spacer Scrollable Actions container
        val actionScroll = HorizontalScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.MATCH_PARENT,
                1.0f
            )
            isHorizontalScrollBarEnabled = false
        }

        val actionsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setPadding(dpToPx(6), 0, 0, 0)
        }

        // Action: Re-Scramble PIN
        val reshuffleBtn = createHeaderButton("🎲 Scramble") {
            performKeyHaptic()
            if (currentMode == KeyboardLayoutMode.SCRAMBLED_PIN) {
                updateKeyboardLayout()
                Toast.makeText(this, "PIN Keypad Re-Scrambled (Fisher-Yates)", Toast.LENGTH_SHORT).show()
            } else {
                currentMode = KeyboardLayoutMode.SCRAMBLED_PIN
                updateKeyboardLayout()
            }
        }
        actionsLayout.addView(reshuffleBtn)

        // Action: Clipboard Purge (Protected)
        val clipPurgeBtn = createHeaderButton("🧹 Purge Clip") {
            performKeyHaptic()
            clipboardProtector.executePurge()
            Toast.makeText(this, "Clipboard Sanitized (Zeroed)", Toast.LENGTH_SHORT).show()
        }
        actionsLayout.addView(clipPurgeBtn)

        // Action: Switch IME
        val switchImeBtn = createHeaderButton("⌨️ Switch") {
            performKeyHaptic()
            val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
            imm?.showInputMethodPicker()
        }
        actionsLayout.addView(switchImeBtn)

        // Action: Hide Keyboard
        val hideBtn = createHeaderButton("▼") {
            performKeyHaptic()
            requestHideSelf(0)
        }
        actionsLayout.addView(hideBtn)

        actionScroll.addView(actionsLayout)
        header.addView(actionScroll)

        return header
    }

    private fun updateHeaderStatus() {
        modeIndicatorTextView?.text = when (currentMode) {
            KeyboardLayoutMode.SCRAMBLED_PIN -> "SCRAMBLED PIN • NO-LOG"
            KeyboardLayoutMode.QWERTY -> "ISOLATED • NO-LOG"
            KeyboardLayoutMode.SYMBOLS -> "SYMBOLS • NO-LOG"
        }
    }

    /**
     * Builds the Scrambled Numeric Keypad.
     * Uses [KeyScrambler.getScrambledDigits] to shuffle 0-9 via Fisher-Yates on EVERY draw.
     */
    private fun createScrambledPinKeypad(): View {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(dpToPx(8), dpToPx(8), dpToPx(8), dpToPx(12))
            setBackgroundColor(COLOR_KEYBOARD_BG)
        }

        // Shuffle 0..9 using cryptographically secure Fisher-Yates
        val scrambled = keyScrambler.getScrambledDigits()

        // Security Subhead within keypad
        val subhead = TextView(this).apply {
            text = "🔒 ANTI-SURF KEYPAD • FISHER-YATES SHUFFLED"
            setTextColor(COLOR_ACCENT_GREEN)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, dpToPx(2), 0, dpToPx(6))
        }
        layout.addView(subhead)

        // 4 Rows Grid for 10 digits + backspace + switch + enter
        // Row 1: scrambled[0], scrambled[1], scrambled[2]
        val row1 = createPinRow(listOf(scrambled[0].toString(), scrambled[1].toString(), scrambled[2].toString()))
        layout.addView(row1)

        // Row 2: scrambled[3], scrambled[4], scrambled[5]
        val row2 = createPinRow(listOf(scrambled[3].toString(), scrambled[4].toString(), scrambled[5].toString()))
        layout.addView(row2)

        // Row 3: scrambled[6], scrambled[7], scrambled[8]
        val row3 = createPinRow(listOf(scrambled[6].toString(), scrambled[7].toString(), scrambled[8].toString()))
        layout.addView(row3)

        // Row 4: Switch to ABC, scrambled[9], Backspace
        val row4 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(54)
            ).apply { topMargin = dpToPx(6) }
        }

        // ABC Key
        val abcKey = createKeyButton("ABC", isSpecial = true, flexWeight = 1.0f) {
            currentMode = KeyboardLayoutMode.QWERTY
            updateKeyboardLayout()
        }
        row4.addView(abcKey)

        // 10th Scrambled Digit
        val digitKey = createPinKeyButton(scrambled[9].toString(), flexWeight = 1.0f) {
            handleCommitText(scrambled[9].toString())
        }
        row4.addView(digitKey)

        // Backspace Key
        val delKey = createKeyButton("⌫", isSpecial = true, flexWeight = 1.0f) {
            handleBackspace()
        }
        row4.addView(delKey)

        layout.addView(row4)

        // Bottom Action Bar: Reshuffle & Enter
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(48)
            ).apply { topMargin = dpToPx(6) }
        }

        val reshuffleCard = createKeyButton("🎲 Reshuffle Digits", isSpecial = true, flexWeight = 1.0f) {
            updateKeyboardLayout()
            Toast.makeText(this, "Keypad Positions Randomized", Toast.LENGTH_SHORT).show()
        }
        bottomBar.addView(reshuffleCard)

        val enterKey = createKeyButton("✓ DONE", isAccent = true, flexWeight = 1.0f) {
            handleActionOrEnter()
        }
        bottomBar.addView(enterKey)

        layout.addView(bottomBar)

        return layout
    }

    private fun createPinRow(digits: List<String>): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpToPx(54)
            ).apply { topMargin = dpToPx(6) }
        }

        for (digit in digits) {
            val btn = createPinKeyButton(digit, flexWeight = 1.0f) {
                handleCommitText(digit)
            }
            row.addView(btn)
        }
        return row
    }

    /**
     * Builds standard QWERTY keypad.
     */
    private fun createQwertyKeypad(): View {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(dpToPx(4), dpToPx(6), dpToPx(4), dpToPx(10))
            setBackgroundColor(COLOR_KEYBOARD_BG)
        }

        // QWERTY Rows
        val row1Letters = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
        val row2Letters = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
        val row3Letters = listOf("z", "x", "c", "v", "b", "n", "m")

        // Row 1
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(48))
        }
        for (char in row1Letters) {
            val key = createCharKey(char)
            row1.addView(key)
        }
        layout.addView(row1)

        // Row 2 (padded with side margins for keyboard ergonomics)
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(48)).apply {
                topMargin = dpToPx(5)
            }
            setPadding(dpToPx(16), 0, dpToPx(16), 0)
        }
        for (char in row2Letters) {
            val key = createCharKey(char)
            row2.addView(key)
        }
        layout.addView(row2)

        // Row 3: Shift, letters, Backspace
        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(48)).apply {
                topMargin = dpToPx(5)
            }
        }

        // Shift button
        val shiftIndicator = if (isCapsLock) "⇪" else if (isShifted) "⬆" else "⇧"
        val shiftKey = createKeyButton(
            label = shiftIndicator,
            isSpecial = true,
            isAccent = isShifted || isCapsLock,
            flexWeight = 1.4f
        ) {
            handleShiftPress()
        }
        row3.addView(shiftKey)

        for (char in row3Letters) {
            val key = createCharKey(char)
            row3.addView(key)
        }

        // Backspace button
        val delKey = createKeyButton(
            label = "⌫",
            isSpecial = true,
            flexWeight = 1.4f
        ) {
            handleBackspace()
        }
        row3.addView(delKey)

        layout.addView(row3)

        // Row 4: Mode switch (?123), PIN mode, Space, Period, Enter
        val row4 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(48)).apply {
                topMargin = dpToPx(5)
            }
        }

        val symKey = createKeyButton("?123", isSpecial = true, flexWeight = 1.3f) {
            currentMode = KeyboardLayoutMode.SYMBOLS
            updateKeyboardLayout()
        }
        row4.addView(symKey)

        val pinSwitchKey = createKeyButton("PIN 🔒", isSpecial = true, flexWeight = 1.3f) {
            currentMode = KeyboardLayoutMode.SCRAMBLED_PIN
            updateKeyboardLayout()
        }
        row4.addView(pinSwitchKey)

        val commaKey = createKeyButton(",", flexWeight = 0.9f) {
            handleCommitText(",")
        }
        row4.addView(commaKey)

        // Spacebar
        val spaceKey = createKeyButton("Space", flexWeight = 3.6f) {
            handleCommitText(" ")
        }
        row4.addView(spaceKey)

        val dotKey = createKeyButton(".", flexWeight = 0.9f) {
            handleCommitText(".")
        }
        row4.addView(dotKey)

        // Enter / Action
        val actionLabel = getActionLabel()
        val enterKey = createKeyButton(actionLabel, isAccent = true, flexWeight = 1.6f) {
            handleActionOrEnter()
        }
        row4.addView(enterKey)

        layout.addView(row4)

        return layout
    }

    /**
     * Builds symbols and numbers keypad.
     */
    private fun createSymbolsKeypad(): View {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            setPadding(dpToPx(4), dpToPx(6), dpToPx(4), dpToPx(10))
            setBackgroundColor(COLOR_KEYBOARD_BG)
        }

        val row1Symbols = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
        val row2Symbols = listOf("@", "#", "$", "%", "&", "-", "+", "(", ")", "/")
        val row3Symbols = listOf("*", "\"", "'", ":", ";", "!", "?")

        // Row 1
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(48))
        }
        for (s in row1Symbols) {
            val key = createKeyButton(s, flexWeight = 1.0f) { handleCommitText(s) }
            row1.addView(key)
        }
        layout.addView(row1)

        // Row 2
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(48)).apply {
                topMargin = dpToPx(5)
            }
        }
        for (s in row2Symbols) {
            val key = createKeyButton(s, flexWeight = 1.0f) { handleCommitText(s) }
            row2.addView(key)
        }
        layout.addView(row2)

        // Row 3
        val row3 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(48)).apply {
                topMargin = dpToPx(5)
            }
        }
        val pinKey = createKeyButton("PIN 🔒", isSpecial = true, flexWeight = 1.3f) {
            currentMode = KeyboardLayoutMode.SCRAMBLED_PIN
            updateKeyboardLayout()
        }
        row3.addView(pinKey)

        for (s in row3Symbols) {
            val key = createKeyButton(s, flexWeight = 1.0f) { handleCommitText(s) }
            row3.addView(key)
        }

        val delKey = createKeyButton("⌫", isSpecial = true, flexWeight = 1.3f) {
            handleBackspace()
        }
        row3.addView(delKey)

        layout.addView(row3)

        // Row 4
        val row4 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(48)).apply {
                topMargin = dpToPx(5)
            }
        }

        val abcKey = createKeyButton("ABC", isSpecial = true, flexWeight = 1.5f) {
            currentMode = KeyboardLayoutMode.QWERTY
            updateKeyboardLayout()
        }
        row4.addView(abcKey)

        val spaceKey = createKeyButton("Space", flexWeight = 4.0f) {
            handleCommitText(" ")
        }
        row4.addView(spaceKey)

        val enterKey = createKeyButton(getActionLabel(), isAccent = true, flexWeight = 1.6f) {
            handleActionOrEnter()
        }
        row4.addView(enterKey)

        layout.addView(row4)

        return layout
    }

    private fun createCharKey(char: String): View {
        val displayChar = if (isShifted || isCapsLock) char.uppercase() else char.lowercase()
        return createKeyButton(displayChar, flexWeight = 1.0f) {
            handleCommitText(displayChar)
            if (isShifted && !isCapsLock) {
                isShifted = false
                updateKeyboardLayout()
            }
        }
    }

    private fun handleShiftPress() {
        val now = System.currentTimeMillis()
        if (now - lastShiftPressTime < 350L) {
            // Double tap = Caps Lock toggle
            isCapsLock = !isCapsLock
            isShifted = isCapsLock
        } else {
            // Single tap = Shift toggle
            if (isCapsLock) {
                isCapsLock = false
                isShifted = false
            } else {
                isShifted = !isShifted
            }
        }
        lastShiftPressTime = now
        updateKeyboardLayout()
    }

    private fun handleCommitText(text: String) {
        performKeyHaptic()
        val ic = currentInputConnection ?: return
        try {
            ic.commitText(text, 1)
        } catch (e: Exception) {
            // Guard against remote process termination
        }
    }

    private fun handleBackspace() {
        performKeyHaptic()
        val ic = currentInputConnection ?: return
        try {
            val selected = ic.getSelectedText(0)
            if (!selected.isNullOrEmpty()) {
                ic.commitText("", 1)
            } else {
                // Delete one character before cursor
                val deleted = ic.deleteSurroundingText(1, 0)
                if (!deleted) {
                    // Fallback to key event for non-standard fields
                    sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
                }
            }
        } catch (e: Exception) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        }
    }

    private fun handleActionOrEnter() {
        performKeyHaptic()
        val ic = currentInputConnection ?: return
        val info = activeEditorInfo
        val action = if (info != null) (info.imeOptions and EditorInfo.IME_MASK_ACTION) else EditorInfo.IME_ACTION_NONE

        try {
            if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) {
                ic.performEditorAction(action)
            } else {
                sendKeyChar('\n')
            }
        } catch (e: Exception) {
            sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
        }
    }

    private fun getActionLabel(): String {
        val info = activeEditorInfo ?: return "↵"
        return when (info.imeOptions and EditorInfo.IME_MASK_ACTION) {
            EditorInfo.IME_ACTION_GO -> "GO"
            EditorInfo.IME_ACTION_SEARCH -> "🔍"
            EditorInfo.IME_ACTION_SEND -> "SEND"
            EditorInfo.IME_ACTION_NEXT -> "NEXT"
            EditorInfo.IME_ACTION_DONE -> "DONE"
            else -> "↵"
        }
    }

    private fun performKeyHaptic() {
        try {
            rootLayout?.performHapticFeedback(
                HapticFeedbackConstants.KEYBOARD_TAP,
                HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
            )
        } catch (ignored: Exception) {
        }
    }

    // --- UI Helper Component Builders ---

    private fun createKeyButton(
        label: String,
        isSpecial: Boolean = false,
        isAccent: Boolean = false,
        flexWeight: Float = 1.0f,
        onClick: () -> Unit
    ): View {
        val button = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (label.length > 2) 13f else 17f)
            typeface = if (isAccent || isSpecial) Typeface.DEFAULT_BOLD else Typeface.DEFAULT

            val textColor = when {
                isAccent -> COLOR_ACCENT_TEXT
                isSpecial -> COLOR_TEXT_PRIMARY
                else -> COLOR_TEXT_PRIMARY
            }
            setTextColor(textColor)

            val lp = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.MATCH_PARENT,
                flexWeight
            ).apply {
                setMargins(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2))
            }
            layoutParams = lp

            val bgColor = when {
                isAccent -> COLOR_ACCENT_GREEN
                isSpecial -> COLOR_SPECIAL_KEY_BG
                else -> COLOR_KEY_BG
            }

            background = createRippleDrawable(bgColor, COLOR_KEY_RIPPLE, dpToPx(6))
            isClickable = true
            isFocusable = false

            setOnClickListener { onClick() }
        }
        return button
    }

    private fun createPinKeyButton(
        digit: String,
        flexWeight: Float = 1.0f,
        onClick: () -> Unit
    ): View {
        val button = TextView(this).apply {
            text = digit
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(COLOR_TEXT_PRIMARY)

            val lp = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.MATCH_PARENT,
                flexWeight
            ).apply {
                setMargins(dpToPx(4), dpToPx(2), dpToPx(4), dpToPx(2))
            }
            layoutParams = lp

            background = createRippleDrawable(COLOR_PIN_KEY_BG, COLOR_ACCENT_GREEN, dpToPx(8))
            isClickable = true
            isFocusable = false

            setOnClickListener { onClick() }
        }
        return button
    }

    private fun createHeaderButton(label: String, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(COLOR_TEXT_SECONDARY)
            setPadding(dpToPx(8), dpToPx(4), dpToPx(8), dpToPx(4))
            val lp = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                leftMargin = dpToPx(6)
            }
            layoutParams = lp
            background = createRippleDrawable(COLOR_KEY_BG, COLOR_KEY_RIPPLE, dpToPx(4))
            isClickable = true
            setOnClickListener { onClick() }
        }
    }

    private fun createBadgeDrawable(bgColor: Int, strokeColor: Int): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpToPx(4).toFloat()
            setColor(bgColor)
            setStroke(dpToPx(1), strokeColor)
        }
    }

    private fun createRippleDrawable(normalColor: Int, rippleColor: Int, radiusPx: Int): RippleDrawable {
        val content = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(normalColor)
        }
        val mask = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radiusPx.toFloat()
            setColor(Color.WHITE)
        }
        return RippleDrawable(ColorStateList.valueOf(rippleColor), content, mask)
    }

    private fun dpToPx(dp: Int): Int {
        return (dp * resources.displayMetrics.density).toInt()
    }

    companion object {
        // High-contrast, modern dark cybersecurity theme palette
        private const val COLOR_KEYBOARD_BG = 0xFF0B0F19.toInt()     // Deep slate void
        private const val COLOR_HEADER_BG = 0xFF070B14.toInt()       // Ultra-dark toolbar
        private const val COLOR_KEY_BG = 0xFF1E293B.toInt()          // Tactile dark slate card
        private const val COLOR_PIN_KEY_BG = 0xFF182234.toInt()      // Scrambled PIN key card
        private const val COLOR_SPECIAL_KEY_BG = 0xFF283548.toInt()  // Action / Function key
        private const val COLOR_ACCENT_GREEN = 0xFF00E676.toInt()    // Cyber neon emerald
        private const val COLOR_ACCENT_TEXT = 0xFF0B0F19.toInt()     // Deep text on emerald key
        private const val COLOR_TEXT_PRIMARY = 0xFFF8FAFC.toInt()    // Bright white
        private const val COLOR_TEXT_SECONDARY = 0xFF94A3B8.toInt()  // Muted silver slate
        private const val COLOR_KEY_RIPPLE = 0x4400E676.toInt()      // Neon tap ripple
        private const val COLOR_BADGE_BG = 0x1A00E676.toInt()        // Translucent emerald tag
    }
}
