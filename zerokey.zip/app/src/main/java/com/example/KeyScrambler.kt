package com.example

import java.security.SecureRandom

/**
 * KeyScrambler: Generates dynamically scrambled digit layouts for the numeric PIN keypad.
 *
 * Implements the Fisher-Yates (Knuth) Shuffle algorithm backed by [SecureRandom] to randomize
 * keypad digit positions on every draw/activation. This strictly prevents:
 * 1. Shoulder-surfing (visual observation of touch locations)
 * 2. Coordinate-based screen touch loggers & malware tap inference
 * 3. Thermal & smudge residue attacks
 */
class KeyScrambler(
    private val secureRandom: SecureRandom = SecureRandom()
) {

    /**
     * Standard digits 0 through 9 baseline template.
     */
    companion object {
        val DEFAULT_DIGITS = intArrayOf(0, 1, 2, 3, 4, 5, 6, 7, 8, 9)
    }

    /**
     * Generates a newly randomized digit sequence (0..9) using the Fisher-Yates shuffle algorithm.
     * Guaranteed to contain all digits 0-9 exactly once.
     *
     * @return A newly allocated, scrambled IntArray of digits 0 through 9.
     */
    fun getScrambledDigits(): IntArray {
        val digits = DEFAULT_DIGITS.clone()
        shuffle(digits)
        return digits
    }

    /**
     * Performs an in-place Fisher-Yates (Knuth) Shuffle on the provided integer array.
     *
     * Runs in O(N) time with O(1) extra space complexity and guarantees an unbiased,
     * uniform permutation across all N! possible combinations.
     *
     * @param array The integer array to be shuffled in-place.
     */
    fun shuffle(array: IntArray) {
        if (array.size <= 1) return
        for (i in array.size - 1 downTo 1) {
            // Pick a uniform random index from 0 to i (inclusive)
            val j = secureRandom.nextInt(i + 1)
            val temp = array[i]
            array[i] = array[j]
            array[j] = temp
        }
    }

    /**
     * Helper to shuffle a mutable list of any type using Fisher-Yates.
     */
    fun <T> shuffleList(list: MutableList<T>) {
        if (list.size <= 1) return
        for (i in list.size - 1 downTo 1) {
            val j = secureRandom.nextInt(i + 1)
            val temp = list[i]
            list[i] = list[j]
            list[j] = temp
        }
    }
}
