package com.example.shizuku

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import com.example.model.CommandLogEntry
import com.example.model.ShizukuState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

class ShizukuManager private constructor(private val context: Context) {

    private val _statusFlow = MutableStateFlow(ShizukuState.DISCONNECTED)
    val statusFlow: StateFlow<ShizukuState> = _statusFlow.asStateFlow()

    private val _commandLogs = MutableStateFlow<List<CommandLogEntry>>(emptyList())
    val commandLogs: StateFlow<List<CommandLogEntry>> = _commandLogs.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        checkStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        _statusFlow.value = ShizukuState.DISCONNECTED
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == REQUEST_CODE_PERMISSION) {
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                _statusFlow.value = ShizukuState.CONNECTED_AUTHORIZED
                logCommand("SYSTEM_PERM", "Shizuku ADB Permission Granted by User", 0, true)
            } else {
                _statusFlow.value = ShizukuState.CONNECTED_NO_PERMISSION
                logCommand("SYSTEM_PERM", "Shizuku ADB Permission Denied", -1, false)
            }
        }
    }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            checkStatus()
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to initialize Shizuku listeners", e)
            _statusFlow.value = ShizukuState.UNSUPPORTED
        }
    }

    fun checkStatus(): ShizukuState {
        val state = try {
            if (Shizuku.pingBinder()) {
                val isPreV11 = try {
                    Shizuku.getVersion() < 11
                } catch (e: Throwable) {
                    false
                }
                if (isPreV11) {
                    ShizukuState.CONNECTED_AUTHORIZED
                } else {
                    val permission = Shizuku.checkSelfPermission()
                    if (permission == PackageManager.PERMISSION_GRANTED) {
                        ShizukuState.CONNECTED_AUTHORIZED
                    } else {
                        ShizukuState.CONNECTED_NO_PERMISSION
                    }
                }
            } else {
                ShizukuState.DISCONNECTED
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Shizuku binder ping failed: ${e.message}")
            ShizukuState.DISCONNECTED
        }
        _statusFlow.value = state
        return state
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(REQUEST_CODE_PERMISSION)
                } else {
                    _statusFlow.value = ShizukuState.CONNECTED_AUTHORIZED
                }
            } else {
                _statusFlow.value = ShizukuState.DISCONNECTED
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error requesting Shizuku permission", e)
        }
    }

    private fun spawnProcess(cmd: Array<String>, env: Array<String>?, dir: String?): Process {
        return try {
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            method.isAccessible = true
            method.invoke(null, cmd, env, dir) as Process
        } catch (e: Exception) {
            // Fallback to Runtime exec if direct binder call unavailable
            Runtime.getRuntime().exec(cmd, env, dir?.let { java.io.File(it) })
        }
    }

    suspend fun executeCommand(command: String): CommandLogEntry = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        var exitCode = -1
        var output = ""
        var isSuccess = false

        if (checkStatus() != ShizukuState.CONNECTED_AUTHORIZED) {
            output = "ERROR: Shizuku is not running or authorization not granted. Please start Shizuku app and grant access."
            val log = CommandLogEntry(
                command = command,
                output = output,
                exitCode = -1,
                isSuccess = false
            )
            appendLog(log)
            return@withContext log
        }

        try {
            val process = spawnProcess(arrayOf("sh", "-c", command), null, null)
            val stdout = BufferedReader(InputStreamReader(process.inputStream)).readText()
            val stderr = BufferedReader(InputStreamReader(process.errorStream)).readText()
            exitCode = process.waitFor()

            output = if (stdout.isNotBlank()) {
                stdout.trim()
            } else if (stderr.isNotBlank()) {
                "STDERR: " + stderr.trim()
            } else {
                "Command executed (Exit code $exitCode)"
            }

            isSuccess = (exitCode == 0)
        } catch (e: Throwable) {
            Log.e(TAG, "Execution failed for '$command'", e)
            output = "EXCEPTION: ${e.localizedMessage ?: e.message}"
            exitCode = -1
            isSuccess = false
        }

        val log = CommandLogEntry(
            command = command,
            output = output,
            exitCode = exitCode,
            isSuccess = isSuccess
        )
        appendLog(log)
        return@withContext log
    }

    /**
     * Direct Shizuku shell execution to block internet connectivity
     * using the Private DNS invalid hostname method.
     */
    suspend fun blockInternet(): CommandLogEntry {
        executeCommand("settings put global private_dns_specifier invalid.dns")
        val result = executeCommand("settings put global private_dns_mode hostname")
        // Flushes existing socket sessions and forces routing via invalid DNS
        refreshNetworkStack()
        return result
    }

    /**
     * Performs a network stack refresh using ADB shell.
     * 1. Terminates all active TCP/UDP sockets via 'svc data disable'.
     * 2. Waits 500ms for radio modem hardware reset.
     * 3. Re-enables mobile data via 'svc data enable' forcing new connections to route via DNS.
     */
    suspend fun refreshNetworkStack(): Boolean = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Flushing sockets: executing 'svc data disable'...")
            executeCommand("svc data disable")
            kotlinx.coroutines.delay(500)
            Log.d(TAG, "Restoring radio modem: executing 'svc data enable'...")
            executeCommand("svc data enable")
            true
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to refresh network stack via ADB", e)
            false
        }
    }

    /**
     * Direct Shizuku shell execution to restore internet connectivity
     * by reverting Private DNS to opportunistic (Automatic).
     */
    suspend fun unblockInternet(): CommandLogEntry {
        return executeCommand("settings put global private_dns_mode opportunistic")
    }

    // Direct aliases for backward-compatibility
    suspend fun lockGlobalNetwork(): CommandLogEntry = blockInternet()
    suspend fun unlockGlobalNetwork(): CommandLogEntry = unblockInternet()
    suspend fun liftAllRestrictions(): CommandLogEntry = unblockInternet()

    private fun logCommand(command: String, output: String, exitCode: Int, isSuccess: Boolean) {
        val entry = CommandLogEntry(
            command = command,
            output = output,
            exitCode = exitCode,
            isSuccess = isSuccess
        )
        appendLog(entry)
    }

    private fun appendLog(entry: CommandLogEntry) {
        val current = _commandLogs.value.toMutableList()
        current.add(0, entry)
        if (current.size > 50) {
            _commandLogs.value = current.take(50)
        } else {
            _commandLogs.value = current
        }
    }

    fun clearLogs() {
        _commandLogs.value = emptyList()
    }

    fun destroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            Log.w(TAG, "Error cleaning up Shizuku listeners", e)
        }
    }

    companion object {
        private const val TAG = "ShizukuManager"
        const val REQUEST_CODE_PERMISSION = 7391

        @Volatile
        private var INSTANCE: ShizukuManager? = null

        fun getInstance(context: Context): ShizukuManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: ShizukuManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
