package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Dialpad
import androidx.compose.material.icons.filled.Hearing
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.CyberAudioRoute
import com.example.model.CyberCallModel
import com.example.model.CyberCallState
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberMagenta
import com.example.ui.theme.CyberPurple
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberYellow
import kotlin.math.sin

/**
 * Main Jetpack Compose Call UI rendering Anime/Cyberpunk HUD state machine.
 */
@Composable
fun CallScreen(
    callState: CyberCallModel,
    onAnswer: () -> Unit,
    onRejectOrDisconnect: () -> Unit,
    onToggleMute: () -> Unit,
    onCycleAudioRoute: () -> Unit,
    onToggleHold: () -> Unit,
    onSendDtmf: (Char) -> Unit,
    onMinimizeToOverlay: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showKeypad by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberDarkBg)
    ) {
        // Futuristic Cyber Grid Canvas & Scanlines
        CyberHudBackground()

        // Main HUD Content Container
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top HUD Status Bar
            TopHudStatusBar(
                callState = callState,
                onMinimizeToOverlay = onMinimizeToOverlay
            )

            // Center Holographic Section: Caller Identity, Glowing Visor Frame, Waveform
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f, fill = false)
            ) {
                Spacer(modifier = Modifier.height(12.dp))

                // Glowing Anime/Cyber Avatar Frame
                CyberAvatarFrame(callState = callState)

                Spacer(modifier = Modifier.height(20.dp))

                // Caller Display Name with Glitch / Monospace styling
                Text(
                    text = callState.callerName.uppercase(),
                    color = CyberTextPrimary,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.testTag("caller_name_text")
                )

                Spacer(modifier = Modifier.height(4.dp))

                // Phone Number with Cyan Glow
                Text(
                    text = callState.phoneNumber,
                    color = CyberCyan,
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    textAlign = TextAlign.Center,
                    letterSpacing = 2.sp,
                    modifier = Modifier.testTag("caller_number_text")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // State Badge & Duration Timer
                StateBadgeAndTimer(callState = callState)

                Spacer(modifier = Modifier.height(16.dp))

                // Active Audio Waveform Visualizer (shown during ACTIVE call)
                if (callState.state == CyberCallState.ACTIVE) {
                    AudioWaveformVisualizer(
                        modifier = Modifier
                            .fillMaxWidth(0.85f)
                            .height(42.dp)
                    )
                }
            }

            // Bottom Action Controls (Changes dynamically depending on Ringing vs Active state)
            BottomControlDeck(
                callState = callState,
                showKeypad = showKeypad,
                onToggleKeypad = { showKeypad = !showKeypad },
                onAnswer = onAnswer,
                onRejectOrDisconnect = onRejectOrDisconnect,
                onToggleMute = onToggleMute,
                onCycleAudioRoute = onCycleAudioRoute,
                onToggleHold = onToggleHold
            )
        }

        // DTMF Slide-up Cyber Keypad Drawer
        AnimatedVisibility(
            visible = showKeypad,
            enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
            exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.BottomCenter)
        ) {
            CyberKeypadDrawer(
                onSendDtmf = onSendDtmf,
                onClose = { showKeypad = false }
            )
        }
    }
}

/**
 * Top HUD Bar displaying telemetry status, security protocol and minimize button.
 */
@Composable
private fun TopHudStatusBar(
    callState: CyberCallModel,
    onMinimizeToOverlay: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // System protocol indicator
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(
                        color = when (callState.state) {
                            CyberCallState.RINGING -> CyberYellow
                            CyberCallState.ACTIVE -> CyberGreen
                            CyberCallState.DISCONNECTED -> CyberRed
                            else -> CyberCyan
                        },
                        shape = CutCornerShape(2.dp)
                    )
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "COMM_LINK // 256-BIT ENCRYPTED",
                color = CyberCyan.copy(alpha = 0.85f),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
        }

        // Floating HUD overlay button
        IconButton(
            onClick = onMinimizeToOverlay,
            modifier = Modifier
                .size(40.dp)
                .background(CyberCyan.copy(alpha = 0.12f), CutCornerShape(6.dp))
                .border(1.dp, CyberCyan.copy(alpha = 0.4f), CutCornerShape(6.dp))
                .testTag("floating_hud_button")
        ) {
            Icon(
                imageVector = Icons.Default.PictureInPictureAlt,
                contentDescription = "Minimize to Floating HUD Overlay",
                tint = CyberCyan,
                modifier = Modifier.size(20.dp)
            )
        }
    }
}

/**
 * Holographic Avatar Frame featuring cyberpunk anime operator portrait,
 * surrounded by rotating radar rings and neon glow.
 */
@Composable
private fun CyberAvatarFrame(callState: CyberCallModel) {
    val infiniteTransition = rememberInfiniteTransition(label = "avatar_anim")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "rotation"
    )

    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.size(170.dp)
    ) {
        // Rotating radar reticle canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2, size.height / 2)
            val radius = size.minDimension / 2 - 4.dp.toPx()

            // Outer ring
            drawCircle(
                color = CyberCyan.copy(alpha = 0.3f),
                radius = radius,
                style = Stroke(width = 1.5.dp.toPx())
            )

            // Pulsing inner ring
            val ringColor = if (callState.state == CyberCallState.RINGING) {
                CyberYellow.copy(alpha = pulseAlpha)
            } else {
                CyberMagenta.copy(alpha = pulseAlpha * 0.7f)
            }
            drawCircle(
                color = ringColor,
                radius = radius - 8.dp.toPx(),
                style = Stroke(width = 2.dp.toPx())
            )
        }

        // Inner Avatar Artwork
        Box(
            modifier = Modifier
                .size(130.dp)
                .clip(CircleShape)
                .background(CyberSurface)
                .border(2.5.dp, CyberCyan, CircleShape)
        ) {
            Image(
                painter = painterResource(id = R.drawable.cyber_anime_caller),
                contentDescription = "Operator Avatar",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }
}

/**
 * State badge (INCOMING TRANSMISSION, ACTIVE LINK, etc.) and live duration timer.
 */
@Composable
private fun StateBadgeAndTimer(callState: CyberCallModel) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        val (stateText, stateColor) = when (callState.state) {
            CyberCallState.RINGING -> "INCOMING TRANSMISSION..." to CyberYellow
            CyberCallState.DIALING -> "ESTABLISHING UPLINK..." to CyberCyan
            CyberCallState.ACTIVE -> {
                if (callState.isHold) "COMM LINK ON HOLD" to CyberYellow
                else "SECURE COMM LINK [ACTIVE]" to CyberGreen
            }
            CyberCallState.HOLDING -> "COMM LINK ON HOLD" to CyberYellow
            CyberCallState.DISCONNECTING -> "DISCONNECTING LINK..." to CyberRed
            CyberCallState.DISCONNECTED -> "TRANSMISSION TERMINATED" to CyberRed
            CyberCallState.IDLE -> "STANDBY PROTOCOL" to CyberCyan
        }

        Surface(
            color = stateColor.copy(alpha = 0.12f),
            shape = CutCornerShape(4.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, stateColor.copy(alpha = 0.6f))
        ) {
            Text(
                text = stateText,
                color = stateColor,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.5.sp,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
            )
        }

        // Show live duration timer in 00:00 format when call is active
        if (callState.state == CyberCallState.ACTIVE || callState.state == CyberCallState.HOLDING) {
            Spacer(modifier = Modifier.height(8.dp))
            val minutes = callState.durationSeconds / 60
            val seconds = callState.durationSeconds % 60
            val hours = minutes / 60
            val timeString = if (hours > 0) {
                String.format("%02d:%02d:%02d", hours, minutes % 60, seconds)
            } else {
                String.format("%02d:%02d", minutes, seconds)
            }

            Text(
                text = timeString,
                color = CyberCyan,
                fontSize = 28.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 3.sp,
                modifier = Modifier.testTag("call_duration_timer")
            )
        }
    }
}

/**
 * Animated cyberpunk audio visualizer bars simulating voice frequency telemetry.
 */
@Composable
private fun AudioWaveformVisualizer(modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "waveform")
    val phase by transition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    Canvas(modifier = modifier) {
        val barCount = 28
        val spacing = size.width / barCount
        val barWidth = spacing * 0.55f

        for (i in 0 until barCount) {
            val normalized = i.toFloat() / barCount
            val heightFactor = (sin(normalized * 12f + phase) * 0.45f + 0.55f).coerceIn(0.15f, 1.0f)
            val barHeight = size.height * heightFactor
            val x = i * spacing + (spacing - barWidth) / 2
            val y = (size.height - barHeight) / 2

            drawRoundRect(
                brush = Brush.verticalGradient(
                    colors = listOf(CyberCyan, CyberMagenta)
                ),
                topLeft = Offset(x, y),
                size = androidx.compose.ui.geometry.Size(barWidth, barHeight),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(2.dp.toPx(), 2.dp.toPx())
            )
        }
    }
}

/**
 * Bottom deck rendering either Cyber-Slice Answer/Reject buttons (Incoming Call)
 * or Active Call control deck (Mute, Speaker, Keypad, Hold, End Call).
 */
@Composable
private fun BottomControlDeck(
    callState: CyberCallModel,
    showKeypad: Boolean,
    onToggleKeypad: () -> Unit,
    onAnswer: () -> Unit,
    onRejectOrDisconnect: () -> Unit,
    onToggleMute: () -> Unit,
    onCycleAudioRoute: () -> Unit,
    onToggleHold: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (callState.state == CyberCallState.RINGING) {
            // INCOMING STATE: Cyber-Slice action buttons for Answer and Reject
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Reject Cyber-Slice Button (Neon Magenta / Red)
                CyberSliceButton(
                    text = "REJECT",
                    subtext = "[TERM_01]",
                    icon = Icons.Default.CallEnd,
                    primaryColor = CyberMagenta,
                    onClick = onRejectOrDisconnect,
                    isLeftSlice = true,
                    modifier = Modifier.weight(1f).testTag("reject_call_button")
                )

                Spacer(modifier = Modifier.width(16.dp))

                // Answer Cyber-Slice Button (Neon Cyan / Green)
                CyberSliceButton(
                    text = "ANSWER",
                    subtext = "[EST_LINK]",
                    icon = Icons.Default.Call,
                    primaryColor = CyberCyan,
                    onClick = onAnswer,
                    isLeftSlice = false,
                    modifier = Modifier.weight(1f).testTag("answer_call_button")
                )
            }
        } else {
            // ACTIVE / CONNECTING / HOLDING STATE: Comprehensive control deck
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // 4-Button Action Grid: Mute, Keypad, Audio Route, Hold
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Mute Toggle
                    CyberCircleAction(
                        icon = if (callState.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        label = if (callState.isMuted) "UNMUTE" else "MUTE",
                        isActive = callState.isMuted,
                        activeColor = CyberRed,
                        onClick = onToggleMute,
                        testTag = "mute_button"
                    )

                    // Keypad Drawer Toggle
                    CyberCircleAction(
                        icon = Icons.Default.Dialpad,
                        label = "KEYPAD",
                        isActive = showKeypad,
                        activeColor = CyberYellow,
                        onClick = onToggleKeypad,
                        testTag = "keypad_toggle_button"
                    )

                    // Audio Route Switcher (Speaker / Earpiece / BT)
                    val (routeIcon, routeLabel) = when (callState.audioRoute) {
                        CyberAudioRoute.SPEAKER -> Icons.AutoMirrored.Filled.VolumeUp to "SPEAKER"
                        CyberAudioRoute.BLUETOOTH -> Icons.Default.Bluetooth to "BT_LINK"
                        else -> Icons.Default.Hearing to "EARPIECE"
                    }
                    CyberCircleAction(
                        icon = routeIcon,
                        label = routeLabel,
                        isActive = callState.audioRoute == CyberAudioRoute.SPEAKER,
                        activeColor = CyberCyan,
                        onClick = onCycleAudioRoute,
                        testTag = "audio_route_button"
                    )

                    // Hold Toggle
                    CyberCircleAction(
                        icon = if (callState.isHold) Icons.Default.PlayArrow else Icons.Default.Pause,
                        label = if (callState.isHold) "RESUME" else "HOLD",
                        isActive = callState.isHold,
                        activeColor = CyberYellow,
                        onClick = onToggleHold,
                        testTag = "hold_button"
                    )
                }

                Spacer(modifier = Modifier.height(26.dp))

                // Big Angled Cyber End Call Button
                Button(
                    onClick = onRejectOrDisconnect,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberRed.copy(alpha = 0.88f)
                    ),
                    shape = CutCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .height(58.dp)
                        .border(1.5.dp, CyberRed, CutCornerShape(12.dp))
                        .testTag("end_call_button")
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "Terminate Link",
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "TERMINATE TRANSMISSION",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.ExtraBold,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 2.sp
                        )
                    }
                }
            }
        }
    }
}

/**
 * Cyber-Slice angular interactive button for Answer / Reject with holographic glowing borders.
 */
@Composable
private fun CyberSliceButton(
    text: String,
    subtext: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    primaryColor: Color,
    onClick: () -> Unit,
    isLeftSlice: Boolean,
    modifier: Modifier = Modifier
) {
    val cutCorner = if (isLeftSlice) {
        CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp)
    } else {
        CutCornerShape(topEnd = 16.dp, bottomStart = 16.dp)
    }

    Box(
        modifier = modifier
            .height(72.dp)
            .clip(cutCorner)
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        primaryColor.copy(alpha = 0.22f),
                        primaryColor.copy(alpha = 0.08f)
                    )
                )
            )
            .border(2.dp, primaryColor, cutCorner)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .background(primaryColor.copy(alpha = 0.2f), CircleShape)
                    .border(1.dp, primaryColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = text,
                    tint = primaryColor,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = text,
                    color = primaryColor,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
                Text(
                    text = subtext,
                    color = CyberTextSecondary,
                    fontSize = 9.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

/**
 * Circular interactive HUD action button with active state highlighting.
 */
@Composable
private fun CyberCircleAction(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isActive: Boolean,
    activeColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .background(
                    if (isActive) activeColor.copy(alpha = 0.25f) else CyberSurface,
                    CircleShape
                )
                .border(
                    width = 1.5.dp,
                    color = if (isActive) activeColor else CyberCyan.copy(alpha = 0.45f),
                    shape = CircleShape
                )
                .testTag(testTag),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = if (isActive) activeColor else CyberTextPrimary,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = label,
            color = if (isActive) activeColor else CyberTextSecondary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )
    }
}

/**
 * Slide-in Cyber DTMF Keypad Drawer allowing dialing digits into active calls.
 */
@Composable
private fun CyberKeypadDrawer(
    onSendDtmf: (Char) -> Unit,
    onClose: () -> Unit
) {
    Surface(
        color = CyberDarkBg.copy(alpha = 0.98f),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberCyan.copy(alpha = 0.6f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("cyber_keypad_drawer")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Drag handle / close row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "// DTMF PROTOCOL KEYPAD",
                    color = CyberCyan,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "[DISMISS]",
                    color = CyberMagenta,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable(onClick = onClose)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Keypad Grid: 1-9, *, 0, #
            val keys = listOf(
                listOf("1" to "", "2" to "ABC", "3" to "DEF"),
                listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
                listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
                listOf("*" to "", "0" to "+", "#" to "")
            )

            keys.forEach { row ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    row.forEach { (digit, sub) ->
                        CyberKeypadKey(
                            digit = digit,
                            letters = sub,
                            onClick = { onSendDtmf(digit[0]) }
                        )
                    }
                }
            }
        }
    }
}

/**
 * Individual DTMF Keypad Button.
 */
@Composable
private fun CyberKeypadKey(
    digit: String,
    letters: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(68.dp)
            .clip(CutCornerShape(8.dp))
            .background(CyberSurface)
            .border(1.dp, CyberCyan.copy(alpha = 0.5f), CutCornerShape(8.dp))
            .clickable(onClick = onClick)
            .testTag("keypad_key_$digit"),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = digit,
                color = CyberCyan,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            if (letters.isNotBlank()) {
                Text(
                    text = letters,
                    color = CyberTextSecondary,
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

/**
 * Background Canvas rendering subtle sci-fi grid lines, glowing corner reticles,
 * and holographic scanlines.
 */
@Composable
private fun CyberHudBackground() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val step = 48.dp.toPx()

        // Grid lines
        var x = 0f
        while (x < width) {
            drawLine(
                color = CyberCyan.copy(alpha = 0.04f),
                start = Offset(x, 0f),
                end = Offset(x, height),
                strokeWidth = 1f
            )
            x += step
        }

        var y = 0f
        while (y < height) {
            drawLine(
                color = CyberCyan.copy(alpha = 0.04f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f
            )
            y += step
        }

        // Corner reticle accents
        val cornerSize = 24.dp.toPx()
        val cornerColor = CyberCyan.copy(alpha = 0.5f)
        val strokeWidth = 2.dp.toPx()

        // Top Left
        drawLine(cornerColor, Offset(16.dp.toPx(), 16.dp.toPx()), Offset(16.dp.toPx() + cornerSize, 16.dp.toPx()), strokeWidth)
        drawLine(cornerColor, Offset(16.dp.toPx(), 16.dp.toPx()), Offset(16.dp.toPx(), 16.dp.toPx() + cornerSize), strokeWidth)

        // Top Right
        drawLine(cornerColor, Offset(width - 16.dp.toPx(), 16.dp.toPx()), Offset(width - 16.dp.toPx() - cornerSize, 16.dp.toPx()), strokeWidth)
        drawLine(cornerColor, Offset(width - 16.dp.toPx(), 16.dp.toPx()), Offset(width - 16.dp.toPx(), 16.dp.toPx() + cornerSize), strokeWidth)

        // Bottom Left
        drawLine(cornerColor, Offset(16.dp.toPx(), height - 16.dp.toPx()), Offset(16.dp.toPx() + cornerSize, height - 16.dp.toPx()), strokeWidth)
        drawLine(cornerColor, Offset(16.dp.toPx(), height - 16.dp.toPx()), Offset(16.dp.toPx(), height - 16.dp.toPx() - cornerSize), strokeWidth)

        // Bottom Right
        drawLine(cornerColor, Offset(width - 16.dp.toPx(), height - 16.dp.toPx()), Offset(width - 16.dp.toPx() - cornerSize, height - 16.dp.toPx()), strokeWidth)
        drawLine(cornerColor, Offset(width - 16.dp.toPx(), height - 16.dp.toPx()), Offset(width - 16.dp.toPx(), height - 16.dp.toPx() - cornerSize), strokeWidth)
    }
}
