package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Core Cyberpunk / Anime HUD Palette
val CyberCyan = Color(0xFF00F0FF)
val CyberMagenta = Color(0xFFFF007F)
val CyberYellow = Color(0xFFFFE600)
val CyberGreen = Color(0xFF00FF66)
val CyberPurple = Color(0xFF7000FF)
val CyberDarkBg = Color(0xFF060913)
val CyberSurface = Color(0xFF0B1224)
val CyberSurfaceElevated = Color(0xFF111C38)
val CyberCardBorder = Color(0xFF1E3A5F)
val CyberTextPrimary = Color(0xFFF1F5F9)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberTextMuted = Color(0xFF475569)
val CyberRed = Color(0xFFFF2A4B)

// Material 3 mappings
val Purple80 = CyberCyan
val PurpleGrey80 = Color(0xFF1E3A5F)
val Pink80 = CyberMagenta

val Purple40 = CyberCyan
val PurpleGrey40 = Color(0xFF0F172A)
val Pink40 = CyberMagenta
