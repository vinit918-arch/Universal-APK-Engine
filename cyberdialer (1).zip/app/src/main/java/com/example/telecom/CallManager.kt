package com.example.telecom

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.SystemClock
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.telecom.VideoProfile
import android.util.Log
import com.example.model.CyberAudioRoute
import com.example.model.CyberCallModel
import com.example.model.CyberCallState
import com.example.ui.CallActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.lang.ref.WeakReference

/**
 * Central Singleton Controller managing Telecom Calls and state distribution.
 * Implements clean separation of concerns, memory leak prevention via WeakReferences,
 * and coroutine-driven timers on Dispatchers.Main.
 */
object CallManager {
    private const val TAG = "CyberCallManager"

    private val scope = CoroutineScope(Dispatchers.Main.immediate + SupervisorJob())

    // Backing reactive StateFlow observed by Compose UI
    private val _callState = MutableStateFlow(CyberCallModel())
    val callState: StateFlow<CyberCallModel> = _callState.asStateFlow()

    // References to real Telecom instances - held weakly or cleared to prevent leaks
    private var currentCall: Call? = null
    private var inCallServiceRef: WeakReference<InCallService>? = null

    // Coroutine job for active call duration tracking
    private var timerJob: Job? = null

    // Callback listening to Call state changes
    private val telecomCallback = object : Call.Callback() {
        override fun onStateChanged(call: Call, state: Int) {
            Log.d(TAG, "Telecom Call state changed: $state")
            handleTelecomStateChange(call, state)
        }

        override fun onDetailsChanged(call: Call, details: Call.Details) {
            Log.d(TAG, "Telecom Call details changed")
            updateDetailsFromCall(call)
        }
    }

    /**
     * Called by CyberInCallService when a new Telecom Call is bound.
     */
    fun onCallAdded(call: Call, service: InCallService) {
        Log.d(TAG, "onCallAdded: ${call.details}")
        inCallServiceRef = WeakReference(service)
        currentCall?.unregisterCallback(telecomCallback)
        currentCall = call
        call.registerCallback(telecomCallback)

        updateDetailsFromCall(call)
        handleTelecomStateChange(call, call.state)

        // Launch full-screen HUD CallActivity
        val context = service.applicationContext
        launchCallActivity(context)
    }

    /**
     * Called by CyberInCallService when a Telecom Call is removed.
     */
    fun onCallRemoved(call: Call) {
        Log.d(TAG, "onCallRemoved")
        if (currentCall == call) {
            currentCall?.unregisterCallback(telecomCallback)
            currentCall = null
            stopTimer()
            _callState.update {
                it.copy(state = CyberCallState.DISCONNECTED)
            }
            // Reset to IDLE after a short animation interval
            scope.launch {
                delay(1200)
                _callState.value = CyberCallModel()
            }
        }
    }

    /**
     * Called by CyberInCallService when Audio State changes (Speaker, Mute, Route).
     */
    @Suppress("DEPRECATION")
    fun onAudioStateChanged(audioState: CallAudioState) {
        val route = when (audioState.route) {
            CallAudioState.ROUTE_SPEAKER -> CyberAudioRoute.SPEAKER
            CallAudioState.ROUTE_BLUETOOTH -> CyberAudioRoute.BLUETOOTH
            CallAudioState.ROUTE_WIRED_HEADSET -> CyberAudioRoute.WIRED_HEADSET
            else -> CyberAudioRoute.EARPIECE
        }
        _callState.update {
            it.copy(
                isMuted = audioState.isMuted,
                audioRoute = route
            )
        }
    }

    /**
     * Answer incoming call.
     */
    fun answerCall() {
        Log.d(TAG, "Answer call invoked")
        val call = currentCall
        if (call != null) {
            try {
                call.answer(VideoProfile.STATE_AUDIO_ONLY)
            } catch (e: Exception) {
                Log.e(TAG, "Error answering call: ${e.message}", e)
            }
        } else if (_callState.value.isSimulated) {
            // Simulated link answered
            startActiveCall()
        }
    }

    /**
     * Reject incoming call or hang up active call.
     */
    fun rejectOrDisconnectCall() {
        Log.d(TAG, "Reject or disconnect invoked")
        val call = currentCall
        if (call != null) {
            try {
                if (call.state == Call.STATE_RINGING) {
                    call.reject(false, null)
                } else {
                    call.disconnect()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error disconnecting call: ${e.message}", e)
            }
        } else if (_callState.value.isSimulated) {
            terminateSimulatedCall()
        }
    }

    /**
     * Toggle Mute protocol.
     */
    fun toggleMute() {
        val nextMuted = !_callState.value.isMuted
        val service = inCallServiceRef?.get()
        if (service != null) {
            try {
                service.setMuted(nextMuted)
            } catch (e: Exception) {
                Log.e(TAG, "Error setting mute: ${e.message}", e)
            }
        } else {
            _callState.update { it.copy(isMuted = nextMuted) }
        }
    }

    /**
     * Toggle or switch Audio Route (Speaker / Earpiece / Bluetooth).
     */
    @Suppress("DEPRECATION")
    fun cycleAudioRoute() {
        val current = _callState.value.audioRoute
        val nextRoute = when (current) {
            CyberAudioRoute.EARPIECE -> CyberAudioRoute.SPEAKER
            CyberAudioRoute.SPEAKER -> CyberAudioRoute.BLUETOOTH
            CyberAudioRoute.BLUETOOTH -> CyberAudioRoute.EARPIECE
            CyberAudioRoute.WIRED_HEADSET -> CyberAudioRoute.SPEAKER
        }
        val targetTelecomRoute = when (nextRoute) {
            CyberAudioRoute.SPEAKER -> CallAudioState.ROUTE_SPEAKER
            CyberAudioRoute.BLUETOOTH -> CallAudioState.ROUTE_BLUETOOTH
            else -> CallAudioState.ROUTE_EARPIECE
        }

        val service = inCallServiceRef?.get()
        if (service != null) {
            try {
                service.setAudioRoute(targetTelecomRoute)
            } catch (e: Exception) {
                Log.e(TAG, "Error setting audio route: ${e.message}", e)
            }
        } else {
            _callState.update { it.copy(audioRoute = nextRoute) }
        }
    }

    /**
     * Toggle Hold state.
     */
    fun toggleHold() {
        val call = currentCall
        val isHolding = _callState.value.isHold
        if (call != null) {
            try {
                if (isHolding) {
                    call.unhold()
                } else {
                    call.hold()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error toggling hold: ${e.message}", e)
            }
        } else if (_callState.value.isSimulated) {
            _callState.update { it.copy(isHold = !isHolding) }
        }
    }

    /**
     * Send DTMF tone on keypad press.
     */
    fun sendDtmf(digit: Char) {
        val call = currentCall
        if (call != null) {
            try {
                call.playDtmfTone(digit)
                scope.launch {
                    delay(180)
                    call.stopDtmfTone()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error playing DTMF: ${e.message}", e)
            }
        }
    }

    // --- TELECOM MAPPING HELPERS ---

    private fun handleTelecomStateChange(call: Call, state: Int) {
        val cyberState = when (state) {
            Call.STATE_RINGING -> CyberCallState.RINGING
            Call.STATE_DIALING, Call.STATE_CONNECTING -> CyberCallState.DIALING
            Call.STATE_ACTIVE -> {
                startTimer()
                CyberCallState.ACTIVE
            }
            Call.STATE_HOLDING -> CyberCallState.HOLDING
            Call.STATE_DISCONNECTING -> CyberCallState.DISCONNECTING
            Call.STATE_DISCONNECTED -> {
                stopTimer()
                CyberCallState.DISCONNECTED
            }
            else -> CyberCallState.IDLE
        }

        _callState.update {
            it.copy(
                state = cyberState,
                isHold = state == Call.STATE_HOLDING
            )
        }

        if (cyberState == CyberCallState.DISCONNECTED) {
            scope.launch {
                delay(1200)
                if (_callState.value.state == CyberCallState.DISCONNECTED) {
                    _callState.value = CyberCallModel()
                }
            }
        }
    }

    private fun updateDetailsFromCall(call: Call) {
        val details = call.details
        val handleUri: Uri? = details?.handle
        val number = handleUri?.schemeSpecificPart ?: "UNKNOWN"
        val callerName = details?.callerDisplayName ?: details?.contactDisplayName ?: "ANONYMOUS OPERATOR"

        _callState.update {
            it.copy(
                id = "CALL_${System.currentTimeMillis()}",
                phoneNumber = number,
                callerName = if (callerName.isNotBlank()) callerName else "OPERATOR: $number",
                isSimulated = false
            )
        }
    }

    private fun startTimer() {
        stopTimer()
        val startTime = SystemClock.elapsedRealtime()
        _callState.update { it.copy(connectTimeMillis = startTime, durationSeconds = 0L) }
        timerJob = scope.launch {
            while (isActive) {
                delay(1000)
                val elapsed = (SystemClock.elapsedRealtime() - startTime) / 1000
                _callState.update { it.copy(durationSeconds = elapsed) }
            }
        }
    }

    private fun stopTimer() {
        timerJob?.cancel()
        timerJob = null
    }

    // --- SIMULATION HARNESS (FOR EMULATORS & OFFLINE PROTOCOL TESTING) ---

    fun startSimulatedIncomingCall(
        context: Context,
        name: String = "CYBER-NET//AI ARCHITECT",
        number: String = "+81 (03) 779-NEON"
    ) {
        stopTimer()
        _callState.value = CyberCallModel(
            id = "SIM_INCOMING_${System.currentTimeMillis()}",
            callerName = name,
            phoneNumber = number,
            state = CyberCallState.RINGING,
            isSimulated = true
        )
        launchCallActivity(context)
    }

    fun startSimulatedOutgoingCall(
        context: Context,
        name: String = "GRID MAINFRAME",
        number: String = "+1 (800) 555-CYBER"
    ) {
        stopTimer()
        _callState.value = CyberCallModel(
            id = "SIM_OUTGOING_${System.currentTimeMillis()}",
            callerName = name,
            phoneNumber = number,
            state = CyberCallState.DIALING,
            isSimulated = true
        )
        launchCallActivity(context)

        // Automatically simulate link connected after 2.5 seconds
        scope.launch {
            delay(2500)
            if (_callState.value.state == CyberCallState.DIALING) {
                startActiveCall()
            }
        }
    }

    private fun startActiveCall() {
        _callState.update { it.copy(state = CyberCallState.ACTIVE) }
        startTimer()
    }

    private fun terminateSimulatedCall() {
        stopTimer()
        _callState.update { it.copy(state = CyberCallState.DISCONNECTED) }
        scope.launch {
            delay(1200)
            _callState.value = CyberCallModel()
        }
    }

    private fun launchCallActivity(context: Context) {
        val intent = Intent(context, CallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        context.startActivity(intent)
    }

    fun cleanup() {
        currentCall?.unregisterCallback(telecomCallback)
        currentCall = null
        inCallServiceRef?.clear()
        inCallServiceRef = null
        stopTimer()
    }
}
