package com.example.telecom

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.example.R
import com.example.ui.CallActivity

/**
 * System InCallService binding Telecom subsystem events to CyberDialer.
 * Registered in AndroidManifest with android.telecom.InCallService and android:permission="android.permission.BIND_INCALL_SERVICE".
 * Compliant with Android 14+ (API 34) Foreground Service type: FOREGROUND_SERVICE_TYPE_PHONE_CALL.
 */
class CyberInCallService : InCallService() {

    companion object {
        private const val TAG = "CyberInCallService"
        private const val CHANNEL_ID = "cyber_incall_channel"
        private const val NOTIFICATION_ID = 40477
    }

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "CyberInCallService initialized")
        createNotificationChannel()
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        Log.d(TAG, "onCallAdded: state=${call.state}")
        CallManager.onCallAdded(call, this)

        // Show foreground call notification for ongoing system link
        updateOngoingNotification(call)
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        Log.d(TAG, "onCallRemoved")
        CallManager.onCallRemoved(call)

        // Stop foreground notification if no more calls
        if (calls.isEmpty()) {
            stopForegroundCompat()
        }
    }

    @Deprecated("Deprecated in Java")
    @Suppress("DEPRECATION")
    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        super.onCallAudioStateChanged(audioState)
        Log.d(TAG, "onCallAudioStateChanged: route=${audioState.route}, isMuted=${audioState.isMuted}")
        CallManager.onAudioStateChanged(audioState)
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "CyberInCallService destroyed")
        CallManager.cleanup()
        stopForegroundCompat()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "CyberDialer Active Link",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "HUD CyberDialer Active Comm Channel"
                setSound(null, null)
                enableVibration(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }

    private fun updateOngoingNotification(call: Call) {
        val intent = Intent(this, CallActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val callerHandle = call.details?.handle?.schemeSpecificPart ?: "LINK SECURED"

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("CYBER//DIALER LINK ACTIVE")
            .setContentText("TRANSMISSION: $callerHandle")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_CALL)
            .build()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                // API 34+ requirement for foreground service type
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_PHONE_CALL
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Could not startForeground: ${e.message}")
        }
    }

    private fun stopForegroundCompat() {
        try {
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping foreground: ${e.message}")
        }
    }
}
