package com.example

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.PhoneCallback
import androidx.compose.material.icons.filled.PictureInPictureAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.telecom.CallManager
import com.example.telecom.CyberOverlayService
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberDarkBg
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberMagenta
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberSurfaceElevated
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.CyberYellow
import com.example.ui.theme.MyApplicationTheme
import com.example.util.DefaultDialerPrompt

class MainActivity : ComponentActivity() {

    private var initialNumber: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        handleIntent(intent)

        setContent {
            MyApplicationTheme {
                MainCyberDialerScreen(
                    initialInput = initialNumber,
                    onRequestDefaultDialer = {
                        DefaultDialerPrompt.requestDefaultDialer(this)
                    },
                    onInitiateCall = { number ->
                        initiateCall(number)
                    }
                )
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(intent: Intent?) {
        val data: Uri? = intent?.data
        if (data != null && data.scheme == "tel") {
            initialNumber = data.schemeSpecificPart ?: ""
        }
    }

    private fun initiateCall(number: String) {
        if (number.isBlank()) {
            Toast.makeText(this, "INPUT REQUIRED: Please dial a target sequence", Toast.LENGTH_SHORT).show()
            return
        }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE)
            == PackageManager.PERMISSION_GRANTED
        ) {
            val callIntent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${Uri.encode(number)}"))
            startActivity(callIntent)
        } else {
            val dialIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(number)}"))
            startActivity(dialIntent)
        }
    }
}

@Composable
fun MainCyberDialerScreen(
    initialInput: String,
    onRequestDefaultDialer: () -> Unit,
    onInitiateCall: (String) -> Unit
) {
    val context = LocalContext.current
    var dialedNumber by remember { mutableStateOf(initialInput) }
    var isDefaultDialer by remember { mutableStateOf(DefaultDialerPrompt.isDefaultDialer(context)) }
    var hasOverlayPermission by remember { mutableStateOf(DefaultDialerPrompt.canDrawOverlays(context)) }

    // System role launcher
    val roleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        isDefaultDialer = DefaultDialerPrompt.isDefaultDialer(context)
    }

    // Permission launcher for Call Phone, Notifications
    val permissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        // Refreshed permissions
    }

    LaunchedEffect(Unit) {
        val needed = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.CALL_PHONE)
        }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            needed.add(Manifest.permission.READ_PHONE_STATE)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                needed.add(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
        if (needed.isNotEmpty()) {
            permissionsLauncher.launch(needed.toTypedArray())
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(CyberDarkBg)
    ) {
        // Futuristic background lines
        CyberGridCanvas()

        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // App Header
            CyberHeader()

            Spacer(modifier = Modifier.height(12.dp))

            // Default Phone Role & Permissions Protocol Card
            RoleStatusCard(
                isDefaultDialer = isDefaultDialer,
                hasOverlayPermission = hasOverlayPermission,
                onRequestRole = {
                    val intent = DefaultDialerPrompt.createDefaultDialerIntent(context)
                    roleLauncher.launch(intent)
                },
                onRequestOverlay = {
                    val intent = DefaultDialerPrompt.createOverlaySettingsIntent(context)
                    context.startActivity(intent)
                }
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Dialed Number Display HUD
            NumberDisplaySection(
                number = dialedNumber,
                onClear = { dialedNumber = "" },
                onBackspace = {
                    if (dialedNumber.isNotEmpty()) {
                        dialedNumber = dialedNumber.dropLast(1)
                    }
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Dialpad Keypad Grid
            DialpadGrid(
                onKeyClick = { char ->
                    if (dialedNumber.length < 24) {
                        dialedNumber += char
                    }
                },
                onCallClick = {
                    onInitiateCall(dialedNumber)
                }
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Protocol Testing & Simulation Deck
            SimulationHarnessSection(
                onSimulateIncoming = {
                    CallManager.startSimulatedIncomingCall(
                        context,
                        name = "OPERATOR//KIRIKO",
                        number = "+81 (03) 779-NEON"
                    )
                },
                onSimulateOutgoing = {
                    val num = dialedNumber.ifBlank { "+1 (800) 555-CYBER" }
                    CallManager.startSimulatedOutgoingCall(
                        context,
                        name = "GRID MAINFRAME",
                        number = num
                    )
                },
                onLaunchMiniOverlay = {
                    if (DefaultDialerPrompt.canDrawOverlays(context)) {
                        CallManager.startSimulatedIncomingCall(context, "MINI_HUD_TEST", "+1-800-OVERLAY")
                        CyberOverlayService.start(context)
                    } else {
                        Toast.makeText(context, "Please grant Floating Overlay permission first", Toast.LENGTH_SHORT).show()
                        val intent = DefaultDialerPrompt.createOverlaySettingsIntent(context)
                        context.startActivity(intent)
                    }
                }
            )

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun CyberHeader() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "CYBER//DIALER",
                color = CyberCyan,
                fontSize = 24.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp
            )
            Text(
                text = "NEURAL TELECOM INTERFACE v3.4",
                color = CyberTextSecondary,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
        }

        Box(
            modifier = Modifier
                .clip(CutCornerShape(4.dp))
                .background(CyberCyan.copy(alpha = 0.15f))
                .border(1.dp, CyberCyan, CutCornerShape(4.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = "SYSTEM: READY",
                color = CyberCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
private fun RoleStatusCard(
    isDefaultDialer: Boolean,
    hasOverlayPermission: Boolean,
    onRequestRole: () -> Unit,
    onRequestOverlay: () -> Unit
) {
    Surface(
        color = CyberSurface,
        shape = CutCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.5.dp,
            if (isDefaultDialer) CyberGreen.copy(alpha = 0.7f) else CyberYellow.copy(alpha = 0.7f)
        ),
        modifier = Modifier.fillMaxWidth().testTag("role_status_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Status Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isDefaultDialer) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isDefaultDialer) CyberGreen else CyberYellow,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isDefaultDialer) "SYSTEM PROTOCOL: DEFAULT DIALER" else "ROLE_DIALER: NOT SET",
                        color = if (isDefaultDialer) CyberGreen else CyberYellow,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                if (!isDefaultDialer) {
                    Button(
                        onClick = onRequestRole,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberYellow),
                        shape = CutCornerShape(4.dp),
                        modifier = Modifier.height(32.dp).testTag("set_default_dialer_button")
                    ) {
                        Text(
                            text = "SET AS DEFAULT",
                            color = Color.Black,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Floating HUD Permission Row
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureInPictureAlt,
                        contentDescription = null,
                        tint = if (hasOverlayPermission) CyberCyan else CyberTextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (hasOverlayPermission) "FLOATING OVERLAY: ACTIVE" else "FLOATING OVERLAY: INACTIVE",
                        color = if (hasOverlayPermission) CyberCyan else CyberTextSecondary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }

                if (!hasOverlayPermission) {
                    Text(
                        text = "[GRANT PERMISSION]",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        modifier = Modifier.clickable(onClick = onRequestOverlay)
                    )
                }
            }
        }
    }
}

@Composable
private fun NumberDisplaySection(
    number: String,
    onClear: () -> Unit,
    onBackspace: () -> Unit
) {
    Surface(
        color = CyberSurfaceElevated,
        shape = CutCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.5.dp, CyberCyan.copy(alpha = 0.6f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (number.isBlank()) "ENTER TARGET FREQ_" else number,
                color = if (number.isBlank()) CyberTextSecondary.copy(alpha = 0.5f) else CyberCyan,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 2.sp,
                modifier = Modifier.weight(1f).testTag("dialed_number_display")
            )

            Row {
                if (number.isNotBlank()) {
                    IconButton(onClick = onClear, modifier = Modifier.size(36.dp)) {
                        Text(
                            text = "CLR",
                            color = CyberMagenta,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    IconButton(onClick = onBackspace, modifier = Modifier.size(36.dp)) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Backspace,
                            contentDescription = "Backspace",
                            tint = CyberCyan,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DialpadGrid(
    onKeyClick: (String) -> Unit,
    onCallClick: () -> Unit
) {
    val keypadRows = listOf(
        listOf("1" to "", "2" to "ABC", "3" to "DEF"),
        listOf("4" to "GHI", "5" to "JKL", "6" to "MNO"),
        listOf("7" to "PQRS", "8" to "TUV", "9" to "WXYZ"),
        listOf("*" to "", "0" to "+", "#" to "")
    )

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        keypadRows.forEach { row ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 5.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                row.forEach { (digit, letters) ->
                    DialpadButton(
                        digit = digit,
                        letters = letters,
                        onClick = { onKeyClick(digit) }
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Large Cyber Call Button
        Button(
            onClick = onCallClick,
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
            shape = CutCornerShape(12.dp),
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .height(56.dp)
                .border(2.dp, CyberCyan, CutCornerShape(12.dp))
                .testTag("dialer_call_button")
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Call,
                    contentDescription = "Initiate Call",
                    tint = Color.Black,
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "INITIATE TRANSMISSION",
                    color = Color.Black,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.ExtraBold,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.5.sp
                )
            }
        }
    }
}

@Composable
private fun DialpadButton(
    digit: String,
    letters: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(74.dp)
            .clip(CutCornerShape(10.dp))
            .background(CyberSurface)
            .border(1.5.dp, CyberCyan.copy(alpha = 0.4f), CutCornerShape(10.dp))
            .clickable(onClick = onClick)
            .testTag("dialpad_btn_$digit"),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = digit,
                color = CyberTextPrimary,
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            if (letters.isNotBlank()) {
                Text(
                    text = letters,
                    color = CyberCyan.copy(alpha = 0.8f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }
        }
    }
}

@Composable
private fun SimulationHarnessSection(
    onSimulateIncoming: () -> Unit,
    onSimulateOutgoing: () -> Unit,
    onLaunchMiniOverlay: () -> Unit
) {
    Surface(
        color = CyberSurface,
        shape = CutCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberMagenta.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "// PROTOCOL SIMULATION DECK (TEST HARNESS)",
                color = CyberMagenta,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Enables testing the Anime/Cyberpunk Call HUD & Floating Window without a cellular SIM card.",
                color = CyberTextSecondary,
                fontSize = 10.sp,
                lineHeight = 14.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onSimulateIncoming,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberMagenta.copy(alpha = 0.2f)),
                    shape = CutCornerShape(4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .border(1.dp, CyberMagenta, CutCornerShape(4.dp))
                        .testTag("test_incoming_call_button")
                ) {
                    Text(
                        text = "TEST INCOMING",
                        color = CyberMagenta,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = onSimulateOutgoing,
                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan.copy(alpha = 0.2f)),
                    shape = CutCornerShape(4.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(40.dp)
                        .border(1.dp, CyberCyan, CutCornerShape(4.dp))
                        .testTag("test_outgoing_call_button")
                ) {
                    Text(
                        text = "TEST OUTGOING",
                        color = CyberCyan,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Button(
                onClick = onLaunchMiniOverlay,
                colors = ButtonDefaults.buttonColors(containerColor = CyberSurfaceElevated),
                shape = CutCornerShape(4.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(38.dp)
                    .border(1.dp, CyberCyan.copy(alpha = 0.5f), CutCornerShape(4.dp))
                    .testTag("test_floating_overlay_button")
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.PictureInPictureAlt,
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TEST FLOATING HUD OVERLAY (WINDOW)",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
private fun CyberGridCanvas() {
    Canvas(modifier = Modifier.fillMaxSize()) {
        val width = size.width
        val height = size.height
        val step = 40.dp.toPx()

        var x = 0f
        while (x < width) {
            drawLine(
                color = CyberCyan.copy(alpha = 0.03f),
                start = Offset(x, 0f),
                end = Offset(x, height),
                strokeWidth = 1f
            )
            x += step
        }

        var y = 0f
        while (y < height) {
            drawLine(
                color = CyberCyan.copy(alpha = 0.03f),
                start = Offset(0f, y),
                end = Offset(width, y),
                strokeWidth = 1f
            )
            y += step
        }
    }
}
