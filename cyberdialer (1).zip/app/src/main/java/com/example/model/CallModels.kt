package com.example.model

/**
 * High-level state representing phone call phases for CyberDialer.
 */
enum class CyberCallState {
    IDLE,
    RINGING,       // Incoming transmission waiting for answer/reject
    DIALING,       // Establishing outgoing uplink
    ACTIVE,        // Secure duplex audio transmission live
    HOLDING,       // Transmission on hold
    DISCONNECTING, // Terminating comm link
    DISCONNECTED   // Transmission ended
}

/**
 * Audio routing targets mapped from Telecom CallAudioState.
 */
enum class CyberAudioRoute(val label: String) {
    EARPIECE("EARPIECE"),
    SPEAKER("SPEAKER"),
    BLUETOOTH("BT_LINK"),
    WIRED_HEADSET("HEADSET")
}

/**
 * Unified model encapsulating active telecommunication link parameters.
 */
data class CyberCallModel(
    val id: String = "",
    val callerName: String = "UNKNOWN TRANSMITTER",
    val phoneNumber: String = "+00-000-0000",
    val state: CyberCallState = CyberCallState.IDLE,
    val isMuted: Boolean = false,
    val audioRoute: CyberAudioRoute = CyberAudioRoute.EARPIECE,
    val isHold: Boolean = false,
    val durationSeconds: Long = 0L,
    val connectTimeMillis: Long = 0L,
    val isSimulated: Boolean = false
)
