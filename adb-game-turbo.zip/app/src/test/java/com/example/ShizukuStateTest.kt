package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ShizukuStateRepository
import com.example.model.ShizukuState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ShizukuStateTest {

    @Test
    fun testShizukuStateTransitions() {
        val notRunning = ShizukuState.NotRunning
        assertFalse(notRunning.isReady)
        assertFalse(notRunning.isBinderAlive)
        assertFalse(notRunning.hasPermission)

        val denied = ShizukuState.PermissionDenied
        assertFalse(denied.isReady)
        assertTrue(denied.isBinderAlive)
        assertFalse(denied.hasPermission)

        val warning = ShizukuState.VersionWarning(version = 10, minRequired = 11)
        assertFalse(warning.isReady)
        assertTrue(warning.isBinderAlive)
        assertTrue(warning.hasPermission)
        assertEquals(10, warning.version)

        val ready = ShizukuState.Ready(version = 13, uid = 2000)
        assertTrue(ready.isReady)
        assertTrue(ready.isBinderAlive)
        assertTrue(ready.hasPermission)
        assertEquals(13, ready.version)
        assertEquals(2000, ready.uid)
    }

    @Test
    fun testRepositoryInitialization() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        ShizukuStateRepository.initialize(context)
        // Verify state is non-null and accessible
        val state = ShizukuStateRepository.state.value
        assertTrue(state is ShizukuState)
    }

    @Test
    fun testPostRestartCatalogueIntegrity() {
        val actions = com.example.model.PostRestartCatalogue.ALL_ACTIONS
        assertEquals(8, actions.size)

        val ids = actions.map { it.id }.toSet()
        assertEquals(8, ids.size)
        assertTrue(ids.contains("kill_background"))
        assertTrue(ids.contains("trim_cache"))
        assertTrue(ids.contains("power_idleness"))
        assertTrue(ids.contains("game_driver"))
        assertTrue(ids.contains("fixed_performance"))
        assertTrue(ids.contains("adaptive_power_saver"))
        assertTrue(ids.contains("deviceidle_disable"))
        assertTrue(ids.contains("wifi_scan_disable"))

        // Ensure no animation scale commands are present
        for (action in actions) {
            assertFalse(action.command.contains("animation_scale"))
            assertFalse(action.command.contains("animator_duration_scale"))
        }
    }

    @Test
    fun testXiaomiTogglesAndBlacklist() {
        val toggles = com.example.model.TurboCatalogue.ALL_TOGGLES
        val ids = toggles.map { it.id }.toSet()
        assertEquals(toggles.size, ids.size) // No duplicate IDs

        val joyose = toggles.find { it.id == "disable_joyose" }
        org.junit.Assert.assertNotNull(joyose)
        assertEquals("pm disable-user --user 0 com.xiaomi.joyose", joyose!!.applyCommand)
        assertEquals("pm enable com.xiaomi.joyose", joyose.revertCommand)
        assertTrue(joyose.isDangerous)
        assertFalse(joyose.warningText.isNullOrBlank())
        assertEquals(com.example.model.ToggleCategory.XIAOMI_MIUI, joyose.category)

        val phantom = toggles.find { it.id == "phantom_process_limit" }
        org.junit.Assert.assertNotNull(phantom)
        assertEquals("device_config put activity_manager max_phantom_processes 2147483647", phantom!!.applyCommand)
        assertEquals("device_config delete activity_manager max_phantom_processes", phantom.revertCommand)
        assertFalse(phantom.isDangerous)
        assertEquals(com.example.model.ToggleCategory.XIAOMI_MIUI, phantom.category)

        // Ensure prohibited commands are nowhere in ALL_TOGGLES
        for (t in toggles) {
            assertFalse(t.applyCommand.contains("cmd thermal set-override"))
            assertFalse(t.applyCommand.contains("dumpsys deviceidle disable"))
            assertFalse(t.applyCommand.contains("am trim-future"))
            assertFalse(t.applyCommand.contains("renice"))
            assertFalse(t.applyCommand.contains("SurfaceFlinger 1008"))
            assertFalse(t.applyCommand.contains("powerkeeper"))
            assertFalse(t.applyCommand.contains("wifi_sleep_policy"))
        }
    }

    @Test
    fun testPerformanceModesAndCommands() {
        val modes = com.example.model.PerformanceMode.values()
        assertEquals(4, modes.size)

        val fullPower = com.example.model.PerformanceMode.FULL_POWER
        assertTrue(fullPower.commands.any { it.contains("thermalservice override-status 0") })
        assertTrue(fullPower.commands.any { it.contains("peak_refresh_rate 120.0") })
        assertTrue(fullPower.commands.any { it.contains("set-fixed-performance-mode-enabled true") })

        val batterySaver = com.example.model.PerformanceMode.BATTERY_SAVER
        assertTrue(batterySaver.commands.any { it.contains("low_power 1") })
        assertTrue(batterySaver.commands.any { it.contains("peak_refresh_rate 60.0") })

        val performance = com.example.model.PerformanceMode.PERFORMANCE
        assertTrue(performance.commands.any { it.contains("set-fixed-performance-mode-enabled true") })
        assertTrue(performance.commands.any { it.contains("touch_pressure_scale 0.001") })
        assertTrue(performance.commands.any { it.contains("trim-caches") })

        val balanced = com.example.model.PerformanceMode.BALANCED
        assertTrue(balanced.commands.any { it.contains("thermalservice reset") })
        assertTrue(balanced.commands.any { it.contains("low_power 0") })

        // Check default popular games include BGMI and Free Fire
        val games = com.example.service.GameSessionService.POPULAR_GAME_PACKAGES
        assertTrue(games.contains("com.pubg.imobile"))
        assertTrue(games.contains("com.dts.freefireth"))
    }
}
