package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ShizukuStateRepository
import com.example.model.ShizukuState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ShizukuStateTest {

    @Test
    fun testShizukuStateTransitions() {
        val notRunning = ShizukuState.NotRunning
        assertFalse(notRunning.isReady)
        assertFalse(notRunning.isBinderAlive)
        assertFalse(notRunning.hasPermission)

        val denied = ShizukuState.PermissionDenied
        assertFalse(denied.isReady)
        assertTrue(denied.isBinderAlive)
        assertFalse(denied.hasPermission)

        val warning = ShizukuState.VersionWarning(version = 10, minRequired = 11)
        assertFalse(warning.isReady)
        assertTrue(warning.isBinderAlive)
        assertTrue(warning.hasPermission)
        assertEquals(10, warning.version)

        val ready = ShizukuState.Ready(version = 13, uid = 2000)
        assertTrue(ready.isReady)
        assertTrue(ready.isBinderAlive)
        assertTrue(ready.hasPermission)
        assertEquals(13, ready.version)
        assertEquals(2000, ready.uid)
    }

    @Test
    fun testRepositoryInitialization() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        ShizukuStateRepository.initialize(context)
        // Verify state is non-null and accessible
        val state = ShizukuStateRepository.state.value
        assertTrue(state is ShizukuState)
    }
}
