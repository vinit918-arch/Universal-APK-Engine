package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.outlined.Dns
import androidx.compose.material.icons.outlined.Speed
import androidx.compose.material.icons.outlined.SportsEsports
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.MainTab
import com.example.ui.MainViewModel
import com.example.ui.components.ShizukuBanner
import com.example.ui.components.TurboTopBar
import com.example.ui.screens.GamesScreen
import com.example.ui.screens.StatusScreen
import com.example.ui.screens.TogglesScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.MonospaceFont
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MyApplicationTheme {
                MainAppScreen(viewModel = viewModel)
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshShizuku()
    }
}

@Composable
fun MainAppScreen(viewModel: MainViewModel) {
    val context = LocalContext.current
    val snackbarHostState = remember { SnackbarHostState() }

    val selectedTab by viewModel.selectedTab.collectAsStateWithLifecycle()
    val shizukuState by viewModel.shizukuState.collectAsStateWithLifecycle()
    val sessionState by viewModel.sessionState.collectAsStateWithLifecycle()
    val toggleItems by viewModel.toggleUiItems.collectAsStateWithLifecycle()
    val savedGames by viewModel.savedGames.collectAsStateWithLifecycle()
    val installedApps by viewModel.installedApps.collectAsStateWithLifecycle()
    val isLoadingApps by viewModel.isLoadingApps.collectAsStateWithLifecycle()
    val commandLogs by viewModel.commandLogs.collectAsStateWithLifecycle()
    val isTerminalRunning by viewModel.isTerminalRunning.collectAsStateWithLifecycle()

    // Notification Permission launcher for Android 13+
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission(),
        onResult = { /* No-op, service works either way */ }
    )

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    LaunchedEffect(Unit) {
        viewModel.snackbarEvent.collectLatest { message ->
            snackbarHostState.showSnackbar(message = message, withDismissAction = true)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DarkBackground,
        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState,
                modifier = Modifier.testTag("app_snackbar_host")
            )
        },
        topBar = {
            Column {
                TurboTopBar(
                    sessionState = sessionState,
                    shizukuState = shizukuState,
                    onRestoreAll = { viewModel.restoreAllTogglesNow() }
                )
                ShizukuBanner(
                    state = shizukuState,
                    onRequestPermission = { viewModel.requestShizukuPermission() },
                    onOpenShizuku = { viewModel.openShizukuApp() },
                    onRefresh = { viewModel.refreshShizuku() }
                )
            }
        },
        bottomBar = {
            NavigationBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_navigation_bar"),
                containerColor = DarkSurface,
                tonalElevation = 8.dp
            ) {
                NavigationBarItem(
                    selected = selectedTab == MainTab.TOGGLES,
                    onClick = { viewModel.selectTab(MainTab.TOGGLES) },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.TOGGLES) Icons.Filled.Speed else Icons.Outlined.Speed,
                            contentDescription = "Toggles Tab",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "TOGGLES",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DarkBackground,
                        selectedTextColor = NeonGreen,
                        indicatorColor = NeonGreen,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_toggles")
                )

                NavigationBarItem(
                    selected = selectedTab == MainTab.GAMES,
                    onClick = { viewModel.selectTab(MainTab.GAMES) },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.GAMES) Icons.Filled.SportsEsports else Icons.Outlined.SportsEsports,
                            contentDescription = "Games Tab",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "GAMES",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DarkBackground,
                        selectedTextColor = ElectricCyan,
                        indicatorColor = ElectricCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_games")
                )

                NavigationBarItem(
                    selected = selectedTab == MainTab.STATUS,
                    onClick = { viewModel.selectTab(MainTab.STATUS) },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == MainTab.STATUS) Icons.Filled.Dns else Icons.Outlined.Dns,
                            contentDescription = "Status Tab",
                            modifier = Modifier.size(22.dp)
                        )
                    },
                    label = {
                        Text(
                            text = "STATUS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = DarkBackground,
                        selectedTextColor = ElectricCyan,
                        indicatorColor = ElectricCyan,
                        unselectedIconColor = TextSecondary,
                        unselectedTextColor = TextSecondary
                    ),
                    modifier = Modifier.testTag("tab_status")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (selectedTab) {
                MainTab.TOGGLES -> {
                    TogglesScreen(
                        toggleItems = toggleItems,
                        isSessionActive = sessionState.isActive,
                        onToggleChanged = { id, enabled -> viewModel.onToggleChanged(id, enabled) },
                        onTestCommand = { toggle, isApply -> viewModel.testRunToggleCommand(toggle, isApply) },
                        onApplyAll = { viewModel.applyAllTogglesNow() },
                        onRestoreAll = { viewModel.restoreAllTogglesNow() }
                    )
                }

                MainTab.GAMES -> {
                    GamesScreen(
                        savedGames = savedGames,
                        installedApps = installedApps,
                        isLoadingApps = isLoadingApps,
                        sessionState = sessionState,
                        onLaunchGame = { game -> viewModel.launchGame(game) },
                        onAddGame = { app -> viewModel.addSavedGame(app) },
                        onRemoveGame = { pkg -> viewModel.removeSavedGame(pkg) }
                    )
                }

                MainTab.STATUS -> {
                    StatusScreen(
                        shizukuState = shizukuState,
                        sessionState = sessionState,
                        commandLogs = commandLogs,
                        isTerminalRunning = isTerminalRunning,
                        onRefreshShizuku = { viewModel.refreshShizuku() },
                        onRequestPermission = { viewModel.requestShizukuPermission() },
                        onOpenShizuku = { viewModel.openShizukuApp() },
                        onRunTerminalCommand = { cmd -> viewModel.runCustomShellCommand(cmd) },
                        onRestoreSession = { viewModel.restoreAllTogglesNow() },
                        onClearLogs = { viewModel.clearLogs() }
                    )
                }
            }
        }
    }
}
