package com.example.util

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.util.Log
import com.example.model.CommandLogEntry
import com.example.model.ShizukuState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

object ShizukuShellExecutor {
    private const val TAG = "ShizukuShellExecutor"
    const val SHIZUKU_PERMISSION_REQUEST_CODE = 4001

    private val _shizukuState = MutableStateFlow(ShizukuState(isChecking = true))
    val shizukuState: StateFlow<ShizukuState> = _shizukuState.asStateFlow()

    private val _commandLogs = MutableStateFlow<List<CommandLogEntry>>(emptyList())
    val commandLogs: StateFlow<List<CommandLogEntry>> = _commandLogs.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku binder received")
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.d(TAG, "Shizuku binder dead")
        _shizukuState.value = ShizukuState(
            isBinderAlive = false,
            hasPermission = false,
            message = "Shizuku service terminated."
        )
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                Log.d(TAG, "Shizuku permission result: granted=$granted")
                refreshStatus()
            }
        }

    private var isListenersRegistered = false

    fun initListeners() {
        if (!isListenersRegistered) {
            try {
                Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
                Shizuku.addBinderDeadListener(binderDeadListener)
                Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
                isListenersRegistered = true
            } catch (e: Exception) {
                Log.e(TAG, "Error registering Shizuku listeners", e)
            }
        }
        refreshStatus()
    }

    fun removeListeners() {
        if (isListenersRegistered) {
            try {
                Shizuku.removeBinderReceivedListener(binderReceivedListener)
                Shizuku.removeBinderDeadListener(binderDeadListener)
                Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
                isListenersRegistered = false
            } catch (e: Exception) {
                Log.e(TAG, "Error removing Shizuku listeners", e)
            }
        }
    }

    fun refreshStatus() {
        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            false
        }

        if (!binderAlive) {
            _shizukuState.value = ShizukuState(
                isBinderAlive = false,
                hasPermission = false,
                isChecking = false,
                message = "Shizuku binder is not running. Please start Shizuku."
            )
            return
        }

        val hasPermission = try {
            if (Shizuku.isPreV11()) {
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (e: Exception) {
            false
        }

        val version = try { Shizuku.getVersion() } catch (e: Exception) { -1 }
        val uid = try { Shizuku.getUid() } catch (e: Exception) { -1 }

        _shizukuState.value = ShizukuState(
            isBinderAlive = true,
            hasPermission = hasPermission,
            version = version,
            uid = uid,
            isChecking = false,
            message = if (hasPermission) "Connected (v$version, UID $uid)" else "Permission required"
        )
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
                } else {
                    refreshStatus()
                }
            } else {
                _shizukuState.value = _shizukuState.value.copy(
                    message = "Cannot request permission: Shizuku service is not active."
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to request Shizuku permission", e)
            _shizukuState.value = _shizukuState.value.copy(
                message = "Permission request failed: ${e.localizedMessage}"
            )
        }
    }

    fun openShizukuApp(context: Context) {
        val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            try {
                val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app"))
                storeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(storeIntent)
            } catch (e: Exception) {
                Log.e(TAG, "Cannot open browser/store", e)
            }
        }
    }

    suspend fun execute(command: String): CommandLogEntry = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        var exitCode = -1
        val outputBuilder = StringBuilder()
        var isSuccess = false

        try {
            if (!Shizuku.pingBinder()) {
                throw IllegalStateException("Shizuku binder is not available.")
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                throw SecurityException("Shizuku permission is not granted.")
            }

            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }

            val process = newProcessMethod.invoke(null, arrayOf("sh", "-c", command), null, null) as java.lang.Process

            val stdOutReader = BufferedReader(InputStreamReader(process.inputStream))
            val stdErrReader = BufferedReader(InputStreamReader(process.errorStream))

            val stdout = stdOutReader.use { it.readText() }
            val stderr = stdErrReader.use { it.readText() }

            exitCode = process.waitFor()

            if (stdout.isNotBlank()) {
                outputBuilder.append(stdout.trim())
            }
            if (stderr.isNotBlank()) {
                if (outputBuilder.isNotEmpty()) outputBuilder.append("\n[ERR] ")
                outputBuilder.append(stderr.trim())
            }
            if (outputBuilder.isEmpty()) {
                outputBuilder.append(if (exitCode == 0) "Executed successfully (no output)" else "Exited with code $exitCode")
            }

            isSuccess = (exitCode == 0)
        } catch (e: Exception) {
            Log.e(TAG, "Error executing shell command: $command", e)
            exitCode = -1
            outputBuilder.append("Execution Exception: ${e.localizedMessage ?: e.javaClass.simpleName}")
            isSuccess = false
        }

        val duration = System.currentTimeMillis() - startTime
        val entry = CommandLogEntry(
            command = command,
            exitCode = exitCode,
            output = outputBuilder.toString(),
            isSuccess = isSuccess,
            durationMs = duration
        )

        val updated = ArrayList<CommandLogEntry>(_commandLogs.value.size + 1)
        updated.add(entry)
        updated.addAll(_commandLogs.value.take(99))
        _commandLogs.value = updated

        return@withContext entry
    }

    fun clearLogs() {
        _commandLogs.value = emptyList()
    }
}
