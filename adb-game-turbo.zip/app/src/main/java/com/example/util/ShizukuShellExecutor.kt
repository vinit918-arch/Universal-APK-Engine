package com.example.util

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import com.example.data.ShizukuStateRepository
import com.example.model.CommandLogEntry
import com.example.model.ShizukuState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuShellExecutor {
    private const val TAG = "ShizukuDebug"

    val shizukuState: StateFlow<ShizukuState> = ShizukuStateRepository.state

    private val _commandLogs = MutableStateFlow<List<CommandLogEntry>>(emptyList())
    val commandLogs: StateFlow<List<CommandLogEntry>> = _commandLogs.asStateFlow()

    fun refreshStatus() {
        ShizukuStateRepository.refreshStatus()
    }

    fun requestPermission() {
        ShizukuStateRepository.requestPermission()
    }

    fun openShizukuApp(context: Context) {
        ShizukuStateRepository.openShizukuApp(context)
    }

    suspend fun execute(command: String): CommandLogEntry = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        var exitCode = -1
        val outputBuilder = StringBuilder()
        var isSuccess = false

        try {
            val currentState = ShizukuStateRepository.state.value
            if (!currentState.isBinderAlive) {
                Log.w(TAG, "Shell execute skipped: Binder offline ($command)")
                throw IllegalStateException("Shizuku binder is not running.")
            }
            if (!currentState.hasPermission) {
                Log.w(TAG, "Shell execute skipped: Shizuku permission not granted ($command)")
                throw SecurityException("Shizuku permission has not been granted.")
            }

            Log.d(TAG, "[EXEC] Executing remote ADB command: $command")

            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }

            val process = newProcessMethod.invoke(null, arrayOf("sh", "-c", command), null, null) as java.lang.Process

            val stdOutReader = BufferedReader(InputStreamReader(process.inputStream))
            val stdErrReader = BufferedReader(InputStreamReader(process.errorStream))

            val stdout = stdOutReader.use { it.readText() }
            val stderr = stdErrReader.use { it.readText() }

            exitCode = process.waitFor()

            if (stdout.isNotBlank()) {
                outputBuilder.append(stdout.trim())
            }
            if (stderr.isNotBlank()) {
                if (outputBuilder.isNotEmpty()) outputBuilder.append("\n[ERR] ")
                outputBuilder.append(stderr.trim())
            }
            if (outputBuilder.isEmpty()) {
                outputBuilder.append(if (exitCode == 0) "Executed successfully (no output)" else "Exited with code $exitCode")
            }

            isSuccess = (exitCode == 0)
            Log.d(TAG, "[EXEC RESULT] exitCode=$exitCode, duration=${System.currentTimeMillis() - startTime}ms, output=${outputBuilder.take(100)}")
        } catch (e: Exception) {
            Log.e(TAG, "[EXEC ERROR] Error executing shell command: $command", e)
            exitCode = -1
            outputBuilder.append("Execution Exception: ${e.localizedMessage ?: e.javaClass.simpleName}")
            isSuccess = false
        }

        val duration = System.currentTimeMillis() - startTime
        val entry = CommandLogEntry(
            command = command,
            exitCode = exitCode,
            output = outputBuilder.toString(),
            isSuccess = isSuccess,
            durationMs = duration
        )

        val updated = ArrayList<CommandLogEntry>(_commandLogs.value.size + 1)
        updated.add(entry)
        updated.addAll(_commandLogs.value.take(99))
        _commandLogs.value = updated

        return@withContext entry
    }

    fun clearLogs() {
        _commandLogs.value = emptyList()
    }
}
