package com.example.model

enum class ToggleCategory(val displayName: String, val icon: String) {
    DISPLAY_ANIMATIONS("Display & Animations", "speed"),
    GPU_GRAPHICS("GPU & Graphics", "memory"),
    SYSTEM_PERFORMANCE("System & Background", "bolt"),
    IMMERSION_DND("Immersion & Feedback", "do_not_disturb")
}

data class TurboToggle(
    val id: String,
    val title: String,
    val description: String,
    val category: ToggleCategory,
    val applyCommand: String,
    val revertCommand: String,
    val isDefaultEnabled: Boolean = true,
    val impactTag: String = "LOW OVERHEAD",
    val technicalImpact: String = "ADB Global/System Setting"
)

object TurboCatalogue {
    val ALL_TOGGLES: List<TurboToggle> = listOf(
        TurboToggle(
            id = "window_animation_scale",
            title = "Disable Window Animation Scale",
            description = "Eliminates window open/close animation latency for instantaneous frame switching.",
            category = ToggleCategory.DISPLAY_ANIMATIONS,
            applyCommand = "settings put global window_animation_scale 0",
            revertCommand = "settings put global window_animation_scale 1",
            isDefaultEnabled = true,
            impactTag = "MAX SPEED",
            technicalImpact = "global window_animation_scale = 0"
        ),
        TurboToggle(
            id = "transition_animation_scale",
            title = "Disable Transition Animation Scale",
            description = "Removes page and activity transition lag across in-game popups and overlay views.",
            category = ToggleCategory.DISPLAY_ANIMATIONS,
            applyCommand = "settings put global transition_animation_scale 0",
            revertCommand = "settings put global transition_animation_scale 1",
            isDefaultEnabled = true,
            impactTag = "ZERO DELAY",
            technicalImpact = "global transition_animation_scale = 0"
        ),
        TurboToggle(
            id = "animator_duration_scale",
            title = "Disable Animator Duration Scale",
            description = "Forces immediate completion of UI animators, reducing micro-stutters during rendering.",
            category = ToggleCategory.DISPLAY_ANIMATIONS,
            applyCommand = "settings put global animator_duration_scale 0",
            revertCommand = "settings put global animator_duration_scale 1",
            isDefaultEnabled = true,
            impactTag = "ZERO DELAY",
            technicalImpact = "global animator_duration_scale = 0"
        ),
        TurboToggle(
            id = "force_gpu_rendering",
            title = "Force 2D GPU Rendering",
            description = "Offloads 2D surface drawing from CPU to GPU hardware rendering pipeline.",
            category = ToggleCategory.GPU_GRAPHICS,
            applyCommand = "settings put global force_gpu_rendering 1",
            revertCommand = "settings put global force_gpu_rendering 0",
            isDefaultEnabled = true,
            impactTag = "CPU OFFLOAD",
            technicalImpact = "global force_gpu_rendering = 1"
        ),
        TurboToggle(
            id = "force_hwui_renderer",
            title = "Force SkiaGL / Reduce MSAA Load",
            description = "Optimizes the HWUI drawing pipeline to prioritize SkiaGL fast path and reduce GPU burden.",
            category = ToggleCategory.GPU_GRAPHICS,
            applyCommand = "setprop debug.hwui.renderer skiagl",
            revertCommand = "setprop debug.hwui.renderer opengl",
            isDefaultEnabled = true,
            impactTag = "GPU TWEAK",
            technicalImpact = "setprop debug.hwui.renderer skiagl"
        ),
        TurboToggle(
            id = "disable_auto_brightness",
            title = "Lock Manual Brightness (Session)",
            description = "Prevents ambient light sensor polling and sudden screen dimming during gameplay.",
            category = ToggleCategory.SYSTEM_PERFORMANCE,
            applyCommand = "settings put system screen_brightness_mode 0",
            revertCommand = "settings put system screen_brightness_mode 1",
            isDefaultEnabled = true,
            impactTag = "SENSOR IDLE",
            technicalImpact = "system screen_brightness_mode = 0"
        ),
        TurboToggle(
            id = "kill_background_apps",
            title = "Purge Background Apps Before Launch",
            description = "Terminates dormant background processes (`am kill-all`) to reclaim RAM and CPU cores.",
            category = ToggleCategory.SYSTEM_PERFORMANCE,
            applyCommand = "am kill-all",
            revertCommand = "echo 'kill-all: session ended'",
            isDefaultEnabled = true,
            impactTag = "MAX RAM",
            technicalImpact = "am kill-all process purge"
        ),
        TurboToggle(
            id = "disable_haptic_feedback",
            title = "Disable System Haptic Feedback",
            description = "Suppresses non-game system vibration calls to prevent CPU micro-lag and scheduler stalls.",
            category = ToggleCategory.IMMERSION_DND,
            applyCommand = "settings put system haptic_feedback_enabled 0",
            revertCommand = "settings put system haptic_feedback_enabled 1",
            isDefaultEnabled = true,
            impactTag = "SMOOTH INPUT",
            technicalImpact = "system haptic_feedback_enabled = 0"
        ),
        TurboToggle(
            id = "dnd_gaming_mode",
            title = "Game Immersion DND (Do Not Disturb)",
            description = "Silences heads-up notifications and phone interrupts to prevent frame drops.",
            category = ToggleCategory.IMMERSION_DND,
            applyCommand = "cmd notification set_dnd on",
            revertCommand = "cmd notification set_dnd off",
            isDefaultEnabled = true,
            impactTag = "NO POPUPS",
            technicalImpact = "cmd notification set_dnd on"
        ),
        TurboToggle(
            id = "disable_auto_sync",
            title = "Pause Background Account Auto-Sync",
            description = "Stops background cloud synchronization threads from waking the modem and CPU.",
            category = ToggleCategory.SYSTEM_PERFORMANCE,
            applyCommand = "settings put global sync_enabled 0",
            revertCommand = "settings put global sync_enabled 1",
            isDefaultEnabled = true,
            impactTag = "NET STABILITY",
            technicalImpact = "global sync_enabled = 0"
        )
    )
}

data class SavedGame(
    val packageName: String,
    val appName: String,
    val activityName: String? = null,
    val addedAt: Long = System.currentTimeMillis()
)

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val isGame: Boolean = false
)

data class CommandLogEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val command: String,
    val exitCode: Int,
    val output: String,
    val isSuccess: Boolean,
    val durationMs: Long
)

data class ShizukuState(
    val isBinderAlive: Boolean = false,
    val hasPermission: Boolean = false,
    val version: Int = -1,
    val uid: Int = -1,
    val isChecking: Boolean = false,
    val message: String? = null
) {
    val isReady: Boolean get() = isBinderAlive && hasPermission
}

data class GameSessionState(
    val isActive: Boolean = false,
    val gamePackage: String? = null,
    val gameName: String? = null,
    val startTime: Long? = null,
    val appliedToggleIds: List<String> = emptyList()
)
