package com.example.service

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.GameSessionState
import com.example.model.TurboCatalogue
import com.example.util.ShizukuShellExecutor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class GameSessionService : Service() {

    companion object {
        private const val TAG = "GameSessionService"
        const val CHANNEL_ID = "game_turbo_session_channel"
        const val NOTIFICATION_ID = 9001

        const val ACTION_START_SESSION = "com.example.adbgameturbo.START_SESSION"
        const val ACTION_STOP_SESSION = "com.example.adbgameturbo.STOP_SESSION"

        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_GAME_NAME = "extra_game_name"
        const val EXTRA_APPLIED_IDS = "extra_applied_ids"

        private val _sessionState = MutableStateFlow(GameSessionState())
        val sessionState: StateFlow<GameSessionState> = _sessionState.asStateFlow()

        fun startSession(context: Context, packageName: String, gameName: String, appliedIds: List<String>) {
            val intent = Intent(context, GameSessionService::class.java).apply {
                action = ACTION_START_SESSION
                putExtra(EXTRA_PACKAGE_NAME, packageName)
                putExtra(EXTRA_GAME_NAME, gameName)
                putStringArrayListExtra(EXTRA_APPLIED_IDS, ArrayList(appliedIds))
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopSession(context: Context) {
            val intent = Intent(context, GameSessionService::class.java).apply {
                action = ACTION_STOP_SESSION
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var monitorJob: Job? = null
    private var currentPackage: String = ""
    private var currentGameName: String = ""
    private var appliedToggleIds: List<String> = emptyList()
    private var missingCount = 0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP_SESSION) {
            Log.d(TAG, "Manual restore requested")
            endSessionAndStop()
            return START_NOT_STICKY
        }

        if (action == ACTION_START_SESSION) {
            val pkg = intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: ""
            val name = intent.getStringExtra(EXTRA_GAME_NAME) ?: "Game"
            val toggleIds = intent.getStringArrayListExtra(EXTRA_APPLIED_IDS) ?: arrayListOf()

            currentPackage = pkg
            currentGameName = name
            appliedToggleIds = toggleIds
            missingCount = 0

            val notification = buildForegroundNotification(name, toggleIds.size)
            startForeground(NOTIFICATION_ID, notification)

            _sessionState.value = GameSessionState(
                isActive = true,
                gamePackage = pkg,
                gameName = name,
                startTime = System.currentTimeMillis(),
                appliedToggleIds = toggleIds
            )

            startMonitoring(pkg)
        }

        return START_NOT_STICKY
    }

    private fun startMonitoring(targetPackage: String) {
        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            // Initial grace period for game to launch and take foreground (10 seconds)
            delay(10_000)

            while (isActive) {
                // Poll every 6 seconds (battery-conscious interval)
                delay(6_000)
                val isRunning = isAppInForegroundOrRunning(targetPackage)
                Log.d(TAG, "Game monitor check for $targetPackage: isRunning=$isRunning (missed=$missingCount)")

                if (!isRunning) {
                    missingCount++
                    if (missingCount >= 2) {
                        Log.i(TAG, "Game $targetPackage exited. Reverting tweaks and stopping session.")
                        endSessionAndStop()
                        break
                    }
                } else {
                    missingCount = 0
                }
            }
        }
    }

    private suspend fun isAppInForegroundOrRunning(pkg: String): Boolean {
        // 1. Check via UsageStatsManager if available
        try {
            val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            if (usageStatsManager != null) {
                val now = System.currentTimeMillis()
                val events = usageStatsManager.queryEvents(now - 15_000, now)
                val event = UsageEvents.Event()
                var lastForegroundPkg = ""
                while (events.hasNextEvent()) {
                    events.getNextEvent(event)
                    if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                        event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                    ) {
                        lastForegroundPkg = event.packageName
                    }
                }
                if (lastForegroundPkg.isNotBlank()) {
                    if (lastForegroundPkg == pkg) return true
                    // If another app is strictly in foreground (excluding system UI / launcher), check process
                }
            }
        } catch (e: Exception) {
            // Fallback
        }

        // 2. Check ActivityManager running processes
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val runningProcesses = am?.runningAppProcesses
            if (runningProcesses != null) {
                val found = runningProcesses.any { processInfo ->
                    processInfo.pkgList?.contains(pkg) == true || processInfo.processName == pkg
                }
                if (found) return true
            }
        } catch (e: Exception) {
            // Fallback
        }

        // 3. Fallback check via Shizuku shell: pidof <pkg>
        if (ShizukuShellExecutor.shizukuState.value.isReady) {
            try {
                val res = ShizukuShellExecutor.execute("pidof $pkg")
                if (res.isSuccess && res.output.trim().isNotBlank() && !res.output.contains("not found")) {
                    return true
                }
            } catch (e: Exception) {
                // Ignore
            }
        }

        return false
    }

    private fun endSessionAndStop() {
        monitorJob?.cancel()
        serviceScope.launch {
            revertAppliedToggles()
            _sessionState.value = GameSessionState(isActive = false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private suspend fun revertAppliedToggles() {
        Log.i(TAG, "Reverting applied toggles: $appliedToggleIds")
        for (toggleId in appliedToggleIds) {
            val toggle = TurboCatalogue.ALL_TOGGLES.find { it.id == toggleId }
            if (toggle != null) {
                try {
                    ShizukuShellExecutor.execute(toggle.revertCommand)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to revert toggle $toggleId", e)
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Game Turbo Session",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows persistent status while ADB Game Turbo is accelerating a game"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(gameName: String, tweaksCount: Int): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val restoreIntent = Intent(this, GameSessionService::class.java).apply {
            action = ACTION_STOP_SESSION
        }
        val restorePendingIntent = PendingIntent.getService(
            this, 1, restoreIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("🎮 Turbo Mode Active — $gameName")
            .setContentText("$tweaksCount ADB performance tweaks active. Auto-revert on exit.")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_revert, "RESTORE NOW", restorePendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        monitorJob?.cancel()
        serviceScope.launch {
            if (_sessionState.value.isActive) {
                revertAppliedToggles()
                _sessionState.value = GameSessionState(isActive = false)
            }
        }
        super.onDestroy()
    }
}
