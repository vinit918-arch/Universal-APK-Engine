package com.example.service

import android.app.ActivityManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.GameSessionState
import com.example.model.PerformanceMode
import com.example.model.TurboCatalogue
import com.example.util.ShizukuShellExecutor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class GameSessionService : Service() {

    companion object {
        private const val TAG = "GameSessionService"
        const val CHANNEL_ID = "game_turbo_session_channel"
        const val NOTIFICATION_ID = 9001

        const val ACTION_START_SESSION = "com.example.adbgameturbo.START_SESSION"
        const val ACTION_STOP_SESSION = "com.example.adbgameturbo.STOP_SESSION"
        const val ACTION_SET_PROFILE = "com.example.adbgameturbo.SET_PROFILE"
        const val ACTION_TOGGLE_AUTODETECT = "com.example.adbgameturbo.TOGGLE_AUTODETECT"

        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_GAME_NAME = "extra_game_name"
        const val EXTRA_APPLIED_IDS = "extra_applied_ids"
        const val EXTRA_PROFILE_ID = "extra_profile_id"
        const val EXTRA_AUTODETECT_ENABLED = "extra_autodetect_enabled"

        // Default popular mobile games for zero-config out-of-the-box auto detection
        val POPULAR_GAME_PACKAGES = setOf(
            "com.pubg.imobile",            // Battlegrounds Mobile India (BGMI)
            "com.dts.freefireth",           // Free Fire
            "com.dts.freefiremax",          // Free Fire MAX
            "com.tencent.ig",               // PUBG Mobile (Global)
            "com.vng.pubgmobile",           // PUBG Mobile VN
            "com.activision.callofduty.shooter", // COD Mobile
            "com.garena.game.codm",         // Call of Duty: Mobile Garena
            "com.mobile.legends",           // Mobile Legends: Bang Bang
            "com.miHoYo.GenshinImpact",     // Genshin Impact
            "com.HoYoverse.hkrpgoversea",   // Honkai: Star Rail
            "com.riotgames.league.wildrift",// League of Legends: Wild Rift
            "com.ea.gp.apexmobile",         // Apex Legends Mobile
            "com.epicgames.fortnite",       // Fortnite
            "com.krafton.battlegroundsmobileind"
        )

        private val _sessionState = MutableStateFlow(GameSessionState())
        val sessionState: StateFlow<GameSessionState> = _sessionState.asStateFlow()

        private val _currentProfile = MutableStateFlow(PerformanceMode.BALANCED)
        val currentProfile: StateFlow<PerformanceMode> = _currentProfile.asStateFlow()

        private val _isAutoDetectEnabled = MutableStateFlow(true)
        val isAutoDetectEnabled: StateFlow<Boolean> = _isAutoDetectEnabled.asStateFlow()

        private val _detectedForegroundPackage = MutableStateFlow<String?>(null)
        val detectedForegroundPackage: StateFlow<String?> = _detectedForegroundPackage.asStateFlow()

        private val _designatedGamePackages = MutableStateFlow<Set<String>>(POPULAR_GAME_PACKAGES)

        fun updateDesignatedGames(packages: Set<String>) {
            _designatedGamePackages.value = POPULAR_GAME_PACKAGES + packages
        }

        fun startSession(context: Context, packageName: String, gameName: String, appliedIds: List<String>) {
            val intent = Intent(context, GameSessionService::class.java).apply {
                action = ACTION_START_SESSION
                putExtra(EXTRA_PACKAGE_NAME, packageName)
                putExtra(EXTRA_GAME_NAME, gameName)
                putStringArrayListExtra(EXTRA_APPLIED_IDS, ArrayList(appliedIds))
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun applyProfile(context: Context, mode: PerformanceMode) {
            val intent = Intent(context, GameSessionService::class.java).apply {
                action = ACTION_SET_PROFILE
                putExtra(EXTRA_PROFILE_ID, mode.id)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun setAutoDetectEnabled(context: Context, enabled: Boolean) {
            val intent = Intent(context, GameSessionService::class.java).apply {
                action = ACTION_TOGGLE_AUTODETECT
                putExtra(EXTRA_AUTODETECT_ENABLED, enabled)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopSession(context: Context) {
            val intent = Intent(context, GameSessionService::class.java).apply {
                action = ACTION_STOP_SESSION
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(Dispatchers.Default + Job())
    private var autoDetectJob: Job? = null
    private var currentPackage: String = ""
    private var currentGameName: String = ""
    private var appliedToggleIds: List<String> = emptyList()
    private var missingCount = 0
    private var wasAutoBoosted = false

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startAutoDetectionLoop()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SESSION -> {
                Log.d(TAG, "Manual restore requested")
                endSessionAndStop()
                return START_NOT_STICKY
            }

            ACTION_SET_PROFILE -> {
                val profileId = intent.getStringExtra(EXTRA_PROFILE_ID) ?: PerformanceMode.BALANCED.id
                val mode = PerformanceMode.values().find { it.id == profileId } ?: PerformanceMode.BALANCED
                serviceScope.launch {
                    executeProfile(mode, manual = true)
                }
                return START_STICKY
            }

            ACTION_TOGGLE_AUTODETECT -> {
                val enabled = intent.getBooleanExtra(EXTRA_AUTODETECT_ENABLED, true)
                _isAutoDetectEnabled.value = enabled
                if (enabled) {
                    startAutoDetectionLoop()
                } else {
                    autoDetectJob?.cancel()
                }
                return START_STICKY
            }

            ACTION_START_SESSION -> {
                val pkg = intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: ""
                val name = intent.getStringExtra(EXTRA_GAME_NAME) ?: "Game"
                val toggleIds = intent.getStringArrayListExtra(EXTRA_APPLIED_IDS) ?: arrayListOf()

                currentPackage = pkg
                currentGameName = name
                appliedToggleIds = toggleIds
                missingCount = 0
                wasAutoBoosted = false

                // Also trigger Full Power Mode for explicitly launched games
                serviceScope.launch {
                    executeProfile(PerformanceMode.FULL_POWER, manual = false)
                }

                val notification = buildForegroundNotification(name, PerformanceMode.FULL_POWER)
                startForeground(NOTIFICATION_ID, notification)

                _sessionState.value = GameSessionState(
                    isActive = true,
                    gamePackage = pkg,
                    gameName = name,
                    startTime = System.currentTimeMillis(),
                    appliedToggleIds = toggleIds
                )
            }
        }

        return START_STICKY
    }

    private suspend fun executeProfile(mode: PerformanceMode, manual: Boolean) {
        val oldMode = _currentProfile.value
        if (oldMode == mode) return

        Log.i(TAG, "Switching Performance Profile: ${oldMode.title} -> ${mode.title}")

        // Revert previous mode commands if needed
        for (revCmd in oldMode.revertCommands) {
            try {
                if (ShizukuShellExecutor.shizukuState.value.isReady) {
                    ShizukuShellExecutor.execute(revCmd)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed executing revert command: $revCmd", e)
            }
        }

        // Apply new mode commands
        for (cmd in mode.commands) {
            try {
                if (ShizukuShellExecutor.shizukuState.value.isReady) {
                    ShizukuShellExecutor.execute(cmd)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Failed executing profile command: $cmd", e)
            }
        }

        _currentProfile.value = mode

        // Update ongoing notification
        val nm = getSystemService(NotificationManager::class.java)
        val notif = buildForegroundNotification(currentGameName.ifBlank { "System" }, mode)
        nm?.notify(NOTIFICATION_ID, notif)
    }

    private fun startAutoDetectionLoop() {
        autoDetectJob?.cancel()
        autoDetectJob = serviceScope.launch {
            Log.i(TAG, "Starting Foreground Game Auto-Detection state loop...")
            while (isActive) {
                // Poll at a safe 2500ms interval to prevent battery drain or ADB pipe exhaustion
                delay(2500)

                if (!_isAutoDetectEnabled.value) continue

                try {
                    val focusedPkg = detectForegroundPackage()
                    _detectedForegroundPackage.value = focusedPkg

                    val isDesignatedGame = focusedPkg != null && _designatedGamePackages.value.contains(focusedPkg)

                    if (isDesignatedGame && focusedPkg != null) {
                        // Game entered foreground -> Trigger Full Power Mode
                        if (_currentProfile.value != PerformanceMode.FULL_POWER) {
                            Log.i(TAG, "Auto-detected game in foreground: $focusedPkg. Triggering FULL POWER MODE!")
                            wasAutoBoosted = true
                            currentPackage = focusedPkg
                            currentGameName = getAppNameFromPackage(focusedPkg)

                            _sessionState.value = GameSessionState(
                                isActive = true,
                                gamePackage = focusedPkg,
                                gameName = currentGameName,
                                startTime = System.currentTimeMillis()
                            )

                            val notification = buildForegroundNotification(currentGameName, PerformanceMode.FULL_POWER)
                            startForeground(NOTIFICATION_ID, notification)

                            executeProfile(PerformanceMode.FULL_POWER, manual = false)
                        }
                        missingCount = 0
                    } else {
                        // If game was auto-boosted and is no longer focused for 2 consecutive cycles
                        if (wasAutoBoosted && _sessionState.value.isActive) {
                            missingCount++
                            if (missingCount >= 2) {
                                Log.i(TAG, "Game exited foreground. Auto-reverting to BALANCED MODE.")
                                wasAutoBoosted = false
                                missingCount = 0
                                _sessionState.value = GameSessionState(isActive = false)

                                executeProfile(PerformanceMode.BALANCED, manual = false)

                                val notification = buildForegroundNotification("Idle", PerformanceMode.BALANCED)
                                val nm = getSystemService(NotificationManager::class.java)
                                nm?.notify(NOTIFICATION_ID, notification)
                            }
                        }
                    }
                } catch (e: Exception) {
                    // Safe error handling to avoid any ADB pipe crashes or loop breaks
                    Log.w(TAG, "Error during game auto-detection poll: ${e.message}")
                }
            }
        }
    }

    private suspend fun detectForegroundPackage(): String? {
        // Priority 1: Shizuku dumpsys window / activity (most accurate across all Android versions)
        if (ShizukuShellExecutor.shizukuState.value.isReady) {
            try {
                val res = ShizukuShellExecutor.execute("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
                if (res.isSuccess && res.output.isNotBlank()) {
                    // Output format often: mCurrentFocus=Window{... u0 com.example.game/com.example.game.MainActivity}
                    val line = res.output
                    val regex = Regex("""([a-zA-Z0-9_.]+)/""")
                    val match = regex.find(line)
                    if (match != null) {
                        val pkg = match.groupValues[1]
                        if (pkg != "null" && !pkg.contains("launcher") && !pkg.contains("systemui")) {
                            return pkg
                        }
                    }
                }
            } catch (e: Exception) {
                // Ignore and fall through to fallback
            }
        }

        // Priority 2: UsageStatsManager query (system level)
        try {
            val usageStatsManager = getSystemService(Context.USAGE_STATS_SERVICE) as? UsageStatsManager
            if (usageStatsManager != null) {
                val now = System.currentTimeMillis()
                val events = usageStatsManager.queryEvents(now - 10_000, now)
                val event = UsageEvents.Event()
                var lastForegroundPkg: String? = null
                while (events.hasNextEvent()) {
                    events.getNextEvent(event)
                    if (event.eventType == UsageEvents.Event.ACTIVITY_RESUMED ||
                        event.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND
                    ) {
                        lastForegroundPkg = event.packageName
                    }
                }
                if (!lastForegroundPkg.isNullOrBlank()) {
                    return lastForegroundPkg
                }
            }
        } catch (e: Exception) {
            // Ignore
        }

        // Priority 3: ActivityManager running processes
        try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val runningProcesses = am?.runningAppProcesses
            if (runningProcesses != null) {
                for (info in runningProcesses) {
                    if (info.importance == ActivityManager.RunningAppProcessInfo.IMPORTANCE_FOREGROUND) {
                        val pkg = info.pkgList?.firstOrNull() ?: info.processName
                        if (pkg.isNotBlank() && !pkg.contains("systemui") && !pkg.contains("launcher")) {
                            return pkg
                        }
                    }
                }
            }
        } catch (e: Exception) {
            // Ignore
        }

        return null
    }

    private fun getAppNameFromPackage(packageName: String): String {
        return try {
            val pm = packageManager
            val appInfo = pm.getApplicationInfo(packageName, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            packageName.substringAfterLast('.').replaceFirstChar { it.uppercase() }
        }
    }

    private fun endSessionAndStop() {
        serviceScope.launch {
            revertAppliedToggles()
            executeProfile(PerformanceMode.BALANCED, manual = true)
            _sessionState.value = GameSessionState(isActive = false)
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private suspend fun revertAppliedToggles() {
        Log.i(TAG, "Reverting applied toggles: $appliedToggleIds")
        for (toggleId in appliedToggleIds) {
            val toggle = TurboCatalogue.ALL_TOGGLES.find { it.id == toggleId }
            if (toggle != null) {
                try {
                    ShizukuShellExecutor.execute(toggle.revertCommand)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to revert toggle $toggleId", e)
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Game Turbo Session",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active performance profile and automated game monitoring status"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm?.createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(gameName: String, mode: PerformanceMode): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val restoreIntent = Intent(this, GameSessionService::class.java).apply {
            action = ACTION_STOP_SESSION
        }
        val restorePendingIntent = PendingIntent.getService(
            this, 1, restoreIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = when (mode) {
            PerformanceMode.FULL_POWER -> "🚀 FULL POWER EXTREME — $gameName"
            PerformanceMode.PERFORMANCE -> "⚡ PERFORMANCE MODE — $gameName"
            PerformanceMode.BATTERY_SAVER -> "🔋 BATTERY SAVER MODE ACTIVE"
            PerformanceMode.BALANCED -> "⚖️ BALANCED MODE — Auto-Detection Active"
        }

        val body = when (mode) {
            PerformanceMode.FULL_POWER -> "120Hz unlocked · Thermals bypassed · Max CPU clock"
            PerformanceMode.PERFORMANCE -> "Touch latency reduced · RAM cleared · Governor locked"
            PerformanceMode.BATTERY_SAVER -> "Background capped · Powersave governor · 60Hz"
            PerformanceMode.BALANCED -> "Monitoring foreground games (BGMI, Free Fire, etc.)"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_revert, "RESET BALANCED", restorePendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        autoDetectJob?.cancel()
        serviceScope.launch {
            if (_sessionState.value.isActive) {
                revertAppliedToggles()
                executeProfile(PerformanceMode.BALANCED, manual = true)
                _sessionState.value = GameSessionState(isActive = false)
            }
        }
        super.onDestroy()
    }
}
