package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MonospaceFont
import kotlinx.coroutines.delay

private val RadialDarkStart = Color(0xFF1A0505)
private val RadialDarkEnd = Color(0xFF050202)
private val NeonRed = Color(0xFFFF1E38)
private val NeonRedGlow = Color(0x66FF1E38)
private val CyberGold = Color(0xFFFFCC00)
private val TechMuted = Color(0xFF884444)

@Composable
fun CyberpunkLaunchOverlay(
    gameTitle: String,
    onLaunchComplete: () -> Unit,
    modifier: Modifier = Modifier
) {
    var rawProgress by remember { mutableFloatStateOf(0f) }

    val animatedProgress by animateFloatAsState(
        targetValue = rawProgress,
        animationSpec = tween(durationMillis = 2000, easing = LinearEasing),
        label = "launch_progress"
    )

    // Infinite transitions for rotating scanner ring and pulsating core
    val infiniteTransition = rememberInfiniteTransition(label = "scanner_transition")

    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_scanner_rotation"
    )

    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_scanner_rotation"
    )

    val corePulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_pulse"
    )

    val coreAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_alpha"
    )

    LaunchedEffect(Unit) {
        rawProgress = 1.0f
        delay(2000)
        onLaunchComplete()
    }

    val dynamicStepText = when {
        animatedProgress < 0.25f -> "INITIALIZING RED MAGIC TURBO BUS..."
        animatedProgress < 0.55f -> "OVERRIDING THERMALS (STATUS: 0) & 120Hz LOCK..."
        animatedProgress < 0.85f -> "PURGING DAEMON APPS & CACHES (am kill-all)..."
        else -> "UNLEASHING FULL HARDWARE PERFORMANCE..."
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(RadialDarkStart, RadialDarkEnd),
                    radius = 1200f
                )
            )
            .testTag("cyberpunk_launch_overlay"),
        contentAlignment = Alignment.Center
    ) {
        // High-tech Corner Brackets Canvas
        Canvas(modifier = Modifier.fillMaxSize()) {
            val strokeWidth = 2.dp.toPx()
            val bracketLen = 36.dp.toPx()
            val color = NeonRedGlow

            // Top-left bracket
            drawLine(color, Offset(24f, 24f), Offset(24f + bracketLen, 24f), strokeWidth)
            drawLine(color, Offset(24f, 24f), Offset(24f, 24f + bracketLen), strokeWidth)

            // Top-right bracket
            drawLine(color, Offset(size.width - 24f, 24f), Offset(size.width - 24f - bracketLen, 24f), strokeWidth)
            drawLine(color, Offset(size.width - 24f, 24f), Offset(size.width - 24f, 24f + bracketLen), strokeWidth)

            // Bottom-left bracket
            drawLine(color, Offset(24f, size.height - 24f), Offset(24f + bracketLen, size.height - 24f), strokeWidth)
            drawLine(color, Offset(24f, size.height - 24f), Offset(24f, size.height - 24f - bracketLen), strokeWidth)

            // Bottom-right bracket
            drawLine(color, Offset(size.width - 24f, size.height - 24f), Offset(size.width - 24f - bracketLen, size.height - 24f), strokeWidth)
            drawLine(color, Offset(size.width - 24f, size.height - 24f), Offset(size.width - 24f, size.height - 24f - bracketLen), strokeWidth)
        }

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // RED MAGIC Cyberpunk Tag
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0x33FF1E38))
                    .border(1.dp, NeonRed, RoundedCornerShape(4.dp))
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "RED MAGIC // GAME SPACE",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = MonospaceFont,
                        fontWeight = FontWeight.Black,
                        letterSpacing = 2.sp
                    ),
                    color = NeonRed
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // The Glowing Scanner Ring & Pulsating Core
            Box(
                modifier = Modifier
                    .size(220.dp)
                    .testTag("cyberpunk_scanner_ring"),
                contentAlignment = Alignment.Center
            ) {
                // Outer rotating scanner canvas
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .rotate(outerRotation)
                ) {
                    val stroke = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
                    // Neon arcs
                    drawArc(
                        color = NeonRed,
                        startAngle = 0f,
                        sweepAngle = 75f,
                        useCenter = false,
                        style = stroke
                    )
                    drawArc(
                        color = NeonRed,
                        startAngle = 120f,
                        sweepAngle = 75f,
                        useCenter = false,
                        style = stroke
                    )
                    drawArc(
                        color = NeonRed,
                        startAngle = 240f,
                        sweepAngle = 75f,
                        useCenter = false,
                        style = stroke
                    )

                    // Subtle crosshair indicators
                    val radius = size.minDimension / 2
                    val center = Offset(size.width / 2, size.height / 2)
                    drawLine(
                        color = NeonRedGlow,
                        start = Offset(center.x - radius, center.y),
                        end = Offset(center.x - radius + 15f, center.y),
                        strokeWidth = 2.dp.toPx()
                    )
                    drawLine(
                        color = NeonRedGlow,
                        start = Offset(center.x + radius - 15f, center.y),
                        end = Offset(center.x + radius, center.y),
                        strokeWidth = 2.dp.toPx()
                    )
                }

                // Inner counter-rotating ring
                Canvas(
                    modifier = Modifier
                        .size(170.dp)
                        .rotate(innerRotation)
                ) {
                    val stroke = Stroke(width = 2.dp.toPx())
                    drawArc(
                        color = CyberGold,
                        startAngle = 45f,
                        sweepAngle = 90f,
                        useCenter = false,
                        style = stroke
                    )
                    drawArc(
                        color = CyberGold,
                        startAngle = 225f,
                        sweepAngle = 90f,
                        useCenter = false,
                        style = stroke
                    )
                }

                // Pulsating Energy Core Icon (⚡)
                Box(
                    modifier = Modifier
                        .size(90.dp)
                        .scale(corePulse)
                        .clip(CircleShape)
                        .background(
                            Brush.radialGradient(
                                colors = listOf(NeonRed.copy(alpha = coreAlpha), Color.Transparent)
                            )
                        )
                        .border(2.dp, NeonRed.copy(alpha = coreAlpha), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Energy Core",
                        tint = Color.White,
                        modifier = Modifier
                            .size(54.dp)
                            .scale(corePulse)
                    )
                }
            }

            Spacer(modifier = Modifier.height(34.dp))

            // Game Space Cyberpunk Titles
            Text(
                text = "GAME SPACE INITIALIZING",
                style = MaterialTheme.typography.titleLarge.copy(
                    fontFamily = MonospaceFont,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 2.5.sp
                ),
                color = NeonRed,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Unleashing Max Hardware Performance...",
                style = MaterialTheme.typography.bodyMedium.copy(
                    fontFamily = MonospaceFont,
                    fontWeight = FontWeight.Medium
                ),
                color = Color(0xFFDDDDDD),
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "TARGET: ${gameTitle.uppercase()}",
                style = MaterialTheme.typography.labelMedium.copy(
                    fontFamily = MonospaceFont,
                    fontWeight = FontWeight.Bold
                ),
                color = CyberGold
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Progress Bar & Dynamic Hardware Step
            Column(
                modifier = Modifier.fillMaxWidth(0.9f),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LinearProgressIndicator(
                    progress = { animatedProgress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(6.dp)
                        .clip(RoundedCornerShape(3.dp)),
                    color = NeonRed,
                    trackColor = Color(0xFF331111)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = dynamicStepText,
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = MonospaceFont,
                            fontSize = 10.sp
                        ),
                        color = TechMuted,
                        maxLines = 1
                    )
                    Text(
                        text = "${(animatedProgress * 100).toInt()}%",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = MonospaceFont,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        ),
                        color = NeonRed
                    )
                }
            }
        }
    }
}
