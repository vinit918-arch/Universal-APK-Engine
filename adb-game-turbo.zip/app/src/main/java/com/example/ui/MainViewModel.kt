package com.example.ui

import android.app.Application
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PreferencesRepository
import com.example.model.CommandLogEntry
import com.example.model.GameSessionState
import com.example.model.InstalledAppInfo
import com.example.model.SavedGame
import com.example.model.ShizukuState
import com.example.model.TurboCatalogue
import com.example.model.TurboToggle
import com.example.service.GameSessionService
import com.example.util.ShizukuShellExecutor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class MainTab(val title: String) {
    TOGGLES("TOGGLES"),
    GAMES("GAMES"),
    STATUS("STATUS")
}

data class ToggleUiItem(
    val toggle: TurboToggle,
    val isEnabledInSettings: Boolean,
    val isCurrentlyAppliedInSession: Boolean,
    val isExecuting: Boolean = false
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = PreferencesRepository(application)
    private val packageManager: PackageManager = application.packageManager

    private val _selectedTab = MutableStateFlow(MainTab.TOGGLES)
    val selectedTab: StateFlow<MainTab> = _selectedTab.asStateFlow()

    val shizukuState: StateFlow<ShizukuState> = ShizukuShellExecutor.shizukuState
    val commandLogs: StateFlow<List<CommandLogEntry>> = ShizukuShellExecutor.commandLogs
    val sessionState: StateFlow<GameSessionState> = GameSessionService.sessionState
    val savedGames: StateFlow<List<SavedGame>> = repository.savedGamesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _executingToggleIds = MutableStateFlow<Set<String>>(emptySet())

    val toggleUiItems: StateFlow<List<ToggleUiItem>> = combine(
        repository.toggleStatesFlow,
        sessionState,
        _executingToggleIds
    ) { statesMap, session, executingIds ->
        TurboCatalogue.ALL_TOGGLES.map { toggle ->
            val isEnabled = statesMap[toggle.id] ?: toggle.isDefaultEnabled
            val isApplied = session.isActive && session.appliedToggleIds.contains(toggle.id)
            val isExecuting = executingIds.contains(toggle.id)
            ToggleUiItem(
                toggle = toggle,
                isEnabledInSettings = isEnabled,
                isCurrentlyAppliedInSession = isApplied,
                isExecuting = isExecuting
            )
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _installedApps = MutableStateFlow<List<InstalledAppInfo>>(emptyList())
    val installedApps: StateFlow<List<InstalledAppInfo>> = _installedApps.asStateFlow()

    private val _isLoadingApps = MutableStateFlow(false)
    val isLoadingApps: StateFlow<Boolean> = _isLoadingApps.asStateFlow()

    private val _snackbarEvent = MutableSharedFlow<String>()
    val snackbarEvent: SharedFlow<String> = _snackbarEvent.asSharedFlow()

    private val _isTerminalRunning = MutableStateFlow(false)
    val isTerminalRunning: StateFlow<Boolean> = _isTerminalRunning.asStateFlow()

    init {
        ShizukuShellExecutor.refreshStatus()
        loadInstalledApps()
    }

    fun selectTab(tab: MainTab) {
        _selectedTab.value = tab
    }

    fun refreshShizuku() {
        ShizukuShellExecutor.refreshStatus()
    }

    fun requestShizukuPermission() {
        ShizukuShellExecutor.requestPermission()
    }

    fun openShizukuApp() {
        ShizukuShellExecutor.openShizukuApp(getApplication())
    }

    fun onToggleChanged(toggleId: String, enable: Boolean) {
        viewModelScope.launch {
            repository.setToggleState(toggleId, enable)
            val toggle = TurboCatalogue.ALL_TOGGLES.find { it.id == toggleId } ?: return@launch

            if (!enable) {
                // If user toggles OFF, immediately run revert command so state stays clean
                _executingToggleIds.value = _executingToggleIds.value + toggleId
                val log = ShizukuShellExecutor.execute(toggle.revertCommand)
                _executingToggleIds.value = _executingToggleIds.value - toggleId
                if (log.isSuccess) {
                    _snackbarEvent.emit("Reverted: ${toggle.title}")
                } else {
                    _snackbarEvent.emit("Revert failed: ${log.output.take(50)}")
                }
            } else {
                _snackbarEvent.emit("Enabled for next game session: ${toggle.title}")
            }
        }
    }

    fun testRunToggleCommand(toggle: TurboToggle, isApply: Boolean) {
        viewModelScope.launch {
            _executingToggleIds.value = _executingToggleIds.value + toggle.id
            val cmd = if (isApply) toggle.applyCommand else toggle.revertCommand
            val log = ShizukuShellExecutor.execute(cmd)
            _executingToggleIds.value = _executingToggleIds.value - toggle.id

            val actionName = if (isApply) "Applied" else "Reverted"
            if (log.isSuccess) {
                _snackbarEvent.emit("$actionName: ${toggle.title}")
            } else {
                _snackbarEvent.emit("Failed ($actionName): ${log.output.take(60)}")
            }
        }
    }

    fun applyAllTogglesNow() {
        viewModelScope.launch {
            val enabledToggles = toggleUiItems.value.filter { it.isEnabledInSettings }
            if (enabledToggles.isEmpty()) {
                _snackbarEvent.emit("No toggles are enabled in settings.")
                return@launch
            }

            var successCount = 0
            for (item in enabledToggles) {
                val log = ShizukuShellExecutor.execute(item.toggle.applyCommand)
                if (log.isSuccess) successCount++
            }
            _snackbarEvent.emit("Applied $successCount/${enabledToggles.size} ADB tweaks.")
        }
    }

    fun restoreAllTogglesNow() {
        viewModelScope.launch {
            if (sessionState.value.isActive) {
                GameSessionService.stopSession(getApplication())
            }
            var count = 0
            for (toggle in TurboCatalogue.ALL_TOGGLES) {
                val log = ShizukuShellExecutor.execute(toggle.revertCommand)
                if (log.isSuccess) count++
            }
            _snackbarEvent.emit("Restored $count system settings to defaults.")
        }
    }

    fun launchGame(savedGame: SavedGame) {
        viewModelScope.launch {
            if (!shizukuState.value.isReady) {
                _snackbarEvent.emit("Cannot launch: Shizuku permission is required.")
                return@launch
            }

            val enabledToggles = toggleUiItems.value.filter { it.isEnabledInSettings }.map { it.toggle }
            val appliedIds = mutableListOf<String>()

            // 1. Run apply commands in sequence
            for (t in enabledToggles) {
                val log = ShizukuShellExecutor.execute(t.applyCommand)
                if (log.isSuccess) {
                    appliedIds.add(t.id)
                }
            }

            // 2. Start Foreground Session Service
            GameSessionService.startSession(
                context = getApplication(),
                packageName = savedGame.packageName,
                gameName = savedGame.appName,
                appliedIds = appliedIds
            )

            // 3. Launch the game intent
            try {
                val launchIntent = packageManager.getLaunchIntentForPackage(savedGame.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    getApplication<Application>().startActivity(launchIntent)
                    _snackbarEvent.emit("🎮 Game Turbo launched ${savedGame.appName} (${appliedIds.size} tweaks active)")
                } else {
                    _snackbarEvent.emit("Could not find launch intent for ${savedGame.appName}")
                }
            } catch (e: Exception) {
                _snackbarEvent.emit("Launch error: ${e.localizedMessage}")
            }
        }
    }

    fun addSavedGame(appInfo: InstalledAppInfo) {
        viewModelScope.launch {
            val game = SavedGame(
                packageName = appInfo.packageName,
                appName = appInfo.appName
            )
            repository.addSavedGame(game)
            _snackbarEvent.emit("Added ${appInfo.appName} to Game Turbo library")
        }
    }

    fun removeSavedGame(packageName: String) {
        viewModelScope.launch {
            repository.removeSavedGame(packageName)
            _snackbarEvent.emit("Removed from library")
        }
    }

    fun runCustomShellCommand(commandStr: String) {
        if (commandStr.isBlank()) return
        viewModelScope.launch {
            _isTerminalRunning.value = true
            val log = ShizukuShellExecutor.execute(commandStr.trim())
            _isTerminalRunning.value = false
            if (!log.isSuccess) {
                _snackbarEvent.emit("Command failed with exit code ${log.exitCode}")
            }
        }
    }

    fun clearLogs() {
        ShizukuShellExecutor.clearLogs()
    }

    fun loadInstalledApps() {
        viewModelScope.launch {
            _isLoadingApps.value = true
            val apps = withContext(Dispatchers.IO) {
                val intent = Intent(Intent.ACTION_MAIN, null).apply {
                    addCategory(Intent.CATEGORY_LAUNCHER)
                }
                val resolveInfos = packageManager.queryIntentActivities(intent, 0)
                val appList = mutableListOf<InstalledAppInfo>()
                val myPackage = getApplication<Application>().packageName

                for (info in resolveInfos) {
                    val pkg = info.activityInfo.packageName
                    if (pkg == myPackage) continue

                    val label = try {
                        info.loadLabel(packageManager).toString()
                    } catch (e: Exception) {
                        pkg
                    }

                    val isGame = try {
                        val appInfo = packageManager.getApplicationInfo(pkg, 0)
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                            appInfo.category == ApplicationInfo.CATEGORY_GAME
                        } else {
                            (appInfo.flags and ApplicationInfo.FLAG_IS_GAME) != 0
                        }
                    } catch (e: Exception) {
                        false
                    }

                    appList.add(
                        InstalledAppInfo(
                            packageName = pkg,
                            appName = label,
                            isGame = isGame
                        )
                    )
                }
                appList.sortedWith(
                    compareByDescending<InstalledAppInfo> { it.isGame }
                        .thenBy { it.appName.lowercase() }
                )
            }
            _installedApps.value = apps
            _isLoadingApps.value = false
        }
    }

    override fun onCleared() {
        super.onCleared()
    }
}
