package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Hacker & Gamer Neon Theme Colors
val NeonGreen = Color(0xFF00FF88)
val NeonGreenDark = Color(0xFF00B359)
val NeonGreenDim = Color(0xFF0A3320)
val ElectricCyan = Color(0xFF00E5FF)
val ElectricCyanDark = Color(0xFF009EB0)
val CyberAmber = Color(0xFFFFB800)
val CyberRed = Color(0xFFFF3366)
val CyberPurple = Color(0xFFBD00FF)

val DarkBackground = Color(0xFF070A0F)
val DarkSurface = Color(0xFF0E131C)
val DarkSurfaceVariant = Color(0xFF161E2C)
val DarkSurfaceElevated = Color(0xFF1C273A)
val DarkBorder = Color(0xFF26354D)
val DarkBorderActive = Color(0xFF00E5FF)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextMuted = Color(0xFF484F58)
val TextCode = Color(0xFF7EE787)

