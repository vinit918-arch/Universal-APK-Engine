package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CommandLogEntry
import com.example.model.GameSessionState
import com.example.model.ShizukuState
import com.example.ui.components.MonospaceTag
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderActive
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.MonospaceFont
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextCode
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun StatusScreen(
    shizukuState: ShizukuState,
    sessionState: GameSessionState,
    commandLogs: List<CommandLogEntry>,
    isTerminalRunning: Boolean,
    onRefreshShizuku: () -> Unit,
    onRequestPermission: () -> Unit,
    onOpenShizuku: () -> Unit,
    onRunTerminalCommand: (String) -> Unit,
    onRestoreSession: () -> Unit,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    var terminalInput by remember { mutableStateOf("") }
    val quickChips = listOf(
        "am kill-all",
        "settings get global window_animation_scale",
        "dumpsys battery",
        "getprop ro.product.model",
        "settings get system haptic_feedback_enabled"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section 1: Shizuku Node & Security Status
        item {
            ShizukuTelemetryCard(
                state = shizukuState,
                onRefresh = onRefreshShizuku,
                onRequestPermission = onRequestPermission,
                onOpenShizuku = onOpenShizuku
            )
        }

        // Section 2: Active Session Monitor (if active)
        if (sessionState.isActive) {
            item {
                ActiveSessionCard(
                    session = sessionState,
                    onRestoreSession = onRestoreSession
                )
            }
        }

        // Section 3: Hacker Shell Terminal
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("terminal_console_card"),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = ElectricCyan, modifier = Modifier.size(18.dp))
                            Text(
                                text = "ADB SHELL CONSOLE",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontFamily = MonospaceFont,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = ElectricCyan
                            )
                        }
                        MonospaceTag(text = "REMOTE PROCESS", color = ElectricCyan)
                    }

                    Text(
                        text = "Execute arbitrary ADB commands directly through Shizuku's remote process runtime.",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )

                    // Quick Command Chips
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        quickChips.forEach { chipCmd ->
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable {
                                        terminalInput = chipCmd
                                        onRunTerminalCommand(chipCmd)
                                    },
                                color = DarkSurfaceElevated,
                                border = BorderStroke(0.8.dp, DarkBorder)
                            ) {
                                Text(
                                    text = chipCmd,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont),
                                    color = TextCode
                                )
                            }
                        }
                    }

                    // Terminal Input Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = terminalInput,
                            onValueChange = { terminalInput = it },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("terminal_command_input"),
                            placeholder = { Text("e.g. pm list packages", color = TextMuted, fontFamily = MonospaceFont, fontSize = 12.sp) },
                            textStyle = MaterialTheme.typography.bodyMedium.copy(fontFamily = MonospaceFont, color = TextCode),
                            shape = RoundedCornerShape(8.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = ElectricCyan,
                                unfocusedBorderColor = DarkBorder,
                                focusedContainerColor = DarkBackground,
                                unfocusedContainerColor = DarkBackground
                            ),
                            singleLine = true
                        )

                        Button(
                            onClick = {
                                if (terminalInput.isNotBlank()) {
                                    onRunTerminalCommand(terminalInput)
                                }
                            },
                            enabled = !isTerminalRunning && terminalInput.isNotBlank(),
                            modifier = Modifier
                                .height(52.dp)
                                .testTag("terminal_run_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NeonGreen,
                                contentColor = DarkBackground
                            )
                        ) {
                            if (isTerminalRunning) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = DarkBackground, strokeWidth = 2.dp)
                            } else {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Run command")
                            }
                        }
                    }
                }
            }
        }

        // Section 4: Shell Execution Logs Feed
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "EXECUTION LOGS (${commandLogs.size})",
                    style = MaterialTheme.typography.labelMedium.copy(
                        fontFamily = MonospaceFont,
                        letterSpacing = 1.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = ElectricCyan
                )

                if (commandLogs.isNotEmpty()) {
                    OutlinedButton(
                        onClick = onClearLogs,
                        modifier = Modifier.testTag("clear_logs_button"),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(0.8.dp, DarkBorder),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = TextSecondary),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Icon(Icons.Default.ClearAll, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear", fontSize = 11.sp, fontFamily = MonospaceFont)
                    }
                }
            }
        }

        if (commandLogs.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurface)
                        .border(1.dp, DarkBorder, RoundedCornerShape(10.dp))
                        .padding(24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No ADB commands executed yet.",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFont),
                        color = TextSecondary
                    )
                }
            }
        } else {
            items(commandLogs, key = { it.id }) { log ->
                CommandLogItem(log = log)
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ShizukuTelemetryCard(
    state: ShizukuState,
    onRefresh: () -> Unit,
    onRequestPermission: () -> Unit,
    onOpenShizuku: () -> Unit
) {
    val borderColor = when (state) {
        is ShizukuState.Ready -> NeonGreen.copy(alpha = 0.5f)
        is ShizukuState.VersionWarning -> CyberAmber.copy(alpha = 0.7f)
        is ShizukuState.PermissionDenied -> CyberAmber.copy(alpha = 0.5f)
        is ShizukuState.NotRunning -> CyberRed.copy(alpha = 0.5f)
        is ShizukuState.NotInstalled -> CyberRed.copy(alpha = 0.6f)
    }

    val statusTagText = when (state) {
        is ShizukuState.Ready -> "OPERATIONAL"
        is ShizukuState.VersionWarning -> "OUTDATED API"
        is ShizukuState.PermissionDenied -> "AUTH REQUIRED"
        is ShizukuState.NotRunning -> "SERVICE OFFLINE"
        is ShizukuState.NotInstalled -> "NOT INSTALLED"
    }

    val statusTagColor = when (state) {
        is ShizukuState.Ready -> NeonGreen
        is ShizukuState.VersionWarning -> CyberAmber
        is ShizukuState.PermissionDenied -> CyberAmber
        is ShizukuState.NotRunning, is ShizukuState.NotInstalled -> CyberRed
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("shizuku_telemetry_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (state.isReady) Icons.Default.CheckCircle else Icons.Default.Security,
                        contentDescription = null,
                        tint = statusTagColor,
                        modifier = Modifier.size(20.dp)
                    )
                    Text(
                        text = "SHIZUKU CORE STATUS",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = MonospaceFont,
                            fontWeight = FontWeight.Bold
                        ),
                        color = TextPrimary
                    )
                }

                MonospaceTag(
                    text = statusTagText,
                    color = statusTagColor
                )
            }

            // Description of current state
            Text(
                text = state.statusSummary,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            // Version Warning Card if applicable
            if (state is ShizukuState.VersionWarning) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(CyberAmber.copy(alpha = 0.12f))
                        .border(1.dp, CyberAmber.copy(alpha = 0.4f), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = "⚠️ Warning: Installed Shizuku API version (${state.version}) is below minimum required (${state.minRequired}). Some features or permissions may fail silently. Please update Shizuku.",
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFont),
                        color = CyberAmber
                    )
                }
            }

            // Grid of Diagnostics
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(DarkBackground)
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                StatusMetric(label = "BINDER", value = if (state.isBinderAlive) "CONNECTED" else "OFFLINE", isGood = state.isBinderAlive)
                StatusMetric(label = "PERMISSION", value = if (state.hasPermission) "GRANTED" else "DENIED", isGood = state.hasPermission)
                StatusMetric(label = "API VER", value = if (state.version > 0) "v${state.version}" else "N/A", isGood = state.version >= 11)
                StatusMetric(label = "SERVER UID", value = if (state.uid >= 0) "${state.uid}" else "N/A", isGood = state.uid >= 0)
            }

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (state) {
                    is ShizukuState.NotInstalled, is ShizukuState.NotRunning -> {
                        Button(
                            onClick = onOpenShizuku,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_shizuku_status_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberRed)
                        ) {
                            Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = if (state is ShizukuState.NotInstalled) "Install Shizuku" else "Open Shizuku",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    is ShizukuState.PermissionDenied -> {
                        Button(
                            onClick = onRequestPermission,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("request_permission_status_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CyberAmber, contentColor = DarkBackground)
                        ) {
                            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Request Auth", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    else -> {
                        // Already Ready or VersionWarning
                    }
                }

                // Dedicated Retry Detection Button
                OutlinedButton(
                    onClick = onRefresh,
                    modifier = if (state.isReady) Modifier.fillMaxWidth() else Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, if (state.isReady) DarkBorder else ElectricCyan.copy(alpha = 0.7f)),
                    colors = ButtonDefaults.outlinedButtonColors(
                        containerColor = if (state.isReady) Color.Transparent else ElectricCyan.copy(alpha = 0.08f),
                        contentColor = if (state.isReady) TextPrimary else ElectricCyan
                    )
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = "Retry Detection", modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Retry Detection",
                        fontSize = 11.sp,
                        fontFamily = MonospaceFont,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusMetric(label: String, value: String, isGood: Boolean) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont, fontSize = 9.sp), color = TextMuted)
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFont, fontWeight = FontWeight.Bold),
            color = if (isGood) NeonGreen else CyberRed
        )
    }
}

@Composable
private fun ActiveSessionCard(
    session: GameSessionState,
    onRestoreSession: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("active_session_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = BorderStroke(1.dp, NeonGreen)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIVE ACTIVE SESSION",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont, letterSpacing = 1.sp),
                        color = NeonGreen
                    )
                    Text(
                        text = session.gameName ?: "Unknown Game",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                }

                Button(
                    onClick = onRestoreSession,
                    modifier = Modifier.testTag("session_restore_now_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyberRed)
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("RESTORE NOW", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }

            Text(
                text = "${session.appliedToggleIds.size} ADB system tweaks actively applied. Background service polling every 6s for game exit.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun CommandLogItem(log: CommandLogEntry) {
    var isExpanded by remember { mutableStateOf(false) }
    val timeFormat = remember { SimpleDateFormat("HH:mm:ss", Locale.getDefault()) }
    val formattedTime = remember(log.timestamp) { timeFormat.format(Date(log.timestamp)) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { isExpanded = !isExpanded }
            .testTag("log_item_${log.id}"),
        shape = RoundedCornerShape(8.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = BorderStroke(0.8.dp, if (log.isSuccess) DarkBorder else CyberRed.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = if (log.isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                    contentDescription = null,
                    tint = if (log.isSuccess) NeonGreen else CyberRed,
                    modifier = Modifier.size(16.dp)
                )

                Text(
                    text = log.command,
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFont, fontWeight = FontWeight.Bold),
                    color = if (log.isSuccess) TextCode else CyberRed,
                    modifier = Modifier.weight(1f),
                    maxLines = if (isExpanded) 4 else 1
                )

                Text(
                    text = "${log.durationMs}ms",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont),
                    color = TextMuted
                )

                Text(
                    text = formattedTime,
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont),
                    color = TextMuted
                )

                Icon(
                    imageVector = if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }

            AnimatedVisibility(visible = isExpanded) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(DarkBackground)
                        .padding(8.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(
                            text = "Exit Code: ${log.exitCode} | Duration: ${log.durationMs}ms",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont),
                            color = ElectricCyan
                        )
                        Text(
                            text = log.output,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFont),
                            color = if (log.isSuccess) TextPrimary else CyberRed,
                            fontSize = 11.sp
                        )
                    }
                }
            }
        }
    }
}
