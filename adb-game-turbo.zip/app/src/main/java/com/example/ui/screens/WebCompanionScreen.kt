package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.MonospaceFont
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun WebCompanionScreen(
    onBack: () -> Unit,
    onShowSnackbar: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("LIVE WEB DASHBOARD", "HTML/CSS/JS CODE", "PYTHON ADB DAEMON")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("web_companion_screen")
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            IconButton(
                onClick = onBack,
                modifier = Modifier.testTag("web_companion_back_btn")
            ) {
                Icon(
                    imageVector = Icons.Default.ArrowBack,
                    contentDescription = "Back",
                    tint = TextPrimary
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "DESKTOP & WEB COMPANION",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = MonospaceFont,
                        letterSpacing = 1.2.sp
                    ),
                    color = ElectricCyan
                )
                Text(
                    text = "Web Dashboard & ADB Daemon",
                    style = MaterialTheme.typography.titleMedium,
                    color = TextPrimary
                )
            }
        }

        // Sub Tabs
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = DarkSurface,
            contentColor = ElectricCyan,
            indicator = { tabPositions ->
                TabRowDefaults.SecondaryIndicator(
                    modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                    color = ElectricCyan
                )
            }
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                fontWeight = FontWeight.Bold,
                                fontSize = 10.sp
                            )
                        )
                    }
                )
            }
        }

        when (selectedTab) {
            0 -> LiveWebDashboardView()
            1 -> CodeViewer(
                title = "Modern Cyberpunk Web Dashboard (HTML5/CSS3/JS)",
                code = WEB_DASHBOARD_CODE,
                onCopy = {
                    copyToClipboard(context, "Web Dashboard HTML", WEB_DASHBOARD_CODE)
                    onShowSnackbar("Copied HTML/CSS/JS Web Dashboard code!")
                }
            )
            2 -> CodeViewer(
                title = "Foreground Game State Manager (Python/ADB)",
                code = PYTHON_ADB_DAEMON_CODE,
                onCopy = {
                    copyToClipboard(context, "Python ADB Daemon", PYTHON_ADB_DAEMON_CODE)
                    onShowSnackbar("Copied Python ADB daemon script!")
                }
            )
        }
    }
}

@Composable
private fun LiveWebDashboardView() {
    AndroidView(
        modifier = Modifier
            .fillMaxSize()
            .testTag("web_dashboard_webview"),
        factory = { ctx ->
            WebView(ctx).apply {
                settings.javaScriptEnabled = true
                settings.domStorageEnabled = true
                webViewClient = WebViewClient()
                loadDataWithBaseURL(null, WEB_DASHBOARD_CODE, "text/html", "UTF-8", null)
            }
        }
    )
}

@Composable
private fun CodeViewer(
    title: String,
    code: String,
    onCopy: () -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall.copy(fontFamily = MonospaceFont),
                    color = ElectricCyan,
                    modifier = Modifier.weight(1f)
                )

                Button(
                    onClick = onCopy,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = ElectricCyan,
                        contentColor = DarkBackground
                    )
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("COPY", fontFamily = MonospaceFont, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF090D12)),
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Text(
                    text = code,
                    style = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = MonospaceFont,
                        fontSize = 11.sp,
                        lineHeight = 16.sp
                    ),
                    color = NeonGreen,
                    modifier = Modifier.padding(14.dp)
                )
            }
        }
    }
}

private fun copyToClipboard(context: Context, label: String, text: String) {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    val clip = ClipData.newPlainText(label, text)
    clipboard?.setPrimaryClip(clip)
}

// Complete, pristine, self-contained modern HTML/CSS/JS Dashboard
private const val WEB_DASHBOARD_CODE = """<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>RED MAGIC // GAME TURBO DASHBOARD</title>
  <style>
    :root {
      --bg-dark: #07090e;
      --surface-dark: #0f141c;
      --surface-card: #141c26;
      --neon-red: #ff1e38;
      --neon-green: #00ff88;
      --neon-cyan: #00e5ff;
      --neon-amber: #ffaa00;
      --text-main: #f0f4f8;
      --text-muted: #7e8b9b;
      --border-dark: #222d3d;
      --font-mono: 'Consolas', 'Courier New', monospace;
    }
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      background-color: var(--bg-dark);
      color: var(--text-main);
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }
    header {
      background: var(--surface-dark);
      border-bottom: 1px solid var(--border-dark);
      padding: 16px 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .brand {
      font-family: var(--font-mono);
      font-size: 18px;
      font-weight: 900;
      letter-spacing: 2px;
      color: var(--neon-red);
      display: flex;
      align-items: center;
      gap: 10px;
    }
    .badge {
      background: rgba(255, 30, 56, 0.15);
      border: 1px solid var(--neon-red);
      color: var(--neon-red);
      padding: 4px 10px;
      font-size: 11px;
      border-radius: 4px;
      font-family: var(--font-mono);
      font-weight: bold;
    }
    main {
      padding: 24px;
      max-width: 1200px;
      margin: 0 auto;
      width: 100%;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 20px;
    }
    .card {
      background: var(--surface-card);
      border: 1px solid var(--border-dark);
      border-radius: 12px;
      padding: 20px;
      transition: all 0.25s ease;
      display: flex;
      flex-direction: column;
      gap: 14px;
      position: relative;
      cursor: pointer;
    }
    .card:hover {
      border-color: var(--neon-cyan);
      transform: translateY(-2px);
      box-shadow: 0 8px 24px rgba(0, 229, 255, 0.1);
    }
    .card.active {
      border-color: var(--neon-red);
      box-shadow: 0 0 20px rgba(255, 30, 56, 0.25);
    }
    .card-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .card-title {
      font-size: 18px;
      font-weight: 700;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .card-desc {
      color: var(--text-muted);
      font-size: 13px;
      line-height: 1.5;
    }
    .commands-box {
      background: #080c10;
      border: 1px solid #1a2330;
      border-radius: 6px;
      padding: 10px;
      font-family: var(--font-mono);
      font-size: 11px;
      color: var(--neon-green);
      line-height: 1.6;
      max-height: 100px;
      overflow-y: auto;
    }
    .btn-apply {
      background: var(--surface-dark);
      border: 1px solid var(--border-dark);
      color: var(--text-main);
      padding: 10px 16px;
      border-radius: 6px;
      font-family: var(--font-mono);
      font-weight: bold;
      font-size: 12px;
      cursor: pointer;
      transition: all 0.2s ease;
      margin-top: auto;
    }
    .card.active .btn-apply {
      background: var(--neon-red);
      color: #fff;
      border-color: var(--neon-red);
    }
    /* Cyberpunk Launch Overlay */
    #launch-overlay {
      position: fixed;
      inset: 0;
      background: radial-gradient(circle, #1a0505 0%, #050202 100%);
      display: none;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      z-index: 9999;
    }
    .scanner-ring {
      width: 180px;
      height: 180px;
      border-radius: 50%;
      border: 3px dashed var(--neon-red);
      animation: spin 2s linear infinite;
      display: flex;
      justify-content: center;
      align-items: center;
      box-shadow: 0 0 30px rgba(255, 30, 56, 0.4);
    }
    .energy-core {
      width: 80px;
      height: 80px;
      background: radial-gradient(circle, #ff1e38 0%, transparent 70%);
      border-radius: 50%;
      display: flex;
      justify-content: center;
      align-items: center;
      font-size: 36px;
      animation: pulse 0.6s ease-in-out infinite alternate;
    }
    @keyframes spin { 100% { transform: rotate(360deg); } }
    @keyframes pulse { 0% { transform: scale(0.9); } 100% { transform: scale(1.15); } }
    .status-text {
      margin-top: 30px;
      font-family: var(--font-mono);
      color: var(--neon-red);
      font-size: 20px;
      font-weight: 900;
      letter-spacing: 3px;
    }
    .sub-status {
      color: #ccc;
      font-size: 13px;
      margin-top: 8px;
      font-family: var(--font-mono);
    }
  </style>
</head>
<body>
  <header>
    <div class="brand">
      <span>⚡</span> RED MAGIC // ADB GAME TURBO
    </div>
    <div id="status-badge" class="badge">SYSTEM READY (120Hz)</div>
  </header>

  <main>
    <!-- Battery Saver Mode -->
    <div class="card" onclick="selectProfile('battery_saver')">
      <div class="card-header">
        <div class="card-title">🔋 Battery Saver</div>
        <span class="badge" style="color:var(--neon-green); border-color:var(--neon-green);">ECO 60Hz</span>
      </div>
      <div class="card-desc">Underclocks CPU governor to powersave, enforces 60Hz display, and limits phantom background processes.</div>
      <div class="commands-box">
        $ settings put global low_power 1<br>
        $ cmd power set-adaptive-power-saver-enabled true<br>
        $ settings put system peak_refresh_rate 60.0
      </div>
      <button class="btn-apply" id="btn-battery_saver">ACTIVATE ECO</button>
    </div>

    <!-- Balanced Mode -->
    <div class="card active" onclick="selectProfile('balanced')">
      <div class="card-header">
        <div class="card-title">⚖️ Balanced Mode</div>
        <span class="badge" style="color:var(--neon-cyan); border-color:var(--neon-cyan);">DEFAULT</span>
      </div>
      <div class="card-desc">Standard daily-driver configuration using schedutil frequency scaling, normal thermals, and dynamic refresh rate.</div>
      <div class="commands-box">
        $ cmd thermalservice reset<br>
        $ cmd power set-adaptive-power-saver-enabled false<br>
        $ settings put system peak_refresh_rate 90.0
      </div>
      <button class="btn-apply" id="btn-balanced">ACTIVE PROFILE</button>
    </div>

    <!-- Performance Mode -->
    <div class="card" onclick="selectProfile('performance')">
      <div class="card-header">
        <div class="card-title">⚡ Performance Mode</div>
        <span class="badge" style="color:var(--neon-amber); border-color:var(--neon-amber);">TURBO</span>
      </div>
      <div class="card-desc">Locks CPU to performance governor, optimizes touch pressure sampling rate, clears RAM cache, and zeroes animation latency.</div>
      <div class="commands-box">
        $ cmd power set-fixed-performance-mode-enabled true<br>
        $ settings put secure touch_pressure_scale 0.001<br>
        $ cmd package trim-caches 4096G
      </div>
      <button class="btn-apply" id="btn-performance">ACTIVATE TURBO</button>
    </div>

    <!-- Full Power Mode (Extreme) -->
    <div class="card" onclick="triggerLaunchAnimation('BGMI / Free Fire')">
      <div class="card-header">
        <div class="card-title">🚀 Full Power Mode</div>
        <span class="badge">EXTREME 120Hz</span>
      </div>
      <div class="card-desc">Forces maximum CPU/GPU frequency, overrides thermal throttling (thermalservice override-status 0), and locks 120Hz.</div>
      <div class="commands-box">
        $ cmd power set-fixed-performance-mode-enabled true<br>
        $ cmd thermalservice override-status 0<br>
        $ settings put system peak_refresh_rate 120.0
      </div>
      <button class="btn-apply" id="btn-full_power">UNLEASH EXTREME</button>
    </div>
  </main>

  <!-- Red Magic Launch Animation Overlay -->
  <div id="launch-overlay">
    <div class="scanner-ring">
      <div class="energy-core">⚡</div>
    </div>
    <div class="status-text">GAME SPACE INITIALIZING</div>
    <div class="sub-status">Unleashing Max Hardware Performance...</div>
  </div>

  <script>
    function selectProfile(profileId) {
      document.querySelectorAll('.card').forEach(c => c.classList.remove('active'));
      document.querySelectorAll('.btn-apply').forEach(b => b.innerText = 'ACTIVATE');
      const activeBtn = document.getElementById('btn-' + profileId);
      if (activeBtn) {
        activeBtn.closest('.card').classList.add('active');
        activeBtn.innerText = 'ACTIVE PROFILE';
      }
      document.getElementById('status-badge').innerText = 'MODE: ' + profileId.toUpperCase();
    }

    function triggerLaunchAnimation(gameName) {
      const overlay = document.getElementById('launch-overlay');
      overlay.style.display = 'flex';
      selectProfile('full_power');
      setTimeout(() => {
        overlay.style.display = 'none';
        alert('🚀 Game launched: ' + gameName + ' with Full Power Mode Active!');
      }, 2000);
    }
  </script>
</body>
</html>"""

// Complete Python ADB daemon script
private const val PYTHON_ADB_DAEMON_CODE = """# ==============================================================================
# RED MAGIC // ADB GAME TURBO STATE MANAGER & AUTO-DETECTION DAEMON
# Continuously monitors focused foreground applications via ADB.
# Auto-triggers Full Power Mode on designated games (BGMI, Free Fire, etc.)
# Auto-reverts to Balanced Mode on game exit.
# ==============================================================================

import subprocess
import time
import re
import sys
import signal

# Monitored Game Packages
DESIGNATED_GAMES = {
    "com.pubg.imobile": "BGMI (Battlegrounds Mobile India)",
    "com.dts.freefireth": "Free Fire",
    "com.dts.freefiremax": "Free Fire MAX",
    "com.tencent.ig": "PUBG Mobile (Global)",
    "com.activision.callofduty.shooter": "Call of Duty Mobile",
    "com.mobile.legends": "Mobile Legends",
    "com.miHoYo.GenshinImpact": "Genshin Impact"
}

# Profile Commands
PROFILE_FULL_POWER = [
    "cmd power set-fixed-performance-mode-enabled true",
    "cmd thermalservice override-status 0",
    "settings put system peak_refresh_rate 120.0",
    "settings put system min_refresh_rate 120.0",
    "settings put global force_gpu_rendering 1",
    "settings put global game_driver_all_apps 1",
    "settings put global window_animation_scale 0",
    "settings put global transition_animation_scale 0",
    "settings put global animator_duration_scale 0",
    "cmd deviceidle disable all",
    "device_config put activity_manager max_phantom_processes 2147483647",
    "am kill-all"
]

PROFILE_BALANCED = [
    "cmd power set-fixed-performance-mode-enabled false",
    "cmd thermalservice reset",
    "cmd deviceidle unforce",
    "settings put global force_gpu_rendering 0",
    "device_config delete activity_manager max_phantom_processes",
    "settings put global window_animation_scale 1",
    "settings put global transition_animation_scale 1",
    "settings put global animator_duration_scale 1",
    "settings put system peak_refresh_rate 90.0"
]

current_mode = "BALANCED"
running = True

def adb_exec(cmd):
    try:
        res = subprocess.run(["adb", "shell", cmd], capture_output=True, text=True, timeout=5)
        return res.stdout.strip()
    except subprocess.SubprocessError as e:
        print(f"[!] ADB Pipe Error: {e}")
        return ""

def apply_profile(mode_name, commands):
    global current_mode
    if current_mode == mode_name:
        return
    print(f"\n[⚡] SWITCHING PERFORMANCE MODE: {current_mode} -> {mode_name}")
    for cmd in commands:
        adb_exec(cmd)
    current_mode = mode_name
    print(f"[✓] Successfully activated {mode_name}!\n")

def get_focused_package():
    output = adb_exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
    if output:
        match = re.search(r'([a-zA-Z0-9_.]+)/', output)
        if match:
            pkg = match.group(1)
            if pkg != "null" and "launcher" not in pkg and "systemui" not in pkg:
                return pkg
    return None

def sig_handler(sig, frame):
    global running
    print("\n[!] Stopping daemon. Reverting to Balanced Mode...")
    running = False
    apply_profile("BALANCED", PROFILE_BALANCED)
    sys.exit(0)

signal.signal(signal.SIGINT, sig_handler)
signal.signal(signal.SIGTERM, sig_handler)

def main():
    print("=" * 65)
    print("  RED MAGIC // ADB GAME TURBO DAEMON RUNNING")
    print("  Target Games: BGMI, Free Fire, COD Mobile, Genshin Impact")
    print("  Polling Frequency: 2.5s (Safe battery & pipe rate)")
    print("=" * 65)

    consecutive_misses = 0

    while running:
        time.sleep(2.5)
        pkg = get_focused_package()

        if pkg in DESIGNATED_GAMES:
            game_name = DESIGNATED_GAMES[pkg]
            consecutive_misses = 0
            if current_mode != "FULL_POWER":
                print(f"[🎮] DETECTED GAME IN FOREGROUND: {game_name} ({pkg})")
                apply_profile("FULL_POWER", PROFILE_FULL_POWER)
        else:
            if current_mode == "FULL_POWER":
                consecutive_misses += 1
                if consecutive_misses >= 2:
                    print("[🔄] Game exited / backgrounded. Auto-reverting to BALANCED MODE.")
                    apply_profile("BALANCED", PROFILE_BALANCED)
                    consecutive_misses = 0

if __name__ == "__main__":
    main()
"""
