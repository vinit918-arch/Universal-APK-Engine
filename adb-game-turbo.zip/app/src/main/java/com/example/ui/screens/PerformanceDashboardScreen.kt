package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoMode
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GameSessionState
import com.example.model.PerformanceMode
import com.example.ui.components.MonospaceTag
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderActive
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.MonospaceFont
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun PerformanceDashboardScreen(
    currentProfile: PerformanceMode,
    isAutoDetectEnabled: Boolean,
    detectedForegroundPkg: String?,
    sessionState: GameSessionState,
    isExecuting: Boolean,
    onSelectProfile: (PerformanceMode) -> Unit,
    onToggleAutoDetect: (Boolean) -> Unit,
    onOpenWebCompanion: () -> Unit,
    onQuickTrimCache: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
            .testTag("performance_dashboard_screen"),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Dashboard Title & Web Companion Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "HARDWARE TUNER",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = MonospaceFont,
                            letterSpacing = 1.4.sp
                        ),
                        color = ElectricCyan
                    )
                    Text(
                        text = "Performance Profiles",
                        style = MaterialTheme.typography.titleLarge,
                        color = TextPrimary
                    )
                }

                Button(
                    onClick = onOpenWebCompanion,
                    modifier = Modifier.testTag("open_web_dashboard_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DarkSurfaceElevated,
                        contentColor = ElectricCyan
                    ),
                    border = BorderStroke(1.dp, ElectricCyan.copy(alpha = 0.5f))
                ) {
                    Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "WEB & PYTHON",
                        fontFamily = MonospaceFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Live Telemetry HUD Bar
        item {
            TelemetryHudCard(
                currentMode = currentProfile,
                detectedPkg = detectedForegroundPkg,
                sessionState = sessionState
            )
        }

        // Auto-Detection Toggle Switch Banner
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("auto_detect_banner"),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(
                    1.dp,
                    if (isAutoDetectEnabled) NeonGreen.copy(alpha = 0.6f) else DarkBorder
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(if (isAutoDetectEnabled) Color(0x3300FF88) else Color(0x22888888)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoMode,
                                contentDescription = null,
                                tint = if (isAutoDetectEnabled) NeonGreen else TextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "Auto Game Detection",
                                style = MaterialTheme.typography.titleMedium,
                                color = TextPrimary
                            )
                            Text(
                                text = if (isAutoDetectEnabled)
                                    "Monitors BGMI, Free Fire & launched games. Auto Full Power on focus."
                                else
                                    "Background polling paused. Manual profile mode only.",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondary
                            )
                        }
                    }

                    Switch(
                        checked = isAutoDetectEnabled,
                        onCheckedChange = onToggleAutoDetect,
                        modifier = Modifier.testTag("auto_detect_switch"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = NeonGreen,
                            checkedTrackColor = Color(0xFF1E3A28),
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = DarkSurfaceElevated
                        )
                    )
                }
            }
        }

        // 4 Performance Profile Cards Section Header
        item {
            Text(
                text = "SELECT PERFORMANCE PROFILE",
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = MonospaceFont,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.2.sp
                ),
                color = TextSecondary
            )
        }

        // Render each of the 4 Profiles
        items(PerformanceMode.values()) { mode ->
            ProfileCard(
                mode = mode,
                isSelected = currentProfile == mode,
                isExecuting = isExecuting,
                onSelect = { onSelectProfile(mode) }
            )
        }

        // Quick Maintenance Tools Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                border = BorderStroke(1.dp, DarkBorder)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "QUICK HARDWARE ACTIONS",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = MonospaceFont,
                            letterSpacing = 1.sp
                        ),
                        color = ElectricCyan
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = onQuickTrimCache,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("quick_trim_cache_btn"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceElevated,
                                contentColor = TextPrimary
                            ),
                            border = BorderStroke(1.dp, DarkBorderActive)
                        ) {
                            Icon(Icons.Default.Memory, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Purge RAM Cache", fontSize = 11.sp, fontFamily = MonospaceFont)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun TelemetryHudCard(
    currentMode: PerformanceMode,
    detectedPkg: String?,
    sessionState: GameSessionState
) {
    val modeColor = when (currentMode) {
        PerformanceMode.FULL_POWER -> CyberRed
        PerformanceMode.PERFORMANCE -> CyberOrange
        PerformanceMode.BALANCED -> ElectricCyan
        PerformanceMode.BATTERY_SAVER -> NeonGreen
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("telemetry_hud_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, modeColor.copy(alpha = 0.5f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = currentMode.iconEmoji,
                        fontSize = 20.sp
                    )
                    Column {
                        Text(
                            text = "ACTIVE PROFILE",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                fontSize = 10.sp,
                                letterSpacing = 1.sp
                            ),
                            color = TextSecondary
                        )
                        Text(
                            text = currentMode.title.uppercase(),
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontFamily = MonospaceFont,
                                fontWeight = FontWeight.Black
                            ),
                            color = modeColor
                        )
                    }
                }

                MonospaceTag(
                    text = currentMode.badge,
                    color = modeColor
                )
            }

            // Real-time metric pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MetricPill(
                    label = "GOVERNOR",
                    value = when (currentMode) {
                        PerformanceMode.FULL_POWER, PerformanceMode.PERFORMANCE -> "LOCKED PERF"
                        PerformanceMode.BALANCED -> "SCHEDUTIL"
                        PerformanceMode.BATTERY_SAVER -> "POWERSAVE"
                    },
                    modifier = Modifier.weight(1f)
                )

                MetricPill(
                    label = "REFRESH",
                    value = when (currentMode) {
                        PerformanceMode.FULL_POWER -> "120Hz LOCK"
                        PerformanceMode.PERFORMANCE -> "90/120Hz"
                        PerformanceMode.BALANCED -> "DYNAMIC"
                        PerformanceMode.BATTERY_SAVER -> "60Hz ECO"
                    },
                    modifier = Modifier.weight(1f)
                )

                MetricPill(
                    label = "THERMALS",
                    value = when (currentMode) {
                        PerformanceMode.FULL_POWER -> "BYPASSED (0)"
                        PerformanceMode.PERFORMANCE -> "OPTIMIZED"
                        PerformanceMode.BALANCED -> "STANDARD"
                        PerformanceMode.BATTERY_SAVER -> "AGGRESSIVE"
                    },
                    modifier = Modifier.weight(1f)
                )
            }

            if (sessionState.isActive && !sessionState.gameName.isNullOrBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0x33FF1E38))
                        .padding(horizontal = 10.dp, vertical = 6.dp)
                ) {
                    Text(
                        text = "🎮 ACCELERATING GAME: ${sessionState.gameName.uppercase()}",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = MonospaceFont,
                            fontWeight = FontWeight.Bold
                        ),
                        color = CyberRed
                    )
                }
            } else if (!detectedPkg.isNullOrBlank()) {
                Text(
                    text = "Focused window: $detectedPkg",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = MonospaceFont,
                        fontSize = 10.sp
                    ),
                    color = TextMuted
                )
            }
        }
    }
}

@Composable
private fun MetricPill(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(DarkSurfaceElevated)
            .border(1.dp, DarkBorder, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 6.dp)
    ) {
        Column {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = MonospaceFont,
                    fontSize = 9.sp
                ),
                color = TextSecondary
            )
            Text(
                text = value,
                style = MaterialTheme.typography.labelSmall.copy(
                    fontFamily = MonospaceFont,
                    fontWeight = FontWeight.Bold,
                    fontSize = 11.sp
                ),
                color = TextPrimary
            )
        }
    }
}

@Composable
private fun ProfileCard(
    mode: PerformanceMode,
    isSelected: Boolean,
    isExecuting: Boolean,
    onSelect: () -> Unit
) {
    var expandedCommands by remember { mutableStateOf(false) }

    val borderColor by animateColorAsState(
        targetValue = when {
            isSelected && mode == PerformanceMode.FULL_POWER -> CyberRed
            isSelected && mode == PerformanceMode.PERFORMANCE -> CyberOrange
            isSelected && mode == PerformanceMode.BALANCED -> ElectricCyan
            isSelected && mode == PerformanceMode.BATTERY_SAVER -> NeonGreen
            else -> DarkBorder
        },
        label = "profile_border"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("profile_card_${mode.id}")
            .clickable { onSelect() },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) DarkSurfaceElevated else DarkSurface
        ),
        border = BorderStroke(if (isSelected) 1.5.dp else 1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(text = mode.iconEmoji, fontSize = 22.sp)
                    Column {
                        Text(
                            text = mode.title,
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold
                            ),
                            color = TextPrimary
                        )
                        Text(
                            text = mode.subtitle,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                fontSize = 10.sp
                            ),
                            color = TextSecondary
                        )
                    }
                }

                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Active",
                        tint = borderColor,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }

            Text(
                text = mode.description,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )

            // Applied system commands preview toggle
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { expandedCommands = !expandedCommands },
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = if (expandedCommands) "▼ HIDE SYSTEM COMMANDS (${mode.commands.size})" else "▶ VIEW ADB COMMANDS (${mode.commands.size})",
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontFamily = MonospaceFont,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold
                    ),
                    color = ElectricCyan
                )

                MonospaceTag(
                    text = mode.badge,
                    color = if (isSelected) borderColor else TextSecondary
                )
            }

            if (expandedCommands) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(Color(0xFF0C1014))
                        .padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    for (cmd in mode.commands) {
                        Text(
                            text = "$ $cmd",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                fontSize = 9.5.sp
                            ),
                            color = NeonGreen
                        )
                    }
                }
            }

            // Apply button
            Button(
                onClick = onSelect,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("apply_profile_${mode.id}"),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSelected) borderColor else DarkSurfaceElevated,
                    contentColor = if (isSelected) DarkBackground else TextPrimary
                ),
                border = BorderStroke(1.dp, if (isSelected) borderColor else DarkBorder)
            ) {
                if (isExecuting && isSelected) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = DarkBackground,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("APPLYING...", fontFamily = MonospaceFont, fontWeight = FontWeight.Bold)
                } else {
                    Text(
                        text = if (isSelected) "CURRENT ACTIVE PROFILE" else "ACTIVATE ${mode.title.uppercase()}",
                        fontFamily = MonospaceFont,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}
