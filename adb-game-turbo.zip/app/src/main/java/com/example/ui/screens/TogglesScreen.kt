package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoNotDisturb
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.ToggleCategory
import com.example.model.TurboToggle
import com.example.ui.ToggleUiItem
import com.example.ui.components.MonospaceTag
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberRed
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkBorderActive
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.MonospaceFont
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenDim
import com.example.ui.theme.TextCode
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun TogglesScreen(
    toggleItems: List<ToggleUiItem>,
    isSessionActive: Boolean,
    onToggleChanged: (String, Boolean) -> Unit,
    onTestCommand: (TurboToggle, Boolean) -> Unit,
    onApplyAll: () -> Unit,
    onRestoreAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    val enabledCount = toggleItems.count { it.isEnabledInSettings }
    val totalCount = toggleItems.size
    val activePercentage = if (totalCount > 0) (enabledCount.toFloat() / totalCount.toFloat()) else 0f

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Overview Card
        item {
            HeroTelemetryCard(
                enabledCount = enabledCount,
                totalCount = totalCount,
                activePercentage = activePercentage,
                isSessionActive = isSessionActive,
                onApplyAll = onApplyAll,
                onRestoreAll = onRestoreAll
            )
        }

        // Group by Categories
        val grouped = toggleItems.groupBy { it.toggle.category }
        ToggleCategory.values().forEach { category ->
            val itemsForCategory = grouped[category] ?: emptyList()
            if (itemsForCategory.isNotEmpty()) {
                item {
                    CategoryHeader(category = category, count = itemsForCategory.count { it.isEnabledInSettings })
                }
                items(itemsForCategory, key = { it.toggle.id }) { item ->
                    ToggleCard(
                        item = item,
                        onToggleChanged = { enabled -> onToggleChanged(item.toggle.id, enabled) },
                        onTestCommand = onTestCommand
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun HeroTelemetryCard(
    enabledCount: Int,
    totalCount: Int,
    activePercentage: Float,
    isSessionActive: Boolean,
    onApplyAll: () -> Unit,
    onRestoreAll: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("hero_telemetry_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, if (isSessionActive) NeonGreen else DarkBorder)
    ) {
        Box(modifier = Modifier.fillMaxWidth()) {
            // Optional background visual asset
            Image(
                painter = painterResource(id = R.drawable.img_turbo_hero),
                contentDescription = "Turbo HUD Banner",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp),
                contentScale = ContentScale.Crop,
                alpha = 0.35f
            )

            // Gradient Overlay
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .background(
                        Brush.verticalGradient(
                            listOf(Color.Transparent, DarkSurface.copy(alpha = 0.95f), DarkSurface)
                        )
                    )
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "SYSTEM ENGINE TWEAKS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                letterSpacing = 1.2.sp
                            ),
                            color = ElectricCyan
                        )
                        Text(
                            text = "Performance Profile",
                            style = MaterialTheme.typography.titleLarge,
                            color = TextPrimary
                        )
                    }

                    MonospaceTag(
                        text = if (isSessionActive) "ENGINE BOOSTED" else "ARMED ($enabledCount/$totalCount)",
                        color = if (isSessionActive) NeonGreen else ElectricCyan
                    )
                }

                // Stats Row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(DarkSurfaceElevated.copy(alpha = 0.8f))
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    MetricItem(
                        label = "ENABLED TWEAKS",
                        value = "$enabledCount / $totalCount",
                        valueColor = if (enabledCount > 0) NeonGreen else TextSecondary
                    )
                    MetricItem(
                        label = "TOUCH OVERHEAD",
                        value = "-15ms",
                        valueColor = ElectricCyan
                    )
                    MetricItem(
                        label = "FRAME LATENCY",
                        value = "MINIMAL",
                        valueColor = NeonGreen
                    )
                }

                // Progress Bar
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "TURBO PROFILE LOADOUT",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont),
                            color = TextSecondary
                        )
                        Text(
                            text = "${(activePercentage * 100).toInt()}% READY",
                            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont),
                            color = NeonGreen
                        )
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(6.dp)
                            .clip(CircleShape)
                            .background(DarkSurfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth(fraction = activePercentage)
                                .height(6.dp)
                                .clip(CircleShape)
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(ElectricCyan, NeonGreen)
                                    )
                                )
                        )
                    }
                }

                // Quick Apply / Restore Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onApplyAll,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("apply_all_now_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonGreen,
                            contentColor = DarkBackground
                        )
                    ) {
                        Icon(Icons.Default.Bolt, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("APPLY ALL NOW", fontWeight = FontWeight.Black, fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onRestoreAll,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("restore_all_toggles_button"),
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, DarkBorder),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = TextPrimary
                        )
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RESTORE ALL", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricItem(
    label: String,
    value: String,
    valueColor: Color
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont, fontSize = 9.sp),
            color = TextSecondary
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontFamily = MonospaceFont,
                fontWeight = FontWeight.Black
            ),
            color = valueColor
        )
    }
}

@Composable
private fun CategoryHeader(
    category: ToggleCategory,
    count: Int
) {
    val icon = when (category) {
        ToggleCategory.DISPLAY_ANIMATIONS -> Icons.Default.Speed
        ToggleCategory.GPU_GRAPHICS -> Icons.Default.Memory
        ToggleCategory.SYSTEM_PERFORMANCE -> Icons.Default.Bolt
        ToggleCategory.IMMERSION_DND -> Icons.Default.DoNotDisturb
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = ElectricCyan,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = category.displayName.uppercase(),
            style = MaterialTheme.typography.labelMedium.copy(
                fontFamily = MonospaceFont,
                letterSpacing = 1.sp,
                fontWeight = FontWeight.Bold
            ),
            color = ElectricCyan
        )
        Spacer(modifier = Modifier.weight(1f))
        Text(
            text = "$count ACTIVE",
            style = MaterialTheme.typography.labelSmall.copy(fontFamily = MonospaceFont),
            color = TextMuted
        )
    }
}

@Composable
private fun ToggleCard(
    item: ToggleUiItem,
    onToggleChanged: (Boolean) -> Unit,
    onTestCommand: (TurboToggle, Boolean) -> Unit
) {
    val isEnabled = item.isEnabledInSettings
    val borderColor by animateColorAsState(
        targetValue = if (item.isCurrentlyAppliedInSession) NeonGreen
        else if (isEnabled) DarkBorderActive.copy(alpha = 0.5f)
        else DarkBorder,
        label = "border_color"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("toggle_card_${item.toggle.id}"),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isEnabled) DarkSurfaceElevated else DarkSurface
        ),
        border = BorderStroke(1.dp, borderColor)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Title & Switch Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = item.toggle.title,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = TextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(2.dp))
                    MonospaceTag(
                        text = item.toggle.impactTag,
                        color = if (isEnabled) NeonGreen else TextMuted
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                if (item.isExecuting) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(28.dp),
                        color = NeonGreen,
                        strokeWidth = 2.5.dp
                    )
                } else {
                    Switch(
                        checked = isEnabled,
                        onCheckedChange = onToggleChanged,
                        modifier = Modifier.testTag("switch_${item.toggle.id}"),
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = DarkBackground,
                            checkedTrackColor = NeonGreen,
                            uncheckedThumbColor = TextSecondary,
                            uncheckedTrackColor = DarkSurfaceVariant,
                            uncheckedBorderColor = DarkBorder
                        )
                    )
                }
            }

            // Description
            Text(
                text = item.toggle.description,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                lineHeight = 18.sp
            )

            // Monospace ADB Command Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(DarkBackground)
                    .border(0.5.dp, DarkBorder, RoundedCornerShape(6.dp))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "$ adb shell ",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = MonospaceFont,
                                fontWeight = FontWeight.Bold
                            ),
                            color = ElectricCyan,
                            fontSize = 11.sp
                        )
                        Text(
                            text = item.toggle.applyCommand,
                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFont),
                            color = TextCode,
                            fontSize = 11.sp
                        )
                    }
                }
            }

            // Interactive Micro-Action: Test Run apply or revert
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { onTestCommand(item.toggle, true) },
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(0.8.dp, NeonGreen.copy(alpha = 0.4f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = NeonGreen),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Test Apply", fontSize = 10.sp, fontFamily = MonospaceFont)
                }

                Spacer(modifier = Modifier.width(8.dp))

                OutlinedButton(
                    onClick = { onTestCommand(item.toggle, false) },
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(0.8.dp, CyberRed.copy(alpha = 0.4f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberRed),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(30.dp)
                ) {
                    Icon(Icons.Default.Restore, contentDescription = null, modifier = Modifier.size(12.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Test Revert", fontSize = 10.sp, fontFamily = MonospaceFont)
                }
            }
        }
    }
}
