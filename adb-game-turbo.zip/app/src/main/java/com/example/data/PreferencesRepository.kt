package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.SavedGame
import com.example.model.TurboCatalogue
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "turbo_preferences")

class PreferencesRepository(private val context: Context) {

    private val KEY_SAVED_GAMES = stringPreferencesKey("saved_games_json_v1")

    // Flow of toggle states: Map<toggleId, Boolean>
    val toggleStatesFlow: Flow<Map<String, Boolean>> = context.dataStore.data.map { preferences ->
        TurboCatalogue.ALL_TOGGLES.associate { toggle ->
            val key = booleanPreferencesKey("toggle_${toggle.id}")
            val isEnabled = preferences[key] ?: toggle.isDefaultEnabled
            toggle.id to isEnabled
        }
    }

    suspend fun setToggleState(toggleId: String, isEnabled: Boolean) {
        context.dataStore.edit { preferences ->
            val key = booleanPreferencesKey("toggle_$toggleId")
            preferences[key] = isEnabled
        }
    }

    suspend fun resetAllToggles(enableAll: Boolean = true) {
        context.dataStore.edit { preferences ->
            TurboCatalogue.ALL_TOGGLES.forEach { toggle ->
                val key = booleanPreferencesKey("toggle_${toggle.id}")
                preferences[key] = enableAll
            }
        }
    }

    // Flow of saved games
    val savedGamesFlow: Flow<List<SavedGame>> = context.dataStore.data.map { preferences ->
        val jsonStr = preferences[KEY_SAVED_GAMES] ?: ""
        if (jsonStr.isBlank()) {
            emptyList()
        } else {
            try {
                val array = JSONArray(jsonStr)
                val list = mutableListOf<SavedGame>()
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        SavedGame(
                            packageName = obj.getString("pkg"),
                            appName = obj.getString("name"),
                            activityName = obj.optString("act").takeIf { it.isNotBlank() },
                            addedAt = obj.optLong("time", System.currentTimeMillis())
                        )
                    )
                }
                list
            } catch (e: Exception) {
                emptyList()
            }
        }
    }

    suspend fun addSavedGame(game: SavedGame) {
        context.dataStore.edit { preferences ->
            val currentList = parseGames(preferences[KEY_SAVED_GAMES] ?: "").toMutableList()
            if (currentList.none { it.packageName == game.packageName }) {
                currentList.add(0, game)
                preferences[KEY_SAVED_GAMES] = serializeGames(currentList)
            }
        }
    }

    suspend fun removeSavedGame(packageName: String) {
        context.dataStore.edit { preferences ->
            val currentList = parseGames(preferences[KEY_SAVED_GAMES] ?: "").filter { it.packageName != packageName }
            preferences[KEY_SAVED_GAMES] = serializeGames(currentList)
        }
    }

    private fun parseGames(jsonStr: String): List<SavedGame> {
        if (jsonStr.isBlank()) return emptyList()
        return try {
            val array = JSONArray(jsonStr)
            val list = mutableListOf<SavedGame>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    SavedGame(
                        packageName = obj.getString("pkg"),
                        appName = obj.getString("name"),
                        activityName = obj.optString("act").takeIf { it.isNotBlank() },
                        addedAt = obj.optLong("time", System.currentTimeMillis())
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun serializeGames(games: List<SavedGame>): String {
        val array = JSONArray()
        for (g in games) {
            val obj = JSONObject()
            obj.put("pkg", g.packageName)
            obj.put("name", g.appName)
            obj.put("act", g.activityName ?: "")
            obj.put("time", g.addedAt)
            array.put(obj)
        }
        return array.toString()
    }
}
