package com.example.data

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import com.example.model.ShizukuState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

object ShizukuStateRepository {
    private const val TAG = "ShizukuDebug"
    const val SHIZUKU_PERMISSION_REQUEST_CODE = 4001
    const val MIN_SHIZUKU_VERSION = 11

    private val _state = MutableStateFlow<ShizukuState>(ShizukuState.NotRunning)
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    private var appContext: Context? = null
    private var isInitialized = false

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "[EVENT] Binder received callback triggered (Sticky)")
        refreshStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.d(TAG, "[EVENT] Binder dead callback triggered — Shizuku service terminated")
        _state.value = ShizukuState.NotRunning
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                Log.d(TAG, "[EVENT] Permission result callback: requestCode=$requestCode, granted=$granted")
                refreshStatus()
            }
        }

    /**
     * Initializes listeners at Application scope.
     * Must be called in Application.onCreate() to register sticky listeners.
     */
    fun initialize(context: Context) {
        if (isInitialized) {
            Log.d(TAG, "ShizukuStateRepository already initialized. Performing refresh.")
            refreshStatus()
            return
        }

        appContext = context.applicationContext
        Log.d(TAG, "Initializing Shizuku listeners in Application scope...")

        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Log.d(TAG, "Registered addBinderReceivedListenerSticky successfully")
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to register addBinderReceivedListenerSticky", e)
        }

        try {
            Shizuku.addBinderDeadListener(binderDeadListener)
            Log.d(TAG, "Registered addBinderDeadListener successfully")
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to register addBinderDeadListener", e)
        }

        try {
            Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
            Log.d(TAG, "Registered addRequestPermissionResultListener successfully")
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to register addRequestPermissionResultListener", e)
        }

        isInitialized = true
        refreshStatus()
    }

    fun isInstalled(context: Context? = appContext): Boolean {
        val ctx = context ?: return false
        val pm = ctx.packageManager
        return try {
            pm.getPackageInfo("moe.shizuku.privileged.api", 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            try {
                pm.getPackageInfo("rikka.shizuku", 0)
                true
            } catch (e2: PackageManager.NameNotFoundException) {
                false
            }
        }
    }

    fun refreshStatus() {
        Log.d(TAG, "--- Performing Shizuku Status Check ---")

        val installed = isInstalled()
        Log.d(TAG, "Shizuku installed check: $installed")
        if (!installed) {
            Log.d(TAG, "State transition -> NotInstalled")
            _state.value = ShizukuState.NotInstalled
            return
        }

        val binderAlive = try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            Log.w(TAG, "pingBinder threw exception: ${e.message}")
            false
        }
        Log.d(TAG, "Shizuku pingBinder result: $binderAlive")

        if (!binderAlive) {
            Log.d(TAG, "State transition -> NotRunning")
            _state.value = ShizukuState.NotRunning
            return
        }

        val version = try {
            Shizuku.getVersion()
        } catch (e: Throwable) {
            Log.w(TAG, "Shizuku.getVersion() failed", e)
            -1
        }
        val uid = try {
            Shizuku.getUid()
        } catch (e: Throwable) {
            Log.w(TAG, "Shizuku.getUid() failed", e)
            -1
        }
        Log.d(TAG, "Shizuku server info: version=$version, uid=$uid, minRequired=$MIN_SHIZUKU_VERSION")

        val hasPermission = try {
            if (Shizuku.isPreV11()) {
                Log.w(TAG, "Shizuku is pre-v11, permission check via legacy mechanism not granted")
                false
            } else {
                val granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                Log.d(TAG, "Shizuku checkSelfPermission: granted=$granted")
                granted
            }
        } catch (e: Throwable) {
            Log.e(TAG, "checkSelfPermission threw exception", e)
            false
        }

        val newState: ShizukuState = when {
            !hasPermission -> {
                Log.d(TAG, "State transition -> PermissionDenied")
                ShizukuState.PermissionDenied
            }
            version > 0 && version < MIN_SHIZUKU_VERSION -> {
                Log.w(TAG, "State transition -> VersionWarning (version=$version < $MIN_SHIZUKU_VERSION)")
                ShizukuState.VersionWarning(version = version, minRequired = MIN_SHIZUKU_VERSION)
            }
            else -> {
                Log.d(TAG, "State transition -> Ready (version=$version, uid=$uid)")
                ShizukuState.Ready(version = version, uid = uid)
            }
        }

        _state.value = newState
        Log.d(TAG, "--- Shizuku Status Check Complete: state=$newState ---")
    }

    fun requestPermission(activity: Activity? = null) {
        Log.d(TAG, "requestPermission invoked")
        try {
            val binderAlive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
            if (!binderAlive) {
                Log.w(TAG, "Cannot request permission: binder is not alive")
                refreshStatus()
                return
            }

            if (Shizuku.isPreV11()) {
                Log.w(TAG, "Cannot request permission: Shizuku version is pre-v11")
                refreshStatus()
                return
            }

            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Permission already granted, refreshing state")
                refreshStatus()
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                Log.d(TAG, "shouldShowRequestPermissionRationale is true, requesting permission directly")
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            } else {
                Log.d(TAG, "Requesting Shizuku permission with code $SHIZUKU_PERMISSION_REQUEST_CODE")
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Exception during requestPermission", e)
            refreshStatus()
        }
    }

    fun openShizukuApp(context: Context) {
        val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            ?: context.packageManager.getLaunchIntentForPackage("rikka.shizuku")

        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            try {
                val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app"))
                storeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(storeIntent)
            } catch (e: Throwable) {
                Log.e(TAG, "Cannot open browser/store link", e)
            }
        }
    }
}
