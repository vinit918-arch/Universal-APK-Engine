package com.example

import android.app.Application
import android.util.Log
import com.example.data.ShizukuStateRepository

class AdbGameTurboApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.d("ShizukuDebug", "AdbGameTurboApp.onCreate() - Initializing Application-level sticky Shizuku binder and permission listeners")
        ShizukuStateRepository.initialize(this)
    }
}
