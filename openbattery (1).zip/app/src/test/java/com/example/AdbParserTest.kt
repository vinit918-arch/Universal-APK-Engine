package com.example

import com.example.model.AdbParser
import com.example.model.BatteryStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class AdbParserTest {

    @Test
    fun testParseStandardDumpsys() {
        val sample = """
Current Battery Service state:
  AC powered: false
  USB powered: true
  Wireless powered: false
  Charge counter: 4000000
  status: 2
  health: 2
  present: true
  level: 80
  scale: 100
  voltage: 4100
  temperature: 320
  technology: Li-ion
        """.trimIndent()

        val parsed = AdbParser.parseDumpsys(sample)
        assertEquals(80, parsed.level)
        assertEquals(4000000L, parsed.chargeCounterUah)
        assertEquals(320, parsed.temperatureRaw)
        assertEquals(4100, parsed.voltageMv)
        assertEquals(BatteryStatus.CHARGING, parsed.status)
        assertEquals("Li-ion", parsed.technology)
        assertEquals(true, parsed.usbPowered)
        assertEquals(false, parsed.acPowered)

        val calculation = AdbParser.calculate(parsed, 5000.0)

        // Current charge = 4000000 / 1000 = 4000.0 mAh
        assertEquals(4000.0, calculation.currentChargeMah!!, 0.001)

        // Estimated full capacity = (4000 / 80) * 100 = 5000.0 mAh
        assertEquals(5000.0, calculation.estimatedFullCapacityMah!!, 0.001)

        // Health = (5000 / 5000) * 100 = 100%
        assertEquals(100.0, calculation.healthPercentage!!, 0.001)

        // Temp = 320 / 10 = 32.0 C
        assertEquals(32.0, calculation.temperatureCelsius!!, 0.001)
        assertFalse(calculation.isOverheating)

        // 4 calculation steps should be present
        assertEquals(4, calculation.steps.size)
    }

    @Test
    fun testThermalWarningDetection() {
        val sample = """
  Charge counter: 4200000
  level: 90
  temperature: 415
        """.trimIndent()

        val parsed = AdbParser.parseDumpsys(sample)
        val calculation = AdbParser.calculate(parsed, 5000.0)

        assertEquals(41.5, calculation.temperatureCelsius!!, 0.001)
        assertTrue("Temperature 41.5C must trigger thermal warning (>39C)", calculation.isOverheating)
    }

    @Test
    fun testDegradedBatteryHealthCalculation() {
        val sample = """
  charge_counter: 2400000
  level: 60
  temperature: 280
        """.trimIndent()

        val parsed = AdbParser.parseDumpsys(sample)
        val calculation = AdbParser.calculate(parsed, 5000.0)

        // Current charge = 2400 mAh
        // Full capacity = (2400 / 60) * 100 = 4000 mAh
        // Health = (4000 / 5000) * 100 = 80.0%
        assertEquals(2400.0, calculation.currentChargeMah!!, 0.001)
        assertEquals(4000.0, calculation.estimatedFullCapacityMah!!, 0.001)
        assertEquals(80.0, calculation.healthPercentage!!, 0.001)
        assertFalse(calculation.isOverheating)
    }

    @Test
    fun testPresetSamplesAreValid() {
        AdbParser.samplePresets.forEach { preset ->
            val parsed = AdbParser.parseDumpsys(preset.rawOutput)
            assertNotNull(parsed.level)
            assertNotNull(parsed.chargeCounterUah)
            assertNotNull(parsed.temperatureRaw)

            val calculation = AdbParser.calculate(parsed, preset.designCapacityMah)
            assertTrue(calculation.isValid)
            assertNotNull(calculation.healthPercentage)
        }
    }
}
