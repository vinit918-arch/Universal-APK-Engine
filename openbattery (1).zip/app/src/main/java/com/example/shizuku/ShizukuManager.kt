package com.example.shizuku

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

private const val TAG = "ShizukuManager"
private const val SHIZUKU_REQ_CODE = 4021
const val SHIZUKU_PACKAGE_NAME = "moe.shizuku.privileged.api"

enum class ShizukuTroubleshootStep {
    NOT_INSTALLED,
    SERVICE_STOPPED,
    PERMISSION_NEEDED,
    READY
}

data class ShizukuState(
    val isAppInstalled: Boolean = false,
    val isServiceRunning: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val isExecuting: Boolean = false,
    val lastExecutionOutput: String? = null,
    val lastExecutionTimeMillis: Long? = null,
    val errorMessage: String? = null,
    val troubleshootStep: ShizukuTroubleshootStep = ShizukuTroubleshootStep.SERVICE_STOPPED
)

class ShizukuManager(private val context: Context) {

    private val _state = MutableStateFlow(ShizukuState())
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku binder received")
        updateStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.d(TAG, "Shizuku binder dead")
        val isInstalled = checkIsAppInstalled()
        _state.value = _state.value.copy(
            isAppInstalled = isInstalled,
            isServiceRunning = false,
            isPermissionGranted = false,
            troubleshootStep = if (isInstalled) ShizukuTroubleshootStep.SERVICE_STOPPED else ShizukuTroubleshootStep.NOT_INSTALLED,
            errorMessage = "Shizuku service stopped. Please restart it in the Shizuku app."
        )
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQ_CODE) {
            val isGranted = grantResult == PackageManager.PERMISSION_GRANTED
            Log.d(TAG, "Shizuku permission result: $isGranted")
            val isInstalled = checkIsAppInstalled()
            val isAlive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

            _state.value = _state.value.copy(
                isAppInstalled = isInstalled,
                isServiceRunning = isAlive,
                isPermissionGranted = isGranted,
                troubleshootStep = if (isGranted && isAlive) ShizukuTroubleshootStep.READY else ShizukuTroubleshootStep.PERMISSION_NEEDED,
                errorMessage = if (isGranted) null else "Shizuku permission was denied."
            )
        }
    }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error initializing Shizuku listeners", e)
        }
        updateStatus()
    }

    private fun checkIsAppInstalled(): Boolean {
        return try {
            context.packageManager.getPackageInfo(SHIZUKU_PACKAGE_NAME, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        } catch (e: Throwable) {
            false
        }
    }

    fun updateStatus() {
        try {
            val isInstalled = checkIsAppInstalled()
            val alive = try {
                Shizuku.pingBinder()
            } catch (e: Throwable) {
                false
            }

            val isVersionSupported = if (alive) {
                try {
                    Shizuku.getVersion() >= 11
                } catch (e: Throwable) {
                    false
                }
            } else false

            val permissionGranted = if (alive && isVersionSupported) {
                try {
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                } catch (e: Throwable) {
                    false
                }
            } else {
                false
            }

            val step = when {
                !isInstalled -> ShizukuTroubleshootStep.NOT_INSTALLED
                !alive -> ShizukuTroubleshootStep.SERVICE_STOPPED
                !permissionGranted -> ShizukuTroubleshootStep.PERMISSION_NEEDED
                else -> ShizukuTroubleshootStep.READY
            }

            val errorMsg = when (step) {
                ShizukuTroubleshootStep.NOT_INSTALLED -> "Shizuku app is not installed on this device."
                ShizukuTroubleshootStep.SERVICE_STOPPED -> "Shizuku app is installed, but the service is NOT running."
                ShizukuTroubleshootStep.PERMISSION_NEEDED -> "Shizuku service is running, but permission is required."
                ShizukuTroubleshootStep.READY -> null
            }

            _state.value = _state.value.copy(
                isAppInstalled = isInstalled,
                isServiceRunning = alive,
                isPermissionGranted = permissionGranted,
                troubleshootStep = step,
                errorMessage = errorMsg
            )
        } catch (e: Throwable) {
            Log.w(TAG, "Shizuku status update failed: ${e.message}")
            val isInstalled = checkIsAppInstalled()
            _state.value = _state.value.copy(
                isAppInstalled = isInstalled,
                isServiceRunning = false,
                isPermissionGranted = false,
                troubleshootStep = if (isInstalled) ShizukuTroubleshootStep.SERVICE_STOPPED else ShizukuTroubleshootStep.NOT_INSTALLED,
                errorMessage = "Status check error: ${e.localizedMessage ?: "Unknown error"}"
            )
        }
    }

    fun requestPermission() {
        try {
            val isInstalled = checkIsAppInstalled()
            if (!isInstalled) {
                _state.value = _state.value.copy(
                    troubleshootStep = ShizukuTroubleshootStep.NOT_INSTALLED,
                    errorMessage = "Please install Shizuku first."
                )
                openShizukuStoreOrApp()
                return
            }

            if (!Shizuku.pingBinder()) {
                _state.value = _state.value.copy(
                    troubleshootStep = ShizukuTroubleshootStep.SERVICE_STOPPED,
                    errorMessage = "Shizuku service is not running. Opening Shizuku..."
                )
                openShizukuApp()
                return
            }

            val version = try { Shizuku.getVersion() } catch (e: Throwable) { 0 }
            if (version < 11) {
                _state.value = _state.value.copy(errorMessage = "Shizuku version $version is unsupported. v11+ required.")
                return
            }

            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                _state.value = _state.value.copy(
                    isPermissionGranted = true,
                    troubleshootStep = ShizukuTroubleshootStep.READY,
                    errorMessage = null
                )
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                _state.value = _state.value.copy(errorMessage = "Please approve Shizuku permission prompt.")
                Shizuku.requestPermission(SHIZUKU_REQ_CODE)
            } else {
                Shizuku.requestPermission(SHIZUKU_REQ_CODE)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed requesting Shizuku permission", e)
            _state.value = _state.value.copy(errorMessage = "Permission request failed: ${e.message}")
        }
    }

    /**
     * Opens the installed Shizuku app so the user can start the service.
     */
    fun openShizukuApp(): Boolean {
        return try {
            val intent = context.packageManager.getLaunchIntentForPackage(SHIZUKU_PACKAGE_NAME)
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                true
            } else {
                openShizukuStoreOrApp()
                false
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error opening Shizuku app", e)
            false
        }
    }

    /**
     * Opens Google Play Store or GitHub to install Shizuku.
     */
    fun openShizukuStoreOrApp() {
        try {
            val playStoreIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$SHIZUKU_PACKAGE_NAME")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(playStoreIntent)
        } catch (e: Throwable) {
            try {
                val browserIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/")).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(browserIntent)
            } catch (ex: Throwable) {
                Log.e(TAG, "Could not open browser for Shizuku", ex)
            }
        }
    }

    /**
     * Executes `dumpsys battery` programmatically with Shizuku ADB shell privileges.
     */
    suspend fun executeDumpsysBattery(): Result<String> = withContext(Dispatchers.IO) {
        _state.value = _state.value.copy(isExecuting = true, errorMessage = null)

        try {
            val isInstalled = checkIsAppInstalled()
            if (!isInstalled) {
                val err = "Shizuku app is not installed. Please install Shizuku."
                _state.value = _state.value.copy(
                    isExecuting = false,
                    isAppInstalled = false,
                    troubleshootStep = ShizukuTroubleshootStep.NOT_INSTALLED,
                    errorMessage = err
                )
                return@withContext Result.failure(IllegalStateException(err))
            }

            if (!Shizuku.pingBinder()) {
                val err = "Shizuku service is not running. Please open Shizuku and start it via Wireless Debugging or Root."
                _state.value = _state.value.copy(
                    isExecuting = false,
                    isServiceRunning = false,
                    troubleshootStep = ShizukuTroubleshootStep.SERVICE_STOPPED,
                    errorMessage = err
                )
                return@withContext Result.failure(IllegalStateException(err))
            }

            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                val err = "Shizuku permission not granted. Tap 'Grant Shizuku Permission' first."
                _state.value = _state.value.copy(
                    isExecuting = false,
                    isPermissionGranted = false,
                    troubleshootStep = ShizukuTroubleshootStep.PERMISSION_NEEDED,
                    errorMessage = err
                )
                return@withContext Result.failure(SecurityException(err))
            }

            // Execute "dumpsys battery" via Shizuku's native binder process reflection
            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            newProcessMethod.isAccessible = true
            val process = newProcessMethod.invoke(
                null,
                arrayOf("dumpsys", "battery"),
                null,
                null
            ) as java.lang.Process

            val output = StringBuilder()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.appendLine(line)
            }

            val exitCode = process.waitFor()
            reader.close()

            val errorOutput = StringBuilder()
            val errReader = BufferedReader(InputStreamReader(process.errorStream))
            var errLine: String?
            while (errReader.readLine().also { errLine = it } != null) {
                errorOutput.appendLine(errLine)
            }
            errReader.close()

            val resultText = output.toString().trim()

            if (exitCode == 0 && resultText.isNotBlank()) {
                _state.value = _state.value.copy(
                    isExecuting = false,
                    lastExecutionOutput = resultText,
                    lastExecutionTimeMillis = System.currentTimeMillis(),
                    troubleshootStep = ShizukuTroubleshootStep.READY,
                    errorMessage = null
                )
                Result.success(resultText)
            } else {
                val err = if (errorOutput.isNotBlank()) errorOutput.toString() else "Command exited with code $exitCode"
                _state.value = _state.value.copy(
                    isExecuting = false,
                    errorMessage = "Execution error: $err"
                )
                Result.failure(RuntimeException(err))
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Shizuku execution failed", e)
            _state.value = _state.value.copy(
                isExecuting = false,
                errorMessage = "Failed to run dumpsys battery: ${e.message}"
            )
            Result.failure(e)
        }
    }

    fun destroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            Log.w(TAG, "Error detaching Shizuku listeners", e)
        }
    }
}
