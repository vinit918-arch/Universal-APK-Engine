package com.example.model

/**
 * Raw data extracted from `adb shell dumpsys battery`.
 */
data class RawBatteryDump(
    val level: Int? = null,
    val chargeCounterUah: Long? = null,
    val temperatureRaw: Int? = null,
    val voltageMv: Int? = null,
    val status: BatteryStatus = BatteryStatus.UNKNOWN,
    val healthStatus: BatteryHealthStatus = BatteryHealthStatus.UNKNOWN,
    val technology: String? = null,
    val acPowered: Boolean? = null,
    val usbPowered: Boolean? = null,
    val wirelessPowered: Boolean? = null,
    val rawText: String = ""
)

/**
 * Standard Android battery status states.
 */
enum class BatteryStatus(val label: String) {
    UNKNOWN("Unknown"),
    CHARGING("Charging"),
    DISCHARGING("Discharging"),
    NOT_CHARGING("Not Charging"),
    FULL("Full");

    companion object {
        fun fromCode(code: Int?): BatteryStatus = when (code) {
            2 -> CHARGING
            3 -> DISCHARGING
            4 -> NOT_CHARGING
            5 -> FULL
            else -> UNKNOWN
        }
    }
}

/**
 * Standard Android battery health conditions reported by the kernel.
 */
enum class BatteryHealthStatus(val label: String) {
    UNKNOWN("Unknown"),
    GOOD("Good"),
    OVERHEAT("Overheat"),
    DEAD("Dead"),
    OVER_VOLTAGE("Over Voltage"),
    FAILURE("Unspecified Failure"),
    COLD("Cold");

    companion object {
        fun fromCode(code: Int?): BatteryHealthStatus = when (code) {
            2 -> GOOD
            3 -> OVERHEAT
            4 -> DEAD
            5 -> OVER_VOLTAGE
            6 -> FAILURE
            7 -> COLD
            else -> UNKNOWN
        }
    }
}

/**
 * Individual step for the "Behind The Scenes" transparent math breakdown.
 */
data class CalculationStep(
    val stepNumber: Int,
    val title: String,
    val formula: String,
    val substitutedFormula: String,
    val result: String,
    val explanation: String,
    val hardwareNote: String
)

/**
 * Comprehensive calculated battery health result and engineering analytics.
 */
data class BatteryHealthCalculation(
    val rawDump: RawBatteryDump,
    val designCapacityMah: Double,
    val currentChargeMah: Double?,
    val estimatedFullCapacityMah: Double?,
    val healthPercentage: Double?,
    val temperatureCelsius: Double?,
    val voltageVolts: Double?,
    val isOverheating: Boolean,
    val steps: List<CalculationStep>,
    val parseErrors: List<String> = emptyList(),
    val isValid: Boolean = true
) {
    val healthRating: HealthRating
        get() = when {
            healthPercentage == null -> HealthRating.UNKNOWN
            healthPercentage >= 95.0 -> HealthRating.EXCELLENT
            healthPercentage >= 85.0 -> HealthRating.GOOD
            healthPercentage >= 80.0 -> HealthRating.FAIR
            else -> HealthRating.DEGRADED
        }
}

enum class HealthRating(val label: String, val description: String) {
    UNKNOWN("Unknown", "Insufficient telemetry data"),
    EXCELLENT("Excellent Condition", "Minimal battery degradation; peak operational performance"),
    GOOD("Good Condition", "Normal wear and tear within standard operational parameters"),
    FAIR("Fair / Moderate Wear", "Noticeable capacity decrease; still operational"),
    DEGRADED("Service Recommended", "Significant degradation (<80%). Fast drain and throttle risks")
}

/**
 * Predefined device dump samples for testing and immediate educational demonstration.
 */
data class SampleBatteryData(
    val deviceName: String,
    val designCapacityMah: Double,
    val rawOutput: String,
    val scenarioNote: String
)
