package com.example.model

import java.util.Locale

/**
 * Low-level ADB dumpsys battery parser and transparent mathematical engine.
 */
object AdbParser {

    private val LEVEL_REGEX = Regex("""(?i)\blevel\s*[:=]\s*(\d+)""")
    private val CHARGE_COUNTER_REGEX = Regex("""(?i)\b(?:charge\s*counter|charge_counter|chargecounter)\s*[:=]\s*(\d+)""")
    private val TEMP_REGEX = Regex("""(?i)\b(?:temperature|temp)\s*[:=]\s*(\d+(?:\.\d+)?)""")
    private val VOLTAGE_REGEX = Regex("""(?i)\bvoltage\s*[:=]\s*(\d+)""")
    private val STATUS_REGEX = Regex("""(?i)\bstatus\s*[:=]\s*(\d+)""")
    private val HEALTH_REGEX = Regex("""(?i)\bhealth\s*[:=]\s*(\d+)""")
    private val TECH_REGEX = Regex("""(?i)\btechnology\s*[:=]\s*([^\r\n]+)""")
    private val AC_REGEX = Regex("""(?i)\bac\s*powered\s*[:=]\s*(true|false)""")
    private val USB_REGEX = Regex("""(?i)\busb\s*powered\s*[:=]\s*(true|false)""")
    private val WIRELESS_REGEX = Regex("""(?i)\bwireless\s*powered\s*[:=]\s*(true|false)""")

    /**
     * Parses raw dumpsys text using robust regular expressions.
     */
    fun parseDumpsys(rawOutput: String): RawBatteryDump {
        val level = LEVEL_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val chargeCounter = CHARGE_COUNTER_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.toLongOrNull()
        val tempRaw = TEMP_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.toDoubleOrNull()?.toInt()
        val voltage = VOLTAGE_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val statusCode = STATUS_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val healthCode = HEALTH_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.toIntOrNull()
        val tech = TECH_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.trim()

        val ac = AC_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.toBooleanStrictOrNull()
        val usb = USB_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.toBooleanStrictOrNull()
        val wireless = WIRELESS_REGEX.find(rawOutput)?.groupValues?.getOrNull(1)?.toBooleanStrictOrNull()

        return RawBatteryDump(
            level = level,
            chargeCounterUah = chargeCounter,
            temperatureRaw = tempRaw,
            voltageMv = voltage,
            status = BatteryStatus.fromCode(statusCode),
            healthStatus = BatteryHealthStatus.fromCode(healthCode),
            technology = tech,
            acPowered = ac,
            usbPowered = usb,
            wirelessPowered = wireless,
            rawText = rawOutput
        )
    }

    /**
     * Executes the educational transparent mathematical calculations and formats each step.
     */
    fun calculate(
        rawDump: RawBatteryDump,
        designCapacityMah: Double
    ): BatteryHealthCalculation {
        val errors = mutableListOf<String>()

        if (rawDump.level == null) {
            errors.add("Missing or unreadable 'level' (battery percentage) field.")
        } else if (rawDump.level <= 0 || rawDump.level > 100) {
            errors.add("Unusual battery level: ${rawDump.level}%. Normal range is 1-100%.")
        }

        if (rawDump.chargeCounterUah == null) {
            errors.add("Missing 'Charge counter' field. Some OEM kernels hide coulometric fuel gauge data.")
        }

        if (rawDump.temperatureRaw == null) {
            errors.add("Missing 'temperature' field in raw log.")
        }

        if (designCapacityMah <= 0) {
            errors.add("Design capacity must be greater than 0 mAh.")
        }

        // Calculations
        val currentChargeMah: Double? = rawDump.chargeCounterUah?.let { it / 1000.0 }

        val estimatedFullCapacityMah: Double? = if (currentChargeMah != null && rawDump.level != null && rawDump.level > 0) {
            (currentChargeMah / rawDump.level.toDouble()) * 100.0
        } else null

        val healthPercentage: Double? = if (estimatedFullCapacityMah != null && designCapacityMah > 0) {
            (estimatedFullCapacityMah / designCapacityMah) * 100.0
        } else null

        val temperatureCelsius: Double? = rawDump.temperatureRaw?.let { it / 10.0 }
        val voltageVolts: Double? = rawDump.voltageMv?.let { it / 1000.0 }
        val isOverheating = (temperatureCelsius ?: 0.0) > 39.0

        // Educational step-by-step breakdown
        val steps = mutableListOf<CalculationStep>()

        // Step 1: µAh to mAh
        if (rawDump.chargeCounterUah != null && currentChargeMah != null) {
            steps.add(
                CalculationStep(
                    stepNumber = 1,
                    title = "Unit Normalization: µAh to mAh",
                    formula = "Current Charge (mAh) = Charge Counter (µAh) / 1,000",
                    substitutedFormula = "${rawDump.chargeCounterUah} µAh / 1,000",
                    result = String.format(Locale.US, "%.2f mAh", currentChargeMah),
                    explanation = "Hardware coulometers in the battery management system (BMS) integrate electron flow in microampere-hours (µAh) for 16-bit integer precision. We divide by 1,000 to convert to standard milliampere-hours.",
                    hardwareNote = "Kernel source: /sys/class/power_supply/battery/charge_counter"
                )
            )
        }

        // Step 2: Extrapolate Full Capacity
        if (currentChargeMah != null && rawDump.level != null && rawDump.level > 0 && estimatedFullCapacityMah != null) {
            steps.add(
                CalculationStep(
                    stepNumber = 2,
                    title = "Extrapolating 100% Real Capacity",
                    formula = "Estimated Full Capacity (mAh) = (Current Charge / Battery Level) × 100",
                    substitutedFormula = "(${String.format(Locale.US, "%.2f", currentChargeMah)} mAh / ${rawDump.level}%) × 100",
                    result = String.format(Locale.US, "%.2f mAh", estimatedFullCapacityMah),
                    explanation = "Assuming linear State-of-Charge (SoC) scaling at this operating point, dividing the instantaneous charge by the reported percentage calculates 1% capacity, then multiplies by 100 to yield the total usable capacity.",
                    hardwareNote = "Higher accuracy is achieved when level is above 70% or below 30% due to Li-ion OCV discharge curve sensitivity."
                )
            )
        }

        // Step 3: Health Percentage
        if (estimatedFullCapacityMah != null && designCapacityMah > 0 && healthPercentage != null) {
            steps.add(
                CalculationStep(
                    stepNumber = 3,
                    title = "Battery State-of-Health (SoH) Ratio",
                    formula = "Battery Health (%) = (Estimated Full Capacity / Design Capacity) × 100",
                    substitutedFormula = "(${String.format(Locale.US, "%.2f", estimatedFullCapacityMah)} mAh / ${String.format(Locale.US, "%.0f", designCapacityMah)} mAh) × 100",
                    result = String.format(Locale.US, "%.1f%%", healthPercentage),
                    explanation = "State-of-Health (SoH) measures the chemical capacity degradation compared to factory specifications. An SoH drop below 80% represents the internationally accepted threshold for chemical retirement.",
                    hardwareNote = "Degraded cells experience higher internal resistance (ESR), causing voltage drops under peak CPU/GPU load."
                )
            )
        }

        // Step 4: Temperature Calibration
        if (rawDump.temperatureRaw != null && temperatureCelsius != null) {
            steps.add(
                CalculationStep(
                    stepNumber = 4,
                    title = "Thermal Telemetry Scaling",
                    formula = "Temperature (°C) = Raw Driver Temperature / 10",
                    substitutedFormula = "${rawDump.temperatureRaw} / 10",
                    result = String.format(Locale.US, "%.1f °C", temperatureCelsius),
                    explanation = "Linux thermal sensor drivers avoid floating point operations in interrupt contexts by reporting temperatures in tenths of a degree Celsius (deci-Celsius). Dividing by 10 yields the physical temperature.",
                    hardwareNote = if (isOverheating) "WARNING: >39°C accelerates electrolyte decomposition and SEI layer growth!" else "Thermal status is optimal (<39°C)."
                )
            )
        }

        return BatteryHealthCalculation(
            rawDump = rawDump,
            designCapacityMah = designCapacityMah,
            currentChargeMah = currentChargeMah,
            estimatedFullCapacityMah = estimatedFullCapacityMah,
            healthPercentage = healthPercentage,
            temperatureCelsius = temperatureCelsius,
            voltageVolts = voltageVolts,
            isOverheating = isOverheating,
            steps = steps,
            parseErrors = errors,
            isValid = errors.isEmpty() || (rawDump.level != null && rawDump.chargeCounterUah != null)
        )
    }

    /**
     * Built-in sample datasets covering different health, degradation, and thermal states.
     */
    val samplePresets = listOf(
        SampleBatteryData(
            deviceName = "Pixel 8 Pro (Healthy ~96%)",
            designCapacityMah = 5050.0,
            rawOutput = """
Current Battery Service state:
  AC powered: false
  USB powered: true
  Wireless powered: false
  Max charging current: 500000
  Max charging voltage: 5000000
  Charge counter: 4120000
  status: 2
  health: 2
  present: true
  level: 85
  scale: 100
  voltage: 4180
  temperature: 315
  technology: Li-ion
            """.trimIndent(),
            scenarioNote = "Normal healthy battery during standard USB charging. 85% level with 4,120 mAh current charge."
        ),
        SampleBatteryData(
            deviceName = "Galaxy S23 (Degraded ~78%)",
            designCapacityMah = 5000.0,
            rawOutput = """
Current Battery Service state:
  AC powered: false
  USB powered: false
  Wireless powered: false
  Charge counter: 2340000
  status: 3
  health: 2
  present: true
  level: 60
  scale: 100
  voltage: 3820
  temperature: 285
  technology: Li-poly
            """.trimIndent(),
            scenarioNote = "Aged device with 2+ years of charge cycles. Extrapolated capacity is 3,900 mAh (<80% SoH)."
        ),
        SampleBatteryData(
            deviceName = "Gaming Device (Thermal Warning >42°C)",
            designCapacityMah = 5000.0,
            rawOutput = """
Current Battery Service state:
  AC powered: true
  USB powered: false
  Wireless powered: false
  Charge counter: 4324000
  status: 2
  health: 3
  present: true
  level: 94
  scale: 100
  voltage: 4350
  temperature: 428
  technology: Li-ion
            """.trimIndent(),
            scenarioNote = "High temperature warning! Kernel reports 42.8°C (temp: 428) which exceeds safe 39.0°C threshold."
        ),
        SampleBatteryData(
            deviceName = "Brand New Device (100% Health)",
            designCapacityMah = 4600.0,
            rawOutput = """
Current Battery Service state:
  AC powered: false
  USB powered: true
  Wireless powered: false
  Charge counter: 3220000
  status: 2
  health: 2
  present: true
  level: 70
  scale: 100
  voltage: 4050
  temperature: 260
  technology: Li-ion
            """.trimIndent(),
            scenarioNote = "Brand new factory condition with exactly 100.0% calculated health capacity."
        )
    )

    const val ADB_COMMAND = "adb shell dumpsys battery"
}
