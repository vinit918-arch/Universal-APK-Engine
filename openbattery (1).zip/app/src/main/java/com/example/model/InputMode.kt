package com.example.model

enum class InputMode(val title: String, val subtitle: String) {
    MANUAL("Manual", "Paste ADB log"),
    SHIZUKU("Shizuku API", "Automated live sync")
}
