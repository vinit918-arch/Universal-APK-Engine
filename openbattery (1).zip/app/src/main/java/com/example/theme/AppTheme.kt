package com.example.theme

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Waves
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * 4 Distinct architectural and visual themes for OpenBattery:
 * 1. BENTO_GRID: Clean Apple-style modular cards with soft surfaces and crisp typography.
 * 2. CYBERPUNK_HUD: Terminal dark mode, glowing neon cyan/amber accents, scanlines, and matrix diagnostics.
 * 3. FLUID_PHYSICS: Organic liquid wave physics and smooth animated fluid energy meters.
 * 4. CYBER_SPEEDOMETER: Automotive cockpit instrument cluster with swept dial needles and tachometer arcs.
 */
enum class AppTheme(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val tag: String
) {
    BENTO_GRID(
        title = "Bento Grid",
        subtitle = "Clean Apple-style modular cards",
        icon = Icons.Default.Dashboard,
        tag = "BENTO"
    ),
    CYBERPUNK_HUD(
        title = "Cyberpunk HUD",
        subtitle = "Neon matrix terminal & telemetry",
        icon = Icons.Default.Terminal,
        tag = "HUD"
    ),
    FLUID_PHYSICS(
        title = "Fluid Physics",
        subtitle = "Liquid dynamic wave simulation",
        icon = Icons.Default.Waves,
        tag = "FLUID"
    ),
    CYBER_SPEEDOMETER(
        title = "Cyber Speedometer",
        subtitle = "Automotive dial gauges & tachometer",
        icon = Icons.Default.Speed,
        tag = "GAUGE"
    );
}
