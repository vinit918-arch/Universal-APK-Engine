package com.example.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

/**
 * Visual color palette and tokens customized for each theme.
 */
@Immutable
data class OpenBatteryThemeColors(
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val primaryAccent: Color,
    val secondaryAccent: Color,
    val warningAccent: Color,
    val successAccent: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val border: Color,
    val glowColor: Color,
    val isDark: Boolean
)

val BentoLightColors = OpenBatteryThemeColors(
    background = Color(0xFFF8FAFC),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFF1F5F9),
    primaryAccent = Color(0xFF2563EB),
    secondaryAccent = Color(0xFF0284C7),
    warningAccent = Color(0xFFEA580C),
    successAccent = Color(0xFF16A34A),
    textPrimary = Color(0xFF0F172A),
    textSecondary = Color(0xFF64748B),
    border = Color(0xFFE2E8F0),
    glowColor = Color(0x332563EB),
    isDark = false
)

val BentoDarkColors = OpenBatteryThemeColors(
    background = Color(0xFF0B1120),
    surface = Color(0xFF1E293B),
    surfaceVariant = Color(0xFF334155),
    primaryAccent = Color(0xFF38BDF8),
    secondaryAccent = Color(0xFF818CF8),
    warningAccent = Color(0xFFFB923C),
    successAccent = Color(0xFF4ADE80),
    textPrimary = Color(0xFFF8FAFC),
    textSecondary = Color(0xFF94A3B8),
    border = Color(0xFF334155),
    glowColor = Color(0x4438BDF8),
    isDark = true
)

val CyberpunkColors = OpenBatteryThemeColors(
    background = Color(0xFF080C14),
    surface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFF162036),
    primaryAccent = Color(0xFF00F5D4),    // Neon Cyan
    secondaryAccent = Color(0xFFFFB703),  // Neon Amber
    warningAccent = Color(0xFFFF0054),    // Neon Warning Magenta
    successAccent = Color(0xFF00F5D4),
    textPrimary = Color(0xFFF1F5F9),
    textSecondary = Color(0xFF94A3B8),
    border = Color(0xFF00F5D4).copy(alpha = 0.4f),
    glowColor = Color(0xFF00F5D4),
    isDark = true
)

val FluidPhysicsColors = OpenBatteryThemeColors(
    background = Color(0xFF061826),
    surface = Color(0xFF0A2540),
    surfaceVariant = Color(0xFF0E385D),
    primaryAccent = Color(0xFF00D4FF),    // Liquid Electric Blue
    secondaryAccent = Color(0xFF06D6A0),  // Aqua Marine
    warningAccent = Color(0xFFFF7B00),
    successAccent = Color(0xFF06D6A0),
    textPrimary = Color(0xFFE0FBFC),
    textSecondary = Color(0xFF8ECAE6),
    border = Color(0xFF00D4FF).copy(alpha = 0.3f),
    glowColor = Color(0x6600D4FF),
    isDark = true
)

val CyberSpeedometerColors = OpenBatteryThemeColors(
    background = Color(0xFF0E0E10),
    surface = Color(0xFF18181C),
    surfaceVariant = Color(0xFF24242A),
    primaryAccent = Color(0xFFFF3366),    // Racing Tach Red / Neon Coral
    secondaryAccent = Color(0xFFFFD166),  // Gauge Amber
    warningAccent = Color(0xFFFF1654),
    successAccent = Color(0xFF06D6A0),
    textPrimary = Color(0xFFF8F9FA),
    textSecondary = Color(0xFFADB5BD),
    border = Color(0xFF2C2C35),
    glowColor = Color(0xFFFF3366),
    isDark = true
)

val LocalOpenBatteryColors = staticCompositionLocalOf { BentoDarkColors }

/**
 * State for OpenBattery theme selection.
 */
data class ThemeState(
    val currentTheme: AppTheme = AppTheme.BENTO_GRID,
    val isBentoDarkMode: Boolean = true
)

/**
 * ViewModel managing dynamic theme state across screens and lifecycles.
 */
class ThemeViewModel : ViewModel() {
    private val _themeState = MutableStateFlow(ThemeState())
    val themeState: StateFlow<ThemeState> = _themeState.asStateFlow()

    fun setTheme(theme: AppTheme) {
        _themeState.update { it.copy(currentTheme = theme) }
    }

    fun toggleBentoDark() {
        _themeState.update { it.copy(isBentoDarkMode = !it.isBentoDarkMode) }
    }

    fun getActiveColors(): OpenBatteryThemeColors {
        val state = _themeState.value
        return when (state.currentTheme) {
            AppTheme.BENTO_GRID -> if (state.isBentoDarkMode) BentoDarkColors else BentoLightColors
            AppTheme.CYBERPUNK_HUD -> CyberpunkColors
            AppTheme.FLUID_PHYSICS -> FluidPhysicsColors
            AppTheme.CYBER_SPEEDOMETER -> CyberSpeedometerColors
        }
    }
}

/**
 * Composition provider wrapper for custom theme styling.
 */
@Composable
fun ProvideOpenBatteryTheme(
    themeViewModel: ThemeViewModel = viewModel(),
    content: @Composable () -> Unit
) {
    val colors = themeViewModel.getActiveColors()
    CompositionLocalProvider(
        LocalOpenBatteryColors provides colors,
        content = content
    )
}
