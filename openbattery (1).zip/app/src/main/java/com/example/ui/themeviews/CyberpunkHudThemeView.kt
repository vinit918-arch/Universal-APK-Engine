package com.example.ui.themeviews

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BatteryHealthCalculation
import com.example.theme.CyberpunkColors
import com.example.ui.components.ThermalWarningBadge
import java.util.Locale

/**
 * Cyberpunk HUD Theme: Dark matrix terminal style, neon cyan and amber accents,
 * angled cut corners, ASCII telemetry framing, and glitch HUD aesthetics.
 */
@Composable
fun CyberpunkHudThemeView(
    calculation: BatteryHealthCalculation,
    modifier: Modifier = Modifier
) {
    val neonCyan = CyberpunkColors.primaryAccent
    val neonAmber = CyberpunkColors.secondaryAccent
    val neonMagenta = CyberpunkColors.warningAccent
    val bgDark = CyberpunkColors.surface
    val borderCyan = CyberpunkColors.border

    val infiniteTransition = rememberInfiniteTransition(label = "hud_pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200),
            repeatMode = RepeatMode.Reverse
        ),
        label = "hud_glow"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("cyberpunk_hud_theme_view"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Terminal Status Strip
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                .background(Color(0xFF070D18))
                .border(1.dp, neonCyan.copy(alpha = 0.4f), CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = neonCyan,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "SYS_DIAGNOSTICS // BMS_PROTOCOL_v4",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = neonCyan,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "STATUS: ${calculation.rawDump.status.name}",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = neonAmber
            )
        }

        // Hero Neon HUD Panel: Battery State of Health
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp))
                .background(bgDark)
                .border(1.5.dp, neonCyan.copy(alpha = glowAlpha), CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp))
                .padding(18.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Top
                ) {
                    Column {
                        Text(
                            text = "[01 // HEALTH_TELEMETRY]",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = neonCyan.copy(alpha = 0.8f),
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (calculation.healthPercentage != null)
                                String.format(Locale.US, "%.1f%%", calculation.healthPercentage)
                            else "ERR_NULL",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Black,
                            color = if (calculation.healthRating.name == "DEGRADED") neonMagenta else neonCyan,
                            letterSpacing = (-1).sp
                        )
                        Text(
                            text = "RATING: ${calculation.healthRating.label.uppercase()}",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = neonAmber
                        )
                    }

                    // Cyber Segment Indicator
                    Column(
                        horizontalAlignment = Alignment.End,
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Text(
                            text = "EXTRAPOLATED",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 9.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = if (calculation.estimatedFullCapacityMah != null)
                                "${calculation.estimatedFullCapacityMah.toInt()} mAh"
                            else "---",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Text(
                            text = "DESIGN: ${calculation.designCapacityMah.toInt()} mAh",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            color = neonCyan
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Futuristic Matrix Segment Bar (20 segments representing 0-100%)
                CyberSegmentBar(
                    percentage = calculation.healthPercentage ?: 0.0,
                    tint = if (calculation.healthRating.name == "DEGRADED") neonMagenta else neonCyan
                )
            }
        }

        // Modular HUD Matrix Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Level Module
            CyberHudTile(
                modifier = Modifier.weight(1f),
                tag = "SOC_LEVEL",
                value = "${calculation.rawDump.level ?: "--"}%",
                subtext = "RAW BMS SOC",
                color = neonAmber
            )

            // Current Charge Module
            CyberHudTile(
                modifier = Modifier.weight(1f),
                tag = "COULOMB_CNT",
                value = if (calculation.currentChargeMah != null)
                    "${calculation.currentChargeMah.toInt()} mAh"
                else "--",
                subtext = "${calculation.rawDump.chargeCounterUah ?: "--"} µAh",
                color = neonCyan
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Voltage
            CyberHudTile(
                modifier = Modifier.weight(1f),
                tag = "VOLT_POTENTIAL",
                value = if (calculation.voltageVolts != null)
                    String.format(Locale.US, "%.3f V", calculation.voltageVolts)
                else "--",
                subtext = "CHEM: ${calculation.rawDump.technology ?: "Li-ion"}",
                color = neonCyan
            )

            // Temperature
            CyberHudTile(
                modifier = Modifier.weight(1f),
                tag = "THERMAL_DECIC",
                value = if (calculation.temperatureCelsius != null)
                    String.format(Locale.US, "%.1f °C", calculation.temperatureCelsius)
                else "--",
                subtext = "RAW SENSOR: ${calculation.rawDump.temperatureRaw ?: "--"}",
                color = if (calculation.isOverheating) neonMagenta else neonCyan
            )
        }

        // Thermal Warning or Normal Status Banner
        ThermalWarningBadge(temperatureCelsius = calculation.temperatureCelsius)
    }
}

@Composable
private fun CyberSegmentBar(
    percentage: Double,
    tint: Color,
    modifier: Modifier = Modifier
) {
    val totalSegments = 20
    val activeSegments = ((percentage / 100.0) * totalSegments).toInt().coerceIn(0, totalSegments)

    Column(modifier = modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "BAR_ARRAY [0-100%]",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = Color(0xFF64748B)
            )
            Text(
                text = "${(percentage).toInt()}% INTEGRITY",
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = tint,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            for (i in 0 until totalSegments) {
                val isActive = i < activeSegments
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .height(10.dp)
                        .clip(CutCornerShape(1.dp))
                        .background(
                            if (isActive) tint else Color(0xFF1E293B)
                        )
                )
            }
        }
    }
}

@Composable
private fun CyberHudTile(
    tag: String,
    value: String,
    subtext: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
            .background(CyberpunkColors.surface)
            .border(1.dp, color.copy(alpha = 0.35f), CutCornerShape(topStart = 8.dp, bottomEnd = 8.dp))
            .padding(12.dp)
    ) {
        Column {
            Text(
                text = "> $tag",
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = color.copy(alpha = 0.8f),
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = value,
                fontFamily = FontFamily.Monospace,
                fontSize = 19.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtext,
                fontFamily = FontFamily.Monospace,
                fontSize = 9.sp,
                color = Color(0xFF94A3B8)
            )
        }
    }
}
