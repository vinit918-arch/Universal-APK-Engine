package com.example.ui.components

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.DataObject
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Launch
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AdbParser
import com.example.model.InputMode
import com.example.model.SampleBatteryData
import com.example.shizuku.ShizukuState
import com.example.shizuku.ShizukuTroubleshootStep
import com.example.theme.LocalOpenBatteryColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Dual Input Modes Section:
 * Mode A: Manual text pasting + Presets + ADB Command helper
 * Mode B: Automated live telemetry via Shizuku API (`Shizuku.newProcess()`)
 */
@Composable
fun InputSection(
    inputMode: InputMode,
    onInputModeChanged: (InputMode) -> Unit,
    rawText: String,
    onRawTextChanged: (String) -> Unit,
    designCapacityText: String,
    onDesignCapacityChanged: (String) -> Unit,
    onSelectSample: (SampleBatteryData) -> Unit,
    shizukuState: ShizukuState,
    onRequestShizukuPermission: () -> Unit,
    onCheckShizukuStatus: () -> Unit,
    onOpenShizukuApp: () -> Unit,
    onInstallShizuku: () -> Unit,
    onExecuteShizukuDumpsys: () -> Unit,
    modifier: Modifier = Modifier
) {
    val colors = LocalOpenBatteryColors.current

    var isExpanded by remember { mutableStateOf(false) }
    var showAdbGuideDialog by remember { mutableStateOf(false) }

    Card(
        modifier = modifier
            .fillMaxWidth()
            .animateContentSize()
            .testTag("input_section_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = colors.surface),
        border = CardDefaults.outlinedCardBorder().copy(
            brush = androidx.compose.ui.graphics.SolidColor(colors.border)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Mode Selector Tabs (Manual vs Shizuku API)
            TabRow(
                selectedTabIndex = inputMode.ordinal,
                containerColor = colors.surfaceVariant.copy(alpha = 0.4f),
                contentColor = colors.primaryAccent,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[inputMode.ordinal]),
                        color = colors.primaryAccent,
                        height = 3.dp
                    )
                },
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .testTag("input_mode_tabs")
            ) {
                InputMode.entries.forEach { mode ->
                    val isSelected = inputMode == mode
                    Tab(
                        selected = isSelected,
                        onClick = { onInputModeChanged(mode) },
                        modifier = Modifier.height(48.dp),
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (mode == InputMode.MANUAL) Icons.Default.EditNote else Icons.Default.AutoAwesome,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp),
                                    tint = if (isSelected) colors.primaryAccent else colors.textSecondary
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = mode.title,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    fontSize = 13.sp,
                                    color = if (isSelected) colors.primaryAccent else colors.textSecondary
                                )
                            }
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Mode-specific Body
            when (inputMode) {
                InputMode.MANUAL -> {
                    ManualModeContent(
                        rawText = rawText,
                        onRawTextChanged = onRawTextChanged,
                        isExpanded = isExpanded,
                        onToggleExpanded = { isExpanded = !isExpanded },
                        onSelectSample = onSelectSample,
                        onShowAdbGuide = { showAdbGuideDialog = true }
                    )
                }
                InputMode.SHIZUKU -> {
                    ShizukuModeContent(
                        shizukuState = shizukuState,
                        onRequestPermission = onRequestShizukuPermission,
                        onCheckStatus = onCheckShizukuStatus,
                        onOpenShizukuApp = onOpenShizukuApp,
                        onInstallShizuku = onInstallShizuku,
                        onExecute = onExecuteShizukuDumpsys
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Shared Design Capacity Spec Input
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "Design Capacity (Factory Spec):",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = colors.textPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = designCapacityText,
                        onValueChange = onDesignCapacityChanged,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("design_capacity_input"),
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        placeholder = { Text("e.g. 5000", color = colors.textSecondary) },
                        suffix = { Text("mAh", color = colors.textSecondary, fontWeight = FontWeight.Bold) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = colors.primaryAccent,
                            unfocusedBorderColor = colors.border,
                            focusedTextColor = colors.textPrimary,
                            unfocusedTextColor = colors.textPrimary
                        ),
                        shape = RoundedCornerShape(8.dp)
                    )
                }

                // Quick chips for common design capacities
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp)
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("4000", "4500", "5000", "5050", "5400", "6000").forEach { cap ->
                        AssistChip(
                            onClick = { onDesignCapacityChanged(cap) },
                            label = { Text("$cap mAh", fontSize = 11.sp) },
                            colors = AssistChipDefaults.assistChipColors(
                                containerColor = if (designCapacityText == cap) colors.primaryAccent.copy(alpha = 0.2f) else colors.surfaceVariant,
                                labelColor = if (designCapacityText == cap) colors.primaryAccent else colors.textSecondary
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (designCapacityText == cap) colors.primaryAccent else colors.border
                            ),
                            shape = RoundedCornerShape(6.dp)
                        )
                    }
                }
            }
        }
    }

    // ADB Terminal Guide Dialog
    if (showAdbGuideDialog) {
        AdbHelpDialog(onDismiss = { showAdbGuideDialog = false })
    }
}

@Composable
private fun ManualModeContent(
    rawText: String,
    onRawTextChanged: (String) -> Unit,
    isExpanded: Boolean,
    onToggleExpanded: () -> Unit,
    onSelectSample: (SampleBatteryData) -> Unit,
    onShowAdbGuide: () -> Unit
) {
    val colors = LocalOpenBatteryColors.current
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    var showPresetsDropdown by remember { mutableStateOf(false) }

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.clickable { onToggleExpanded() }
            ) {
                Icon(
                    imageVector = Icons.Default.Terminal,
                    contentDescription = null,
                    tint = colors.primaryAccent,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Manual Telemetry Input",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = colors.textPrimary
                )
                Icon(
                    imageVector = if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = colors.textSecondary
                )
            }

            Row {
                IconButton(
                    onClick = onShowAdbGuide,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.HelpOutline,
                        contentDescription = "ADB Guide",
                        tint = colors.primaryAccent,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Box {
                    OutlinedButton(
                        onClick = { showPresetsDropdown = true },
                        modifier = Modifier.height(36.dp),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.primaryAccent)
                    ) {
                        Icon(Icons.Default.DataObject, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Presets", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    }

                    DropdownMenu(
                        expanded = showPresetsDropdown,
                        onDismissRequest = { showPresetsDropdown = false }
                    ) {
                        AdbParser.samplePresets.forEach { preset ->
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(preset.deviceName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                        Text("${preset.designCapacityMah.toInt()} mAh • ${preset.scenarioNote.take(35)}...", fontSize = 11.sp, color = colors.textSecondary)
                                    }
                                },
                                onClick = {
                                    showPresetsDropdown = false
                                    onSelectSample(preset)
                                    Toast.makeText(context, "Loaded: ${preset.deviceName}", Toast.LENGTH_SHORT).show()
                                }
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    val clip = clipboardManager.getText()?.text
                    if (!clip.isNullOrBlank()) {
                        onRawTextChanged(clip)
                        Toast.makeText(context, "Pasted from clipboard", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Clipboard is empty", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.buttonColors(containerColor = colors.primaryAccent)
            ) {
                Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Paste Log", fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
                onClick = {
                    clipboardManager.setText(AnnotatedString(AdbParser.ADB_COMMAND))
                    Toast.makeText(context, "Copied '${AdbParser.ADB_COMMAND}'", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier
                    .weight(1f)
                    .height(38.dp),
                shape = RoundedCornerShape(8.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.textPrimary)
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Copy ADB Cmd", fontSize = 12.sp)
            }
        }

        AnimatedVisibility(visible = isExpanded || rawText.isEmpty()) {
            Column(modifier = Modifier.padding(top = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Raw dumpsys battery Output:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.textPrimary
                    )

                    if (rawText.isNotEmpty()) {
                        TextButton(
                            onClick = { onRawTextChanged("") },
                            modifier = Modifier.height(28.dp)
                        ) {
                            Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Clear", fontSize = 11.sp, color = colors.warningAccent)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                OutlinedTextField(
                    value = rawText,
                    onValueChange = onRawTextChanged,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp)
                        .testTag("raw_adb_input"),
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        lineHeight = 15.sp
                    ),
                    placeholder = {
                        Text(
                            "Paste dumpsys battery output here...",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = colors.textSecondary.copy(alpha = 0.7f)
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = colors.primaryAccent,
                        unfocusedBorderColor = colors.border,
                        focusedTextColor = colors.textPrimary,
                        unfocusedTextColor = colors.textPrimary
                    ),
                    shape = RoundedCornerShape(8.dp)
                )
            }
        }
    }
}

@Composable
private fun ShizukuModeContent(
    shizukuState: ShizukuState,
    onRequestPermission: () -> Unit,
    onCheckStatus: () -> Unit,
    onOpenShizukuApp: () -> Unit,
    onInstallShizuku: () -> Unit,
    onExecute: () -> Unit
) {
    val colors = LocalOpenBatteryColors.current
    var showWirelessHelp by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("shizuku_mode_content")
    ) {
        // Shizuku Service Status Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(colors.surfaceVariant.copy(alpha = 0.5f))
                .border(1.dp, colors.border.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(14.dp)
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(
                                    when (shizukuState.troubleshootStep) {
                                        ShizukuTroubleshootStep.READY -> colors.successAccent
                                        ShizukuTroubleshootStep.PERMISSION_NEEDED -> colors.warningAccent
                                        ShizukuTroubleshootStep.SERVICE_STOPPED -> colors.warningAccent
                                        ShizukuTroubleshootStep.NOT_INSTALLED -> Color(0xFFEF4444)
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = when (shizukuState.troubleshootStep) {
                                ShizukuTroubleshootStep.READY -> "Shizuku: READY & CONNECTED"
                                ShizukuTroubleshootStep.PERMISSION_NEEDED -> "Shizuku: PERMISSION REQUIRED"
                                ShizukuTroubleshootStep.SERVICE_STOPPED -> "Shizuku Service: NOT RUNNING"
                                ShizukuTroubleshootStep.NOT_INSTALLED -> "Shizuku App: NOT INSTALLED"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (shizukuState.troubleshootStep) {
                                ShizukuTroubleshootStep.READY -> colors.successAccent
                                ShizukuTroubleshootStep.PERMISSION_NEEDED -> colors.warningAccent
                                ShizukuTroubleshootStep.SERVICE_STOPPED -> colors.warningAccent
                                ShizukuTroubleshootStep.NOT_INSTALLED -> Color(0xFFEF4444)
                            }
                        )
                    }

                    Row {
                        IconButton(
                            onClick = onCheckStatus,
                            modifier = Modifier.size(28.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Refresh,
                                contentDescription = "Refresh Status",
                                tint = colors.primaryAccent,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Detailed Status Text
                Text(
                    text = when (shizukuState.troubleshootStep) {
                        ShizukuTroubleshootStep.READY -> "Privileged ADB binder connection active. Ready to read battery fuel gauge."
                        ShizukuTroubleshootStep.PERMISSION_NEEDED -> "Service is active, but OpenBattery needs authorization."
                        ShizukuTroubleshootStep.SERVICE_STOPPED -> "Shizuku app is present, but its background service needs to be started."
                        ShizukuTroubleshootStep.NOT_INSTALLED -> "Shizuku app is not installed on this Android device."
                    },
                    fontSize = 11.sp,
                    color = colors.textSecondary,
                    lineHeight = 15.sp
                )

                if (shizukuState.lastExecutionTimeMillis != null) {
                    val formattedTime = remember(shizukuState.lastExecutionTimeMillis) {
                        SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(shizukuState.lastExecutionTimeMillis))
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Last Live Sync: $formattedTime",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = colors.primaryAccent
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Dynamic Action Button based on troubleshooting diagnosis
        when (shizukuState.troubleshootStep) {
            ShizukuTroubleshootStep.NOT_INSTALLED -> {
                Button(
                    onClick = onInstallShizuku,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("install_shizuku_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.primaryAccent)
                ) {
                    Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Install Shizuku App (Google Play)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            ShizukuTroubleshootStep.SERVICE_STOPPED -> {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = onOpenShizukuApp,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                                .testTag("open_shizuku_button"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = colors.primaryAccent)
                        ) {
                            Icon(Icons.Default.Launch, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Open Shizuku App", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = onCheckStatus,
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = colors.textPrimary)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Re-check Status", fontSize = 12.sp)
                        }
                    }

                    // Quick Wireless Debugging accordion
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(colors.surfaceVariant.copy(alpha = 0.4f))
                            .clickable { showWirelessHelp = !showWirelessHelp }
                            .padding(horizontal = 12.dp, vertical = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "How to start Shizuku without a PC (Wireless Debugging)",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = colors.primaryAccent
                            )
                            Icon(
                                imageVector = if (showWirelessHelp) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                tint = colors.primaryAccent,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }

                    AnimatedVisibility(visible = showWirelessHelp) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(colors.surfaceVariant.copy(alpha = 0.2f))
                                .border(1.dp, colors.border.copy(alpha = 0.3f), RoundedCornerShape(8.dp))
                                .padding(10.dp)
                        ) {
                            Text(
                                text = "1. Enable 'Developer Options' on your device.\n" +
                                        "2. Enable 'Wireless Debugging' (connect to Wi-Fi).\n" +
                                        "3. Open Shizuku > 'Start via Wireless debugging' > 'Pairing'.\n" +
                                        "4. Enter the 6-digit pairing code from notification.\n" +
                                        "5. Return to Shizuku and tap 'Start'.",
                                fontSize = 11.sp,
                                color = colors.textSecondary,
                                lineHeight = 16.sp
                            )
                        }
                    }
                }
            }

            ShizukuTroubleshootStep.PERMISSION_NEEDED -> {
                Button(
                    onClick = onRequestPermission,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .testTag("shizuku_grant_permission_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.warningAccent)
                ) {
                    Icon(Icons.Default.LockOpen, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Grant Shizuku Permission", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }
            }

            ShizukuTroubleshootStep.READY -> {
                Button(
                    onClick = onExecute,
                    enabled = !shizukuState.isExecuting,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("shizuku_execute_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = colors.primaryAccent)
                ) {
                    if (shizukuState.isExecuting) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = Color.White,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Executing dumpsys battery...", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    } else {
                        Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Fetch Live Battery Telemetry", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
            }
        }

        // Error message banner if present
        if (shizukuState.errorMessage != null && shizukuState.troubleshootStep == ShizukuTroubleshootStep.READY) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF3B151E))
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFFF6B6B), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = shizukuState.errorMessage,
                    color = Color(0xFFFFD1D1),
                    fontSize = 11.sp,
                    lineHeight = 15.sp
                )
            }
        }
    }
}

@Composable
private fun AdbHelpDialog(onDismiss: () -> Unit) {
    val colors = LocalOpenBatteryColors.current
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Terminal, contentDescription = null, tint = colors.primaryAccent)
                Spacer(modifier = Modifier.width(8.dp))
                Text("How to fetch raw battery logs", fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column {
                Text(
                    text = "Mode A (Terminal/PC):\n" +
                            "1. Connect phone via USB or Wireless ADB.\n" +
                            "2. Run the command below and paste output:\n",
                    fontSize = 12.sp,
                    color = colors.textPrimary
                )

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .background(colors.surfaceVariant)
                        .border(1.dp, colors.border, RoundedCornerShape(6.dp))
                        .padding(10.dp)
                ) {
                    Text(
                        text = AdbParser.ADB_COMMAND,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = colors.primaryAccent,
                        fontSize = 12.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Mode B (Automated via Shizuku):\n" +
                            "Install and start the Shizuku app (via Wireless Debugging on Android 11+). OpenBattery will automatically query the service on-device without a PC!",
                    fontSize = 12.sp,
                    color = colors.textSecondary,
                    lineHeight = 16.sp
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    clipboardManager.setText(AnnotatedString(AdbParser.ADB_COMMAND))
                    onDismiss()
                    Toast.makeText(context, "Command copied!", Toast.LENGTH_SHORT).show()
                },
                colors = ButtonDefaults.buttonColors(containerColor = colors.primaryAccent)
            ) {
                Text("Copy Command")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}
