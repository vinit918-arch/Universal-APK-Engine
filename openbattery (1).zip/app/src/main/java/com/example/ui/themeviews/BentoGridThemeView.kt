package com.example.ui.themeviews

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ElectricMeter
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BatteryHealthCalculation
import com.example.model.HealthRating
import com.example.theme.LocalOpenBatteryColors
import com.example.ui.components.ThermalWarningBadge
import java.util.Locale

/**
 * Bento Grid Theme UI: Clean Apple-style modular cards with soft surfaces,
 * rounded geometry, crisp typography, and high visual balance.
 */
@Composable
fun BentoGridThemeView(
    calculation: BatteryHealthCalculation,
    modifier: Modifier = Modifier
) {
    val colors = LocalOpenBatteryColors.current
    val health = calculation.healthPercentage ?: 0.0
    val animatedProgress by animateFloatAsState(
        targetValue = (health / 100.0).coerceIn(0.0, 1.0).toFloat(),
        animationSpec = tween(durationMillis = 1000),
        label = "bento_progress"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("bento_grid_theme_view"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Hero Card: Battery Health with Circular Progress Ring
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(colors.surface)
                .border(1.dp, colors.border, RoundedCornerShape(24.dp))
                .padding(20.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    // Badge
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(100.dp))
                            .background(
                                when (calculation.healthRating) {
                                    HealthRating.EXCELLENT -> colors.successAccent.copy(alpha = 0.15f)
                                    HealthRating.GOOD -> colors.primaryAccent.copy(alpha = 0.15f)
                                    HealthRating.FAIR -> colors.warningAccent.copy(alpha = 0.15f)
                                    HealthRating.DEGRADED -> Color(0xFFEF4444).copy(alpha = 0.15f)
                                    HealthRating.UNKNOWN -> colors.surfaceVariant
                                }
                            )
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = calculation.healthRating.label,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (calculation.healthRating) {
                                HealthRating.EXCELLENT -> colors.successAccent
                                HealthRating.GOOD -> colors.primaryAccent
                                HealthRating.FAIR -> colors.warningAccent
                                HealthRating.DEGRADED -> Color(0xFFEF4444)
                                HealthRating.UNKNOWN -> colors.textSecondary
                            }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = if (calculation.healthPercentage != null)
                            String.format(Locale.US, "%.1f%%", calculation.healthPercentage)
                        else "--%",
                        fontSize = 38.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = colors.textPrimary,
                        letterSpacing = (-1).sp
                    )

                    Text(
                        text = "Estimated Battery Health",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = colors.textSecondary
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = calculation.healthRating.description,
                        fontSize = 12.sp,
                        color = colors.textSecondary,
                        lineHeight = 16.sp
                    )
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Circular Progress Dial
                Box(
                    modifier = Modifier.size(96.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(
                        progress = { 1f },
                        modifier = Modifier.size(96.dp),
                        color = colors.surfaceVariant,
                        strokeWidth = 8.dp,
                    )
                    CircularProgressIndicator(
                        progress = { animatedProgress },
                        modifier = Modifier.size(96.dp),
                        color = when (calculation.healthRating) {
                            HealthRating.EXCELLENT -> colors.successAccent
                            HealthRating.GOOD -> colors.primaryAccent
                            HealthRating.FAIR -> colors.warningAccent
                            HealthRating.DEGRADED -> Color(0xFFEF4444)
                            HealthRating.UNKNOWN -> colors.textSecondary
                        },
                        strokeWidth = 8.dp,
                        strokeCap = StrokeCap.Round
                    )
                    Icon(
                        imageVector = Icons.Default.HealthAndSafety,
                        contentDescription = null,
                        tint = colors.primaryAccent,
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }

        // Modular Grid Row 1: Current Level & Estimated Full Capacity
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card: Current Level
            BentoCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.BatteryChargingFull,
                title = "State of Charge",
                value = "${calculation.rawDump.level ?: "--"}%",
                subtitle = "Reported by BMS",
                accentColor = colors.primaryAccent
            )

            // Card: Estimated Full Capacity
            BentoCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.ElectricMeter,
                title = "Real Full Capacity",
                value = if (calculation.estimatedFullCapacityMah != null)
                    "${calculation.estimatedFullCapacityMah.toInt()} mAh"
                else "--",
                subtitle = "Design: ${calculation.designCapacityMah.toInt()} mAh",
                accentColor = colors.secondaryAccent
            )
        }

        // Modular Grid Row 2: Instant Charge & Voltage / Health
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Card: Charge Counter
            BentoCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Bolt,
                title = "Instant Charge",
                value = if (calculation.currentChargeMah != null)
                    "${calculation.currentChargeMah.toInt()} mAh"
                else "--",
                subtitle = "Raw: ${calculation.rawDump.chargeCounterUah ?: "--"} µAh",
                accentColor = colors.warningAccent
            )

            // Card: Voltage / Power
            BentoCard(
                modifier = Modifier.weight(1f),
                icon = Icons.Default.Memory,
                title = "Cell Potential",
                value = if (calculation.voltageVolts != null)
                    String.format(Locale.US, "%.3f V", calculation.voltageVolts)
                else "--",
                subtitle = "${calculation.rawDump.technology ?: "Li-ion"} • ${calculation.rawDump.status.label}",
                accentColor = colors.successAccent
            )
        }

        // Thermal Warning or Normal Status Banner
        ThermalWarningBadge(temperatureCelsius = calculation.temperatureCelsius)
    }
}

@Composable
private fun BentoCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    val colors = LocalOpenBatteryColors.current

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(20.dp))
            .background(colors.surface)
            .border(1.dp, colors.border, RoundedCornerShape(20.dp))
            .padding(16.dp)
    ) {
        Column {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium,
                    color = colors.textSecondary
                )
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = value,
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = colors.textPrimary
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = colors.textSecondary
            )
        }
    }
}
