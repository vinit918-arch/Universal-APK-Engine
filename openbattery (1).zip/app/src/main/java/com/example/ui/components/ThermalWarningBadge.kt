package com.example.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.theme.LocalOpenBatteryColors
import java.util.Locale

/**
 * Thermal Warning Badge that alerts the user when temperature exceeds 39°C.
 * Lithium battery degradation accelerates exponentially at elevated temperatures.
 */
@Composable
fun ThermalWarningBadge(
    temperatureCelsius: Double?,
    modifier: Modifier = Modifier
) {
    val colors = LocalOpenBatteryColors.current
    val temp = temperatureCelsius ?: return

    val isOverheating = temp > 39.0
    val infiniteTransition = rememberInfiniteTransition(label = "thermal_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 800),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    if (isOverheating) {
        val warningBg = Color(0xFF450A0A)
        val warningBorder = Color(0xFFEF4444)
        val warningText = Color(0xFFFCA5A5)

        Column(
            modifier = modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(warningBg)
                .border(1.5.dp, warningBorder.copy(alpha = pulseAlpha), RoundedCornerShape(12.dp))
                .padding(14.dp)
                .testTag("thermal_warning_badge")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Start
            ) {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = "Thermal Warning",
                    tint = Color(0xFFFF4D4D),
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "THERMAL WARNING: ${String.format(Locale.US, "%.1f°C", temp)} (> 39.0°C)",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.sp
                    )
                    Text(
                        text = "Dangerous Operating Zone",
                        color = warningText,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Li-ion cell temperatures above 39°C dramatically accelerate Solid Electrolyte Interphase (SEI) growth, causing irreversible lithium plating and capacity loss. Disconnect fast charger or allow cell to cool.",
                color = Color(0xFFFECACA),
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }
    } else {
        // Normal Safe Operating Temp
        Row(
            modifier = modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(colors.surfaceVariant.copy(alpha = 0.6f))
                .border(1.dp, colors.border.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
                .padding(horizontal = 14.dp, vertical = 10.dp)
                .testTag("thermal_normal_badge"),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Thermostat,
                contentDescription = "Normal Temperature",
                tint = colors.primaryAccent,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Cell Temp: ${String.format(Locale.US, "%.1f°C", temp)}",
                color = colors.textPrimary,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.weight(1f))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = null,
                    tint = colors.successAccent,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "Optimal (<39°C)",
                    color = colors.successAccent,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}
