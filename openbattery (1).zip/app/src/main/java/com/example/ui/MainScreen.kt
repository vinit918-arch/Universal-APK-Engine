package com.example.ui

import android.widget.Toast
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Brightness4
import androidx.compose.material.icons.filled.Brightness7
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.model.AdbParser
import com.example.model.InputMode
import com.example.shizuku.ShizukuManager
import com.example.theme.AppTheme
import com.example.theme.LocalOpenBatteryColors
import com.example.theme.ProvideOpenBatteryTheme
import com.example.theme.ThemeViewModel
import com.example.ui.components.BehindTheScenesCard
import com.example.ui.components.InputSection
import com.example.ui.themeviews.BentoGridThemeView
import com.example.ui.themeviews.CyberSpeedometerThemeView
import com.example.ui.themeviews.CyberpunkHudThemeView
import com.example.ui.themeviews.FluidPhysicsThemeView
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * MainScreen for OpenBattery:
 * - Dynamic 4-Theme Switcher in header
 * - Dual Input Modes: Manual paste vs Automated Shizuku API
 * - Conditional Theme UI Rendering (Bento Grid, Cyberpunk HUD, Fluid Physics, Cyber Speedometer)
 * - "Behind The Scenes" step-by-step mathematical breakdown
 * - Quick copy/share calculations report
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    themeViewModel: ThemeViewModel = viewModel()
) {
    ProvideOpenBatteryTheme(themeViewModel = themeViewModel) {
        val colors = LocalOpenBatteryColors.current
        val themeState by themeViewModel.themeState.collectAsState()
        val context = LocalContext.current
        val clipboardManager = LocalClipboardManager.current
        val coroutineScope = rememberCoroutineScope()

        // Shizuku Manager instance
        val shizukuManager = remember { ShizukuManager(context) }
        val shizukuState by shizukuManager.state.collectAsState()

        DisposableEffect(Unit) {
            onDispose {
                shizukuManager.destroy()
            }
        }

        // Dual Input Mode State (Manual vs Shizuku)
        var inputMode by remember { mutableStateOf(InputMode.MANUAL) }

        // Initial default with sample preset
        val initialPreset = remember { AdbParser.samplePresets.first() }
        var rawText by remember { mutableStateOf(initialPreset.rawOutput) }
        var designCapacityText by remember { mutableStateOf(initialPreset.designCapacityMah.toInt().toString()) }

        val designCapacity = designCapacityText.toDoubleOrNull() ?: 5000.0
        val parsedDump = remember(rawText) { AdbParser.parseDumpsys(rawText) }
        val calculation = remember(parsedDump, designCapacity) {
            AdbParser.calculate(parsedDump, designCapacity)
        }

        Scaffold(
            modifier = Modifier
                .fillMaxSize()
                .testTag("main_screen"),
            containerColor = colors.background,
            contentColor = colors.textPrimary,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                Surface(
                    color = colors.surface,
                    border = CardDefaults.outlinedCardBorder().copy(
                        brush = androidx.compose.ui.graphics.SolidColor(colors.border)
                    )
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 40.dp, bottom = 12.dp, start = 16.dp, end = 16.dp)
                    ) {
                        // Title Bar Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(colors.primaryAccent.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Bolt,
                                        contentDescription = "OpenBattery Icon",
                                        tint = colors.primaryAccent,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "OpenBattery",
                                        fontSize = 19.sp,
                                        fontWeight = FontWeight.Black,
                                        color = colors.textPrimary,
                                        letterSpacing = (-0.5).sp
                                    )
                                    Text(
                                        text = "Transparent Battery Health & ADB Telemetry",
                                        fontSize = 11.sp,
                                        color = colors.textSecondary
                                    )
                                }
                            }

                            Row {
                                // Share / Copy Report Button
                                IconButton(
                                    onClick = {
                                        val report = buildReportMarkdown(calculation)
                                        clipboardManager.setText(AnnotatedString(report))
                                        Toast.makeText(context, "Copied analysis report to clipboard!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.testTag("copy_report_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Share,
                                        contentDescription = "Copy Report",
                                        tint = colors.primaryAccent
                                    )
                                }

                                if (themeState.currentTheme == AppTheme.BENTO_GRID) {
                                    IconButton(
                                        onClick = { themeViewModel.toggleBentoDark() },
                                        modifier = Modifier.testTag("bento_dark_toggle")
                                    ) {
                                        Icon(
                                            imageVector = if (themeState.isBentoDarkMode) Icons.Default.Brightness7 else Icons.Default.Brightness4,
                                            contentDescription = "Toggle Dark Mode",
                                            tint = colors.textSecondary
                                        )
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Onboarding Theme Switcher Horizontal Carousel
                        Text(
                            text = "CHOOSE UI ARCHITECTURE / THEME:",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = colors.textSecondary,
                            letterSpacing = 0.8.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .testTag("theme_switcher_row"),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            AppTheme.entries.forEach { theme ->
                                val isSelected = themeState.currentTheme == theme
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { themeViewModel.setTheme(theme) },
                                    label = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(
                                                imageVector = theme.icon,
                                                contentDescription = null,
                                                modifier = Modifier.size(16.dp),
                                                tint = if (isSelected) colors.primaryAccent else colors.textSecondary
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                text = theme.title,
                                                fontSize = 12.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                        }
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = colors.primaryAccent.copy(alpha = 0.18f),
                                        selectedLabelColor = colors.primaryAccent,
                                        containerColor = colors.surfaceVariant.copy(alpha = 0.5f),
                                        labelColor = colors.textSecondary
                                    ),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (isSelected) colors.primaryAccent else colors.border
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.testTag("theme_chip_${theme.name.lowercase()}")
                                )
                            }
                        }
                    }
                }
            }
        ) { paddingValues ->
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues),
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 1. Dual Input Modes Section (Manual vs Shizuku)
                item {
                    InputSection(
                        inputMode = inputMode,
                        onInputModeChanged = { inputMode = it },
                        rawText = rawText,
                        onRawTextChanged = { rawText = it },
                        designCapacityText = designCapacityText,
                        onDesignCapacityChanged = { designCapacityText = it },
                        onSelectSample = { sample ->
                            rawText = sample.rawOutput
                            designCapacityText = sample.designCapacityMah.toInt().toString()
                        },
                        shizukuState = shizukuState,
                        onRequestShizukuPermission = {
                            shizukuManager.requestPermission()
                        },
                        onCheckShizukuStatus = {
                            shizukuManager.updateStatus()
                            Toast.makeText(context, "Shizuku status refreshed", Toast.LENGTH_SHORT).show()
                        },
                        onOpenShizukuApp = {
                            val opened = shizukuManager.openShizukuApp()
                            if (!opened) {
                                Toast.makeText(context, "Could not launch Shizuku. Please install it.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onInstallShizuku = {
                            shizukuManager.openShizukuStoreOrApp()
                        },
                        onExecuteShizukuDumpsys = {
                            coroutineScope.launch {
                                val result = shizukuManager.executeDumpsysBattery()
                                result.onSuccess { output ->
                                    rawText = output
                                    Toast.makeText(
                                        context,
                                        "Live telemetry loaded via Shizuku!",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }.onFailure { e ->
                                    Toast.makeText(
                                        context,
                                        "Shizuku error: ${e.message}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                            }
                        }
                    )
                }

                // Parse Warnings or Missing Fields banner if needed
                if (calculation.parseErrors.isNotEmpty() && rawText.isNotBlank()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = colors.surfaceVariant),
                            border = CardDefaults.outlinedCardBorder().copy(
                                brush = androidx.compose.ui.graphics.SolidColor(colors.warningAccent)
                            )
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "Parser Notice:",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    color = colors.warningAccent
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                calculation.parseErrors.forEach { err ->
                                    Text(
                                        text = "• $err",
                                        fontSize = 12.sp,
                                        color = colors.textPrimary
                                    )
                                }
                            }
                        }
                    }
                }

                // 2. Conditional Theme Result View
                item {
                    AnimatedContent(
                        targetState = themeState.currentTheme,
                        transitionSpec = { fadeIn() togetherWith fadeOut() },
                        label = "theme_content_switch"
                    ) { activeTheme ->
                        when (activeTheme) {
                            AppTheme.BENTO_GRID -> BentoGridThemeView(calculation = calculation)
                            AppTheme.CYBERPUNK_HUD -> CyberpunkHudThemeView(calculation = calculation)
                            AppTheme.FLUID_PHYSICS -> FluidPhysicsThemeView(calculation = calculation)
                            AppTheme.CYBER_SPEEDOMETER -> CyberSpeedometerThemeView(calculation = calculation)
                        }
                    }
                }

                // 3. "Behind The Scenes" Step-by-Step Calculation Card
                item {
                    BehindTheScenesCard(calculation = calculation)
                }

                // Footer info
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "OpenBattery • Transparent Android Performance Engineering",
                            fontSize = 11.sp,
                            color = colors.textSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Dual Mode: Manual ADB Paste or Direct Shizuku Kernel Telemetry",
                            fontSize = 10.sp,
                            color = colors.textSecondary.copy(alpha = 0.7f)
                        )
                    }
                }
            }
        }
    }
}

private fun buildReportMarkdown(calc: com.example.model.BatteryHealthCalculation): String {
    val sb = StringBuilder()
    sb.appendLine("# OpenBattery Telemetry Report")
    sb.appendLine("**Estimated State of Health:** ${calc.healthPercentage?.let { String.format(Locale.US, "%.1f%%", it) } ?: "N/A"} (${calc.healthRating.label})")
    sb.appendLine("**Battery Level:** ${calc.rawDump.level ?: "N/A"}%")
    sb.appendLine("**Current Charge:** ${calc.currentChargeMah?.let { String.format(Locale.US, "%.2f mAh", it) } ?: "N/A"} (${calc.rawDump.chargeCounterUah ?: "N/A"} µAh)")
    sb.appendLine("**Estimated Full Capacity:** ${calc.estimatedFullCapacityMah?.let { String.format(Locale.US, "%.2f mAh", it) } ?: "N/A"}")
    sb.appendLine("**Design Spec:** ${calc.designCapacityMah} mAh")
    sb.appendLine("**Temperature:** ${calc.temperatureCelsius?.let { String.format(Locale.US, "%.1f °C", it) } ?: "N/A"} ${if (calc.isOverheating) "(OVERHEATING >39°C)" else "(Normal)"}")
    sb.appendLine("**Voltage:** ${calc.voltageVolts?.let { String.format(Locale.US, "%.3f V", it) } ?: "N/A"}")
    sb.appendLine()
    sb.appendLine("## Mathematical Calculations Pipeline:")
    calc.steps.forEach { step ->
        sb.appendLine("### Step ${step.stepNumber}: ${step.title}")
        sb.appendLine("- Formula: `${step.formula}`")
        sb.appendLine("- Substituted: `${step.substitutedFormula}` = **${step.result}**")
        sb.appendLine("- Logic: ${step.explanation}")
    }
    return sb.toString()
}
