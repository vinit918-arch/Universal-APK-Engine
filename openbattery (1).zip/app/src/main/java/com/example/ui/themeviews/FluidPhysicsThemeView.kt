package com.example.ui.themeviews

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.InvertColors
import androidx.compose.material.icons.filled.Waves
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BatteryHealthCalculation
import com.example.theme.FluidPhysicsColors
import com.example.ui.components.ThermalWarningBadge
import java.util.Locale
import kotlin.math.sin

/**
 * Fluid Physics Theme: Organic dynamic wave simulation where battery capacity
 * and charge are modeled as fluid liquid volume with oscillating surface waves.
 */
@Composable
fun FluidPhysicsThemeView(
    calculation: BatteryHealthCalculation,
    modifier: Modifier = Modifier
) {
    val health = calculation.healthPercentage ?: 0.0
    val level = calculation.rawDump.level ?: 0

    val infiniteTransition = rememberInfiniteTransition(label = "fluid_waves")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 2f * Math.PI.toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("fluid_physics_theme_view"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Liquid Chamber Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(230.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(FluidPhysicsColors.surface)
                .border(1.5.dp, FluidPhysicsColors.primaryAccent.copy(alpha = 0.4f), RoundedCornerShape(24.dp))
        ) {
            // Wave Canvas in Background
            FluidWaveCanvas(
                fillRatio = (health / 100.0).coerceIn(0.1, 0.95).toFloat(),
                wavePhase = wavePhase,
                modifier = Modifier.fillMaxSize()
            )

            // Content Foreground
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(FluidPhysicsColors.primaryAccent.copy(alpha = 0.25f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Waves,
                                contentDescription = null,
                                tint = FluidPhysicsColors.primaryAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Fluid State of Health",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = FluidPhysicsColors.textPrimary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(100.dp))
                            .background(FluidPhysicsColors.surfaceVariant.copy(alpha = 0.8f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "CHARGE: $level%",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = FluidPhysicsColors.secondaryAccent
                        )
                    }
                }

                // Health Percentage Readout
                Column {
                    Text(
                        text = if (calculation.healthPercentage != null)
                            String.format(Locale.US, "%.1f%%", calculation.healthPercentage)
                        else "--%",
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "Chemical Volume: ${calculation.estimatedFullCapacityMah?.toInt() ?: "--"} / ${calculation.designCapacityMah.toInt()} mAh",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color.White.copy(alpha = 0.9f)
                    )
                }

                Text(
                    text = "${calculation.healthRating.label} • Coulometric Liquid Model",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.75f)
                )
            }
        }

        // Fluid Metrics Grid
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            FluidMetricCard(
                modifier = Modifier.weight(1f),
                title = "Liquid Charge",
                value = if (calculation.currentChargeMah != null) "${calculation.currentChargeMah.toInt()} mAh" else "--",
                detail = "Remaining fluid"
            )
            FluidMetricCard(
                modifier = Modifier.weight(1f),
                title = "Max Capacity",
                value = if (calculation.estimatedFullCapacityMah != null) "${calculation.estimatedFullCapacityMah.toInt()} mAh" else "--",
                detail = "Extrapolated reservoir"
            )
        }

        // Thermal Warning or Normal Status Banner
        ThermalWarningBadge(temperatureCelsius = calculation.temperatureCelsius)
    }
}

@Composable
private fun FluidWaveCanvas(
    fillRatio: Float,
    wavePhase: Float,
    modifier: Modifier = Modifier
) {
    val primaryCyan = FluidPhysicsColors.primaryAccent
    val secondaryTeal = FluidPhysicsColors.secondaryAccent

    Canvas(modifier = modifier) {
        val width = size.width
        val height = size.height
        val waterLevelY = height * (1f - fillRatio)
        val waveAmplitude = 12.dp.toPx()
        val waveFrequency = 1.8f

        // Wave Layer 1 (Back Layer)
        val backWavePath = Path().apply {
            moveTo(0f, height)
            lineTo(0f, waterLevelY)
            val step = 10f
            var x = 0f
            while (x <= width) {
                val waveOffset = (x / width) * 2f * Math.PI.toFloat() * waveFrequency + wavePhase + 1f
                val y = waterLevelY + sin(waveOffset) * (waveAmplitude * 0.7f)
                lineTo(x, y)
                x += step
            }
            lineTo(width, height)
            close()
        }

        drawPath(
            path = backWavePath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    secondaryTeal.copy(alpha = 0.35f),
                    primaryCyan.copy(alpha = 0.45f)
                ),
                startY = waterLevelY - waveAmplitude,
                endY = height
            )
        )

        // Wave Layer 2 (Front Layer)
        val frontWavePath = Path().apply {
            moveTo(0f, height)
            lineTo(0f, waterLevelY)
            val step = 10f
            var x = 0f
            while (x <= width) {
                val waveOffset = (x / width) * 2f * Math.PI.toFloat() * waveFrequency + wavePhase
                val y = waterLevelY + sin(waveOffset) * waveAmplitude
                lineTo(x, y)
                x += step
            }
            lineTo(width, height)
            close()
        }

        drawPath(
            path = frontWavePath,
            brush = Brush.verticalGradient(
                colors = listOf(
                    primaryCyan.copy(alpha = 0.75f),
                    secondaryTeal.copy(alpha = 0.9f)
                ),
                startY = waterLevelY - waveAmplitude,
                endY = height
            )
        )
    }
}

@Composable
private fun FluidMetricCard(
    title: String,
    value: String,
    detail: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(FluidPhysicsColors.surface)
            .border(1.dp, FluidPhysicsColors.border, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Column {
            Text(
                text = title,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium,
                color = FluidPhysicsColors.textSecondary
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = FluidPhysicsColors.textPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = detail,
                fontSize = 10.sp,
                color = FluidPhysicsColors.textSecondary
            )
        }
    }
}
