package com.example.ui.themeviews

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BatteryHealthCalculation
import com.example.theme.CyberSpeedometerColors
import com.example.ui.components.ThermalWarningBadge
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

/**
 * Cyber Speedometer Theme: High performance automotive digital instrument cluster,
 * swept radial dial gauges, redline tachometer arc, and digital RPM/health readouts.
 */
@Composable
fun CyberSpeedometerThemeView(
    calculation: BatteryHealthCalculation,
    modifier: Modifier = Modifier
) {
    val health = (calculation.healthPercentage ?: 0.0).coerceIn(0.0, 100.0)
    val animatedHealth by animateFloatAsState(
        targetValue = health.toFloat(),
        animationSpec = tween(durationMillis = 1000),
        label = "gauge_health"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("cyber_speedometer_theme_view"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Speedometer Dial Cluster
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(CyberSpeedometerColors.surface)
                .border(1.5.dp, CyberSpeedometerColors.border, RoundedCornerShape(24.dp))
                .padding(20.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "DIGITAL TACHOMETER // SOH CLUSTER",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    color = CyberSpeedometerColors.textSecondary,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Custom Canvas Speedometer
                Box(
                    modifier = Modifier.size(240.dp),
                    contentAlignment = Alignment.Center
                ) {
                    SpeedometerDialCanvas(
                        value = animatedHealth,
                        maxValue = 100f,
                        modifier = Modifier.size(240.dp)
                    )

                    // Center Digital Readout
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (calculation.healthPercentage != null)
                                String.format(Locale.US, "%.1f", animatedHealth)
                            else "--",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 42.sp,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                        Text(
                            text = "% SOH HEALTH",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberSpeedometerColors.primaryAccent
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "${calculation.estimatedFullCapacityMah?.toInt() ?: "--"} mAh",
                            fontFamily = FontFamily.Monospace,
                            fontSize = 13.sp,
                            color = CyberSpeedometerColors.secondaryAccent
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "RATING: ${calculation.healthRating.label.uppercase()}",
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = when (calculation.healthRating.name) {
                        "DEGRADED" -> CyberSpeedometerColors.warningAccent
                        "EXCELLENT" -> CyberSpeedometerColors.successAccent
                        else -> CyberSpeedometerColors.secondaryAccent
                    }
                )
            }
        }

        // Sub-Dials Row: Fuel Gauge (Level) & Coolant Temp Gauge
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Level Fuel Meter
            SpeedoSubDial(
                modifier = Modifier.weight(1f),
                title = "FUEL GAUGE (SOC)",
                value = "${calculation.rawDump.level ?: "--"}%",
                subtext = "Instant: ${calculation.currentChargeMah?.toInt() ?: "--"} mAh",
                accentColor = CyberSpeedometerColors.secondaryAccent
            )

            // Coolant Temperature
            SpeedoSubDial(
                modifier = Modifier.weight(1f),
                title = "COOLANT TEMP",
                value = if (calculation.temperatureCelsius != null)
                    String.format(Locale.US, "%.1f°C", calculation.temperatureCelsius)
                else "--",
                subtext = if (calculation.isOverheating) "REDLINE THRESHOLD!" else "NORMAL RANGE",
                accentColor = if (calculation.isOverheating) CyberSpeedometerColors.warningAccent else CyberSpeedometerColors.successAccent
            )
        }

        // Thermal Warning or Normal Status Banner
        ThermalWarningBadge(temperatureCelsius = calculation.temperatureCelsius)
    }
}

@Composable
private fun SpeedometerDialCanvas(
    value: Float,
    maxValue: Float,
    modifier: Modifier = Modifier
) {
    val trackColor = Color(0xFF24242A)
    val primaryAccent = CyberSpeedometerColors.primaryAccent
    val amberAccent = CyberSpeedometerColors.secondaryAccent
    val greenAccent = CyberSpeedometerColors.successAccent

    Canvas(modifier = modifier) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val strokeWidthPx = 16.dp.toPx()
        val radius = (size.width - strokeWidthPx) / 2f - 10.dp.toPx()

        val startAngle = 140f
        val sweepAngleTotal = 260f

        // 1. Background Arc Track
        drawArc(
            color = trackColor,
            startAngle = startAngle,
            sweepAngle = sweepAngleTotal,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round)
        )

        // 2. Active Gradient Arc
        val currentSweep = (value / maxValue).coerceIn(0f, 1f) * sweepAngleTotal
        drawArc(
            brush = Brush.sweepGradient(
                colors = listOf(
                    greenAccent,
                    amberAccent,
                    primaryAccent
                )
            ),
            startAngle = startAngle,
            sweepAngle = currentSweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = strokeWidthPx, cap = StrokeCap.Round)
        )

        // 3. Tick Marks
        val tickCount = 10
        for (i in 0..tickCount) {
            val angleDeg = startAngle + (i.toFloat() / tickCount) * sweepAngleTotal
            val angleRad = Math.toRadians(angleDeg.toDouble())
            val innerR = radius - 18.dp.toPx()
            val outerR = radius - 8.dp.toPx()

            val p1 = Offset(
                x = (center.x + innerR * cos(angleRad)).toFloat(),
                y = (center.y + innerR * sin(angleRad)).toFloat()
            )
            val p2 = Offset(
                x = (center.x + outerR * cos(angleRad)).toFloat(),
                y = (center.y + outerR * sin(angleRad)).toFloat()
            )

            drawLine(
                color = if (i >= 8) primaryAccent else Color(0xFF8D99AE),
                start = p1,
                end = p2,
                strokeWidth = 2.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        // 4. Sweeping Needle
        val needleAngleDeg = startAngle + (value / maxValue).coerceIn(0f, 1f) * sweepAngleTotal
        val needleRad = Math.toRadians(needleAngleDeg.toDouble())
        val needleLen = radius - 14.dp.toPx()

        val needleTip = Offset(
            x = (center.x + needleLen * cos(needleRad)).toFloat(),
            y = (center.y + needleLen * sin(needleRad)).toFloat()
        )

        drawLine(
            color = primaryAccent,
            start = center,
            end = needleTip,
            strokeWidth = 4.dp.toPx(),
            cap = StrokeCap.Round
        )

        // Needle Hub Pivot
        drawCircle(
            color = Color.White,
            radius = 6.dp.toPx(),
            center = center
        )
        drawCircle(
            color = primaryAccent,
            radius = 3.dp.toPx(),
            center = center
        )
    }
}

@Composable
private fun SpeedoSubDial(
    title: String,
    value: String,
    subtext: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(CyberSpeedometerColors.surface)
            .border(1.dp, CyberSpeedometerColors.border, RoundedCornerShape(16.dp))
            .padding(14.dp)
    ) {
        Column {
            Text(
                text = title,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = CyberSpeedometerColors.textSecondary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontFamily = FontFamily.Monospace,
                fontSize = 20.sp,
                fontWeight = FontWeight.Black,
                color = accentColor
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtext,
                fontFamily = FontFamily.Monospace,
                fontSize = 10.sp,
                color = CyberSpeedometerColors.textSecondary
            )
        }
    }
}
