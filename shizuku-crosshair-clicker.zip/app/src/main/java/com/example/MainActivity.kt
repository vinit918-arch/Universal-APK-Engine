package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.MyApplicationTheme
import rikka.shizuku.Shizuku

private const val SHIZUKU_REQUEST_CODE = 2001

class MainActivity : ComponentActivity() {

    private val isShizukuAliveState = mutableStateOf(false)
    private val hasShizukuPermissionState = mutableStateOf(false)

    private val shizukuBinderReceivedListener = Shizuku.OnBinderReceivedListener {
        checkShizukuState()
    }

    private val shizukuBinderDeadListener = Shizuku.OnBinderDeadListener {
        checkShizukuState()
    }

    private val shizukuPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_REQUEST_CODE) {
                hasShizukuPermissionState.value = grantResult == PackageManager.PERMISSION_GRANTED
                checkShizukuState()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        try {
            Shizuku.addBinderReceivedListenerSticky(shizukuBinderReceivedListener)
            Shizuku.addBinderDeadListener(shizukuBinderDeadListener)
            Shizuku.addRequestPermissionResultListener(shizukuPermissionResultListener)
        } catch (e: Throwable) {
            // Shizuku provider may not be initialized if running in tests
        }

        setContent {
            MyApplicationTheme(darkTheme = true) {
                ControlCenterScreen(
                    isShizukuAlive = isShizukuAliveState.value,
                    hasShizukuPermission = hasShizukuPermissionState.value,
                    onRefreshShizuku = { checkShizukuState() },
                    onRequestShizukuPermission = { requestShizukuPermission() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkShizukuState()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeBinderReceivedListener(shizukuBinderReceivedListener)
            Shizuku.removeBinderDeadListener(shizukuBinderDeadListener)
            Shizuku.removeRequestPermissionResultListener(shizukuPermissionResultListener)
        } catch (e: Throwable) {
            // Ignore during cleanup
        }
    }

    private fun checkShizukuState() {
        val alive = try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            false
        }
        isShizukuAliveState.value = alive

        val permitted = if (alive) {
            try {
                if (Shizuku.isPreV11()) false
                else Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            } catch (e: Throwable) {
                false
            }
        } else {
            false
        }
        hasShizukuPermissionState.value = permitted
    }

    private fun requestShizukuPermission() {
        if (!isShizukuAliveState.value) {
            Toast.makeText(this, "Shizuku service is not running!", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            Shizuku.requestPermission(SHIZUKU_REQUEST_CODE)
        } catch (e: Throwable) {
            Toast.makeText(this, "Failed to request Shizuku permission: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ControlCenterScreen(
    isShizukuAlive: Boolean,
    hasShizukuPermission: Boolean,
    onRefreshShizuku: () -> Unit,
    onRequestShizukuPermission: () -> Unit
) {
    val context = LocalContext.current
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    val isServiceRunning by FloatingService.isRunning.collectAsState()
    val isLocked by FloatingService.isLockedState.collectAsState()
    val currentSize by FloatingService.crosshairSizeState.collectAsState()
    val currentOpacity by FloatingService.opacityState.collectAsState()
    val currentInterval by FloatingService.intervalMsState.collectAsState()
    val lastCoords by FloatingService.lastTapCoord.collectAsState()
    val tapCount by FloatingService.tapCount.collectAsState()

    var showHelpDialog by remember { mutableStateOf(false) }

    // Launcher for Notification Permission (Android 13+)
    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { /* Permission response handled silently */ }

    // Check permissions on lifecycle resumed
    DisposableEffect(Unit) {
        val intervalCheck = {
            hasOverlayPermission = Settings.canDrawOverlays(context)
        }
        intervalCheck()
        onDispose { }
    }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(10.dp)
                                .clip(CircleShape)
                                .background(if (isServiceRunning) Color(0xFF00F0FF) else Color(0xFFFF2A55))
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "CROSSHAIR AUTO-CLICKER",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF0D111A)
                )
            )
        },
        containerColor = Color(0xFF070A10)
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // 1. MASTER TOGGLE SWITCH CARD
            MasterToggleCard(
                isServiceRunning = isServiceRunning,
                canStart = hasOverlayPermission,
                onToggle = { enabled ->
                    if (enabled) {
                        if (!hasOverlayPermission) {
                            Toast.makeText(
                                context,
                                "Grant 'Display Over Other Apps' permission first",
                                Toast.LENGTH_LONG
                            ).show()
                        } else {
                            FloatingService.start(context)
                        }
                    } else {
                        FloatingService.stop(context)
                    }
                },
                onRequestOverlay = {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    context.startActivity(intent)
                }
            )

            // 2. PERMISSION HANDLER CARDS
            Text(
                text = "SYSTEM ACCESS & DRIVERS",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF64748B),
                letterSpacing = 1.2.sp
            )

            // A. Overlay Permission Card
            OverlayPermissionCard(
                hasPermission = hasOverlayPermission,
                onRequest = {
                    val intent = Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:${context.packageName}")
                    )
                    context.startActivity(intent)
                }
            )

            // B. Shizuku API Permission Card
            ShizukuPermissionCard(
                isAlive = isShizukuAlive,
                hasPermission = hasShizukuPermission,
                onRefresh = onRefreshShizuku,
                onRequest = onRequestShizukuPermission,
                onHelpClick = { showHelpDialog = !showHelpDialog }
            )

            AnimatedVisibility(visible = showHelpDialog) {
                ShizukuSetupGuideCard()
            }

            // 3. OVERLAY STATUS & HUD TELEMETRY
            OverlayTelemetryCard(
                isServiceRunning = isServiceRunning,
                isLocked = isLocked,
                sizePx = currentSize,
                opacityPercent = currentOpacity,
                intervalMs = currentInterval,
                lastCoords = lastCoords,
                tapCount = tapCount
            )

            // 4. RETICLE PREVIEW & TOUCH TEST AREA
            InteractiveReticleTesterCard()
        }
    }
}

@Composable
fun MasterToggleCard(
    isServiceRunning: Boolean,
    canStart: Boolean,
    onToggle: (Boolean) -> Unit,
    onRequestOverlay: () -> Unit
) {
    val borderColor by animateColorAsState(
        targetValue = if (isServiceRunning) Color(0xFF00F0FF) else Color(0xFF1E293B),
        label = "border_color"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("master_toggle_card"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFF0F172A)
        ),
        border = BorderStroke(1.5.dp, borderColor)
    ) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "MASTER OVERLAY SERVICE",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isServiceRunning)
                            "ACTIVE: Reticle HUD & Floating Controls Visible"
                        else
                            "OFFLINE: Overlays Cleanly Removed (Clean Screen)",
                        fontSize = 12.sp,
                        color = if (isServiceRunning) Color(0xFF00F0FF) else Color(0xFF94A3B8)
                    )
                }

                Switch(
                    checked = isServiceRunning,
                    onCheckedChange = { onToggle(it) },
                    modifier = Modifier.testTag("master_toggle_switch"),
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = Color.Black,
                        checkedTrackColor = Color(0xFF00F0FF),
                        uncheckedThumbColor = Color(0xFF64748B),
                        uncheckedTrackColor = Color(0xFF1E293B)
                    )
                )
            }

            if (!canStart && !isServiceRunning) {
                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color(0xFF1E293B))
                Spacer(modifier = Modifier.height(12.dp))
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Overlay permission required to start",
                        fontSize = 12.sp,
                        color = Color(0xFFFFB74D)
                    )
                    Button(
                        onClick = onRequestOverlay,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFFB74D)),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("Grant", color = Color.Black, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun OverlayPermissionCard(
    hasPermission: Boolean,
    onRequest: () -> Unit
) {
    PermissionCardTemplate(
        icon = Icons.Default.Layers,
        title = "Display Over Other Apps",
        description = "Required to render the tactical crosshair reticle and HUD over mobile games.",
        statusText = if (hasPermission) "GRANTED" else "PERMISSION REQUIRED",
        isSuccess = hasPermission,
        actionButtonText = if (hasPermission) "Settings" else "Grant Permission",
        onAction = onRequest,
        testTag = "overlay_permission_button"
    )
}

@Composable
fun ShizukuPermissionCard(
    isAlive: Boolean,
    hasPermission: Boolean,
    onRefresh: () -> Unit,
    onRequest: () -> Unit,
    onHelpClick: () -> Unit
) {
    val statusText = when {
        !isAlive -> "NOT RUNNING"
        hasPermission -> "AUTHORIZED (ADB)"
        else -> "AUTHORIZATION REQUIRED"
    }

    val isSuccess = isAlive && hasPermission

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1526)),
        border = BorderStroke(1.dp, if (isSuccess) Color(0x3300E676) else Color(0x33FF5252))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSuccess) Color(0x2200E676) else Color(0x22FF5252)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = "Shizuku",
                        tint = if (isSuccess) Color(0xFF00E676) else Color(0xFFFF5252),
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Shizuku API Service",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                        Badge(text = statusText, isSuccess = isSuccess)
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "Enables hardware-level ADB touch injection without root.",
                        fontSize = 11.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = onRefresh,
                    modifier = Modifier
                        .weight(1f)
                        .testTag("refresh_shizuku_button"),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, Color(0xFF334155))
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Refresh",
                        modifier = Modifier.size(16.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Ping", fontSize = 12.sp, color = Color.White)
                }

                if (isAlive && !hasPermission) {
                    Button(
                        onClick = onRequest,
                        modifier = Modifier
                            .weight(1.5f)
                            .testTag("request_shizuku_button"),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00F0FF))
                    ) {
                        Text("Authorize", fontSize = 12.sp, color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                } else if (!isAlive) {
                    Button(
                        onClick = onHelpClick,
                        modifier = Modifier.weight(1.5f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Info,
                            contentDescription = "Help",
                            tint = Color(0xFF00F0FF),
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Setup Guide", fontSize = 12.sp, color = Color(0xFF00F0FF))
                    }
                }
            }
        }
    }
}

@Composable
fun PermissionCardTemplate(
    icon: ImageVector,
    title: String,
    description: String,
    statusText: String,
    isSuccess: Boolean,
    actionButtonText: String,
    onAction: () -> Unit,
    testTag: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0E1526)),
        border = BorderStroke(1.dp, if (isSuccess) Color(0x3300E676) else Color(0x33FFB74D))
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isSuccess) Color(0x2200E676) else Color(0x22FFB74D)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSuccess) Color(0xFF00E676) else Color(0xFFFFB74D),
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = title,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    Badge(text = statusText, isSuccess = isSuccess)
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    fontSize = 11.sp,
                    color = Color(0xFF94A3B8)
                )
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onAction,
                    modifier = Modifier.testTag(testTag),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSuccess) Color(0xFF1E293B) else Color(0xFF00F0FF)
                    )
                ) {
                    Text(
                        text = actionButtonText,
                        fontSize = 12.sp,
                        color = if (isSuccess) Color.White else Color.Black,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
fun Badge(text: String, isSuccess: Boolean) {
    val bgColor = if (isSuccess) Color(0x2000E676) else Color(0x20FF5252)
    val textColor = if (isSuccess) Color(0xFF00E676) else Color(0xFFFF5252)

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(bgColor)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(
            text = text,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = textColor
        )
    }
}

@Composable
fun ShizukuSetupGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF131C31)),
        border = BorderStroke(1.dp, Color(0xFF1E293B))
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(
                text = "HOW TO ACTIVATE SHIZUKU:",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF00F0FF)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "1. Install 'Shizuku' from Play Store or GitHub.\n" +
                        "2. Enable 'Developer Options' & 'Wireless Debugging' in Android Settings.\n" +
                        "3. Pair and Start Shizuku via Wireless Debugging.\n" +
                        "4. Return here and tap 'Authorize'.",
                fontSize = 11.sp,
                lineHeight = 16.sp,
                color = Color(0xFFCBD5E1)
            )
        }
    }
}

@Composable
fun OverlayTelemetryCard(
    isServiceRunning: Boolean,
    isLocked: Boolean,
    sizePx: Int,
    opacityPercent: Int,
    intervalMs: Long,
    lastCoords: Pair<Int, Int>?,
    tapCount: Int
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0D1424)),
        border = BorderStroke(1.dp, Color(0xFF1E293B))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "ACTIVE HUD CONFIGURATION",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF64748B),
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                TelemetryItem(label = "Reticle Lock", value = if (isLocked) "LOCKED" else "UNLOCKED")
                TelemetryItem(label = "Reticle Size", value = "$sizePx px")
                TelemetryItem(label = "Opacity", value = "$opacityPercent%")
                TelemetryItem(label = "Speed", value = "$intervalMs ms")
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = Color(0xFF1E293B))
            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "Target Anchor Coordinates", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Text(
                        text = if (lastCoords != null) "X: ${lastCoords.first}, Y: ${lastCoords.second}" else "Center of screen",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFF00F0FF)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text(text = "Total Injected Taps", fontSize = 11.sp, color = Color(0xFF94A3B8))
                    Text(
                        text = "$tapCount",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        color = Color(0xFFFF2A55)
                    )
                }
            }
        }
    }
}

@Composable
fun TelemetryItem(label: String, value: String) {
    Column {
        Text(text = label, fontSize = 10.sp, color = Color(0xFF64748B))
        Spacer(modifier = Modifier.height(2.dp))
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White)
    }
}

@Composable
fun InteractiveReticleTesterCard() {
    var isPressing by remember { mutableStateOf(false) }
    var localTapCount by remember { mutableIntStateOf(0) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("reticle_sandbox_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F172A)),
        border = BorderStroke(1.dp, Color(0xFF1E293B))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = "RETICLE PREVIEW & TOUCH TEST AREA",
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color(0xFF64748B),
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Hold down the reticle below to simulate the auto-clicker trigger",
                fontSize = 11.sp,
                color = Color(0xFF94A3B8)
            )
            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0xFF090D16))
                    .border(
                        BorderStroke(
                            1.dp,
                            if (isPressing) Color(0xFFFF2A55) else Color(0xFF1E293B)
                        ),
                        RoundedCornerShape(16.dp)
                    )
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onPress = {
                                isPressing = true
                                localTapCount++
                                tryAwaitRelease()
                                isPressing = false
                            }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                AndroidView(
                    factory = { ctx ->
                        CrosshairView(ctx).apply {
                            isLocked = true
                        }
                    },
                    update = { view ->
                        view.isClicking = isPressing
                    },
                    modifier = Modifier.size(130.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = if (isPressing) "FIRING INPUT TAPS..." else "TOUCH & HOLD RETICLE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isPressing) Color(0xFFFF2A55) else Color(0xFF00F0FF)
            )
        }
    }
}

// Keep Greeting for screenshot test compatibility
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(text = "Hello $name!", modifier = modifier)
}
