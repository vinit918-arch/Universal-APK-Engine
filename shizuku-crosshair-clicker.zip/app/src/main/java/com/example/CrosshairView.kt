package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

/**
 * Custom Canvas View depicting a tactical gaming Crosshair reticle.
 * Features:
 * - Center precision dot (exact coordinate for tap injection)
 * - 4 crosshair tick marks (North, South, East, West) with tactical gaps
 * - Segmented circular outer targeting brackets
 * - Visual feedback states for Locked, Unlocked (drag mode), and Clicking (tap active)
 */
class CrosshairView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    var isLocked: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    var isClicking: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    // Colors
    private val colorPrimary = Color.parseColor("#00F0FF")   // Tactical Neon Cyan
    private val colorActive = Color.parseColor("#FF2A55")    // Active Clicking Neon Red
    private val colorAccent = Color.parseColor("#FFD700")    // Drag Mode Gold
    private val colorShadow = Color.parseColor("#99000000")  // High-contrast outline

    // Paints
    private val shadowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = colorShadow
        strokeCap = Paint.Cap.ROUND
    }

    private val reticlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 22f
        textAlign = Paint.Align.CENTER
        color = Color.WHITE
        isFakeBoldText = true
    }

    private val arcRect = RectF()

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val cx = width / 2f
        val cy = height / 2f
        val radius = Math.min(cx, cy)
        if (radius <= 0) return

        val activeColor = when {
            isClicking -> colorActive
            !isLocked -> colorAccent
            else -> colorPrimary
        }

        // Set Paint properties dynamically based on size
        val strokeW = Math.max(2.5f, radius * 0.05f)
        reticlePaint.strokeWidth = strokeW
        reticlePaint.color = activeColor

        shadowPaint.strokeWidth = strokeW + 2f

        // 1. Draw outer tactical bracket arcs (4 segments)
        val arcRadius = radius * 0.72f
        arcRect.set(cx - arcRadius, cy - arcRadius, cx + arcRadius, cy + arcRadius)

        val sweepAngle = 54f
        val startAngles = floatArrayOf(18f, 108f, 198f, 288f)
        for (start in startAngles) {
            // Shadow for maximum visibility against bright games
            canvas.drawArc(arcRect, start, sweepAngle, false, shadowPaint)
            canvas.drawArc(arcRect, start, sweepAngle, false, reticlePaint)
        }

        // 2. Draw 4 Crosshair Tick Marks (North, South, East, West)
        val gap = radius * 0.22f
        val tickOuter = radius * 0.90f

        // Top Tick (North)
        canvas.drawLine(cx, cy - gap, cx, cy - tickOuter, shadowPaint)
        canvas.drawLine(cx, cy - gap, cx, cy - tickOuter, reticlePaint)

        // Bottom Tick (South)
        canvas.drawLine(cx, cy + gap, cx, cy + tickOuter, shadowPaint)
        canvas.drawLine(cx, cy + gap, cx, cy + tickOuter, reticlePaint)

        // Left Tick (West)
        canvas.drawLine(cx - gap, cy, cx - tickOuter, cy, shadowPaint)
        canvas.drawLine(cx - gap, cy, cx - tickOuter, cy, reticlePaint)

        // Right Tick (East)
        canvas.drawLine(cx + gap, cy, cx + tickOuter, cy, shadowPaint)
        canvas.drawLine(cx + gap, cy, cx + tickOuter, cy, reticlePaint)

        // Sub-ticks on the crosshairs for sniper reticle style
        val subTickLen = radius * 0.09f
        val subPos = radius * 0.50f
        // Horizontal sub-ticks on vertical axis
        canvas.drawLine(cx - subTickLen, cy - subPos, cx + subTickLen, cy - subPos, reticlePaint)
        canvas.drawLine(cx - subTickLen, cy + subPos, cx + subTickLen, cy + subPos, reticlePaint)
        // Vertical sub-ticks on horizontal axis
        canvas.drawLine(cx - subPos, cy - subTickLen, cx - subPos, cy + subTickLen, reticlePaint)
        canvas.drawLine(cx + subPos, cy - subTickLen, cx + subPos, cy + subTickLen, reticlePaint)

        // 3. Center Target Dot (Screen Tap Anchor Point)
        val dotRadius = Math.max(3.5f, radius * 0.08f)
        dotPaint.color = Color.BLACK
        canvas.drawCircle(cx, cy, dotRadius + 1.5f, dotPaint)
        dotPaint.color = if (isClicking) colorActive else colorPrimary
        canvas.drawCircle(cx, cy, dotRadius, dotPaint)

        // 4. Visual Feedback for Active Click Loop
        if (isClicking) {
            pulsePaint.color = colorActive
            pulsePaint.strokeWidth = strokeW * 1.5f
            canvas.drawCircle(cx, cy, radius * 0.38f, pulsePaint)
        }

        // 5. Status indicator badge
        if (!isLocked) {
            // Drag mode indicator
            textPaint.color = colorAccent
            textPaint.textSize = Math.max(16f, radius * 0.22f)
            canvas.drawText("MOVE", cx, cy + radius * 0.40f, textPaint)
        }
    }

    /**
     * Calculates the exact screen coordinate (X, Y) corresponding to the center dot.
     */
    fun getReticleScreenCenter(): Pair<Int, Int> {
        val location = IntArray(2)
        getLocationOnScreen(location)
        val centerX = location[0] + width / 2
        val centerY = location[1] + height / 2
        return Pair(centerX, centerY)
    }
}
