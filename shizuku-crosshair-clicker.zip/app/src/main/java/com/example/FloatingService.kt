package com.example

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import kotlin.math.abs

/**
 * Foreground Service managing the WindowManager overlays:
 * 1. Tactical Crosshair Reticle Overlay (with hold-to-click Shizuku tap injection)
 * 2. Floating Settings Trigger Button (edge-anchored compact launcher)
 * 3. Center Compact Frosted Customization Panel (low opacity glassmorphism HUD)
 */
class FloatingService : Service() {

    private lateinit var windowManager: WindowManager

    // Overlays
    private var crosshairView: CrosshairView? = null
    private var crosshairParams: WindowManager.LayoutParams? = null

    private var triggerView: View? = null
    private var triggerParams: WindowManager.LayoutParams? = null

    private var panelView: View? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var isPanelVisible = false

    // Tap loop & coroutines
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var clickJob: Job? = null
    @Volatile private var isHolding = false

    // Reticle Configuration State
    private var isLocked = true
    private var reticleSizePx = 120 // 50 to 250
    private var reticleOpacityPercent = 85 // 10 to 100
    private var clickIntervalMs = 50L // 10 to 500

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundNotification()

        initCrosshairOverlay()
        initFloatingTrigger()
        initCenterCustomizationPanel()

        isRunning.value = true
        Log.i(TAG, "FloatingService created and overlays attached")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = NOTIFICATION_CHANNEL_ID
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the floating reticle overlay running during gaming"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pOpenIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, FloatingService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val pStopIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_gear)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_desc))
            .setContentIntent(pOpenIntent)
            .addAction(R.drawable.ic_close, "Stop Overlay", pStopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    // ==========================================
    // 1. Crosshair Reticle Overlay
    // ==========================================
    private fun initCrosshairOverlay() {
        val crosshair = CrosshairView(this).apply {
            isLocked = this@FloatingService.isLocked
            alpha = reticleOpacityPercent / 100f
        }
        crosshairView = crosshair

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            reticleSizePx,
            reticleSizePx,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = 0
            y = 0
        }
        crosshairParams = params

        setupCrosshairTouchListener(crosshair, params)
        windowManager.addView(crosshair, params)
    }

    private fun setupCrosshairTouchListener(view: CrosshairView, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchDownX = 0f
        var touchDownY = 0f

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchDownX = event.rawX
                    touchDownY = event.rawY

                    if (isLocked) {
                        // Locked State: Start continuous click loop
                        isHolding = true
                        view.isClicking = true
                        startClickLoop()
                    }
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    if (!isLocked) {
                        // Unlocked State: Drag reticle across screen
                        val dx = (event.rawX - touchDownX).toInt()
                        val dy = (event.rawY - touchDownY).toInt()
                        params.x = startX + dx
                        params.y = startY + dy
                        windowManager.updateViewLayout(view, params)
                    }
                    true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isLocked) {
                        // Instantly stop click loop
                        isHolding = false
                        view.isClicking = false
                        stopClickLoop()
                    }
                    true
                }

                else -> false
            }
        }
    }

    // ==========================================
    // 2. Floating Settings Trigger Button
    // ==========================================
    private fun initFloatingTrigger() {
        val inflater = LayoutInflater.from(this)
        val trigger = inflater.inflate(R.layout.overlay_floating_trigger, null)
        triggerView = trigger

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24
            y = 350
        }
        triggerParams = params

        setupTriggerTouchListener(trigger, params)
        windowManager.addView(trigger, params)
    }

    private fun setupTriggerTouchListener(view: View, params: WindowManager.LayoutParams) {
        var startX = 0
        var startY = 0
        var touchDownX = 0f
        var touchDownY = 0f
        var touchDownTime = 0L

        view.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x
                    startY = params.y
                    touchDownX = event.rawX
                    touchDownY = event.rawY
                    touchDownTime = System.currentTimeMillis()
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - touchDownX).toInt()
                    val dy = (event.rawY - touchDownY).toInt()
                    params.x = startX + dx
                    params.y = startY + dy
                    windowManager.updateViewLayout(view, params)
                    true
                }

                MotionEvent.ACTION_UP -> {
                    val duration = System.currentTimeMillis() - touchDownTime
                    val moveDist = abs(event.rawX - touchDownX) + abs(event.rawY - touchDownY)
                    // If tap with minimal movement, toggle customization panel
                    if (duration < 400 && moveDist < 20) {
                        toggleCenterPanel()
                    }
                    true
                }

                else -> false
            }
        }
    }

    // ==========================================
    // 3. Center Frosted Customization Panel
    // ==========================================
    private fun initCenterCustomizationPanel() {
        val inflater = LayoutInflater.from(this)
        val panel = inflater.inflate(R.layout.overlay_customization_panel, null)
        panelView = panel

        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }
        panelParams = params

        // Setup Controls
        val switchLock = panel.findViewById<Switch>(R.id.switchLock)
        val tvLockStatus = panel.findViewById<TextView>(R.id.tvLockStatus)
        val seekBarSize = panel.findViewById<SeekBar>(R.id.seekBarSize)
        val tvSizeValue = panel.findViewById<TextView>(R.id.tvSizeValue)
        val seekBarOpacity = panel.findViewById<SeekBar>(R.id.seekBarOpacity)
        val tvOpacityValue = panel.findViewById<TextView>(R.id.tvOpacityValue)
        val seekBarInterval = panel.findViewById<SeekBar>(R.id.seekBarInterval)
        val tvIntervalValue = panel.findViewById<TextView>(R.id.tvIntervalValue)
        val btnClose = panel.findViewById<ImageButton>(R.id.btnClosePanel)

        // 1. Lock/Unlock Switch
        switchLock.isChecked = isLocked
        switchLock.setOnCheckedChangeListener { _, isChecked ->
            isLocked = isChecked
            isLockedState.value = isChecked
            crosshairView?.isLocked = isChecked
            tvLockStatus.text = if (isChecked) {
                "Locked: Tap to click • Drag disabled"
            } else {
                "Unlocked: Touch and drag reticle to aim"
            }
        }

        // 2. Crosshair Size (50px to 250px)
        // Range 50..250 -> max is 200 (progress 0 = 50px)
        seekBarSize.progress = reticleSizePx - 50
        tvSizeValue.text = "$reticleSizePx px"
        seekBarSize.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                reticleSizePx = 50 + progress
                tvSizeValue.text = "$reticleSizePx px"
                crosshairSizeState.value = reticleSizePx
                crosshairParams?.let { cp ->
                    cp.width = reticleSizePx
                    cp.height = reticleSizePx
                    crosshairView?.let { cv ->
                        windowManager.updateViewLayout(cv, cp)
                        cv.invalidate()
                    }
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // 3. Opacity (10% to 100%)
        // Range 10..100 -> max is 90 (progress 0 = 10%)
        seekBarOpacity.progress = reticleOpacityPercent - 10
        tvOpacityValue.text = "$reticleOpacityPercent%"
        seekBarOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                reticleOpacityPercent = 10 + progress
                tvOpacityValue.text = "$reticleOpacityPercent%"
                opacityState.value = reticleOpacityPercent
                crosshairView?.alpha = reticleOpacityPercent / 100f
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // 4. Click Interval (10ms to 500ms)
        // Range 10..500 -> max is 490 (progress 0 = 10ms)
        seekBarInterval.progress = (clickIntervalMs - 10).toInt()
        val initialCps = if (clickIntervalMs > 0) 1000f / clickIntervalMs else 0f
        tvIntervalValue.text = "$clickIntervalMs ms (%.0f clicks/s)".format(initialCps)
        seekBarInterval.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                clickIntervalMs = 10L + progress
                intervalMsState.value = clickIntervalMs
                val cps = if (clickIntervalMs > 0) 1000f / clickIntervalMs else 0f
                tvIntervalValue.text = "$clickIntervalMs ms (%.0f clicks/s)".format(cps)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // 5. Close Button
        btnClose.setOnClickListener {
            hideCenterPanel()
        }
    }

    private fun toggleCenterPanel() {
        if (isPanelVisible) {
            hideCenterPanel()
        } else {
            showCenterPanel()
        }
    }

    private fun showCenterPanel() {
        if (!isPanelVisible && panelView != null && panelParams != null) {
            try {
                windowManager.addView(panelView, panelParams)
                isPanelVisible = true
            } catch (e: Exception) {
                Log.e(TAG, "Error showing center panel", e)
            }
        }
    }

    private fun hideCenterPanel() {
        if (isPanelVisible && panelView != null) {
            try {
                windowManager.removeView(panelView)
                isPanelVisible = false
            } catch (e: Exception) {
                Log.e(TAG, "Error hiding center panel", e)
            }
        }
    }

    // ==========================================
    // 4. Shizuku Input Injection Logic
    // ==========================================
    private fun startClickLoop() {
        clickJob?.cancel()
        clickJob = serviceScope.launch(Dispatchers.IO) {
            while (isActive && isHolding) {
                val point = withContext(Dispatchers.Main) {
                    crosshairView?.getReticleScreenCenter()
                }

                if (point != null) {
                    val (x, y) = point
                    executeShizukuTap(x, y)
                    withContext(Dispatchers.Main) {
                        lastTapCoord.value = Pair(x, y)
                        tapCount.value += 1
                    }
                }

                delay(clickIntervalMs)
            }
        }
    }

    private fun stopClickLoop() {
        clickJob?.cancel()
        clickJob = null
    }

    // Cached reflection for Shizuku.newProcess
    private val shizukuNewProcessMethod by lazy {
        try {
            Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply {
                isAccessible = true
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to reflect Shizuku.newProcess", e)
            null
        }
    }

    private fun executeShizukuTap(x: Int, y: Int) {
        try {
            val isBinderAlive = try {
                Shizuku.pingBinder()
            } catch (e: Throwable) {
                false
            }

            val hasPermission = if (isBinderAlive) {
                try {
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                } catch (e: Throwable) {
                    false
                }
            } else {
                false
            }

            if (isBinderAlive && hasPermission) {
                // Execute low-level input tap via Shizuku shell process
                val cmd = "input tap $x $y"
                val method = shizukuNewProcessMethod
                if (method != null) {
                    val process = method.invoke(
                        null,
                        arrayOf("sh", "-c", cmd),
                        null,
                        null
                    ) as? Process

                    process?.let { p ->
                        p.outputStream?.close()
                        p.inputStream?.close()
                        p.errorStream?.close()
                        p.waitFor()
                        p.destroy()
                    }
                } else {
                    Log.w(TAG, "Shizuku newProcess method unavailable")
                }
            } else {
                Log.w(TAG, "Shizuku not ready (alive: $isBinderAlive, permission: $hasPermission). Tap at ($x, $y) skipped.")
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Shizuku tap execution failed at ($x, $y)", e)
        }
    }

    // ==========================================
    // Lifecycle Cleanup
    // ==========================================
    override fun onDestroy() {
        super.onDestroy()
        isHolding = false
        stopClickLoop()
        serviceScope.cancel()

        // Cleanly remove all overlays so no clutter remains
        if (isPanelVisible && panelView != null) {
            try {
                windowManager.removeView(panelView)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing panelView", e)
            }
            isPanelVisible = false
        }
        panelView = null

        if (triggerView != null) {
            try {
                windowManager.removeView(triggerView)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing triggerView", e)
            }
            triggerView = null
        }

        if (crosshairView != null) {
            try {
                windowManager.removeView(crosshairView)
            } catch (e: Exception) {
                Log.e(TAG, "Error removing crosshairView", e)
            }
            crosshairView = null
        }

        isRunning.value = false
        Log.i(TAG, "FloatingService destroyed: all overlays cleanly removed from WindowManager")
    }

    companion object {
        const val TAG = "FloatingService"
        const val NOTIFICATION_CHANNEL_ID = "crosshair_service_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_SERVICE = "com.example.ACTION_STOP_SERVICE"

        // Observable StateFlows for UI synchronization
        val isRunning = MutableStateFlow(false)
        val isLockedState = MutableStateFlow(true)
        val crosshairSizeState = MutableStateFlow(120)
        val opacityState = MutableStateFlow(85)
        val intervalMsState = MutableStateFlow(50L)
        val lastTapCoord = MutableStateFlow<Pair<Int, Int>?>(null)
        val tapCount = MutableStateFlow(0)

        fun start(context: Context) {
            val intent = Intent(context, FloatingService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingService::class.java)
            context.stopService(intent)
        }
    }
}
