package com.example

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private var shizukuPermissionGranted by mutableStateOf(false)
    private var shizukuAvailable by mutableStateOf(false)
    private var overlayPermissionGranted by mutableStateOf(false)
    private var notificationPermissionGranted by mutableStateOf(false)

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        checkShizukuState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        checkShizukuState()
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode: Int, _: Int ->
        if (requestCode == ShizukuManager.SHIZUKU_PERMISSION_REQUEST_CODE) {
            checkShizukuState()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        ShizukuManager.addBinderReceivedListener(binderReceivedListener)
        ShizukuManager.addBinderDeadListener(binderDeadListener)
        ShizukuManager.addRequestPermissionResultListener(permissionResultListener)

        setContent {
            MyApplicationTheme {
                MainScreen(
                    shizukuAvailable = shizukuAvailable,
                    shizukuPermissionGranted = shizukuPermissionGranted,
                    overlayPermissionGranted = overlayPermissionGranted,
                    notificationPermissionGranted = notificationPermissionGranted,
                    onRequestShizukuPermission = { ShizukuManager.requestPermission() },
                    onRequestOverlayPermission = { requestOverlayPermission() },
                    onStartService = { startOverlayService() },
                    onStopService = { stopOverlayService() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkAllPermissions()
    }

    override fun onDestroy() {
        ShizukuManager.removeBinderReceivedListener(binderReceivedListener)
        ShizukuManager.removeBinderDeadListener(binderDeadListener)
        ShizukuManager.removeRequestPermissionResultListener(permissionResultListener)
        super.onDestroy()
    }

    private fun checkAllPermissions() {
        checkShizukuState()
        overlayPermissionGranted = Settings.canDrawOverlays(this)
        notificationPermissionGranted = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    private fun checkShizukuState() {
        shizukuAvailable = ShizukuManager.isShizukuAvailable()
        shizukuPermissionGranted = ShizukuManager.hasPermission()
    }

    private fun requestOverlayPermission() {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivity(intent)
    }

    private fun startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant System Overlay permission first!", Toast.LENGTH_SHORT).show()
            requestOverlayPermission()
            return
        }

        if (!ShizukuManager.hasPermission()) {
            Toast.makeText(this, "Please grant Shizuku permission for click taps!", Toast.LENGTH_SHORT).show()
            ShizukuManager.requestPermission()
            return
        }

        val serviceIntent = Intent(this, FloatingClickerService::class.java).apply {
            action = FloatingClickerService.ACTION_START_SERVICE
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "Floating Clicker Launched! Check your screen.", Toast.LENGTH_SHORT).show()
    }

    private fun stopOverlayService() {
        val serviceIntent = Intent(this, FloatingClickerService::class.java).apply {
            action = FloatingClickerService.ACTION_STOP_SERVICE
        }
        startService(serviceIntent)
        Toast.makeText(this, "Overlays Stopped.", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun MainScreen(
    shizukuAvailable: Boolean,
    shizukuPermissionGranted: Boolean,
    overlayPermissionGranted: Boolean,
    notificationPermissionGranted: Boolean,
    onRequestShizukuPermission: () -> Unit,
    onRequestOverlayPermission: () -> Unit,
    onStartService: () -> Unit,
    onStopService: () -> Unit
) {
    val scrollState = rememberScrollState()
    val context = LocalContext.current

    val notificationLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Header Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.linearGradient(
                                colors = listOf(
                                    Color(0xFF0D1B2A),
                                    Color(0xFF1B263B),
                                    DarkSurface
                                )
                            )
                        )
                        .padding(20.dp)
                ) {
                    Column {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "⚡ AUTO CLICKER",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Black,
                                color = CyberCyan,
                                letterSpacing = 1.sp
                            )
                            StatusPill(
                                isReady = shizukuPermissionGranted && overlayPermissionGranted
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Floating WindowManager Overlay powered by Shizuku Low-Latency Tap Engine",
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary
                        )
                    }
                }
            }

            // Launch Controls Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "OVERLAY SERVICE CONTROLS",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan
                    )

                    Button(
                        onClick = onStartService,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("main_launch_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonGreen,
                            contentColor = Color.Black
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Start Overlays",
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "START FLOATING OVERLAYS",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }

                    OutlinedButton(
                        onClick = onStopService,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("main_stop_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = Color(0xFFEF4444)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "Stop Overlays",
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "DISMISS / STOP OVERLAYS",
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }

            // Permissions Status Section
            Text(
                text = "SYSTEM PERMISSIONS",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = TextSecondary
            )

            // 1. Shizuku Status Card
            PermissionCard(
                title = "Shizuku ADB Service",
                description = if (!shizukuAvailable) {
                    "Shizuku is not running. Launch Shizuku app and start via Wireless Debugging or ADB."
                } else if (shizukuPermissionGranted) {
                    "Connected & Permission Granted. Ready for high-speed input taps."
                } else {
                    "Shizuku is running but permission is required for simulating taps."
                },
                isGranted = shizukuPermissionGranted,
                buttonText = if (!shizukuAvailable) "Check Shizuku" else "Grant Shizuku",
                testTag = "shizuku_permission_button",
                onButtonClick = onRequestShizukuPermission
            )

            // 2. System Alert Window Overlay
            PermissionCard(
                title = "Draw Over Other Apps",
                description = "Required to display the Floating Crosshair, Settings Cog, and Sliders over games.",
                isGranted = overlayPermissionGranted,
                buttonText = "Grant Overlay",
                testTag = "overlay_permission_button",
                onButtonClick = onRequestOverlayPermission
            )

            // 3. Notification Permission (Android 13+)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !notificationPermissionGranted) {
                PermissionCard(
                    title = "Foreground Notification",
                    description = "Needed to keep the overlay service persistent while switching apps and games.",
                    isGranted = notificationPermissionGranted,
                    buttonText = "Allow Notifications",
                    testTag = "notification_permission_button",
                    onButtonClick = {
                        notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                )
            }

            // Features & Gaming Guide
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = "GAMING AUTO CLICKER FEATURES",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = CyberCyan
                    )

                    FeatureRow(
                        icon = Icons.Default.Speed,
                        title = "Speed & Humanized Jitter",
                        desc = "Adjust click frequency from 20ms to 1000ms with automatic ±15ms humanized randomness."
                    )

                    FeatureRow(
                        icon = Icons.Default.Lock,
                        title = "Freeze Target (Lock/Unlock)",
                        desc = "Pin the crosshair over game buttons (e.g. Fire) so touch gestures don't dislodge it."
                    )

                    FeatureRow(
                        icon = Icons.Default.Layers,
                        title = "Dynamic Size & Transparency",
                        desc = "Scale the reticle and floating cog from 40dp to 120dp, and adjust opacity from 20% to 100%."
                    )
                }
            }

            // Greeting Composable kept for test harness backwards compatibility
            Greeting(name = "Auto Clicker Ready")

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun StatusPill(isReady: Boolean) {
    Surface(
        shape = CircleShape,
        color = if (isReady) Color(0x2200E676) else Color(0x22EF4444),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isReady) NeonGreen else Color(0xFFEF4444)
        )
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .background(
                        if (isReady) NeonGreen else Color(0xFFEF4444),
                        shape = CircleShape
                    )
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isReady) "READY" else "CONFIG REQUIRED",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isReady) NeonGreen else Color(0xFFEF4444)
            )
        }
    }
}

@Composable
fun PermissionCard(
    title: String,
    description: String,
    isGranted: Boolean,
    buttonText: String,
    testTag: String,
    onButtonClick: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceVariant)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                contentDescription = null,
                tint = if (isGranted) NeonGreen else Color(0xFFFFB74D),
                modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary
                )
                if (!isGranted) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = onButtonClick,
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyan,
                            contentColor = Color.Black
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
                        modifier = Modifier
                            .height(34.dp)
                            .testTag(testTag)
                    ) {
                        Text(
                            text = buttonText,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FeatureRow(
    icon: ImageVector,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Surface(
            shape = RoundedCornerShape(10.dp),
            color = DarkSurfaceVariant,
            modifier = Modifier.size(36.dp)
        ) {
            Box(contentAlignment = Alignment.Center) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = CyberCyan,
                    modifier = Modifier.size(20.dp)
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            Text(
                text = desc,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = name,
        style = MaterialTheme.typography.bodySmall,
        color = TextSecondary.copy(alpha = 0.5f),
        modifier = modifier.padding(top = 4.dp)
    )
}

@Preview(showBackground = true)
@Composable
fun MainScreenPreview() {
    MyApplicationTheme {
        MainScreen(
            shizukuAvailable = true,
            shizukuPermissionGranted = true,
            overlayPermissionGranted = true,
            notificationPermissionGranted = true,
            onRequestShizukuPermission = {},
            onRequestOverlayPermission = {},
            onStartService = {},
            onStopService = {}
        )
    }
}
