package com.example

import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.OutputStream
import java.lang.reflect.Method
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Manages Shizuku connection, permission checks, binder lifecycle,
 * and low-latency input tap process execution via Shizuku.newProcess.
 */
object ShizukuManager {
    private const val TAG = "ShizukuManager"
    const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001

    private var persistentProcess: Process? = null
    private var persistentOutputStream: OutputStream? = null
    private val isShellActive = AtomicBoolean(false)

    // Cached reflection handle for Shizuku.newProcess
    private val newProcessMethod: Method? by lazy {
        try {
            Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply {
                isAccessible = true
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to reflect Shizuku.newProcess method", e)
            null
        }
    }

    /**
     * Executes a process with elevated Shizuku ADB/root privileges using Shizuku.newProcess.
     */
    fun newProcess(cmd: Array<String>, env: Array<String>? = null, dir: String? = null): Process? {
        return try {
            newProcessMethod?.invoke(null, cmd, env, dir) as? Process
        } catch (e: Throwable) {
            Log.e(TAG, "Error invoking Shizuku.newProcess", e)
            null
        }
    }

    /**
     * Checks whether Shizuku service is running and binder is responding.
     */
    fun isShizukuAvailable(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Throwable) {
            Log.e(TAG, "Shizuku pingBinder failed: ${e.message}")
            false
        }
    }

    /**
     * Checks if Shizuku permission has been granted to this app.
     */
    fun hasPermission(): Boolean {
        if (!isShizukuAvailable()) return false
        return try {
            if (Shizuku.isPreV11()) {
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to check Shizuku permission", e)
            false
        }
    }

    /**
     * Requests Shizuku permission via the standard Shizuku API dialog.
     */
    fun requestPermission(requestCode: Int = SHIZUKU_PERMISSION_REQUEST_CODE) {
        if (isShizukuAvailable() && !hasPermission()) {
            try {
                Shizuku.requestPermission(requestCode)
            } catch (e: Throwable) {
                Log.e(TAG, "Failed to request Shizuku permission", e)
            }
        }
    }

    fun addBinderReceivedListener(listener: Shizuku.OnBinderReceivedListener) {
        try {
            Shizuku.addBinderReceivedListenerSticky(listener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error adding binder received listener", e)
        }
    }

    fun removeBinderReceivedListener(listener: Shizuku.OnBinderReceivedListener) {
        try {
            Shizuku.removeBinderReceivedListener(listener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error removing binder received listener", e)
        }
    }

    fun addBinderDeadListener(listener: Shizuku.OnBinderDeadListener) {
        try {
            Shizuku.addBinderDeadListener(listener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error adding binder dead listener", e)
        }
    }

    fun removeBinderDeadListener(listener: Shizuku.OnBinderDeadListener) {
        try {
            Shizuku.removeBinderDeadListener(listener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error removing binder dead listener", e)
        }
    }

    fun addRequestPermissionResultListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try {
            Shizuku.addRequestPermissionResultListener(listener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error adding permission result listener", e)
        }
    }

    fun removeRequestPermissionResultListener(listener: Shizuku.OnRequestPermissionResultListener) {
        try {
            Shizuku.removeRequestPermissionResultListener(listener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error removing permission result listener", e)
        }
    }

    /**
     * Initializes a persistent root/ADB shell process through Shizuku
     * for high-frequency, low-latency tapping without spawning a new process on each click.
     */
    @Synchronized
    private fun ensurePersistentShell(): Boolean {
        if (isShellActive.get() && persistentOutputStream != null) {
            return true
        }
        return try {
            destroyShell()
            val process = newProcess(arrayOf("sh"), null, null)
            if (process != null) {
                persistentProcess = process
                persistentOutputStream = process.outputStream
                isShellActive.set(true)
                true
            } else {
                false
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to initialize persistent shell via Shizuku", e)
            destroyShell()
            false
        }
    }

    /**
     * Destroys persistent shell process and releases standard streams.
     */
    @Synchronized
    fun destroyShell() {
        try {
            persistentOutputStream?.close()
        } catch (_: Throwable) {}
        try {
            persistentProcess?.destroy()
        } catch (_: Throwable) {}
        persistentOutputStream = null
        persistentProcess = null
        isShellActive.set(false)
    }

    /**
     * Executes an input tap at (x, y) coordinates via Shizuku with ultra-low latency.
     * Tries the persistent shell pipe first, and falls back to a standalone Shizuku process.
     */
    suspend fun executeInputTap(x: Int, y: Int): Boolean = withContext(Dispatchers.IO) {
        if (!hasPermission()) {
            Log.w(TAG, "Cannot tap: Shizuku permission not granted")
            return@withContext false
        }

        val tapCommand = "input tap $x $y\n"
        try {
            if (ensurePersistentShell()) {
                val os = persistentOutputStream
                if (os != null) {
                    os.write(tapCommand.toByteArray(Charsets.UTF_8))
                    os.flush()
                    return@withContext true
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Persistent shell tap failed, reconnecting and falling back: ${e.message}")
            destroyShell()
        }

        // Direct process fallback
        return@withContext try {
            val process = newProcess(arrayOf("input", "tap", x.toString(), y.toString()), null, null)
            val exitCode = process?.waitFor() ?: -1
            exitCode == 0
        } catch (e: Throwable) {
            Log.e(TAG, "Direct Shizuku tap failed", e)
            false
        }
    }
}
