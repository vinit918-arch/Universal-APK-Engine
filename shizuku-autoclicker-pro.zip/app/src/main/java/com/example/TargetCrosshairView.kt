package com.example

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View

/**
 * Custom View rendering the precision "Locket" Crosshair target with:
 * - Dynamic Neon Cyan / Amber color scheme depending on Freeze/Lock state
 * - Precision reticle rings and crosshair guidelines
 * - Center coordinate label readout
 * - Animated tap feedback pulse
 */
class TargetCrosshairView(context: Context) : View(context) {

    var isFrozen: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var isFlashing: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    var targetX: Int = 0
    var targetY: Int = 0

    private val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val innerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val crosshairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 3f
        strokeCap = Paint.Cap.ROUND
    }

    private val centerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 24f
        textAlign = Paint.Align.CENTER
        setShadowLayer(4f, 0f, 2f, Color.BLACK)
    }

    private val flashPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.argb(140, 255, 235, 59) // Radiant gold flash
    }

    private val badgeBackgroundPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    private val badgeRect = RectF()

    fun updateCoordinates(x: Int, y: Int) {
        targetX = x
        targetY = y
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        val widthF = width.toFloat()
        val heightF = height.toFloat()
        if (widthF <= 0f || heightF <= 0f) return

        val centerX = widthF / 2f
        val centerY = heightF / 2f
        val radius = (Math.min(widthF, heightF) / 2f) - 8f

        // Colors adjust depending on Lock (Freeze) state
        val primaryColor = if (isFrozen) Color.parseColor("#FF9800") else Color.parseColor("#00E5FF")
        val secondaryColor = if (isFrozen) Color.parseColor("#FF5722") else Color.parseColor("#00B0FF")
        val dotColor = if (isFrozen) Color.parseColor("#E91E63") else Color.parseColor("#FF1744")

        outerRingPaint.color = primaryColor
        innerRingPaint.color = secondaryColor
        crosshairPaint.color = primaryColor
        centerDotPaint.color = dotColor

        // Tap feedback flash
        if (isFlashing) {
            canvas.drawCircle(centerX, centerY, radius * 0.9f, flashPaint)
        }

        // Outer Reticle Ring
        canvas.drawCircle(centerX, centerY, radius, outerRingPaint)

        // Inner Reticle Ring
        val innerRadius = radius * 0.55f
        canvas.drawCircle(centerX, centerY, innerRadius, innerRingPaint)

        // Precision 4 Crosshair Lines
        val tickLength = radius * 0.22f
        // Top
        canvas.drawLine(centerX, centerY - radius, centerX, centerY - radius + tickLength, crosshairPaint)
        // Bottom
        canvas.drawLine(centerX, centerY + radius - tickLength, centerX, centerY + radius, crosshairPaint)
        // Left
        canvas.drawLine(centerX - radius, centerY, centerX - radius + tickLength, centerY, crosshairPaint)
        // Right
        canvas.drawLine(centerX + radius - tickLength, centerY, centerX + radius, centerY, crosshairPaint)

        // Center Bullseye Dot
        val dotRadius = Math.max(4f, radius * 0.12f)
        canvas.drawCircle(centerX, centerY, dotRadius, centerDotPaint)

        // Lock / Freeze Badge on Top
        if (isFrozen) {
            val badgeWidth = 46f
            val badgeHeight = 22f
            badgeRect.set(centerX - badgeWidth / 2f, centerY - radius - 14f, centerX + badgeWidth / 2f, centerY - radius + 8f)
            badgeBackgroundPaint.color = Color.parseColor("#CC212121")
            canvas.drawRoundRect(badgeRect, 6f, 6f, badgeBackgroundPaint)

            val lockTextPaint = Paint(textPaint).apply {
                color = Color.parseColor("#FFB74D")
                textSize = 18f
                isFakeBoldText = true
            }
            canvas.drawText("LOCK", centerX, centerY - radius + 2f, lockTextPaint)
        }

        // Bottom Coordinates Readout pill
        val coordText = "$targetX, $targetY"
        val textWidth = textPaint.measureText(coordText)
        val pillPadX = 12f
        val pillHeight = 26f
        val pillTop = centerY + radius * 0.6f
        badgeRect.set(centerX - (textWidth / 2f) - pillPadX, pillTop, centerX + (textWidth / 2f) + pillPadX, pillTop + pillHeight)
        badgeBackgroundPaint.color = Color.argb(190, 15, 23, 42)
        canvas.drawRoundRect(badgeRect, 8f, 8f, badgeBackgroundPaint)

        canvas.drawText(coordText, centerX, pillTop + 19f, textPaint)
    }
}
