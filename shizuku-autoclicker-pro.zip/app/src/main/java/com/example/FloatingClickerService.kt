package com.example

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/**
 * Foreground Service that manages:
 * 1. WindowManager overlays (Target "Locket" Crosshair, Floating Cog button, Settings Panel)
 * 2. Touch dragging and Freeze/Lock toggle
 * 3. Dynamic resizing, transparency, and click interval with +/-15ms humanized jitter
 * 4. High-frequency Shizuku tap execution loop on Dispatchers.IO
 */
class FloatingClickerService : Service() {

    companion object {
        const val ACTION_START_SERVICE = "com.example.action.START_SERVICE"
        const val ACTION_STOP_SERVICE = "com.example.action.STOP_SERVICE"
        private const val NOTIFICATION_CHANNEL_ID = "clicker_overlay_channel"
        private const val NOTIFICATION_ID = 2001
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager

    // Overlay Views
    private lateinit var targetView: TargetCrosshairView
    private lateinit var targetParams: WindowManager.LayoutParams

    private lateinit var settingsCogView: FrameLayout
    private lateinit var settingsCogParams: WindowManager.LayoutParams

    private lateinit var settingsPanelView: FrameLayout
    private lateinit var settingsPanelParams: WindowManager.LayoutParams

    // State Variables
    private var isFrozen = false
    private var currentIntervalMs = 100L
    private var currentSizeDp = 72
    private var currentAlpha = 1.0f
    private val isClicking = AtomicBoolean(false)
    private var clickerJob: Job? = null
    private var clickCounter = 0L

    // UI references in Settings Panel
    private var speedLabel: TextView? = null
    private var sizeLabel: TextView? = null
    private var opacityLabel: TextView? = null
    private var freezeButton: Button? = null
    private var startStopButton: Button? = null
    private var statsLabel: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
        startForegroundServiceWithNotification()

        setupTargetOverlay()
        setupSettingsCogOverlay()
        setupSettingsPanelOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                "Gaming Clicker Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active floating overlay service for gaming auto clicker"
                setShowBadge(false)
            }
            val notificationManager = getSystemService(NotificationManager::class.java)
            notificationManager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundServiceWithNotification() {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            this.flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Auto Clicker Active")
            .setContentText("Floating controls are displayed on screen")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    // ==========================================
    // 1. Target "Locket" Crosshair Overlay
    // ==========================================
    @SuppressLint("ClickableViewAccessibility")
    private fun setupTargetOverlay() {
        val targetSizePx = dpToPx(currentSizeDp)
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        targetParams = WindowManager.LayoutParams(
            targetSizePx,
            targetSizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels / 2 - targetSizePx / 2
            y = resources.displayMetrics.heightPixels / 3
        }

        targetView = TargetCrosshairView(this).apply {
            alpha = currentAlpha
        }

        targetView.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                if (isFrozen) {
                    // Frozen/Locked: Ignore drag gestures
                    return false
                }
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = targetParams.x
                        initialY = targetParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        targetParams.x = initialX + dx
                        targetParams.y = initialY + dy
                        try {
                            windowManager.updateViewLayout(targetView, targetParams)
                            updateCoordinatesDisplay()
                        } catch (_: Throwable) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        updateCoordinatesDisplay()
                        return true
                    }
                }
                return false
            }
        })

        try {
            windowManager.addView(targetView, targetParams)
            targetView.post { updateCoordinatesDisplay() }
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    // ==========================================
    // 2. Floating Settings Cog Icon Overlay
    // ==========================================
    @SuppressLint("ClickableViewAccessibility")
    private fun setupSettingsCogOverlay() {
        val cogSizePx = dpToPx((currentSizeDp * 0.75f).toInt().coerceAtLeast(44))
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        settingsCogParams = WindowManager.LayoutParams(
            cogSizePx,
            cogSizePx,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = resources.displayMetrics.heightPixels / 4
        }

        val shapeDrawable = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(Color.parseColor("#E60F172A")) // Dark slate
            setStroke(dpToPx(2), Color.parseColor("#00E5FF")) // Neon Cyan border
        }

        val iconInner = TextView(this).apply {
            text = "⚙"
            textSize = 22f
            setTextColor(Color.parseColor("#00E5FF"))
            gravity = Gravity.CENTER
        }

        settingsCogView = FrameLayout(this).apply {
            background = shapeDrawable
            alpha = currentAlpha
            addView(
                iconInner,
                FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            )
        }

        settingsCogView.setOnTouchListener(object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var isDrag = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = settingsCogParams.x
                        initialY = settingsCogParams.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        isDrag = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()
                        if (Math.hypot(dx.toDouble(), dy.toDouble()) > 15) {
                            isDrag = true
                        }
                        settingsCogParams.x = initialX + dx
                        settingsCogParams.y = initialY + dy
                        try {
                            windowManager.updateViewLayout(settingsCogView, settingsCogParams)
                        } catch (_: Throwable) {}
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!isDrag) {
                            toggleSettingsPanel()
                        }
                        return true
                    }
                }
                return false
            }
        })

        try {
            windowManager.addView(settingsCogView, settingsCogParams)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    // ==========================================
    // 3. Floating Settings Panel Overlay
    // ==========================================
    @SuppressLint("ClickableViewAccessibility", "SetTextI18n")
    private fun setupSettingsPanelOverlay() {
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val panelWidthPx = (resources.displayMetrics.widthPixels * 0.88f).toInt().coerceAtMost(dpToPx(380))

        settingsPanelParams = WindowManager.LayoutParams(
            panelWidthPx,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
        }

        // Panel Container with modern dark gaming glassmorphism
        val panelContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val pad = dpToPx(16)
            setPadding(pad, pad, pad, pad)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(18).toFloat()
                setColor(Color.parseColor("#F00A0E17")) // Deep cyber dark
                setStroke(dpToPx(2), Color.parseColor("#1E293B"))
            }
        }

        // Header Row (Title & Close Button)
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        val titleCol = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }

        val titleText = TextView(this).apply {
            text = "⚡ CLICKER CONTROLS"
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.parseColor("#00E5FF"))
        }

        val subtitleText = TextView(this).apply {
            text = "Shizuku Low-Latency Engine"
            textSize = 11f
            setTextColor(Color.parseColor("#94A3B8"))
        }
        titleCol.addView(titleText)
        titleCol.addView(subtitleText)

        val minimizeBtn = Button(this).apply {
            text = "✕"
            textSize = 14f
            setTextColor(Color.parseColor("#94A3B8"))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#1E293B"))
            }
            val btnSize = dpToPx(36)
            layoutParams = LinearLayout.LayoutParams(btnSize, btnSize)
            setOnClickListener {
                settingsPanelView.visibility = View.GONE
            }
        }

        headerRow.addView(titleCol)
        headerRow.addView(minimizeBtn)
        panelContainer.addView(headerRow)

        // Coordinates & Stats Row
        val statsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            val p = dpToPx(10)
            setPadding(p, p, p, p)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(12)
            }
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(10).toFloat()
                setColor(Color.parseColor("#111827"))
                setStroke(dpToPx(1), Color.parseColor("#1F2937"))
            }
        }

        statsLabel = TextView(this).apply {
            text = "Target: (0, 0) | Clicks: 0"
            textSize = 12f
            typeface = Typeface.MONOSPACE
            setTextColor(Color.parseColor("#E2E8F0"))
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        statsContainer.addView(statsLabel)
        panelContainer.addView(statsContainer)

        // 1. SPEED SLIDER (Click interval ms + randomized jitter)
        speedLabel = TextView(this).apply {
            text = "Click Interval: ${currentIntervalMs}ms (±15ms jitter)"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(12)
            }
        }
        panelContainer.addView(speedLabel)

        val speedSeekBar = SeekBar(this).apply {
            max = 1000 // 20ms to 1020ms
            progress = (currentIntervalMs - 20).toInt().coerceIn(0, 1000)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    currentIntervalMs = (progress + 20).toLong()
                    speedLabel?.text = "Click Interval: ${currentIntervalMs}ms (±15ms jitter)"
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        panelContainer.addView(speedSeekBar)

        // 2. SIZE ADJUSTMENT SLIDER
        sizeLabel = TextView(this).apply {
            text = "Overlay Size: ${currentSizeDp}dp"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(10)
            }
        }
        panelContainer.addView(sizeLabel)

        val sizeSeekBar = SeekBar(this).apply {
            max = 80 // 40dp to 120dp
            progress = (currentSizeDp - 40).coerceIn(0, 80)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    currentSizeDp = progress + 40
                    sizeLabel?.text = "Overlay Size: ${currentSizeDp}dp"
                    updateOverlaySizes(currentSizeDp)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        panelContainer.addView(sizeSeekBar)

        // 3. VISIBILITY / TRANSPARENCY SLIDER
        opacityLabel = TextView(this).apply {
            text = "Opacity: ${(currentAlpha * 100).toInt()}%"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.WHITE)
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpToPx(10)
            }
        }
        panelContainer.addView(opacityLabel)

        val opacitySeekBar = SeekBar(this).apply {
            max = 80 // 20% to 100%
            progress = ((currentAlpha - 0.2f) * 100).toInt().coerceIn(0, 80)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val alphaVal = 0.2f + (progress / 100f)
                    currentAlpha = alphaVal.coerceIn(0.2f, 1.0f)
                    opacityLabel?.text = "Opacity: ${(currentAlpha * 100).toInt()}%"
                    updateOverlaysAlpha(currentAlpha)
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        panelContainer.addView(opacitySeekBar)

        // BUTTONS ROW 1: FREEZE / LOCK TARGET
        freezeButton = Button(this).apply {
            text = "🔓 FREEZE TARGET (DRAGGABLE)"
            textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(10).toFloat()
                setColor(Color.parseColor("#00E5FF")) // Cyan unlocked
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(44)
            ).apply {
                topMargin = dpToPx(14)
            }
            setOnClickListener {
                toggleFreezeTarget()
            }
        }
        panelContainer.addView(freezeButton)

        // BUTTONS ROW 2: START / STOP CLICKER
        startStopButton = Button(this).apply {
            text = "▶ START AUTO CLICKER"
            textSize = 14f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.BLACK)
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(10).toFloat()
                setColor(Color.parseColor("#00E676")) // Neon Green start
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(48)
            ).apply {
                topMargin = dpToPx(10)
            }
            setOnClickListener {
                if (isClicking.get()) {
                    stopClickerLoop()
                } else {
                    startClickerLoop()
                }
            }
        }
        panelContainer.addView(startStopButton)

        // Exit overlay service button
        val exitButton = Button(this).apply {
            text = "STOP & DISMISS OVERLAYS"
            textSize = 12f
            setTextColor(Color.parseColor("#EF4444")) // Crimson Red
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpToPx(8).toFloat()
                setColor(Color.parseColor("#201F1F"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                dpToPx(38)
            ).apply {
                topMargin = dpToPx(8)
            }
            setOnClickListener {
                stopSelf()
            }
        }
        panelContainer.addView(exitButton)

        settingsPanelView = FrameLayout(this).apply {
            visibility = View.GONE
            addView(panelContainer)
        }

        try {
            windowManager.addView(settingsPanelView, settingsPanelParams)
        } catch (e: Throwable) {
            e.printStackTrace()
        }
    }

    private fun toggleSettingsPanel() {
        if (settingsPanelView.visibility == View.VISIBLE) {
            settingsPanelView.visibility = View.GONE
        } else {
            updateCoordinatesDisplay()
            settingsPanelView.visibility = View.VISIBLE
        }
    }

    // ==========================================
    // Dynamic Updates (Size, Alpha, Freeze)
    // ==========================================
    private fun updateOverlaySizes(sizeDp: Int) {
        val targetSizePx = dpToPx(sizeDp)
        targetParams.width = targetSizePx
        targetParams.height = targetSizePx
        try {
            windowManager.updateViewLayout(targetView, targetParams)
            updateCoordinatesDisplay()
        } catch (_: Throwable) {}

        val cogSizePx = dpToPx((sizeDp * 0.75f).toInt().coerceAtLeast(44))
        settingsCogParams.width = cogSizePx
        settingsCogParams.height = cogSizePx
        try {
            windowManager.updateViewLayout(settingsCogView, settingsCogParams)
        } catch (_: Throwable) {}
    }

    private fun updateOverlaysAlpha(alpha: Float) {
        targetView.alpha = alpha
        settingsCogView.alpha = alpha
        settingsPanelView.alpha = alpha
    }

    @SuppressLint("SetTextI18n")
    private fun toggleFreezeTarget() {
        isFrozen = !isFrozen
        targetView.isFrozen = isFrozen

        val bg = freezeButton?.background as? GradientDrawable
        if (isFrozen) {
            freezeButton?.text = "🔒 TARGET FROZEN (PINNED)"
            freezeButton?.setTextColor(Color.WHITE)
            bg?.setColor(Color.parseColor("#FF5722")) // Amber/Red pinned
        } else {
            freezeButton?.text = "🔓 FREEZE TARGET (DRAGGABLE)"
            freezeButton?.setTextColor(Color.BLACK)
            bg?.setColor(Color.parseColor("#00E5FF")) // Cyan draggable
        }
    }

    private fun getAbsoluteCenterCoordinates(): Pair<Int, Int> {
        val loc = IntArray(2)
        targetView.getLocationOnScreen(loc)
        val cx = loc[0] + (targetView.width / 2)
        val cy = loc[1] + (targetView.height / 2)
        return Pair(cx, cy)
    }

    @SuppressLint("SetTextI18n")
    private fun updateCoordinatesDisplay() {
        val (cx, cy) = getAbsoluteCenterCoordinates()
        targetView.updateCoordinates(cx, cy)
        val status = if (isClicking.get()) "RUNNING" else "READY"
        statsLabel?.text = "Target: ($cx, $cy) | Clicks: $clickCounter | $status"
    }

    // ==========================================
    // High-Frequency Auto Clicker Loop
    // ==========================================
    @SuppressLint("SetTextI18n")
    private fun startClickerLoop() {
        if (isClicking.get()) return
        isClicking.set(true)
        clickCounter = 0

        // Update Button UI
        startStopButton?.text = "⏹ STOP AUTO CLICKER"
        startStopButton?.setTextColor(Color.WHITE)
        val bg = startStopButton?.background as? GradientDrawable
        bg?.setColor(Color.parseColor("#E53935")) // Crimson red

        clickerJob = serviceScope.launch(Dispatchers.IO) {
            while (isActive && isClicking.get()) {
                val (tapX, tapY) = withContext(Dispatchers.Main) {
                    getAbsoluteCenterCoordinates()
                }

                val tapped = ShizukuManager.executeInputTap(tapX, tapY)
                if (tapped) {
                    clickCounter++
                }

                withContext(Dispatchers.Main) {
                    targetView.isFlashing = true
                    targetView.postDelayed({ targetView.isFlashing = false }, 40)
                    updateCoordinatesDisplay()
                }

                // Random jitter (+/-15ms)
                val jitter = if (currentIntervalMs > 25) {
                    Random.nextInt(-15, 16)
                } else {
                    0
                }
                val delayDuration = (currentIntervalMs + jitter).coerceAtLeast(10L)
                delay(delayDuration)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun stopClickerLoop() {
        isClicking.set(false)
        clickerJob?.cancel()
        clickerJob = null

        startStopButton?.text = "▶ START AUTO CLICKER"
        startStopButton?.setTextColor(Color.BLACK)
        val bg = startStopButton?.background as? GradientDrawable
        bg?.setColor(Color.parseColor("#00E676")) // Neon Green

        updateCoordinatesDisplay()
    }

    private fun dpToPx(dp: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            dp.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onDestroy() {
        stopClickerLoop()
        serviceScope.cancel()

        try {
            if (::targetView.isInitialized) windowManager.removeView(targetView)
        } catch (_: Throwable) {}
        try {
            if (::settingsCogView.isInitialized) windowManager.removeView(settingsCogView)
        } catch (_: Throwable) {}
        try {
            if (::settingsPanelView.isInitialized) windowManager.removeView(settingsPanelView)
        } catch (_: Throwable) {}

        ShizukuManager.destroyShell()
        super.onDestroy()
    }
}
