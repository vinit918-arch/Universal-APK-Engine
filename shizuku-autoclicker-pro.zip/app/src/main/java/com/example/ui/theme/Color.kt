package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberCyan = Color(0xFF00E5FF)
val CyberCyanDark = Color(0xFF00B0FF)
val NeonGreen = Color(0xFF00E676)
val CyberAmber = Color(0xFFFF9800)
val DarkBackground = Color(0xFF0A0E17)
val DarkSurface = Color(0xFF131B2A)
val DarkSurfaceVariant = Color(0xFF1E293B)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
