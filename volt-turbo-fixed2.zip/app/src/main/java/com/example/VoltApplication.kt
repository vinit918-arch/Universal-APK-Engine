package com.example

import android.app.Application
import android.util.Log
import com.example.shizuku.ShizukuStateRepository

class VoltApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.d("VoltApplication", "onCreate() - Initializing Shizuku state repository")
        ShizukuStateRepository.init(this)
    }
}
