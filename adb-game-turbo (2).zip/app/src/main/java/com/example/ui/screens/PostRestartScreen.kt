package com.example.ui.screens

import android.content.pm.PackageManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Gamepad
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.example.model.DeviceUptimeInfo
import com.example.model.InstalledAppInfo
import com.example.model.PostRestartAction
import com.example.model.PostRestartCatalogue
import com.example.model.SavedGame
import com.example.ui.components.MonospaceTag
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberOrange
import com.example.ui.theme.CyberOrangeDark
import com.example.ui.theme.CyberOrangeDim
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.MonospaceFont
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.TextCode
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostRestartScreen(
    selectedActionIds: Set<String>,
    isExecuting: Boolean,
    uptimeInfo: DeviceUptimeInfo,
    savedGames: List<SavedGame>,
    installedApps: List<InstalledAppInfo>,
    isLoadingApps: Boolean,
    onToggleAction: (String) -> Unit,
    onSelectAll: (Boolean) -> Unit,
    onRefreshUptime: () -> Unit,
    onLaunchWithGame: (SavedGame) -> Unit,
    modifier: Modifier = Modifier
) {
    var showGamePickerSheet by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Card
            item {
                PostRestartHeaderCard(
                    uptimeInfo = uptimeInfo,
                    onRefreshUptime = onRefreshUptime
                )
            }

            // Quick Selection Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = null,
                            tint = CyberOrange,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "ONE-SHOT CLEANUP ACTIONS",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            ),
                            color = CyberOrange
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val allSelected = selectedActionIds.size == PostRestartCatalogue.ALL_ACTIONS.size
                        OutlinedButton(
                            onClick = { onSelectAll(!allSelected) },
                            shape = RoundedCornerShape(6.dp),
                            border = BorderStroke(1.dp, CyberOrange.copy(alpha = 0.5f)),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = CyberOrange
                            ),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp).testTag("select_all_post_restart_button")
                        ) {
                            Text(
                                text = if (allSelected) "DESELECT ALL" else "SELECT ALL",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = MonospaceFont,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp
                                )
                            )
                        }
                    }
                }
            }

            // List of Post-Restart Action items
            items(PostRestartCatalogue.ALL_ACTIONS, key = { it.id }) { action ->
                val isChecked = selectedActionIds.contains(action.id)
                PostRestartActionCard(
                    action = action,
                    isChecked = isChecked,
                    onToggle = { onToggleAction(action.id) }
                )
            }
        }

        // Bottom Fixed Launch Action Bar
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(12.dp),
            color = DarkSurfaceElevated,
            border = BorderStroke(1.dp, CyberOrange.copy(alpha = 0.6f)),
            shadowElevation = 12.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${selectedActionIds.size}/${PostRestartCatalogue.ALL_ACTIONS.size} SELECTED",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = MonospaceFont,
                            fontWeight = FontWeight.Bold
                        ),
                        color = if (selectedActionIds.isNotEmpty()) CyberOrange else TextSecondary
                    )
                    Text(
                        text = if (isExecuting) "Executing ADB Sequence..." else "Ready to execute & launch",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextSecondary
                    )
                }

                Button(
                    onClick = { showGamePickerSheet = true },
                    enabled = !isExecuting && selectedActionIds.isNotEmpty(),
                    modifier = Modifier.testTag("run_and_launch_game_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberOrange,
                        contentColor = DarkBackground,
                        disabledContainerColor = DarkSurfaceVariant,
                        disabledContentColor = TextMuted
                    )
                ) {
                    if (isExecuting) {
                        CircularProgressIndicator(
                            color = DarkBackground,
                            modifier = Modifier.size(16.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("RUNNING...", fontWeight = FontWeight.Black, fontSize = 12.sp)
                    } else {
                        Icon(
                            imageVector = Icons.Default.RocketLaunch,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "RUN & LAUNCH GAME",
                            fontWeight = FontWeight.Black,
                            fontSize = 12.sp,
                            fontFamily = MonospaceFont
                        )
                    }
                }
            }
        }
    }

    // Modal Game Picker Sheet to choose which game to launch after running actions
    if (showGamePickerSheet) {
        PostRestartGamePickerSheet(
            savedGames = savedGames,
            installedApps = installedApps,
            isLoadingApps = isLoadingApps,
            onDismiss = { showGamePickerSheet = false },
            onSelectGame = { game ->
                showGamePickerSheet = false
                onLaunchWithGame(game)
            }
        )
    }
}

@Composable
fun PostRestartHeaderCard(
    uptimeInfo: DeviceUptimeInfo,
    onRefreshUptime: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("post_restart_header_card"),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = BorderStroke(1.dp, CyberOrange.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(CyberOrangeDim)
                            .border(1.dp, CyberOrange.copy(alpha = 0.6f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.ElectricBolt,
                            contentDescription = null,
                            tint = CyberOrange,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "POST-RESTART BOOST",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Black,
                                letterSpacing = 0.5.sp
                            ),
                            color = TextPrimary
                        )
                        Text(
                            text = "Fresh Boot Turbo Sequence",
                            style = MaterialTheme.typography.bodySmall,
                            color = TextSecondary
                        )
                    }
                }

                MonospaceTag(
                    text = "ONE-SHOT",
                    color = CyberOrange
                )
            }

            Text(
                text = "Runs aggressive clean-up commands tailored for execution immediately following a system restart: purges dormant boot bloatware, trims accumulated package caches, locks high-performance power profiles, and forces optimal GPU drivers.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary,
                lineHeight = 18.sp
            )

            // Uptime Diagnostic Banner
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(8.dp),
                color = if (uptimeInfo.isRestartRecommended) Color(0xFF261805) else Color(0xFF0E2218),
                border = BorderStroke(
                    1.dp,
                    if (uptimeInfo.isRestartRecommended) CyberOrange.copy(alpha = 0.5f) else NeonGreen.copy(alpha = 0.4f)
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = if (uptimeInfo.isRestartRecommended) Icons.Default.Warning else Icons.Default.Check,
                        contentDescription = null,
                        tint = if (uptimeInfo.isRestartRecommended) CyberOrange else NeonGreen,
                        modifier = Modifier.size(16.dp)
                    )

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (uptimeInfo.isRestartRecommended) {
                                "Restart Recommended (Uptime: ${uptimeInfo.formattedUptime})"
                            } else {
                                "Peak Readiness (Uptime: ${uptimeInfo.formattedUptime})"
                            },
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = MonospaceFont,
                                fontWeight = FontWeight.Bold
                            ),
                            color = if (uptimeInfo.isRestartRecommended) CyberOrange else NeonGreen
                        )
                        Text(
                            text = if (uptimeInfo.isRestartRecommended) {
                                "Device uptime exceeds 3 hours. Post-Restart Boost is most effective right after a fresh phone restart."
                            } else {
                                "Device was restarted recently. System memory and CPU states are prime for maximum turbo boost."
                            },
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = TextSecondary
                        )
                    }

                    IconButton(
                        onClick = onRefreshUptime,
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Refresh Uptime",
                            tint = TextSecondary,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun PostRestartActionCard(
    action: PostRestartAction,
    isChecked: Boolean,
    onToggle: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onToggle() }
            .testTag("post_restart_card_${action.id}"),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isChecked) DarkSurfaceElevated else DarkSurface
        ),
        border = BorderStroke(
            1.dp,
            if (isChecked) CyberOrange.copy(alpha = 0.5f) else DarkBorder
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Checkbox(
                checked = isChecked,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(
                    checkedColor = CyberOrange,
                    checkmarkColor = DarkBackground,
                    uncheckedColor = TextSecondary
                ),
                modifier = Modifier.size(24.dp).testTag("checkbox_${action.id}")
            )

            Column(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text(
                    text = action.label,
                    style = MaterialTheme.typography.titleSmall.copy(
                        fontWeight = FontWeight.Bold
                    ),
                    color = if (isChecked) TextPrimary else TextSecondary
                )

                Text(
                    text = action.description,
                    style = MaterialTheme.typography.bodySmall,
                    color = TextSecondary,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(2.dp))

                // Monospace Shell Command Box
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(DarkBackground)
                        .border(0.5.dp, DarkBorder, RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "$ ${action.command}",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontFamily = MonospaceFont,
                            fontSize = 11.sp
                        ),
                        color = if (isChecked) TextCode else TextMuted
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PostRestartGamePickerSheet(
    savedGames: List<SavedGame>,
    installedApps: List<InstalledAppInfo>,
    isLoadingApps: Boolean,
    onDismiss: () -> Unit,
    onSelectGame: (SavedGame) -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val context = LocalContext.current
    val pm = context.packageManager
    var searchQuery by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DarkSurface,
        scrimColor = Color.Black.copy(alpha = 0.7f),
        dragHandle = null
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "SELECT GAME TO LAUNCH",
                        style = MaterialTheme.typography.labelSmall.copy(
                            fontFamily = MonospaceFont,
                            letterSpacing = 1.sp
                        ),
                        color = CyberOrange
                    )
                    Text(
                        text = "Execute & Launch Target",
                        style = MaterialTheme.typography.titleMedium,
                        color = TextPrimary
                    )
                }

                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            // Search filter
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("post_restart_game_search_input"),
                placeholder = { Text("Filter games or apps...", color = TextMuted, fontSize = 13.sp) },
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberOrange,
                    unfocusedBorderColor = DarkBorder,
                    focusedTextColor = TextPrimary,
                    unfocusedTextColor = TextPrimary,
                    focusedContainerColor = DarkBackground,
                    unfocusedContainerColor = DarkBackground
                ),
                singleLine = true
            )

            val availableSavedGames = remember(savedGames, searchQuery) {
                if (searchQuery.isBlank()) savedGames
                else savedGames.filter {
                    it.appName.contains(searchQuery, ignoreCase = true) ||
                            it.packageName.contains(searchQuery, ignoreCase = true)
                }
            }

            val otherGames = remember(installedApps, savedGames, searchQuery) {
                val savedPkgs = savedGames.map { it.packageName }.toSet()
                installedApps.filter { app ->
                    !savedPkgs.contains(app.packageName) &&
                            (searchQuery.isBlank() || app.appName.contains(searchQuery, ignoreCase = true) || app.packageName.contains(searchQuery, ignoreCase = true))
                }
            }

            if (isLoadingApps) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    CircularProgressIndicator(color = CyberOrange)
                }
            } else if (availableSavedGames.isEmpty() && otherGames.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No matching games or apps found",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(360.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (availableSavedGames.isNotEmpty()) {
                        item {
                            Text(
                                text = "SAVED GAME LIBRARY",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = MonospaceFont,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = TextSecondary,
                                modifier = Modifier.padding(vertical = 4.dp)
                            )
                        }

                        items(availableSavedGames, key = { "saved_${it.packageName}" }) { game ->
                            val iconDrawable = remember(game.packageName) {
                                try { pm.getApplicationIcon(game.packageName) } catch (e: Exception) { null }
                            }

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onSelectGame(game) }
                                    .testTag("post_restart_launch_${game.packageName}"),
                                color = DarkSurfaceElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, CyberOrange.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    if (iconDrawable != null) {
                                        val bitmap = remember(iconDrawable) {
                                            iconDrawable.toBitmap(72, 72).asImageBitmap()
                                        }
                                        Image(
                                            bitmap = bitmap,
                                            contentDescription = null,
                                            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(6.dp))
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(DarkSurfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.SportsEsports, contentDescription = null, tint = CyberOrange, modifier = Modifier.size(20.dp))
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = game.appName,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimary,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = game.packageName,
                                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFont),
                                            color = TextSecondary,
                                            maxLines = 1
                                        )
                                    }

                                    Icon(
                                        imageVector = Icons.Default.PlayArrow,
                                        contentDescription = "Launch",
                                        tint = CyberOrange,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }
                    }

                    if (otherGames.isNotEmpty()) {
                        item {
                            Text(
                                text = "OTHER INSTALLED APPS & GAMES",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontFamily = MonospaceFont,
                                    fontWeight = FontWeight.Bold
                                ),
                                color = TextSecondary,
                                modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
                            )
                        }

                        items(otherGames, key = { "other_${it.packageName}" }) { app ->
                            val iconDrawable = remember(app.packageName) {
                                try { pm.getApplicationIcon(app.packageName) } catch (e: Exception) { null }
                            }

                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        onSelectGame(
                                            SavedGame(
                                                packageName = app.packageName,
                                                appName = app.appName
                                            )
                                        )
                                    }
                                    .testTag("post_restart_launch_other_${app.packageName}"),
                                color = DarkSurfaceElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(0.8.dp, DarkBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    if (iconDrawable != null) {
                                        val bitmap = remember(iconDrawable) {
                                            iconDrawable.toBitmap(72, 72).asImageBitmap()
                                        }
                                        Image(
                                            bitmap = bitmap,
                                            contentDescription = null,
                                            modifier = Modifier.size(36.dp).clip(RoundedCornerShape(6.dp))
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(DarkSurfaceVariant),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(Icons.Default.Gamepad, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
                                        }
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = app.appName,
                                            style = MaterialTheme.typography.titleSmall,
                                            color = TextPrimary,
                                            maxLines = 1
                                        )
                                        Text(
                                            text = app.packageName,
                                            style = MaterialTheme.typography.bodySmall.copy(fontFamily = MonospaceFont),
                                            color = TextSecondary,
                                            maxLines = 1
                                        )
                                    }

                                    if (app.isGame) {
                                        MonospaceTag(text = "GAME", color = NeonGreen)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}
