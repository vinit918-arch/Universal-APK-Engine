package com.example.model

enum class ToggleCategory(val displayName: String, val icon: String) {
    DISPLAY_ANIMATIONS("Display & Animations", "speed"),
    GPU_GRAPHICS("GPU & Graphics", "memory"),
    SYSTEM_PERFORMANCE("System & Background", "bolt"),
    IMMERSION_DND("Immersion & Feedback", "do_not_disturb")
}

data class TurboToggle(
    val id: String,
    val title: String,
    val description: String,
    val category: ToggleCategory,
    val applyCommand: String,
    val revertCommand: String,
    val isDefaultEnabled: Boolean = true,
    val impactTag: String = "LOW OVERHEAD",
    val technicalImpact: String = "ADB Global/System Setting"
)

object TurboCatalogue {
    val ALL_TOGGLES: List<TurboToggle> = listOf(
        TurboToggle(
            id = "window_animation_scale",
            title = "Disable Window Animation Scale",
            description = "Eliminates window open/close animation latency for instantaneous frame switching.",
            category = ToggleCategory.DISPLAY_ANIMATIONS,
            applyCommand = "settings put global window_animation_scale 0",
            revertCommand = "settings put global window_animation_scale 1",
            isDefaultEnabled = true,
            impactTag = "MAX SPEED",
            technicalImpact = "global window_animation_scale = 0"
        ),
        TurboToggle(
            id = "transition_animation_scale",
            title = "Disable Transition Animation Scale",
            description = "Removes page and activity transition lag across in-game popups and overlay views.",
            category = ToggleCategory.DISPLAY_ANIMATIONS,
            applyCommand = "settings put global transition_animation_scale 0",
            revertCommand = "settings put global transition_animation_scale 1",
            isDefaultEnabled = true,
            impactTag = "ZERO DELAY",
            technicalImpact = "global transition_animation_scale = 0"
        ),
        TurboToggle(
            id = "animator_duration_scale",
            title = "Disable Animator Duration Scale",
            description = "Forces immediate completion of UI animators, reducing micro-stutters during rendering.",
            category = ToggleCategory.DISPLAY_ANIMATIONS,
            applyCommand = "settings put global animator_duration_scale 0",
            revertCommand = "settings put global animator_duration_scale 1",
            isDefaultEnabled = true,
            impactTag = "ZERO DELAY",
            technicalImpact = "global animator_duration_scale = 0"
        ),
        TurboToggle(
            id = "force_gpu_rendering",
            title = "Force 2D GPU Rendering",
            description = "Offloads 2D surface drawing from CPU to GPU hardware rendering pipeline.",
            category = ToggleCategory.GPU_GRAPHICS,
            applyCommand = "settings put global force_gpu_rendering 1",
            revertCommand = "settings put global force_gpu_rendering 0",
            isDefaultEnabled = true,
            impactTag = "CPU OFFLOAD",
            technicalImpact = "global force_gpu_rendering = 1"
        ),
        TurboToggle(
            id = "force_hwui_renderer",
            title = "Force SkiaGL / Reduce MSAA Load",
            description = "Optimizes the HWUI drawing pipeline to prioritize SkiaGL fast path and reduce GPU burden.",
            category = ToggleCategory.GPU_GRAPHICS,
            applyCommand = "setprop debug.hwui.renderer skiagl",
            revertCommand = "setprop debug.hwui.renderer opengl",
            isDefaultEnabled = true,
            impactTag = "GPU TWEAK",
            technicalImpact = "setprop debug.hwui.renderer skiagl"
        ),
        TurboToggle(
            id = "disable_auto_brightness",
            title = "Lock Manual Brightness (Session)",
            description = "Prevents ambient light sensor polling and sudden screen dimming during gameplay.",
            category = ToggleCategory.SYSTEM_PERFORMANCE,
            applyCommand = "settings put system screen_brightness_mode 0",
            revertCommand = "settings put system screen_brightness_mode 1",
            isDefaultEnabled = true,
            impactTag = "SENSOR IDLE",
            technicalImpact = "system screen_brightness_mode = 0"
        ),
        TurboToggle(
            id = "kill_background_apps",
            title = "Purge Background Apps Before Launch",
            description = "Terminates dormant background processes (`am kill-all`) to reclaim RAM and CPU cores.",
            category = ToggleCategory.SYSTEM_PERFORMANCE,
            applyCommand = "am kill-all",
            revertCommand = "echo 'kill-all: session ended'",
            isDefaultEnabled = true,
            impactTag = "MAX RAM",
            technicalImpact = "am kill-all process purge"
        ),
        TurboToggle(
            id = "disable_haptic_feedback",
            title = "Disable System Haptic Feedback",
            description = "Suppresses non-game system vibration calls to prevent CPU micro-lag and scheduler stalls.",
            category = ToggleCategory.IMMERSION_DND,
            applyCommand = "settings put system haptic_feedback_enabled 0",
            revertCommand = "settings put system haptic_feedback_enabled 1",
            isDefaultEnabled = true,
            impactTag = "SMOOTH INPUT",
            technicalImpact = "system haptic_feedback_enabled = 0"
        ),
        TurboToggle(
            id = "dnd_gaming_mode",
            title = "Game Immersion DND (Do Not Disturb)",
            description = "Silences heads-up notifications and phone interrupts to prevent frame drops.",
            category = ToggleCategory.IMMERSION_DND,
            applyCommand = "cmd notification set_dnd on",
            revertCommand = "cmd notification set_dnd off",
            isDefaultEnabled = true,
            impactTag = "NO POPUPS",
            technicalImpact = "cmd notification set_dnd on"
        ),
        TurboToggle(
            id = "disable_auto_sync",
            title = "Pause Background Account Auto-Sync",
            description = "Stops background cloud synchronization threads from waking the modem and CPU.",
            category = ToggleCategory.SYSTEM_PERFORMANCE,
            applyCommand = "settings put global sync_enabled 0",
            revertCommand = "settings put global sync_enabled 1",
            isDefaultEnabled = true,
            impactTag = "NET STABILITY",
            technicalImpact = "global sync_enabled = 0"
        )
    )
}

data class SavedGame(
    val packageName: String,
    val appName: String,
    val activityName: String? = null,
    val addedAt: Long = System.currentTimeMillis()
)

data class InstalledAppInfo(
    val packageName: String,
    val appName: String,
    val isGame: Boolean = false
)

data class CommandLogEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val command: String,
    val exitCode: Int,
    val output: String,
    val isSuccess: Boolean,
    val durationMs: Long
)

sealed class ShizukuState {
    object NotInstalled : ShizukuState()
    object NotRunning : ShizukuState()
    object PermissionDenied : ShizukuState()
    data class VersionWarning(override val version: Int, val minRequired: Int) : ShizukuState()
    data class Ready(override val version: Int = -1, override val uid: Int = -1) : ShizukuState()

    val isReady: Boolean get() = this is Ready
    val isBinderAlive: Boolean get() = this is PermissionDenied || this is VersionWarning || this is Ready
    val hasPermission: Boolean get() = this is VersionWarning || this is Ready
    open val version: Int get() = -1
    open val uid: Int get() = -1
    val statusSummary: String get() = when (this) {
        is NotInstalled -> "Shizuku is not installed on this device."
        is NotRunning -> "Shizuku service is not running. Start via ADB or Wireless Debugging."
        is PermissionDenied -> "Shizuku is active, but authorization has not been granted."
        is VersionWarning -> "Shizuku v$version detected. Minimum recommended is v$minRequired."
        is Ready -> "Connected to Shizuku service (API v$version, UID $uid)."
    }
}

data class GameSessionState(
    val isActive: Boolean = false,
    val gamePackage: String? = null,
    val gameName: String? = null,
    val startTime: Long? = null,
    val appliedToggleIds: List<String> = emptyList()
)

data class PostRestartAction(
    val id: String,
    val label: String,
    val description: String,
    val command: String,
    val isDefaultSelected: Boolean = true
)

object PostRestartCatalogue {
    val ALL_ACTIONS: List<PostRestartAction> = listOf(
        PostRestartAction(
            id = "kill_background",
            label = "Clear Background Processes",
            description = "Kills all background apps freshly loaded during boot",
            command = "am kill-all"
        ),
        PostRestartAction(
            id = "trim_cache",
            label = "Trim System Caches",
            description = "Clears accumulated cache for more available storage/RAM",
            command = "cmd package trim-caches 4096G"
        ),
        PostRestartAction(
            id = "power_idleness",
            label = "Disable Power Idleness Factor",
            description = "Prevents system from treating device as idle post-boot",
            command = "settings put global power_idleness_factor 0"
        ),
        PostRestartAction(
            id = "game_driver",
            label = "Force Game Driver (GPU)",
            description = "Forces updated GPU driver for all apps",
            command = "settings put global game_driver_all_apps 1"
        ),
        PostRestartAction(
            id = "fixed_performance",
            label = "Enable Fixed Performance Mode",
            description = "Locks CPU/GPU to consistent high performance state",
            command = "cmd power set-fixed-performance-mode-enabled true"
        ),
        PostRestartAction(
            id = "adaptive_power_saver",
            label = "Disable Adaptive Power Saver",
            description = "Prevents automatic power throttling",
            command = "cmd power set-adaptive-power-saver-enabled false"
        ),
        PostRestartAction(
            id = "deviceidle_disable",
            label = "Disable Doze/App Standby",
            description = "Prevents background process idling during gameplay",
            command = "cmd deviceidle disable all"
        ),
        PostRestartAction(
            id = "wifi_scan_disable",
            label = "Disable Background WiFi Scanning",
            description = "Reduces background radio activity",
            command = "settings put global wifi_scan_always_enabled 0"
        )
    )
}

data class DeviceUptimeInfo(
    val uptimeMs: Long = 0L,
    val formattedUptime: String = "0m",
    val isRestartRecommended: Boolean = false
)
