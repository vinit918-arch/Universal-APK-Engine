package com.example.ui

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.model.CyberCallState
import com.example.telecom.CallManager
import com.example.telecom.CyberOverlayService
import com.example.ui.theme.MyApplicationTheme
import com.example.util.DefaultDialerPrompt
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Full-screen in-call activity displaying the Cyberpunk HUD call screen.
 * Configured with lock-screen display capabilities (SHOW_WHEN_LOCKED, TURN_SCREEN_ON).
 */
class CallActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Configure lock-screen bypass and keep-screen-on flags
        setupLockscreenFlags()

        setContent {
            MyApplicationTheme {
                val callState by CallManager.callState.collectAsState()

                CallScreen(
                    callState = callState,
                    onAnswer = { CallManager.answerCall() },
                    onRejectOrDisconnect = { CallManager.rejectOrDisconnectCall() },
                    onToggleMute = { CallManager.toggleMute() },
                    onCycleAudioRoute = { CallManager.cycleAudioRoute() },
                    onToggleHold = { CallManager.toggleHold() },
                    onSendDtmf = { digit -> CallManager.sendDtmf(digit) },
                    onMinimizeToOverlay = { minimizeToOverlay() }
                )
            }
        }

        // Auto-close activity when call is terminated
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                CallManager.callState.collect { state ->
                    if (state.state == CyberCallState.DISCONNECTED) {
                        // Allow user to see "TRANSMISSION TERMINATED" status before closing
                        delay(1200)
                        if (!isFinishing) {
                            finishAndRemoveTask()
                        }
                    }
                }
            }
        }
    }

    private fun setupLockscreenFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
            val keyguardManager = getSystemService(Context.KEYGUARD_SERVICE) as? KeyguardManager
            keyguardManager?.requestDismissKeyguard(this, null)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun minimizeToOverlay() {
        if (DefaultDialerPrompt.canDrawOverlays(this)) {
            CyberOverlayService.start(this)
            moveTaskToBack(true)
        } else {
            Toast.makeText(
                this,
                "SYSTEM ALERT: Floating HUD permission required in system settings",
                Toast.LENGTH_LONG
            ).show()
            val intent = DefaultDialerPrompt.createOverlaySettingsIntent(this)
            startActivity(intent)
        }
    }

    override fun onBackPressed() {
        // Prevent accidental back press during incoming ringing call
        if (CallManager.callState.value.state == CyberCallState.RINGING) {
            // Ignored or minimize
            moveTaskToBack(true)
        } else {
            super.onBackPressed()
        }
    }
}
