package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin
import com.example.model.CommandLogEntry
import com.example.model.LimiterConfig
import com.example.model.ShizukuState
import com.example.model.UsageStatsData
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberCardBg
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberDarkSurface
import com.example.ui.theme.CyberPink
import com.example.ui.theme.DeepPurple
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.GlassBorderRefract
import com.example.ui.theme.GlassBorderSubtle
import com.example.ui.theme.GlassFrostWhite
import com.example.ui.theme.GlassHighlight
import com.example.ui.theme.GlassSurface
import com.example.ui.theme.GlassSurfaceSecondary
import com.example.ui.theme.LiquidAqua
import com.example.ui.theme.LiquidEmerald
import com.example.ui.theme.LiquidIndigo
import com.example.ui.theme.LiquidMint
import com.example.ui.theme.LiquidRose
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanGlow
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenGlow
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.CyberViewModel

/**
 * Reusable Liquid Glass Card Container
 * Features a frosted glass gradient fill, delicate refractive border, and top specular light sheen.
 */
@Composable
fun LiquidGlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(22.dp),
    glowColor: Color = NeonCyan,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .clip(shape)
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0x381E2F4D),
                        Color(0x1F14223A),
                        Color(0x281B2B47)
                    )
                )
            )
            .border(
                width = 1.2.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0x80FFFFFF),
                        Color(0x20FFFFFF),
                        glowColor.copy(alpha = 0.45f),
                        Color(0x15FFFFFF)
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                ),
                shape = shape
            )
            .drawBehind {
                // Specular light reflection on top curved rim of the glass
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(Color(0x22FFFFFF), Color.Transparent),
                        startY = 0f,
                        endY = 48f
                    )
                )
            },
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent)
    ) {
        content()
    }
}

@Composable
fun CyberDashboardScreen(
    viewModel: CyberViewModel,
    modifier: Modifier = Modifier
) {
    val usageStats by viewModel.usageStats.collectAsState()
    val config by viewModel.config.collectAsState()
    val shizukuStatus by viewModel.shizukuStatus.collectAsState()
    val countdownText by viewModel.countdownText.collectAsState()
    val commandLogs by viewModel.commandLogs.collectAsState()
    val hasUsagePermission by viewModel.hasUsagePermission.collectAsState()
    val isExecuting by viewModel.isExecuting.collectAsState()

    var customCommandText by remember { mutableStateOf("") }

    // Ambient floating liquid orbs transition
    val infiniteTransition = rememberInfiniteTransition(label = "liquid_ambient")
    val liquidPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 14000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ambient_liquid_phase"
    )

    // Current accent state color
    val progressFraction = if (config.dailyLimitBytes > 0) {
        (usageStats.grandTotalBytes.toFloat() / config.dailyLimitBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f
    val percentage = (progressFraction * 100).toInt()
    val stateColor = when {
        config.isNetworkLocked -> CyberPink
        percentage >= 90 -> WarningAmber
        percentage >= 75 -> ElectricViolet
        else -> NeonCyan
    }

    // Liquid Glass Abyss Background with animated floating fluid orbs & glass caustics
    Box(
        modifier = modifier
            .fillMaxSize()
            .drawBehind {
                drawLiquidGlassBackground(
                    scope = this,
                    timeAnim = liquidPhase,
                    primaryColor = stateColor
                )
            }
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 36.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Top Liquid Glass Header with Shizuku Indicator
            item {
                CyberHeaderCard(
                    shizukuStatus = shizukuStatus,
                    onRequestPermission = { viewModel.requestShizukuPermission() },
                    onRefresh = {
                        viewModel.refreshShizukuStatus()
                        viewModel.checkUsagePermission()
                    }
                )
            }

            // 2. Permission Banner (if Usage Access missing)
            if (!hasUsagePermission) {
                item {
                    UsagePermissionBanner(onGrantClick = { viewModel.openUsageAccessSettings() })
                }
            }

            // 3. Liquid Radial Gauge & Countdown Timer
            item {
                CyberRadialGaugeCard(
                    usageStats = usageStats,
                    config = config,
                    countdownText = countdownText,
                    liquidPhase = liquidPhase
                )
            }

            // 4. Liquid Glass Control Toggles (Mobile & Wi-Fi Restrictions)
            item {
                CyberControlTogglesCard(
                    config = config,
                    onMobileToggle = { viewModel.setMobileRestricted(it) },
                    onWifiToggle = { viewModel.setWifiRestricted(it) }
                )
            }

            // 5. Daily Data Quota Configuration Card (with Glass Presets & Slider)
            item {
                CyberQuotaConfigCard(
                    currentLimitBytes = config.dailyLimitBytes,
                    onLimitChange = { viewModel.setDailyLimit(it) }
                )
            }

            // 6. Live Usage Telemetry Cards (Mobile vs Wi-Fi) with Liquid Waveforms
            item {
                CyberLiveUsageCards(
                    usageStats = usageStats,
                    phaseAnim = liquidPhase
                )
            }

            // 7. Manual Network Lockdown & Sentinel Controls
            item {
                CyberSentinelControlsCard(
                    isLocked = config.isNetworkLocked,
                    isExecuting = isExecuting,
                    onEmergencyLock = { viewModel.emergencyLockdown() },
                    onEmergencyRelease = { viewModel.emergencyRelease() }
                )
            }

            // 8. Shizuku ADB Command Terminal & Execution Console
            item {
                CyberTerminalCard(
                    logs = commandLogs,
                    customCommand = customCommandText,
                    onCommandChange = { customCommandText = it },
                    onExecuteCommand = {
                        viewModel.executeCustomAdbCommand(customCommandText)
                        customCommandText = ""
                    },
                    onClearLogs = { viewModel.clearLogs() }
                )
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 1: Top Liquid Glass Header with Shizuku Indicator
// -------------------------------------------------------------
@Composable
fun CyberHeaderCard(
    shizukuStatus: ShizukuState,
    onRequestPermission: () -> Unit,
    onRefresh: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "header_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.45f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    val (statusColor, statusLabel, isConnected) = when (shizukuStatus) {
        ShizukuState.CONNECTED_AUTHORIZED -> Triple(LiquidMint, "SHIZUKU ACTIVE", true)
        ShizukuState.CONNECTED_NO_PERMISSION -> Triple(WarningAmber, "PERM REQUIRED", false)
        ShizukuState.CONNECTING -> Triple(LiquidAqua, "CONNECTING...", false)
        ShizukuState.DISCONNECTED -> Triple(CyberPink, "DISCONNECTED", false)
        ShizukuState.UNSUPPORTED -> Triple(CyberPink, "NOT DETECTED", false)
    }

    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = statusColor
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.WaterDrop,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "CYBERNET",
                        color = TextPrimary,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.5.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "SENTINEL",
                        color = NeonCyan,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.5.sp
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "LIQUID GLASS CORE • STEALTH DNS SHIELD",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }

            // Live Connection Badge in Frosted Glass Pill
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0x3516243A))
                    .border(1.dp, statusColor.copy(alpha = 0.55f), RoundedCornerShape(20.dp))
                    .clickable {
                        if (shizukuStatus == ShizukuState.CONNECTED_NO_PERMISSION || shizukuStatus == ShizukuState.DISCONNECTED) {
                            onRequestPermission()
                        } else {
                            onRefresh()
                        }
                    }
                    .padding(horizontal = 12.dp, vertical = 7.dp)
                    .testTag("shizuku_status_badge")
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(statusColor.copy(alpha = pulseAlpha))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = statusLabel,
                    color = statusColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(5.dp))
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh Shizuku",
                    tint = statusColor,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 2: Permission Helper Banner
// -------------------------------------------------------------
@Composable
fun UsagePermissionBanner(onGrantClick: () -> Unit) {
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = WarningAmber
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = WarningAmber,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "USAGE ACCESS REQUIRED",
                    color = WarningAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Enable Usage Access to stream precise network hardware telemetry.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onGrantClick,
                colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
                shape = RoundedCornerShape(12.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                modifier = Modifier.testTag("grant_usage_perm_button")
            ) {
                Text("GRANT", color = CyberBlack, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 3: Radial Speedometer / Progress Gauge & Reset Countdown
// -------------------------------------------------------------
@Composable
fun CyberRadialGaugeCard(
    usageStats: UsageStatsData,
    config: LimiterConfig,
    countdownText: String,
    liquidPhase: Float = 0f
) {
    val totalBytes = usageStats.grandTotalBytes
    val limitBytes = config.dailyLimitBytes
    val progressFraction = if (limitBytes > 0) {
        (totalBytes.toFloat() / limitBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val animatedProgress by animateFloatAsState(
        targetValue = progressFraction,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "radial_progress"
    )

    val percentage = (progressFraction * 100).toInt()
    val totalGB = totalBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
    val limitGB = limitBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)

    val stateColor = when {
        config.isNetworkLocked -> CyberPink
        percentage >= 90 -> WarningAmber
        percentage >= 75 -> ElectricViolet
        else -> NeonCyan
    }

    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = stateColor
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Speedometer Canvas with undulating reservoir liquid wave & glowing glass arc
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(240.dp)
                    .padding(8.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawLiquidRadialGauge(
                        progress = animatedProgress,
                        primaryColor = stateColor,
                        isLocked = config.isNetworkLocked,
                        liquidPhase = liquidPhase
                    )
                }

                // Center Digital Readout in Glass Core
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "$percentage%",
                        color = stateColor,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (config.isNetworkLocked) "SYSTEM LOCKED" else "USED OF QUOTA",
                        color = if (config.isNetworkLocked) CyberPink else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = String.format(Locale.US, "%.2f GB / %.2f GB", totalGB, limitGB),
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Countdown Timer in a Sleek Frosted Glass Capsule
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0x3018263E),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    Brush.linearGradient(
                        listOf(Color(0x60FFFFFF), NeonCyan.copy(alpha = 0.35f))
                    )
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = countdownText.uppercase(),
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 4: Control Toggles (Liquid Glass Switch Cards)
// -------------------------------------------------------------
@Composable
fun CyberControlTogglesCard(
    config: LimiterConfig,
    onMobileToggle: (Boolean) -> Unit,
    onWifiToggle: (Boolean) -> Unit
) {
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = LiquidMint
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = LiquidMint,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TARGET RESTRICTION INTERFACES",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Text(
                text = "When daily data ceiling is reached, Sentinel locks connectivity via Stealth DNS without VPN overhead.",
                color = TextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            // Mobile Data Toggle Item
            CyberToggleRow(
                title = "Mobile Data Restriction",
                subtitle = "Apply firewall cutoff on Cellular network interfaces",
                icon = Icons.Default.SignalCellularAlt,
                isChecked = config.mobileRestricted,
                accentColor = NeonCyan,
                testTag = "mobile_data_toggle",
                onCheckedChange = onMobileToggle
            )

            // Wi-Fi Toggle Item
            CyberToggleRow(
                title = "Wi-Fi Restriction",
                subtitle = "Apply firewall cutoff on Wi-Fi WLAN interfaces",
                icon = Icons.Default.Wifi,
                isChecked = config.wifiRestricted,
                accentColor = LiquidMint,
                testTag = "wifi_data_toggle",
                onCheckedChange = onWifiToggle
            )
        }
    }
}

@Composable
fun CyberToggleRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isChecked: Boolean,
    accentColor: Color,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0x28192842))
            .border(
                1.dp,
                if (isChecked) accentColor.copy(alpha = 0.5f) else Color(0x20FFFFFF),
                RoundedCornerShape(16.dp)
            )
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(38.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (isChecked) accentColor.copy(alpha = 0.18f) else Color(0x20152438))
                    .border(
                        1.dp,
                        if (isChecked) accentColor.copy(alpha = 0.4f) else Color(0x18FFFFFF),
                        RoundedCornerShape(10.dp)
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isChecked) accentColor else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    color = if (isChecked) TextPrimary else TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = subtitle,
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = accentColor,
                checkedTrackColor = accentColor.copy(alpha = 0.35f),
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = Color(0x35142138)
            )
        )
    }
}

// -------------------------------------------------------------
// COMPONENT 5: Daily Data Quota Configuration Card (with Glass Presets)
// -------------------------------------------------------------
@Composable
fun CyberQuotaConfigCard(
    currentLimitBytes: Long,
    onLimitChange: (Long) -> Unit
) {
    val focusManager = LocalFocusManager.current

    var selectedUnit by remember {
        mutableStateOf(if (currentLimitBytes < 1024L * 1024 * 1024) "MB" else "GB")
    }

    fun formatBytesToInput(bytes: Long, unit: String): String {
        return if (unit == "MB") {
            val mb = bytes.toDouble() / (1024.0 * 1024.0)
            if (mb == mb.toLong().toDouble()) mb.toLong().toString() else String.format(Locale.US, "%.1f", mb)
        } else {
            val gb = bytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            if (gb == gb.toLong().toDouble()) gb.toLong().toString() else String.format(Locale.US, "%.2f", gb)
        }
    }

    var inputText by remember {
        mutableStateOf(formatBytesToInput(currentLimitBytes, selectedUnit))
    }

    // Synchronize input text if external updates happen
    androidx.compose.runtime.LaunchedEffect(currentLimitBytes, selectedUnit) {
        val currentParsedBytes = if (selectedUnit == "MB") {
            ((inputText.toDoubleOrNull() ?: 0.0) * 1024.0 * 1024.0).toLong()
        } else {
            ((inputText.toDoubleOrNull() ?: 0.0) * 1024.0 * 1024.0 * 1024.0).toLong()
        }
        if (Math.abs(currentParsedBytes - currentLimitBytes) > 1024 * 1024) {
            inputText = formatBytesToInput(currentLimitBytes, selectedUnit)
        }
    }

    val currentGB = (currentLimitBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)).toFloat()
    val maxSliderGB = maxOf(10f, currentGB.coerceAtLeast(1f))

    // Top right dynamic display text
    val parsedInput = inputText.toDoubleOrNull()
    val displayTopRight = if (parsedInput != null && parsedInput > 0) {
        if (selectedUnit == "MB") {
            if (parsedInput == parsedInput.toLong().toDouble()) "${parsedInput.toLong()} MB" else String.format(Locale.US, "%.1f MB", parsedInput)
        } else {
            if (parsedInput == parsedInput.toLong().toDouble()) "${parsedInput.toLong()}.00 GB" else String.format(Locale.US, "%.2f GB", parsedInput)
        }
    } else {
        if (selectedUnit == "MB") {
            val mb = currentLimitBytes.toDouble() / (1024.0 * 1024.0)
            if (mb == mb.toLong().toDouble()) "${mb.toLong()} MB" else String.format(Locale.US, "%.1f MB", mb)
        } else {
            String.format(Locale.US, "%.2f GB", currentGB)
        }
    }

    // Quick preset items in frosted glass capsules
    val quickPresets = listOf(
        Pair("500 MB", 500L * 1024 * 1024),
        Pair("1 GB", 1L * 1024 * 1024 * 1024),
        Pair("2 GB", 2L * 1024 * 1024 * 1024),
        Pair("3 GB", 3L * 1024 * 1024 * 1024),
        Pair("5 GB", 5L * 1024 * 1024 * 1024),
        Pair("10 GB", 10L * 1024 * 1024 * 1024)
    )

    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = DeepPurple
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row: Shield Icon, Label, and Dynamic Number Display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = DeepPurple,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "DAILY DATA CEILING",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Frosted Pill for Current Quota Readout
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x301E2E4A))
                        .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                        .padding(horizontal = 12.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = displayTopRight,
                        color = NeonCyan,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            // Custom Input Row: Numeric Text Field + MB/GB Segmented Control
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Numeric Input Field
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { raw ->
                        val filtered = raw.filter { it.isDigit() || it == '.' }
                        if (filtered.count { it == '.' } <= 1 && filtered.length <= 7) {
                            inputText = filtered
                            val parsed = filtered.toDoubleOrNull()
                            if (parsed != null && parsed > 0.0) {
                                val bytes = if (selectedUnit == "MB") {
                                    (parsed * 1024.0 * 1024.0).toLong()
                                } else {
                                    (parsed * 1024.0 * 1024.0 * 1024.0).toLong()
                                }.coerceIn(1024L * 1024L, 999L * 1024 * 1024 * 1024)
                                onLimitChange(bytes)
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quota_custom_input"),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    placeholder = {
                        Text(
                            text = if (selectedUnit == "MB") "e.g. 750" else "e.g. 1.5",
                            color = TextMuted,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            if (inputText.toDoubleOrNull() == null || (inputText.toDoubleOrNull() ?: 0.0) <= 0.0) {
                                inputText = formatBytesToInput(currentLimitBytes, selectedUnit)
                            }
                        }
                    ),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color(0x3517263E),
                        unfocusedContainerColor = Color(0x25142136),
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = Color(0x28FFFFFF),
                        cursorColor = NeonCyan
                    )
                )

                // MB / GB Segmented Glass Control
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0x3016253C))
                        .border(1.dp, Color(0x25FFFFFF), RoundedCornerShape(14.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("MB", "GB").forEach { unit ->
                        val isSelected = (selectedUnit == unit)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) NeonCyan else Color.Transparent)
                                .clickable {
                                    if (selectedUnit != unit) {
                                        selectedUnit = unit
                                        inputText = formatBytesToInput(currentLimitBytes, unit)
                                    }
                                }
                            .padding(horizontal = 14.dp, vertical = 12.dp)
                            .testTag("unit_toggle_${unit.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = unit,
                                color = if (isSelected) CyberBlack else TextSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Quick Preset Glass Chips
            LazyRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(quickPresets) { (label, bytes) ->
                    val isCurrent = Math.abs(currentLimitBytes - bytes) < 50L * 1024 * 1024
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(14.dp))
                            .background(
                                if (isCurrent) NeonCyan.copy(alpha = 0.22f) else Color(0x201C2C45)
                            )
                            .border(
                                1.dp,
                                if (isCurrent) NeonCyan.copy(alpha = 0.65f) else Color(0x1EFFFFFF),
                                RoundedCornerShape(14.dp)
                            )
                            .clickable {
                                onLimitChange(bytes)
                                inputText = formatBytesToInput(bytes, selectedUnit)
                            }
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = label,
                            color = if (isCurrent) NeonCyan else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Liquid Glass Slider
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Slider(
                    value = currentGB.coerceIn(0.1f, maxSliderGB),
                    onValueChange = { newGB ->
                        val bytes = (newGB * 1024 * 1024 * 1024).toLong()
                        onLimitChange(bytes)
                        inputText = formatBytesToInput(bytes, selectedUnit)
                    },
                    valueRange = 0.1f..maxSliderGB,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = Color(0x35192842)
                    ),
                    modifier = Modifier.testTag("quota_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SLIDER ADJUST (0.1 - ${String.format(Locale.US, "%.0f", maxSliderGB)} GB)",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "CAP: 999 GB",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 6: Live Usage Cards (Mobile vs Wi-Fi) with Liquid Waveforms
// -------------------------------------------------------------
@Composable
fun CyberLiveUsageCards(
    usageStats: UsageStatsData,
    phaseAnim: Float = 0f
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Mobile Data Card
        LiquidInterfaceCard(
            title = "MOBILE DATA",
            icon = Icons.Default.SignalCellularAlt,
            accentColor = NeonCyan,
            rxBytes = usageStats.mobileRxBytes,
            txBytes = usageStats.mobileTxBytes,
            speedBps = usageStats.mobileSpeedBps,
            phaseAnim = phaseAnim,
            modifier = Modifier.weight(1f)
        )

        // Wi-Fi Card
        LiquidInterfaceCard(
            title = "WI-FI STREAM",
            icon = Icons.Default.Wifi,
            accentColor = LiquidMint,
            rxBytes = usageStats.wifiRxBytes,
            txBytes = usageStats.wifiTxBytes,
            speedBps = usageStats.wifiSpeedBps,
            phaseAnim = phaseAnim + 1.2f,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun LiquidInterfaceCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    rxBytes: Long,
    txBytes: Long,
    speedBps: Long,
    phaseAnim: Float = 0f,
    modifier: Modifier = Modifier
) {
    val totalBytes = rxBytes + txBytes
    val formattedTotal = formatBytes(totalBytes)
    val formattedRx = formatBytes(rxBytes)
    val formattedTx = formatBytes(txBytes)
    val formattedSpeed = formatSpeed(speedBps)

    LiquidGlassCard(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        glowColor = accentColor
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        color = accentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Frosted Speed Capsule
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x2514243A))
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = formattedSpeed,
                        color = LiquidMint,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = formattedTotal,
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Mini Liquid Waveform Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(30.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0x30132034))
            ) {
                drawLiquidWaveform(this, accentColor, speedBps, phaseAnim)
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "↓ $formattedRx",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "↑ $formattedTx",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 7: Manual Network Lockdown Controls (Liquid Gel Buttons)
// -------------------------------------------------------------
@Composable
fun CyberSentinelControlsCard(
    isLocked: Boolean,
    isExecuting: Boolean,
    onEmergencyLock: () -> Unit,
    onEmergencyRelease: () -> Unit
) {
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = if (isLocked) CyberPink else NeonCyan
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                    contentDescription = null,
                    tint = if (isLocked) CyberPink else NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MANUAL OVERRIDE & SENTINEL LOCK",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Liquid Ruby Lockdown Button
                Button(
                    onClick = onEmergencyLock,
                    enabled = !isExecuting && !isLocked,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberPink,
                        disabledContainerColor = Color(0x301B2B47)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .drawBehind {
                            if (!isLocked) {
                                // Glossy top specular reflection
                                drawRect(
                                    brush = Brush.verticalGradient(
                                        colors = listOf(Color(0x35FFFFFF), Color.Transparent),
                                        startY = 0f,
                                        endY = size.height * 0.5f
                                    )
                                )
                            }
                        }
                        .testTag("emergency_lock_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Block,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LOCKDOWN",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Liquid Emerald Release Button
                Button(
                    onClick = onEmergencyRelease,
                    enabled = !isExecuting,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = LiquidMint,
                        contentColor = CyberBlack,
                        disabledContainerColor = Color(0x301B2B47)
                    ),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .drawBehind {
                            drawRect(
                                brush = Brush.verticalGradient(
                                    colors = listOf(Color(0x40FFFFFF), Color.Transparent),
                                    startY = 0f,
                                    endY = size.height * 0.5f
                                )
                            )
                        }
                        .testTag("emergency_release_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.NetworkCheck,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "RELEASE NET",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 8: Shizuku Terminal Console & Command Runner
// -------------------------------------------------------------
@Composable
fun CyberTerminalCard(
    logs: List<CommandLogEntry>,
    customCommand: String,
    onCommandChange: (String) -> Unit,
    onExecuteCommand: () -> Unit,
    onClearLogs: () -> Unit
) {
    LiquidGlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = TerminalGreen
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = null,
                        tint = TerminalGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SHIZUKU ADB TERMINAL",
                        color = TerminalGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(
                    onClick = onClearLogs,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear logs",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Command output window in Smoked Obsidian Glass
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x400A111F))
                    .border(1.dp, Color(0x20FFFFFF), RoundedCornerShape(12.dp))
                    .padding(10.dp)
            ) {
                if (logs.isEmpty()) {
                    Text(
                        text = "> Sentinel active. Waiting for system telemetry...\n> Ready to execute Private DNS stealth lock & release commands.",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 14.sp
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(logs, key = { it.id }) { log ->
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "> ",
                                        color = if (log.isSuccess) TerminalGreen else CyberPink,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = log.command,
                                        color = TextPrimary,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text(
                                    text = "  ${log.output}",
                                    color = if (log.isSuccess) TextSecondary else CyberPink,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Custom ADB command input field in Frosted Glass Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = customCommand,
                    onValueChange = onCommandChange,
                    placeholder = {
                        Text(
                            "e.g. settings put global private_dns_mode opportunistic",
                            fontSize = 11.sp,
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 11.sp,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onExecuteCommand() }),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("terminal_input"),
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = TerminalGreen,
                        unfocusedBorderColor = Color(0x25FFFFFF),
                        focusedContainerColor = Color(0x30152438),
                        unfocusedContainerColor = Color(0x25111E30)
                    )
                )

                IconButton(
                    onClick = onExecuteCommand,
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(TerminalGreen)
                        .size(46.dp)
                        .testTag("terminal_send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Execute ADB",
                        tint = CyberBlack,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// CUSTOM CANVAS DRAWINGS (Liquid Glass Abyss, Liquid Radial Gauge, Waveform)
// -------------------------------------------------------------
fun drawLiquidGlassBackground(
    scope: DrawScope,
    timeAnim: Float,
    primaryColor: Color
) {
    val width = scope.size.width
    val height = scope.size.height

    // Deep midnight liquid base
    scope.drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF060914),
                Color(0xFF0B1428),
                Color(0xFF050811)
            ),
            startY = 0f,
            endY = height
        )
    )

    // Liquid Orb 1 (Aqua / Cyan glow - floating top right)
    val orb1X = width * (0.8f + 0.12f * sin(timeAnim * 0.8f))
    val orb1Y = height * (0.16f + 0.08f * cos(timeAnim * 0.9f))
    scope.drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0x3500F0FF), Color(0x1500C2FF), Color.Transparent),
            center = Offset(orb1X, orb1Y),
            radius = width * 0.65f
        ),
        center = Offset(orb1X, orb1Y),
        radius = width * 0.65f
    )

    // Liquid Orb 2 (Electric Violet / Indigo - floating center left)
    val orb2X = width * (0.18f + 0.10f * cos(timeAnim * 0.7f))
    val orb2Y = height * (0.48f + 0.10f * sin(timeAnim * 0.85f))
    scope.drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0x307C3AED), Color(0x12A855F7), Color.Transparent),
            center = Offset(orb2X, orb2Y),
            radius = width * 0.7f
        ),
        center = Offset(orb2X, orb2Y),
        radius = width * 0.7f
    )

    // Liquid Orb 3 (Emerald / Rose accent - floating bottom right)
    val orb3Color = if (primaryColor == CyberPink) Color(0x35FF2A6D) else Color(0x2500FF88)
    val orb3X = width * (0.75f + 0.14f * cos(timeAnim * 0.6f))
    val orb3Y = height * (0.85f + 0.08f * sin(timeAnim * 0.75f))
    scope.drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(orb3Color, Color.Transparent),
            center = Offset(orb3X, orb3Y),
            radius = width * 0.6f
        ),
        center = Offset(orb3X, orb3Y),
        radius = width * 0.6f
    )

    // Subtle glass caustic wave paths
    val causticPath = Path()
    val steps = 8
    val waveStep = width / steps
    causticPath.moveTo(0f, height * 0.32f)
    for (i in 1..steps) {
        val cx = (i - 0.5f) * waveStep
        val cy = height * 0.32f + sin(timeAnim + i * 1.1f) * 45f
        val ex = i * waveStep
        val ey = height * 0.32f + sin(timeAnim + i * 0.9f) * 20f
        causticPath.quadraticBezierTo(cx, cy, ex, ey)
    }
    scope.drawPath(
        path = causticPath,
        color = Color(0x1000F0FF),
        style = Stroke(width = 2f, cap = StrokeCap.Round)
    )
}

fun DrawScope.drawLiquidRadialGauge(
    progress: Float,
    primaryColor: Color,
    isLocked: Boolean,
    liquidPhase: Float = 0f
) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val radius = size.minDimension / 2f - 22f

    val startAngle = 135f
    val sweepAngle = 270f
    val currentSweep = sweepAngle * progress

    // Outer Frosted Glass Track Ring
    drawArc(
        color = Color(0x281F304E),
        startAngle = startAngle,
        sweepAngle = sweepAngle,
        useCenter = false,
        topLeft = Offset(center.x - radius, center.y - radius),
        size = Size(radius * 2, radius * 2),
        style = Stroke(width = 16f, cap = StrokeCap.Round)
    )

    // Inner subtle glass border
    drawArc(
        color = Color(0x25FFFFFF),
        startAngle = startAngle,
        sweepAngle = sweepAngle,
        useCenter = false,
        topLeft = Offset(center.x - (radius - 8f), center.y - (radius - 8f)),
        size = Size((radius - 8f) * 2, (radius - 8f) * 2),
        style = Stroke(width = 1.2f, cap = StrokeCap.Round)
    )

    // Undulating Reservoir Wave inside the bottom area of the gauge
    val wavePath = Path()
    val waveRadius = radius * 0.65f
    val waveBaseY = center.y + waveRadius * (0.6f - progress * 0.8f).coerceIn(-0.4f, 0.6f)
    val waveStepCount = 16
    val waveWidth = waveRadius * 2f
    val waveStartX = center.x - waveRadius

    wavePath.moveTo(waveStartX, waveBaseY)
    for (i in 1..waveStepCount) {
        val x = waveStartX + (waveWidth / waveStepCount) * i
        val amp = (sin(i * 0.8 + liquidPhase) * 6f).toFloat()
        val y = waveBaseY + amp
        wavePath.lineTo(x, y)
    }
    wavePath.lineTo(center.x + waveRadius, center.y + waveRadius)
    wavePath.lineTo(center.x - waveRadius, center.y + waveRadius)
    wavePath.close()

    drawPath(
        path = wavePath,
        brush = Brush.verticalGradient(
            colors = listOf(
                primaryColor.copy(alpha = 0.18f),
                primaryColor.copy(alpha = 0.05f)
            ),
            startY = waveBaseY - 10f,
            endY = center.y + waveRadius
        )
    )

    // Glowing Liquid Progress Arc
    if (progress > 0f) {
        // Outer soft fluid aura
        drawArc(
            color = primaryColor.copy(alpha = 0.32f),
            startAngle = startAngle,
            sweepAngle = currentSweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = 24f, cap = StrokeCap.Round)
        )

        // Core bright liquid stream
        drawArc(
            brush = Brush.sweepGradient(
                colors = listOf(NeonCyan, DeepPurple, primaryColor),
                center = center
            ),
            startAngle = startAngle,
            sweepAngle = currentSweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = 14f, cap = StrokeCap.Round)
        )

        // Leading tip glowing liquid droplet
        val endAngleRad = Math.toRadians((startAngle + currentSweep).toDouble())
        val tipX = center.x + (radius * cos(endAngleRad)).toFloat()
        val tipY = center.y + (radius * sin(endAngleRad)).toFloat()

        drawCircle(
            color = primaryColor,
            radius = 9f,
            center = Offset(tipX, tipY)
        )
        drawCircle(
            color = Color.White,
            radius = 4f,
            center = Offset(tipX, tipY)
        )
    }

    // Specular Glass Reflection Sheen on top-right rim
    drawArc(
        brush = Brush.linearGradient(
            colors = listOf(Color(0x40FFFFFF), Color.Transparent),
            start = Offset(center.x, center.y - radius),
            end = Offset(center.x + radius, center.y)
        ),
        startAngle = 260f,
        sweepAngle = 70f,
        useCenter = false,
        topLeft = Offset(center.x - radius, center.y - radius),
        size = Size(radius * 2, radius * 2),
        style = Stroke(width = 3f, cap = StrokeCap.Round)
    )
}

fun drawLiquidWaveform(
    scope: DrawScope,
    color: Color,
    speedBps: Long,
    phaseAnim: Float = 0f
) {
    val width = scope.size.width
    val height = scope.size.height
    val path = Path()
    val fillPath = Path()
    val count = 20
    val dx = width / count

    path.moveTo(0f, height / 2f)
    fillPath.moveTo(0f, height)
    fillPath.lineTo(0f, height / 2f)

    for (i in 1..count) {
        val x = i * dx
        val amp = if (speedBps > 0) {
            (sin(i * 0.85 + phaseAnim) * (height / 2.7f)).toFloat()
        } else {
            (sin(i * 0.6 + phaseAnim) * 3f).toFloat()
        }
        val y = (height / 2f) + amp
        path.lineTo(x, y)
        fillPath.lineTo(x, y)
    }
    fillPath.lineTo(width, height)
    fillPath.close()

    // Liquid fill under the waveform
    scope.drawPath(
        path = fillPath,
        brush = Brush.verticalGradient(
            colors = listOf(color.copy(alpha = 0.22f), Color.Transparent),
            startY = height * 0.3f,
            endY = height
        )
    )

    // Wave surface line with smooth cap
    scope.drawPath(
        path = path,
        color = color,
        style = Stroke(width = 2.5f, cap = StrokeCap.Round)
    )
}

// -------------------------------------------------------------
// HELPER UTILITIES
// -------------------------------------------------------------
fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format(Locale.US, "%.2f MB", mb)
    val gb = mb / 1024.0
    return String.format(Locale.US, "%.2f GB", gb)
}

fun formatSpeed(bytesPerSec: Long): String {
    if (bytesPerSec <= 0) return "0.0 KB/s"
    val kb = bytesPerSec / 1024.0
    if (kb < 1024) return String.format(Locale.US, "%.1f KB/s", kb)
    val mb = kb / 1024.0
    return String.format(Locale.US, "%.2f MB/s", mb)
}
