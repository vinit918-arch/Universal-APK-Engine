package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Liquid Glass Abyss Backgrounds
val CyberBlack = Color(0xFF070B16)
val CyberDarkSurface = Color(0x281A2840)
val CyberCardBg = Color(0x22131F33)
val CyberCardBorder = Color(0x384A658A)

// Liquid & Glass Neon Accents
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanGlow = Color(0x4000F0FF)
val NeonGreen = Color(0xFF00FF88)
val NeonGreenGlow = Color(0x4000FF88)
val DeepPurple = Color(0xFF7C3AED)
val ElectricViolet = Color(0xFFA855F7)
val CyberPink = Color(0xFFFF2A6D)
val CyberPinkGlow = Color(0x40FF2A6D)
val WarningAmber = Color(0xFFFBBF24)

// Liquid Glass Specific Tones
val LiquidGlassBgStart = Color(0xFF060913)
val LiquidGlassBgMid = Color(0xFF0C152B)
val LiquidGlassBgEnd = Color(0xFF050812)

val GlassFrostWhite = Color(0x45FFFFFF)
val GlassHighlight = Color(0x80FFFFFF)
val GlassSurface = Color(0x2E1E2F4D)
val GlassSurfaceSecondary = Color(0x1F14223A)
val GlassBorderRefract = Color(0x5500F0FF)
val GlassBorderSubtle = Color(0x28FFFFFF)

val LiquidAqua = Color(0xFF38BDF8)
val LiquidIndigo = Color(0xFF6366F1)
val LiquidMint = Color(0xFF34D399)
val LiquidEmerald = Color(0xFF10B981)
val LiquidRuby = Color(0xFFF43F5E)
val LiquidRose = Color(0xFFFF2A6D)

// Text Colors
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)
val TerminalGreen = Color(0xFF34D399)

