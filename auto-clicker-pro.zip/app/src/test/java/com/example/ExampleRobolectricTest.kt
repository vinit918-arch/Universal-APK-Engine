package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Auto Clicker Pro", appName)
  }

  @Test
  fun `speed multiplier calculates accurate delays`() {
    val delay2x = com.example.engine.ShizukuClickEngine.calculateDelayFromSpeed(2)
    val delay20x = com.example.engine.ShizukuClickEngine.calculateDelayFromSpeed(20)
    val delay10x = com.example.engine.ShizukuClickEngine.calculateDelayFromSpeed(10)

    assertEquals(50L, delay2x)
    assertEquals(2L, delay20x)
    assertEquals(10L, delay10x)
  }
}
