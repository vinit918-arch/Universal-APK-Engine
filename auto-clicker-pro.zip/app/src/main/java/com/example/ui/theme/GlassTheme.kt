package com.example.ui.theme

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

// Water Glass & Neon Cyber Palette
val NeonCyan = Color(0xFF00E5FF)
val NeonCyanDim = Color(0x6600E5FF)
val NeonIceBlue = Color(0xFF80D8FF)
val NeonGreen = Color(0xFF00E676)
val NeonFire = Color(0xFFFF3D00)
val NeonPurple = Color(0xFFD500F9)

val GlassDarkBg = Color(0xCC09111E)
val GlassSurface = Color(0xB30F1A2E)
val GlassSurfaceLight = Color(0x8017253D)
val GlassBorder = Color(0x4D00E5FF)
val GlassBorderHighlight = Color(0x99FFFFFF)

val DeepVoidBlack = Color(0xFF060B12)
val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFFA0B2C6)
val TextMuted = Color(0xFF627D98)

/**
 * Applies a Frosted Water Glass style with translucent backdrop,
 * specular reflection highlight and glowing neon cyber border.
 */
fun Modifier.waterGlass(
    shape: Shape = RoundedCornerShape(16.dp),
    backgroundColor: Color = GlassSurface,
    borderColor: Color = GlassBorder,
    borderWidth: Dp = 1.dp,
    elevation: Dp = 8.dp
): Modifier = this
    .shadow(
        elevation = elevation,
        shape = shape,
        ambientColor = NeonCyan.copy(alpha = 0.2f),
        spotColor = NeonCyan.copy(alpha = 0.35f)
    )
    .clip(shape)
    .background(
        brush = Brush.verticalGradient(
            colors = listOf(
                backgroundColor.copy(alpha = 0.85f),
                backgroundColor.copy(alpha = 0.65f)
            )
        )
    )
    .border(
        width = borderWidth,
        brush = Brush.verticalGradient(
            colors = listOf(
                GlassBorderHighlight,
                borderColor,
                borderColor.copy(alpha = 0.2f)
            )
        ),
        shape = shape
    )

/**
 * Neon pulsing border modifier for active/firing targets
 */
@Composable
fun Modifier.pulsingGlow(
    enabled: Boolean = true,
    glowColor: Color = NeonCyan,
    shape: Shape = RoundedCornerShape(16.dp)
): Modifier {
    if (!enabled) return this

    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    return this
        .drawBehind {
            drawCircle(
                color = glowColor.copy(alpha = alpha * 0.4f),
                radius = size.maxDimension * 0.7f
            )
        }
        .border(
            width = 2.dp,
            color = glowColor.copy(alpha = alpha),
            shape = shape
        )
}

/**
 * Fire button styling with intense orange-red/cyan flame glow
 */
fun Modifier.fireButtonGlass(
    shape: Shape = RoundedCornerShape(20.dp)
): Modifier = this
    .shadow(
        elevation = 16.dp,
        shape = shape,
        ambientColor = NeonFire,
        spotColor = NeonFire
    )
    .clip(shape)
    .background(
        brush = Brush.horizontalGradient(
            colors = listOf(
                Color(0xFFFF3D00).copy(alpha = 0.9f),
                Color(0xFFFF9100).copy(alpha = 0.85f),
                Color(0xFFDD2C00).copy(alpha = 0.9f)
            )
        )
    )
    .border(
        width = 1.5.dp,
        brush = Brush.linearGradient(
            colors = listOf(
                Color(0xFFFFF9C4),
                Color(0xFFFFD180),
                Color(0xFFFF3D00)
            )
        ),
        shape = shape
    )
