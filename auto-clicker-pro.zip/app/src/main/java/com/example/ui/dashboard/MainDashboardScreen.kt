package com.example.ui.dashboard

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.ShizukuClickEngine
import com.example.model.ClickMode
import com.example.model.ClickSettings
import com.example.model.PresetProfile
import com.example.service.OverlayService
import com.example.shizuku.ShizukuManager
import com.example.ui.theme.*

val PRESET_PROFILES = listOf(
    PresetProfile("default", "Default", "Balanced 5x speed for general games", 5, 20L, true, ClickMode.REPEAT_TAP),
    PresetProfile("bgmi", "BGMI Rapid", "Ultra burst 15x firing for tactical shooters", 15, 5L, true, ClickMode.HOLD),
    PresetProfile("roblox", "Roblox Clicker", "Max 20x zero-lag tapping (500 CPS)", 20, 2L, false, ClickMode.REPEAT_TAP),
    PresetProfile("afk", "AFK Farmer", "Safe persistent clicking with random jitter", 3, 35L, true, ClickMode.REPEAT_TAP),
    PresetProfile("tactical", "Tactical Tap", "Precision single trigger executions", 10, 10L, true, ClickMode.TAP)
)

@Composable
fun MainDashboardScreen(
    modifier: Modifier = Modifier,
    isOverlayServiceRunning: Boolean,
    onToggleOverlayService: (Boolean) -> Unit
) {
    val context = LocalContext.current
    val scrollState = rememberScrollState()

    val isShizukuRunning by ShizukuManager.isShizukuRunning.collectAsState()
    val isShizukuPermissionGranted by ShizukuManager.isPermissionGranted.collectAsState()
    val shizukuStatusMessage by ShizukuManager.statusMessage.collectAsState()

    val totalClicks by ShizukuClickEngine.totalClicksCount.collectAsState()
    val currentCps by ShizukuClickEngine.currentCps.collectAsState()

    var selectedProfileId by remember { mutableStateOf("default") }
    var speedMultiplier by remember { mutableIntStateOf(5) }
    var jitterEnabled by remember { mutableStateOf(true) }
    var clickMode by remember { mutableStateOf(ClickMode.REPEAT_TAP) }

    val hasOverlayPermission = remember(isOverlayServiceRunning) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(context)
        } else {
            true
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        DeepVoidBlack,
                        Color(0xFF091424),
                        Color(0xFF0D1B2A)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // App Header
            AppHeaderSection()

            // Permission Status Card
            PermissionStatusCard(
                hasOverlayPermission = hasOverlayPermission,
                isShizukuRunning = isShizukuRunning,
                isShizukuAuthorized = isShizukuPermissionGranted,
                statusMessage = shizukuStatusMessage,
                onGrantOverlay = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        val intent = Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:${context.packageName}")
                        )
                        context.startActivity(intent)
                    }
                },
                onRequestShizuku = {
                    ShizukuManager.requestPermission()
                }
            )

            // Preset Profiles Card
            PresetProfilesCard(
                profiles = PRESET_PROFILES,
                selectedId = selectedProfileId,
                onSelectProfile = { profile ->
                    selectedProfileId = profile.id
                    speedMultiplier = profile.speedMultiplier
                    jitterEnabled = profile.jitterEnabled
                    clickMode = profile.mode
                    OverlayService.updateConfig(
                        ClickSettings(
                            speedMultiplier = profile.speedMultiplier,
                            baseDelayMs = profile.baseDelayMs,
                            jitterEnabled = profile.jitterEnabled,
                            mode = profile.mode
                        )
                    )
                }
            )

            // Anti-Ban Humanizer Jitter Card
            AntiBanHumanizerCard(
                jitterEnabled = jitterEnabled,
                onToggleJitter = { enabled ->
                    jitterEnabled = enabled
                    OverlayService.updateJitter(enabled)
                },
                speedMultiplier = speedMultiplier
            )

            // Dual Target-Aim Mechanism Info Card
            TargetPairOverviewCard()

            // Live Performance Telemetry Card
            PerformanceStatsCard(
                totalClicks = totalClicks,
                currentCps = currentCps,
                onReset = { ShizukuClickEngine.resetStats() }
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Large Glowing Rectangular Fire Button
            StartFireServiceButton(
                isRunning = isOverlayServiceRunning,
                canStart = hasOverlayPermission,
                onClick = {
                    if (!hasOverlayPermission) {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            )
                            context.startActivity(intent)
                        }
                    } else {
                        onToggleOverlayService(!isOverlayServiceRunning)
                    }
                }
            )

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun AppHeaderSection() {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "SHIZUKU PRO",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary,
                    letterSpacing = 1.2.sp
                )
                Text(
                    text = "Zero-Lag Persistent ADB Shell Stream",
                    fontSize = 12.sp,
                    color = NeonCyan,
                    fontWeight = FontWeight.Medium
                )
            }

            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x3300E5FF))
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "ULTRA SPEED",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonCyan
                )
            }
        }
    }
}

@Composable
private fun PermissionStatusCard(
    hasOverlayPermission: Boolean,
    isShizukuRunning: Boolean,
    isShizukuAuthorized: Boolean,
    statusMessage: String,
    onGrantOverlay: () -> Unit,
    onRequestShizuku: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .waterGlass(shape = RoundedCornerShape(18.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "SYSTEM PRIVILEGES",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 1.sp
            )

            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = "Security Status",
                tint = NeonCyan,
                modifier = Modifier.size(18.dp)
            )
        }

        // Overlay Permission Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Screen Overlay (Float Window)",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Text(
                    text = if (hasOverlayPermission) "Granted & Ready" else "Required for floating target HUD",
                    fontSize = 11.sp,
                    color = if (hasOverlayPermission) NeonGreen else Color(0xFFFF8A80)
                )
            }

            if (!hasOverlayPermission) {
                Button(
                    onClick = onGrantOverlay,
                    modifier = Modifier.testTag("grant_overlay_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = NeonCyan.copy(alpha = 0.85f)),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text("Grant", color = DeepVoidBlack, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            } else {
                BadgeChip(text = "GRANTED", color = NeonGreen)
            }
        }

        HorizontalDivider(color = GlassBorder.copy(alpha = 0.4f))

        // Shizuku ADB Privileges Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "Shizuku ADB Shell Stream",
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextPrimary
                )
                Text(
                    text = statusMessage,
                    fontSize = 11.sp,
                    color = when {
                        isShizukuAuthorized -> NeonGreen
                        isShizukuRunning -> Color(0xFFFFD180)
                        else -> TextMuted
                    }
                )
            }

            if (!isShizukuAuthorized) {
                Button(
                    onClick = onRequestShizuku,
                    modifier = Modifier.testTag("authorize_shizuku_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00B0FF)),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(
                        if (isShizukuRunning) "Authorize" else "Check",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            } else {
                BadgeChip(text = "CONNECTED", color = NeonCyan)
            }
        }
    }
}

@Composable
private fun PresetProfilesCard(
    profiles: List<PresetProfile>,
    selectedId: String,
    onSelectProfile: (PresetProfile) -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .waterGlass(shape = RoundedCornerShape(18.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "PRESET PROFILES",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 1.sp
            )
            Text(
                text = "Tap to load",
                fontSize = 11.sp,
                color = TextMuted
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            profiles.forEach { profile ->
                val isSelected = profile.id == selectedId
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            if (isSelected) NeonCyan.copy(alpha = 0.25f) else Color(0x33101E35)
                        )
                        .clickable { onSelectProfile(profile) }
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Column {
                        Text(
                            text = profile.name,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) NeonCyan else TextPrimary
                        )
                        Text(
                            text = "${profile.speedMultiplier}x Speed • ${profile.mode.name}",
                            fontSize = 10.sp,
                            color = if (isSelected) TextPrimary else TextMuted
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun AntiBanHumanizerCard(
    jitterEnabled: Boolean,
    onToggleJitter: (Boolean) -> Unit,
    speedMultiplier: Int
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .waterGlass(shape = RoundedCornerShape(18.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Anti-Ban Humanizer (Jitter Engine)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }
                Text(
                    text = "Applies randomized +1ms to +5ms micro-jitter to prevent automated robotic detection",
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }

            Switch(
                checked = jitterEnabled,
                onCheckedChange = onToggleJitter,
                modifier = Modifier.testTag("jitter_toggle_switch"),
                colors = SwitchDefaults.colors(
                    checkedThumbColor = DeepVoidBlack,
                    checkedTrackColor = NeonCyan,
                    uncheckedThumbColor = TextMuted,
                    uncheckedTrackColor = Color(0x331E2D4A)
                )
            )
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x2B00E5FF))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Text(
                text = if (jitterEnabled) {
                    "✓ Micro-jitter active: Base ${speedMultiplier}x + random (1~5ms) variable cadence"
                } else {
                    "⚠ Fixed interval: Pure static timing (Higher risk of anti-cheat pattern detection)"
                },
                fontSize = 11.sp,
                color = if (jitterEnabled) NeonCyan else Color(0xFFFFD180)
            )
        }
    }
}

@Composable
private fun TargetPairOverviewCard() {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .waterGlass(shape = RoundedCornerShape(18.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(
            text = "TRIGGER-AIM PAIR ARCHITECTURE",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = TextSecondary,
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Target Pair A
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x2600E5FF))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Target Pair A",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan
                    )
                    Text(
                        text = "Trigger 'A' ➔ Aim 'a'",
                        fontSize = 11.sp,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Hold Trigger A to tap Aim spot a.",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }

            // Target Pair B
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0x26D500F9))
                    .padding(12.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        text = "Target Pair B",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonPurple
                    )
                    Text(
                        text = "Trigger 'B' ➔ Aim 'b'",
                        fontSize = 11.sp,
                        color = TextPrimary,
                        fontWeight = FontWeight.Medium
                    )
                    Text(
                        text = "Secondary action / scope / macro.",
                        fontSize = 10.sp,
                        color = TextSecondary
                    )
                }
            }
        }
    }
}

@Composable
private fun PerformanceStatsCard(
    totalClicks: Long,
    currentCps: Int,
    onReset: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .waterGlass(shape = RoundedCornerShape(18.dp))
            .padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "ENGINE TELEMETRY",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 1.sp
            )

            Text(
                text = "Reset",
                fontSize = 11.sp,
                color = NeonCyan,
                modifier = Modifier.clickable { onReset() }
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = "CURRENT SPEED", fontSize = 10.sp, color = TextMuted)
                Text(
                    text = "$currentCps CPS",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = if (currentCps > 0) NeonGreen else TextPrimary,
                    fontFamily = FontFamily.Monospace
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(text = "TOTAL DISPATCHED", fontSize = 10.sp, color = TextMuted)
                Text(
                    text = "$totalClicks",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Black,
                    color = NeonCyan,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun StartFireServiceButton(
    isRunning: Boolean,
    canStart: Boolean,
    onClick: () -> Unit
) {
    Button(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(58.dp)
            .testTag("fire_service_button"),
        colors = ButtonDefaults.buttonColors(
            containerColor = if (isRunning) Color(0xFFD32F2F) else Color(0xFFFF3D00)
        ),
        shape = RoundedCornerShape(16.dp),
        elevation = ButtonDefaults.buttonElevation(defaultElevation = 8.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
        ) {
            Text(
                text = if (isRunning) "⏹  STOP FIRE SERVICE" else "🔥  START FIRE SERVICE",
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 1.sp,
                color = Color.White
            )
        }
    }
}

@Composable
private fun BadgeChip(text: String, color: Color) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.2f))
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = color
        )
    }
}
