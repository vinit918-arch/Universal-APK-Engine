package com.example.service

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.Log
import android.view.*
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.*
import androidx.savedstate.*
import com.example.MainActivity
import com.example.R
import com.example.engine.ShizukuClickEngine
import com.example.model.*
import com.example.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class OverlayService : Service(), LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    companion object {
        private const val TAG = "OverlayService"
        private const val NOTIFICATION_ID = 9001
        private const val CHANNEL_ID = "overlay_service_channel"

        private val _isRunning = MutableStateFlow(false)
        val isRunning: StateFlow<Boolean> = _isRunning.asStateFlow()

        private val _settings = MutableStateFlow(ClickSettings())
        val settings: StateFlow<ClickSettings> = _settings.asStateFlow()

        fun updateConfig(newSettings: ClickSettings) {
            _settings.value = newSettings
        }

        fun updateJitter(enabled: Boolean) {
            _settings.value = _settings.value.copy(jitterEnabled = enabled)
        }

        fun start(context: Context) {
            val intent = Intent(context, OverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, OverlayService::class.java)
            context.stopService(intent)
        }
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = store

    private var windowManager: WindowManager? = null

    // Overlay Views
    private var controlPanelComposeView: ComposeView? = null
    private var controlPanelParams: WindowManager.LayoutParams? = null

    private var triggerAView: ComposeView? = null
    private var triggerAParams: WindowManager.LayoutParams? = null

    private var aimAView: ComposeView? = null
    private var aimAParams: WindowManager.LayoutParams? = null

    private var triggerBView: ComposeView? = null
    private var triggerBParams: WindowManager.LayoutParams? = null

    private var aimBView: ComposeView? = null
    private var aimBParams: WindowManager.LayoutParams? = null

    // Target positions in screen pixels
    private val targetA_Aim = MutableStateFlow(TargetPoint(x = 400, y = 800))
    private val targetA_Trigger = MutableStateFlow(TriggerPoint(x = 100, y = 800))

    private val targetB_Aim = MutableStateFlow(TargetPoint(x = 600, y = 800))
    private val targetB_Trigger = MutableStateFlow(TriggerPoint(x = 100, y = 950))

    private val isControlPanelMinimized = MutableStateFlow(false)
    private val selectedTargetForEdit = MutableStateFlow(TargetId.TARGET_A)

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundNotification()

        initAllOverlays()
        _isRunning.value = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        _isRunning.value = false
        ShizukuClickEngine.stopAll()
        removeAllOverlays()

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
        super.onDestroy()
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Auto Clicker Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows floating target HUD and Shizuku click controls"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Shizuku Auto Clicker Pro")
            .setContentText("Overlay HUD active • Zero-lag stream ready")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun createBaseLayoutParams(initialX: Int, initialY: Int): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = initialX
            y = initialY
        }
    }

    private fun initAllOverlays() {
        initControlPanel()
        initTargetAPair()
        initTargetBPair()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun initControlPanel() {
        controlPanelParams = createBaseLayoutParams(30, 150)
        controlPanelComposeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                val isMinimized by isControlPanelMinimized.collectAsState()
                val currentConf by settings.collectAsState()
                val selectedTarget by selectedTargetForEdit.collectAsState()
                val totalClicks by ShizukuClickEngine.totalClicksCount.collectAsState()
                val currentCps by ShizukuClickEngine.currentCps.collectAsState()

                if (isMinimized) {
                    // Minimized Floating Bubble
                    MinimizedBubble(
                        onExpand = { isControlPanelMinimized.value = false },
                        onDrag = { dx, dy ->
                            controlPanelParams?.let { params ->
                                params.x += dx.toInt()
                                params.y += dy.toInt()
                                windowManager?.updateViewLayout(this@apply, params)
                            }
                        }
                    )
                } else {
                    // Full Glassmorphic Control Panel
                    FloatingControlPanelCard(
                        settings = currentConf,
                        selectedTarget = selectedTarget,
                        totalClicks = totalClicks,
                        currentCps = currentCps,
                        onSelectTarget = { selectedTargetForEdit.value = it },
                        onUpdateSettings = { newS -> updateConfig(newS) },
                        onMinimize = { isControlPanelMinimized.value = true },
                        onClose = { stopSelf() },
                        onDrag = { dx, dy ->
                            controlPanelParams?.let { params ->
                                params.x += dx.toInt()
                                params.y += dy.toInt()
                                windowManager?.updateViewLayout(this@apply, params)
                            }
                        }
                    )
                }
            }
        }
        windowManager?.addView(controlPanelComposeView, controlPanelParams)
    }

    private fun initTargetAPair() {
        // Trigger A (Capital 'A')
        triggerAParams = createBaseLayoutParams(targetA_Trigger.value.x, targetA_Trigger.value.y)
        triggerAView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                val currentConf by settings.collectAsState()
                val isFiring by ShizukuClickEngine.isFiringA.collectAsState()

                TriggerButton(
                    label = "A",
                    color = NeonCyan,
                    isFiring = isFiring,
                    sizeDp = currentConf.targetSizeDp,
                    opacity = currentConf.opacityPercent / 100f,
                    isLocked = currentConf.isLocked,
                    onStartFire = {
                        val aim = targetA_Aim.value
                        val centerX = aim.x + (currentConf.targetSizeDp * resources.displayMetrics.density / 2).toInt()
                        val centerY = aim.y + (currentConf.targetSizeDp * resources.displayMetrics.density / 2).toInt()
                        ShizukuClickEngine.startClicking(TargetId.TARGET_A, centerX, centerY, currentConf)
                    },
                    onStopFire = {
                        ShizukuClickEngine.stopClicking(TargetId.TARGET_A)
                    },
                    onDrag = { dx, dy ->
                        triggerAParams?.let { p ->
                            p.x += dx.toInt()
                            p.y += dy.toInt()
                            targetA_Trigger.value = TriggerPoint(p.x, p.y)
                            windowManager?.updateViewLayout(this@apply, p)
                        }
                    }
                )
            }
        }
        windowManager?.addView(triggerAView, triggerAParams)

        // Aim Target A (Small 'a')
        aimAParams = createBaseLayoutParams(targetA_Aim.value.x, targetA_Aim.value.y)
        aimAView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                val currentConf by settings.collectAsState()
                val isFiring by ShizukuClickEngine.isFiringA.collectAsState()

                AimCrosshair(
                    label = "a",
                    color = NeonCyan,
                    isFiring = isFiring,
                    sizeDp = currentConf.targetSizeDp,
                    opacity = currentConf.opacityPercent / 100f,
                    isLocked = currentConf.isLocked,
                    onDrag = { dx, dy ->
                        aimAParams?.let { p ->
                            p.x += dx.toInt()
                            p.y += dy.toInt()
                            targetA_Aim.value = TargetPoint(p.x, p.y)
                            windowManager?.updateViewLayout(this@apply, p)
                        }
                    }
                )
            }
        }
        windowManager?.addView(aimAView, aimAParams)
    }

    private fun initTargetBPair() {
        // Trigger B (Capital 'B')
        triggerBParams = createBaseLayoutParams(targetB_Trigger.value.x, targetB_Trigger.value.y)
        triggerBView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                val currentConf by settings.collectAsState()
                val isFiring by ShizukuClickEngine.isFiringB.collectAsState()

                TriggerButton(
                    label = "B",
                    color = NeonPurple,
                    isFiring = isFiring,
                    sizeDp = currentConf.targetSizeDp,
                    opacity = currentConf.opacityPercent / 100f,
                    isLocked = currentConf.isLocked,
                    onStartFire = {
                        val aim = targetB_Aim.value
                        val centerX = aim.x + (currentConf.targetSizeDp * resources.displayMetrics.density / 2).toInt()
                        val centerY = aim.y + (currentConf.targetSizeDp * resources.displayMetrics.density / 2).toInt()
                        ShizukuClickEngine.startClicking(TargetId.TARGET_B, centerX, centerY, currentConf)
                    },
                    onStopFire = {
                        ShizukuClickEngine.stopClicking(TargetId.TARGET_B)
                    },
                    onDrag = { dx, dy ->
                        triggerBParams?.let { p ->
                            p.x += dx.toInt()
                            p.y += dy.toInt()
                            targetB_Trigger.value = TriggerPoint(p.x, p.y)
                            windowManager?.updateViewLayout(this@apply, p)
                        }
                    }
                )
            }
        }
        windowManager?.addView(triggerBView, triggerBParams)

        // Aim Target B (Small 'b')
        aimBParams = createBaseLayoutParams(targetB_Aim.value.x, targetB_Aim.value.y)
        aimBView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@OverlayService)
            setViewTreeViewModelStoreOwner(this@OverlayService)
            setViewTreeSavedStateRegistryOwner(this@OverlayService)
            setContent {
                val currentConf by settings.collectAsState()
                val isFiring by ShizukuClickEngine.isFiringB.collectAsState()

                AimCrosshair(
                    label = "b",
                    color = NeonPurple,
                    isFiring = isFiring,
                    sizeDp = currentConf.targetSizeDp,
                    opacity = currentConf.opacityPercent / 100f,
                    isLocked = currentConf.isLocked,
                    onDrag = { dx, dy ->
                        aimBParams?.let { p ->
                            p.x += dx.toInt()
                            p.y += dy.toInt()
                            targetB_Aim.value = TargetPoint(p.x, p.y)
                            windowManager?.updateViewLayout(this@apply, p)
                        }
                    }
                )
            }
        }
        windowManager?.addView(aimBView, aimBParams)
    }

    private fun removeAllOverlays() {
        try {
            controlPanelComposeView?.let { windowManager?.removeView(it) }
            triggerAView?.let { windowManager?.removeView(it) }
            aimAView?.let { windowManager?.removeView(it) }
            triggerBView?.let { windowManager?.removeView(it) }
            aimBView?.let { windowManager?.removeView(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing overlay views", e)
        }
        controlPanelComposeView = null
        triggerAView = null
        aimAView = null
        triggerBView = null
        aimBView = null
    }
}

/**
 * Minimized glowing floating orb
 */
@Composable
fun MinimizedBubble(
    onExpand: () -> Unit,
    onDrag: (Float, Float) -> Unit
) {
    Box(
        modifier = Modifier
            .size(54.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDrag(dragAmount.x, dragAmount.y)
                }
            }
            .clip(CircleShape)
            .background(Color(0xEE091528))
            .border(2.dp, NeonCyan, CircleShape)
            .clickable { onExpand() },
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Bolt,
                contentDescription = "Expand",
                tint = NeonCyan,
                modifier = Modifier.size(24.dp)
            )
            Text(
                text = "PRO",
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                color = TextPrimary
            )
        }
    }
}

/**
 * Glassmorphic Floating Control Panel
 */
@Composable
fun FloatingControlPanelCard(
    settings: ClickSettings,
    selectedTarget: TargetId,
    totalClicks: Long,
    currentCps: Int,
    onSelectTarget: (TargetId) -> Unit,
    onUpdateSettings: (ClickSettings) -> Unit,
    onMinimize: () -> Unit,
    onClose: () -> Unit,
    onDrag: (Float, Float) -> Unit
) {
    Column(
        modifier = Modifier
            .width(280.dp)
            .waterGlass(shape = RoundedCornerShape(20.dp))
            .alpha(settings.opacityPercent / 100f)
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Drag Handle & Top Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .pointerInput(Unit) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        onDrag(dragAmount.x, dragAmount.y)
                    }
                },
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.DragIndicator,
                    contentDescription = "Drag Panel",
                    tint = NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "SHIZUKU PRO",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Black,
                    color = TextPrimary
                )
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                // Lock / Unlock Toggle
                IconButton(
                    onClick = {
                        onUpdateSettings(settings.copy(isLocked = !settings.isLocked))
                    },
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = if (settings.isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                        contentDescription = "Lock Targets",
                        tint = if (settings.isLocked) NeonGreen else Color(0xFFFFD180),
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Minimize
                IconButton(
                    onClick = onMinimize,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Remove,
                        contentDescription = "Minimize",
                        tint = TextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                // Close / Stop Service
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(28.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color(0xFFFF5252),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }

        // Live Telemetry bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0x33061224))
                .padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = "$currentCps CPS",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (currentCps > 0) NeonGreen else TextSecondary,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "Taps: $totalClicks",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = NeonCyan,
                fontFamily = FontFamily.Monospace
            )
        }

        // Target Switcher: [Target A] | [Target B]
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0x330F1A2E))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selectedTarget == TargetId.TARGET_A) NeonCyan.copy(alpha = 0.25f) else Color.Transparent)
                    .clickable { onSelectTarget(TargetId.TARGET_A) }
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "TARGET A",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedTarget == TargetId.TARGET_A) NeonCyan else TextMuted
                )
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (selectedTarget == TargetId.TARGET_B) NeonPurple.copy(alpha = 0.25f) else Color.Transparent)
                    .clickable { onSelectTarget(TargetId.TARGET_B) }
                    .padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "TARGET B",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (selectedTarget == TargetId.TARGET_B) NeonPurple else TextMuted
                )
            }
        }

        // Mode Selector: [Tap] | [Hold] | [Repeat Tap]
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            ClickMode.entries.forEach { mode ->
                val isSelected = settings.mode == mode
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) Color(0x4400E5FF) else Color(0x2217253D))
                        .clickable { onUpdateSettings(settings.copy(mode = mode)) }
                        .padding(vertical = 5.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = when (mode) {
                            ClickMode.TAP -> "Tap"
                            ClickMode.HOLD -> "Hold"
                            ClickMode.REPEAT_TAP -> "Repeat"
                        },
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isSelected) TextPrimary else TextSecondary
                    )
                }
            }
        }

        // Speed Slider (2x to 20x / 50ms to 2ms)
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Speed Multiplier", fontSize = 10.sp, color = TextSecondary)
                val estimatedMs = ShizukuClickEngine.calculateDelayFromSpeed(settings.speedMultiplier)
                Text(
                    text = "${settings.speedMultiplier}x (${estimatedMs}ms)",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = NeonCyan
                )
            }
            Slider(
                value = settings.speedMultiplier.toFloat(),
                onValueChange = { onUpdateSettings(settings.copy(speedMultiplier = it.toInt())) },
                valueRange = 2f..20f,
                steps = 17,
                modifier = Modifier.height(28.dp),
                colors = SliderDefaults.colors(
                    thumbColor = NeonCyan,
                    activeTrackColor = NeonCyan,
                    inactiveTrackColor = Color(0x3317253D)
                )
            )
        }

        // Size Scale Slider (40dp to 72dp)
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "Target Scale", fontSize = 10.sp, color = TextSecondary)
                Text(text = "${settings.targetSizeDp}dp", fontSize = 10.sp, color = TextPrimary)
            }
            Slider(
                value = settings.targetSizeDp.toFloat(),
                onValueChange = { onUpdateSettings(settings.copy(targetSizeDp = it.toInt())) },
                valueRange = 40f..72f,
                steps = 15,
                modifier = Modifier.height(28.dp),
                colors = SliderDefaults.colors(
                    thumbColor = TextPrimary,
                    activeTrackColor = NeonIceBlue,
                    inactiveTrackColor = Color(0x3317253D)
                )
            )
        }

        // Opacity Slider (10% to 100%)
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(text = "HUD Visibility", fontSize = 10.sp, color = TextSecondary)
                Text(text = "${settings.opacityPercent}%", fontSize = 10.sp, color = TextPrimary)
            }
            Slider(
                value = settings.opacityPercent.toFloat(),
                onValueChange = { onUpdateSettings(settings.copy(opacityPercent = it.toInt())) },
                valueRange = 15f..100f,
                steps = 16,
                modifier = Modifier.height(28.dp),
                colors = SliderDefaults.colors(
                    thumbColor = TextPrimary,
                    activeTrackColor = NeonIceBlue,
                    inactiveTrackColor = Color(0x3317253D)
                )
            )
        }
    }
}

/**
 * Trigger Button: Capital 'A' or 'B'
 * When tapped/held, executes clicks at Aim Target 'a' or 'b'
 */
@Composable
fun TriggerButton(
    label: String,
    color: Color,
    isFiring: Boolean,
    sizeDp: Int,
    opacity: Float,
    isLocked: Boolean,
    onStartFire: () -> Unit,
    onStopFire: () -> Unit,
    onDrag: (Float, Float) -> Unit
) {
    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .alpha(opacity)
            .then(
                if (!isLocked) {
                    Modifier.pointerInput(isLocked) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onDrag(dragAmount.x, dragAmount.y)
                        }
                    }
                } else Modifier
            )
            .pointerInput(isFiring) {
                detectTapGestures(
                    onPress = {
                        onStartFire()
                        tryAwaitRelease()
                        onStopFire()
                    }
                )
            }
            .clip(CircleShape)
            .background(if (isFiring) color.copy(alpha = 0.85f) else Color(0xDD091528))
            .border(
                width = if (isFiring) 3.dp else 2.dp,
                color = if (isFiring) Color.White else color,
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = label,
                fontSize = (sizeDp * 0.45f).sp,
                fontWeight = FontWeight.Black,
                color = if (isFiring) DeepVoidBlack else TextPrimary
            )
        }
    }
}

/**
 * Aim Target Spot: Small 'a' or 'b'
 * Crosshair showing where clicks are dispatched
 */
@Composable
fun AimCrosshair(
    label: String,
    color: Color,
    isFiring: Boolean,
    sizeDp: Int,
    opacity: Float,
    isLocked: Boolean,
    onDrag: (Float, Float) -> Unit
) {
    Box(
        modifier = Modifier
            .size(sizeDp.dp)
            .alpha(opacity)
            .then(
                if (!isLocked) {
                    Modifier.pointerInput(isLocked) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onDrag(dragAmount.x, dragAmount.y)
                        }
                    }
                } else Modifier
            )
            .border(
                width = if (isFiring) 2.5.dp else 1.5.dp,
                color = if (isFiring) Color(0xFFFF3D00) else color,
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        // Center reticle
        Box(
            modifier = Modifier
                .size((sizeDp * 0.4f).dp)
                .clip(CircleShape)
                .background(if (isFiring) Color(0xAAFF3D00) else color.copy(alpha = 0.3f))
                .border(1.dp, color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                fontSize = (sizeDp * 0.25f).sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }
    }
}
