package com.example.shizuku

import android.content.Context
import android.content.pm.PackageManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku
import java.io.DataOutputStream
import java.io.IOException

object ShizukuManager {
    private const val TAG = "ShizukuManager"
    const val SHIZUKU_PERMISSION_REQUEST_CODE = 8001

    private val _isShizukuRunning = MutableStateFlow(false)
    val isShizukuRunning: StateFlow<Boolean> = _isShizukuRunning.asStateFlow()

    private val _isPermissionGranted = MutableStateFlow(false)
    val isPermissionGranted: StateFlow<Boolean> = _isPermissionGranted.asStateFlow()

    private val _statusMessage = MutableStateFlow("Initializing Shizuku...")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    private var persistentProcess: Process? = null
    private var outputStream: DataOutputStream? = null
    private val lock = Any()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku Binder Received")
        updateState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.d(TAG, "Shizuku Binder Dead")
        closeShell()
        _isShizukuRunning.value = false
        _isPermissionGranted.value = false
        _statusMessage.value = "Shizuku Service Disconnected"
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                _isPermissionGranted.value = granted
                _statusMessage.value = if (granted) "Shizuku Permission Granted" else "Shizuku Permission Denied"
                if (granted) {
                    initPersistentShell()
                }
            }
        }

    fun init(context: Context) {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
            updateState()
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to register Shizuku listeners", e)
            _isShizukuRunning.value = false
            _statusMessage.value = "Shizuku not installed or unsupported"
        }
    }

    fun destroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
            closeShell()
        } catch (e: Throwable) {
            Log.e(TAG, "Error destroying ShizukuManager", e)
        }
    }

    fun updateState() {
        try {
            val ping = Shizuku.pingBinder()
            _isShizukuRunning.value = ping
            if (ping) {
                val permission = try {
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                } catch (e: Throwable) {
                    false
                }
                _isPermissionGranted.value = permission
                _statusMessage.value = if (permission) {
                    "Shizuku Connected & Authorized"
                } else {
                    "Shizuku Connected (Needs Permission)"
                }
                if (permission && persistentProcess == null) {
                    initPersistentShell()
                }
            } else {
                _isPermissionGranted.value = false
                _statusMessage.value = "Shizuku Not Running (Start Shizuku App)"
            }
        } catch (e: Throwable) {
            _isShizukuRunning.value = false
            _isPermissionGranted.value = false
            _statusMessage.value = "Shizuku Offline"
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.getVersion() < 11) {
                _statusMessage.value = "Shizuku v11+ is required"
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                _isPermissionGranted.value = true
                _statusMessage.value = "Shizuku Connected & Authorized"
                initPersistentShell()
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                _statusMessage.value = "Please grant Shizuku permission in prompt"
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            } else {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to request Shizuku permission", e)
            _statusMessage.value = "Permission Request Failed: ${e.message}"
        }
    }

    @Synchronized
    fun initPersistentShell(): Boolean {
        synchronized(lock) {
            if (persistentProcess != null && outputStream != null) {
                return true
            }
            try {
                if (Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    Log.i(TAG, "Spawning persistent sh via Shizuku...")
                    val method = Shizuku::class.java.getDeclaredMethod(
                        "newProcess",
                        Array<String>::class.java,
                        Array<String>::class.java,
                        String::class.java
                    )
                    method.isAccessible = true
                    val proc = method.invoke(null, arrayOf("sh"), null, null) as Process
                    persistentProcess = proc
                    outputStream = DataOutputStream(proc.outputStream)
                    Log.i(TAG, "Persistent Shizuku sh stream established successfully")
                    return true
                }
            } catch (e: Throwable) {
                Log.w(TAG, "Failed to spawn Shizuku process, falling back: ${e.message}")
            }

            // Fallback shell process if running in local shell or test environment
            return try {
                val proc = ProcessBuilder("sh").redirectErrorStream(true).start()
                persistentProcess = proc
                outputStream = DataOutputStream(proc.outputStream)
                Log.i(TAG, "Local shell stream established as fallback")
                true
            } catch (e: Throwable) {
                Log.e(TAG, "Failed to spawn fallback shell", e)
                closeShell()
                false
            }
        }
    }

    fun executeShellCommand(cmd: String): Boolean {
        synchronized(lock) {
            try {
                if (outputStream == null) {
                    val initialized = initPersistentShell()
                    if (!initialized) return false
                }
                val stream = outputStream ?: return false
                stream.writeBytes("$cmd\n")
                stream.flush()
                return true
            } catch (e: IOException) {
                Log.e(TAG, "IOException executing shell command: $cmd", e)
                closeShell()
                // Auto reconnect once
                return try {
                    if (initPersistentShell()) {
                        outputStream?.writeBytes("$cmd\n")
                        outputStream?.flush()
                        true
                    } else false
                } catch (retryEx: Exception) {
                    false
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Fatal error executing shell command: $cmd", e)
                return false
            }
        }
    }

    fun closeShell() {
        synchronized(lock) {
            try {
                outputStream?.writeBytes("exit\n")
                outputStream?.flush()
                outputStream?.close()
            } catch (ignored: Throwable) {}
            try {
                persistentProcess?.destroy()
            } catch (ignored: Throwable) {}
            outputStream = null
            persistentProcess = null
        }
    }
}
