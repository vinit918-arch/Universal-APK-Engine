package com.example.model

enum class ClickMode {
    TAP,
    HOLD,
    REPEAT_TAP
}

enum class TargetId {
    TARGET_A,
    TARGET_B
}

data class TargetPoint(
    val x: Int = 300,
    val y: Int = 600
)

data class TriggerPoint(
    val x: Int = 100,
    val y: Int = 600
)

data class ClickSettings(
    val speedMultiplier: Int = 5, // 2x to 20x
    val baseDelayMs: Long = 20L,   // Corresponds to speed: 20x = 2ms, 2x = 50ms
    val jitterEnabled: Boolean = true,
    val jitterMinMs: Long = 1L,
    val jitterMaxMs: Long = 5L,
    val mode: ClickMode = ClickMode.REPEAT_TAP,
    val targetSizeDp: Int = 56,
    val opacityPercent: Int = 85,
    val isLocked: Boolean = false // If locked, touch passes through or positions fixed
)

data class PresetProfile(
    val id: String,
    val name: String,
    val description: String,
    val speedMultiplier: Int,
    val baseDelayMs: Long,
    val jitterEnabled: Boolean,
    val mode: ClickMode
)
