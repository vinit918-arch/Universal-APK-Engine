package com.example.engine

import android.util.Log
import com.example.model.ClickMode
import com.example.model.ClickSettings
import com.example.model.TargetId
import com.example.shizuku.ShizukuManager
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

object ShizukuClickEngine {
    private const val TAG = "ShizukuClickEngine"

    private val engineScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private var activeJobA: Job? = null
    private var activeJobB: Job? = null

    private val _isFiringA = MutableStateFlow(false)
    val isFiringA: StateFlow<Boolean> = _isFiringA.asStateFlow()

    private val _isFiringB = MutableStateFlow(false)
    val isFiringB: StateFlow<Boolean> = _isFiringB.asStateFlow()

    private val _totalClicksCount = MutableStateFlow(0L)
    val totalClicksCount: StateFlow<Long> = _totalClicksCount.asStateFlow()

    private val _currentCps = MutableStateFlow(0)
    val currentCps: StateFlow<Int> = _currentCps.asStateFlow()

    private var clicksInWindow = 0
    private var cpsMonitorJob: Job? = null

    init {
        startCpsMonitor()
    }

    private fun startCpsMonitor() {
        cpsMonitorJob?.cancel()
        cpsMonitorJob = engineScope.launch {
            while (isActive) {
                delay(1000L)
                _currentCps.value = clicksInWindow
                clicksInWindow = 0
            }
        }
    }

    /**
     * Executes single tap at specified coordinate using persistent shell stream
     */
    fun tapOnce(x: Int, y: Int) {
        engineScope.launch {
            dispatchTap(x, y)
        }
    }

    /**
     * Starts continuous clicking loop for target pair
     */
    fun startClicking(targetId: TargetId, x: Int, y: Int, settings: ClickSettings) {
        when (targetId) {
            TargetId.TARGET_A -> {
                activeJobA?.cancel()
                _isFiringA.value = true
                activeJobA = engineScope.launch {
                    runClickLoop(x, y, settings, { _isFiringA.value })
                }
            }
            TargetId.TARGET_B -> {
                activeJobB?.cancel()
                _isFiringB.value = true
                activeJobB = engineScope.launch {
                    runClickLoop(x, y, settings, { _isFiringB.value })
                }
            }
        }
    }

    /**
     * Stops continuous clicking for target pair
     */
    fun stopClicking(targetId: TargetId) {
        when (targetId) {
            TargetId.TARGET_A -> {
                _isFiringA.value = false
                activeJobA?.cancel()
                activeJobA = null
            }
            TargetId.TARGET_B -> {
                _isFiringB.value = false
                activeJobB?.cancel()
                activeJobB = null
            }
        }
    }

    fun stopAll() {
        stopClicking(TargetId.TARGET_A)
        stopClicking(TargetId.TARGET_B)
    }

    private suspend fun runClickLoop(
        targetX: Int,
        targetY: Int,
        settings: ClickSettings,
        isActiveCheck: () -> Boolean
    ) {
        val baseDelay = calculateDelayFromSpeed(settings.speedMultiplier, settings.baseDelayMs)
        
        while (currentCoroutineContext().isActive && isActiveCheck()) {
            val tapSuccess = dispatchTap(targetX, targetY)
            
            // Jitter Humanizer Calculation: base delay + randomized offset (+1ms to +5ms)
            val jitter = if (settings.jitterEnabled) {
                Random.nextLong(settings.jitterMinMs, settings.jitterMaxMs + 1)
            } else {
                0L
            }

            val totalDelay = (baseDelay + jitter).coerceAtLeast(1L)
            
            if (settings.mode == ClickMode.TAP) {
                // Single execution mode
                break
            }

            delay(totalDelay)
        }
    }

    private fun dispatchTap(x: Int, y: Int): Boolean {
        _totalClicksCount.value += 1
        clicksInWindow++

        val cmd = "input tap $x $y"
        val success = ShizukuManager.executeShellCommand(cmd)
        if (!success) {
            Log.d(TAG, "Shell tap command simulated or shizuku not connected: ($x, $y)")
        }
        return success
    }

    /**
     * Speed multiplier (2x to 20x) mapping:
     * 2x = 50ms (20 CPS)
     * 5x = 20ms (50 CPS)
     * 10x = 10ms (100 CPS)
     * 15x = 5ms (200 CPS)
     * 20x = 2ms (500 CPS, near zero lag)
     */
    fun calculateDelayFromSpeed(multiplier: Int, customBaseMs: Long = 20L): Long {
        return when {
            multiplier <= 2 -> 50L
            multiplier <= 5 -> 25L
            multiplier <= 8 -> 15L
            multiplier <= 10 -> 10L
            multiplier <= 15 -> 5L
            multiplier >= 20 -> 2L
            else -> {
                // Linear interpolation between 2x (50ms) and 20x (2ms)
                val ratio = (multiplier - 2).toFloat() / (20 - 2)
                (50L - (ratio * 48L)).toLong().coerceAtLeast(2L)
            }
        }
    }

    fun resetStats() {
        _totalClicksCount.value = 0L
        _currentCps.value = 0
        clicksInWindow = 0
    }
}
