package com.example

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.service.FloatingService
import com.example.service.MacroAccessibilityService
import com.example.shizuku.ShizukuDispatcher
import com.example.ui.theme.CyberBgDark
import com.example.ui.theme.CyberBorderCyan
import com.example.ui.theme.CyberBorderGreen
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberPanelBg
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.theme.ElectricAmber
import com.example.ui.theme.MatrixGreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonPinkRed
import kotlinx.coroutines.delay
import rikka.shizuku.Shizuku

class MainActivity : ComponentActivity() {

    private val shizukuPermissionListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (grantResult == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SHIZUKU ACCESS GRANTED // LINK ESTABLISHED", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "SHIZUKU ACCESS DENIED // ACCESSIBILITY ACTIVE", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        try {
            Shizuku.addRequestPermissionResultListener(shizukuPermissionListener)
        } catch (e: Exception) {
            // Shizuku provider may not be present
        }

        setContent {
            MyApplicationTheme {
                CyberAutoClickerScreen(
                    onRequestOverlayPermission = { requestOverlayPermission() },
                    onRequestAccessibilityPermission = { openAccessibilitySettings() },
                    onRequestShizukuPermission = { ShizukuDispatcher.requestShizukuPermission() },
                    onStartFloatingOverlay = { startFloatingOverlay() },
                    onStopFloatingOverlay = { stopFloatingOverlay() }
                )
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener)
        } catch (e: Exception) {
            // Ignore
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
            } else {
                Toast.makeText(this, "OVERLAY_PERMISSION // ALREADY_GRANTED", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        startActivity(intent)
        Toast.makeText(this, "Locate 'Cyber Macro Input Service' and enable it", Toast.LENGTH_LONG).show()
    }

    private fun startFloatingOverlay() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "OVERLAY PERMISSION REQUIRED // GRANT FIRST", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }

        val serviceIntent = Intent(this, FloatingService::class.java).apply {
            action = FloatingService.ACTION_START
        }
        ContextCompat.startForegroundService(this, serviceIntent)
        Toast.makeText(this, "CYBER_MACRO // HUD ACTIVATED", Toast.LENGTH_SHORT).show()
    }

    private fun stopFloatingOverlay() {
        val serviceIntent = Intent(this, FloatingService::class.java).apply {
            action = FloatingService.ACTION_STOP
        }
        startService(serviceIntent)
        Toast.makeText(this, "CYBER_MACRO // HUD TERMINATED", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CyberAutoClickerScreen(
    onRequestOverlayPermission: () -> Unit,
    onRequestAccessibilityPermission: () -> Unit,
    onRequestShizukuPermission: () -> Unit,
    onStartFloatingOverlay: () -> Unit,
    onStopFloatingOverlay: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var hasOverlayPermission by remember { mutableStateOf(checkOverlayPermission(context)) }
    val isAccessibilityActive by MacroAccessibilityService.isServiceRunning.collectAsState()
    val isOverlayActive by FloatingService.isOverlayRunning.collectAsState()

    var hasShizukuRunning by remember { mutableStateOf(ShizukuDispatcher.isShizukuInstalledAndRunning()) }
    var hasShizukuPermission by remember { mutableStateOf(ShizukuDispatcher.hasShizukuPermission()) }

    // Test chamber state
    var testHitCount by remember { mutableIntStateOf(0) }
    var testLastHitTimestamp by remember { mutableStateOf(0L) }
    var testCps by remember { mutableStateOf(0.0) }

    // Refresh permission statuses on resume
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = checkOverlayPermission(context)
                hasShizukuRunning = ShizukuDispatcher.isShizukuInstalledAndRunning()
                hasShizukuPermission = ShizukuDispatcher.hasShizukuPermission()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    // Periodic check for Shizuku binder state
    LaunchedEffect(Unit) {
        while (true) {
            hasOverlayPermission = checkOverlayPermission(context)
            hasShizukuRunning = ShizukuDispatcher.isShizukuInstalledAndRunning()
            hasShizukuPermission = ShizukuDispatcher.hasShizukuPermission()
            delay(1500)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "CYBER_MACRO",
                            style = MaterialTheme.typography.titleLarge,
                            color = CyberCyan,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = " // v2.0",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MatrixGreen
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CyberBgDark,
                    titleContentColor = CyberCyan
                ),
                actions = {
                    val statusText = if (isOverlayActive) "HUD_ACTIVE" else "HUD_IDLE"
                    val statusColor = if (isOverlayActive) MatrixGreen else CyberTextMuted
                    Surface(
                        color = CyberSurface,
                        shape = RoundedCornerShape(4.dp),
                        border = BorderStroke(1.dp, statusColor),
                        modifier = Modifier.padding(end = 12.dp)
                    ) {
                        Text(
                            text = statusText,
                            color = statusColor,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            )
        },
        containerColor = CyberBgDark
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // 1. Cyber HUD Status Header
            CyberEngineBanner(
                hasShizuku = hasShizukuPermission,
                hasAccessibility = isAccessibilityActive,
                isOverlayRunning = isOverlayActive
            )

            // 2. Primary Launch / Kill HUD Overlay Controller
            CyberActionControlPanel(
                isOverlayActive = isOverlayActive,
                hasOverlayPermission = hasOverlayPermission,
                onStart = onStartFloatingOverlay,
                onStop = onStopFloatingOverlay,
                onRequestOverlay = onRequestOverlayPermission
            )

            // 3. Subsystem Security & Permission Diagnostics Matrix
            CyberSecurityMatrix(
                hasOverlayPermission = hasOverlayPermission,
                isAccessibilityActive = isAccessibilityActive,
                hasShizukuRunning = hasShizukuRunning,
                hasShizukuPermission = hasShizukuPermission,
                onRequestOverlay = onRequestOverlayPermission,
                onRequestAccessibility = onRequestAccessibilityPermission,
                onRequestShizuku = onRequestShizukuPermission
            )

            // 4. Cyber Target Test Chamber (Interactive Click Practice Target)
            CyberTestChamber(
                hitCount = testHitCount,
                cps = testCps,
                onTargetHit = {
                    val now = System.currentTimeMillis()
                    testHitCount++
                    if (testLastHitTimestamp > 0) {
                        val diff = now - testLastHitTimestamp
                        if (diff in 1..2000) {
                            testCps = (1000.0 / diff).coerceAtMost(100.0)
                        }
                    }
                    testLastHitTimestamp = now
                },
                onReset = {
                    testHitCount = 0
                    testCps = 0.0
                    testLastHitTimestamp = 0L
                }
            )

            // 5. System Manual & Protocols
            CyberSystemProtocols()

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun CyberEngineBanner(
    hasShizuku: Boolean,
    hasAccessibility: Boolean,
    isOverlayRunning: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.5f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glow"
    )

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberPanelBg),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, CyberBorderCyan)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE_INJECTION_ENGINE",
                    color = CyberTextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            if (isOverlayRunning) MatrixGreen.copy(alpha = glowAlpha) else NeonPinkRed
                        )
                )
            }

            val engineName: String
            val engineColor: Color
            val engineDesc: String

            when {
                hasShizuku -> {
                    engineName = "⚡ SHIZUKU_ROOTLESS_BINDER"
                    engineColor = MatrixGreen
                    engineDesc = "Direct ADB shell touch injection active. Zero delay high-frequency dispatch."
                }
                hasAccessibility -> {
                    engineName = "🛡️ ACCESSIBILITY_GESTURE_DISPATCH"
                    engineColor = ElectricAmber
                    engineDesc = "Native Android AccessibilityService dispatch gesture fallback active."
                }
                else -> {
                    engineName = "⚠️ NO_INPUT_ENGINE_AVAILABLE"
                    engineColor = NeonPinkRed
                    engineDesc = "Enable Shizuku or Accessibility Service below to dispatch real screen clicks."
                }
            }

            Text(
                text = engineName,
                color = engineColor,
                fontSize = 14.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = engineDesc,
                color = CyberTextPrimary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

@Composable
fun CyberActionControlPanel(
    isOverlayActive: Boolean,
    hasOverlayPermission: Boolean,
    onStart: () -> Unit,
    onStop: () -> Unit,
    onRequestOverlay: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberPanelBg),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, if (isOverlayActive) MatrixGreen else CyberBorderCyan)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "[ OVERLAY_LAUNCH_CONTROL ]",
                color = CyberTextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            if (!hasOverlayPermission) {
                Button(
                    onClick = onRequestOverlay,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonPinkRed),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("grant_overlay_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Layers,
                        contentDescription = null,
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "GRANT OVERLAY PERMISSION",
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                }
            } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = onStart,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isOverlayActive) CyberSurface else MatrixGreen
                        ),
                        shape = RoundedCornerShape(6.dp),
                        border = if (isOverlayActive) BorderStroke(1.dp, MatrixGreen) else null,
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("launch_hud_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = null,
                            tint = if (isOverlayActive) MatrixGreen else CyberBgDark
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isOverlayActive) "HUD RUNNING" else "LAUNCH HUD",
                            color = if (isOverlayActive) MatrixGreen else CyberBgDark,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }

                    Button(
                        onClick = onStop,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSurface),
                        shape = RoundedCornerShape(6.dp),
                        border = BorderStroke(1.dp, NeonPinkRed),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                            .testTag("kill_hud_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = null,
                            tint = NeonPinkRed
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "KILL HUD",
                            color = NeonPinkRed,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CyberSecurityMatrix(
    hasOverlayPermission: Boolean,
    isAccessibilityActive: Boolean,
    hasShizukuRunning: Boolean,
    hasShizukuPermission: Boolean,
    onRequestOverlay: () -> Unit,
    onRequestAccessibility: () -> Unit,
    onRequestShizuku: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberPanelBg),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, CyberBorderCyan)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text(
                text = "[ SYSTEM_PERMISSION_MATRIX ]",
                color = CyberTextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            // Overlay Item
            PermissionStatusItem(
                title = "DRAW_OVER_OTHER_APPS",
                subtitle = "Required for Floating Control Bar, Trigger 'A', & Target 'a'",
                isGranted = hasOverlayPermission,
                grantedText = "OVERLAY_AUTHORIZED",
                actionText = "GRANT_OVERLAY",
                onAction = onRequestOverlay
            )

            // Accessibility Item
            PermissionStatusItem(
                title = "ACCESSIBILITY_SERVICE",
                subtitle = "Input dispatch fallback engine via dispatchGesture",
                isGranted = isAccessibilityActive,
                grantedText = "SERVICE_ONLINE",
                actionText = "ENABLE_SERVICE",
                onAction = onRequestAccessibility
            )

            // Shizuku Item
            val shizukuSubtitle = when {
                !hasShizukuRunning -> "Shizuku Server not running. (Fallback to Accessibility)"
                !hasShizukuPermission -> "Shizuku Server detected. Permission authorization required."
                else -> "Shizuku Linked. High-speed direct shell tap injector ready."
            }

            PermissionStatusItem(
                title = "SHIZUKU_ROOTLESS_API",
                subtitle = shizukuSubtitle,
                isGranted = hasShizukuPermission,
                grantedText = "SHIZUKU_LINKED",
                actionText = if (hasShizukuRunning) "AUTHORIZE_SHIZUKU" else "CHECK_SHIZUKU",
                onAction = onRequestShizuku
            )
        }
    }
}

@Composable
fun PermissionStatusItem(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    grantedText: String,
    actionText: String,
    onAction: () -> Unit
) {
    Surface(
        color = CyberSurface,
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, if (isGranted) CyberBorderGreen else CyberTextMuted.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
                        contentDescription = null,
                        tint = if (isGranted) MatrixGreen else ElectricAmber,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        color = if (isGranted) MatrixGreen else CyberTextPrimary,
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = subtitle,
                    color = CyberTextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.width(8.dp))

            if (isGranted) {
                Surface(
                    color = Color(0x3300FF66),
                    shape = RoundedCornerShape(4.dp),
                    border = BorderStroke(1.dp, MatrixGreen)
                ) {
                    Text(
                        text = grantedText,
                        color = MatrixGreen,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                    )
                }
            } else {
                OutlinedButton(
                    onClick = onAction,
                    border = BorderStroke(1.dp, CyberCyan),
                    shape = RoundedCornerShape(4.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text(
                        text = actionText,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
fun CyberTestChamber(
    hitCount: Int,
    cps: Double,
    onTargetHit: () -> Unit,
    onReset: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberPanelBg),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, ElectricAmber)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "[ TARGET_TEST_CHAMBER ]",
                    color = ElectricAmber,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )

                IconButton(
                    onClick = onReset,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset stats",
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Text(
                text = "Drag Small 'a' target here to test real-time click macro dispatch:",
                color = CyberTextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            // Test Reticle Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(6.dp))
                    .background(CyberBgDark)
                    .border(BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f)), RoundedCornerShape(6.dp))
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        onTargetHit()
                    },
                contentAlignment = Alignment.Center
            ) {
                // Background Crosshairs
                Box(
                    modifier = Modifier
                        .size(100.dp)
                        .border(1.dp, CyberCyan.copy(alpha = 0.3f), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(60.dp)
                        .border(1.dp, MatrixGreen.copy(alpha = 0.4f), CircleShape)
                )
                Box(
                    modifier = Modifier
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(NeonPinkRed)
                )

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = "TEST_HITS: $hitCount",
                        color = MatrixGreen,
                        fontSize = 15.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "LIVE_RATE: ${String.format("%.1f", cps)} CPS",
                        color = CyberCyan,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

@Composable
fun CyberSystemProtocols() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = CyberPanelBg),
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, CyberBorderCyan)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "[ SYSTEM_PROTOCOLS // MANUAL ]",
                color = CyberTextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )

            ProtocolLine(
                step = "01",
                text = "Grant 'Draw over other apps' and either Accessibility or Shizuku."
            )
            ProtocolLine(
                step = "02",
                text = "Tap 'LAUNCH HUD' to spawn the Floating Control Bar, Trigger [A], and Pointer Target [a]."
            )
            ProtocolLine(
                step = "03",
                text = "Drag the Small 'a' crosshair target anywhere on your screen (or over game buttons)."
            )
            ProtocolLine(
                step = "04",
                text = "Press or Hold Capital 'A' to start automatic high-speed click macro injection."
            )
            ProtocolLine(
                step = "05",
                text = "Customize speed (10ms - 500ms), opacity, scale, and mode in the Cyber HUD menu."
            )
        }
    }
}

@Composable
fun ProtocolLine(step: String, text: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Text(
            text = "[$step] ",
            color = MatrixGreen,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = text,
            color = CyberTextPrimary,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace
        )
    }
}

fun checkOverlayPermission(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(context)
    } else {
        true
    }
}
