package com.example.shizuku

import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import com.example.service.MacroAccessibilityService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

object ShizukuDispatcher {

    private const val TAG = "ShizukuDispatcher"

    enum class EngineType {
        SHIZUKU,
        ACCESSIBILITY,
        NONE
    }

    fun isShizukuInstalledAndRunning(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (t: Throwable) {
            false
        }
    }

    fun hasShizukuPermission(): Boolean {
        return try {
            if (!isShizukuInstalledAndRunning()) return false
            if (Shizuku.isPreV11()) {
                false
            } else {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            }
        } catch (t: Throwable) {
            false
        }
    }

    fun requestShizukuPermission(requestCode: Int = 101) {
        try {
            if (isShizukuInstalledAndRunning() && !hasShizukuPermission()) {
                Shizuku.requestPermission(requestCode)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting Shizuku permission", e)
        }
    }

    fun getActiveEngine(): EngineType {
        return when {
            hasShizukuPermission() -> EngineType.SHIZUKU
            MacroAccessibilityService.isServiceRunning.value -> EngineType.ACCESSIBILITY
            else -> EngineType.NONE
        }
    }

    suspend fun dispatchClick(x: Float, y: Float): Boolean {
        val targetX = x.toInt().coerceAtLeast(0)
        val targetY = y.toInt().coerceAtLeast(0)

        // 1. Try High-Speed Shizuku Touch Injection
        if (hasShizukuPermission()) {
            val shizukuSuccess = dispatchShizukuTap(targetX, targetY)
            if (shizukuSuccess) return true
        }

        // 2. Fallback to Accessibility Service Gesture Dispatch
        if (MacroAccessibilityService.isServiceRunning.value) {
            val accSuccess = MacroAccessibilityService.dispatchTap(x, y)
            if (accSuccess) return true
        }

        return false
    }

    private suspend fun dispatchShizukuTap(x: Int, y: Int): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val command = arrayOf("input", "tap", x.toString(), y.toString())
            val method = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            ).apply { isAccessible = true }
            val process = method.invoke(null, command, null, null) as? Process
            process?.let {
                it.waitFor()
                it.exitValue() == 0
            } ?: false
        } catch (e: Exception) {
            Log.e(TAG, "Failed Shizuku tap injection", e)
            false
        }
    }
}
