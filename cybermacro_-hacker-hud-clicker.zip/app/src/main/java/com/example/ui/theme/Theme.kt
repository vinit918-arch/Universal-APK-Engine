package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val CyberColorScheme = darkColorScheme(
    primary = CyberCyan,
    onPrimary = CyberBgDark,
    primaryContainer = Color(0x3300E5FF),
    onPrimaryContainer = CyberCyan,
    secondary = MatrixGreen,
    onSecondary = CyberBgDark,
    secondaryContainer = Color(0x3300FF66),
    onSecondaryContainer = MatrixGreen,
    tertiary = NeonPinkRed,
    onTertiary = Color.White,
    tertiaryContainer = Color(0x40FF0055),
    onTertiaryContainer = NeonPinkRed,
    background = CyberBgDark,
    onBackground = CyberTextPrimary,
    surface = CyberPanelBg,
    onSurface = CyberTextPrimary,
    surfaceVariant = CyberSurface,
    onSurfaceVariant = CyberTextSecondary,
    outline = CyberBorderCyan,
    error = NeonPinkRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = CyberColorScheme,
        typography = Typography,
        content = content
    )
}
