package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val CyberBgDark = Color(0xFF0D0E15)
val CyberPanelBg = Color(0xFF141622)
val CyberSurface = Color(0xFF1A1D2E)
val CyberCard = Color(0xFF22263D)

val MatrixGreen = Color(0xFF00FF66)
val MatrixGreenGlow = Color(0x3300FF66)
val CyberCyan = Color(0xFF00E5FF)
val CyberCyanGlow = Color(0x3300E5FF)
val NeonPinkRed = Color(0xFFFF0055)
val NeonPinkGlow = Color(0x40FF0055)
val ElectricAmber = Color(0xFFFFB700)
val ElectricAmberGlow = Color(0x33FFB700)
val CyberPurple = Color(0xFF7B2CBF)

val CyberTextPrimary = Color(0xFFE0F7FA)
val CyberTextSecondary = Color(0xFF80DEEA)
val CyberTextMuted = Color(0xFF546E7A)
val CyberBorderCyan = Color(0xFF00E5FF)
val CyberBorderGreen = Color(0xFF00FF66)
