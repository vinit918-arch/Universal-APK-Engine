package com.example.service

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.AccelerateDecelerateInterpolator
import android.widget.SeekBar
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.databinding.OverlayMenuBinding
import com.example.databinding.PointerTargetBinding
import com.example.databinding.TriggerButtonBinding
import com.example.shizuku.ShizukuDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs

class FloatingService : Service() {

    companion object {
        private const val TAG = "FloatingService"
        private const val NOTIFICATION_ID = 9001
        private const val CHANNEL_ID = "cyber_macro_channel"

        const val ACTION_START = "ACTION_START_OVERLAY"
        const val ACTION_STOP = "ACTION_STOP_OVERLAY"

        private val _isOverlayRunning = MutableStateFlow(false)
        val isOverlayRunning = _isOverlayRunning.asStateFlow()

        enum class MacroMode {
            REPEAT,
            ON_HOLD,
            BURST
        }
    }

    private lateinit var windowManager: WindowManager
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var clickDispatcherJob: Job? = null

    // View Bindings
    private var _menuBinding: OverlayMenuBinding? = null
    private val menuBinding get() = _menuBinding!!

    private var _triggerBinding: TriggerButtonBinding? = null
    private val triggerBinding get() = _triggerBinding!!

    private var _pointerBinding: PointerTargetBinding? = null
    private val pointerBinding get() = _pointerBinding!!

    // Window Layout Params
    private lateinit var menuParams: WindowManager.LayoutParams
    private lateinit var triggerParams: WindowManager.LayoutParams
    private lateinit var pointerParams: WindowManager.LayoutParams

    // State Variables
    private var currentMode = MacroMode.REPEAT
    private var dispatchDelayMs = 50L
    private var isClickingActive = false
    private var totalTapCount = 0
    private var currentOpacity = 0.9f
    private var currentScale = 1.0f
    private var isMenuMinimized = false
    private var isPointerVisible = true

    // Pointer Coordinates in absolute screen pixels
    private var pointerTargetX = 500f
    private var pointerTargetY = 800f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForegroundNotification()
        initOverlayViews()
        _isOverlayRunning.value = true
        Log.i(TAG, "Floating Cyber Macro Service Created")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    private fun startForegroundNotification() {
        val channelName = getString(R.string.service_notification_channel_name)
        val channelDesc = getString(R.string.service_notification_channel_desc)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                channelName,
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = channelDesc
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingService::class.java).apply {
            action = ACTION_STOP
        }
        val pendingStopIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.service_notification_title))
            .setContentText(getString(R.string.service_notification_text))
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .setContentIntent(pendingIntent)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "KILL HUD",
                pendingStopIntent
            )
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun createOverlayParams(
        x: Int,
        y: Int,
        width: Int = WindowManager.LayoutParams.WRAP_CONTENT,
        height: Int = WindowManager.LayoutParams.WRAP_CONTENT
    ): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        return WindowManager.LayoutParams(
            width,
            height,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
    }

    private fun initOverlayViews() {
        val inflater = LayoutInflater.from(this)
        val metrics = resources.displayMetrics

        // 1. Overlay Menu Bar
        _menuBinding = OverlayMenuBinding.inflate(inflater)
        menuParams = createOverlayParams(
            x = 40,
            y = 120,
            width = WindowManager.LayoutParams.WRAP_CONTENT,
            height = WindowManager.LayoutParams.WRAP_CONTENT
        )

        // 2. Capital 'A' Trigger Button
        _triggerBinding = TriggerButtonBinding.inflate(inflater)
        triggerParams = createOverlayParams(
            x = 40,
            y = (metrics.heightPixels * 0.45).toInt()
        )

        // 3. Small 'a' Pointer Target
        _pointerBinding = PointerTargetBinding.inflate(inflater)
        pointerParams = createOverlayParams(
            x = (metrics.widthPixels * 0.5 - 60).toInt(),
            y = (metrics.heightPixels * 0.5 - 60).toInt()
        )

        // Attach views to WindowManager
        try {
            windowManager.addView(menuBinding.root, menuParams)
            windowManager.addView(triggerBinding.root, triggerParams)
            windowManager.addView(pointerBinding.root, pointerParams)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding overlay views to WindowManager", e)
        }

        setupMenuControls()
        setupTriggerButton()
        setupPointerTarget()
        updateTargetCoordinates(pointerParams.x, pointerParams.y)
        updateEngineStatusBadge()
    }

    private fun setupMenuControls() {
        // Drag listener for Menu Bar Header
        attachDragListener(menuBinding.headerBar, menuParams, menuBinding.root)

        // Minimize / Expand HUD
        menuBinding.btnMinimize.setOnClickListener {
            isMenuMinimized = !isMenuMinimized
            menuBinding.panelContent.visibility = if (isMenuMinimized) View.GONE else View.VISIBLE
            menuBinding.btnMinimize.setImageResource(
                if (isMenuMinimized) android.R.drawable.ic_menu_more else android.R.drawable.ic_menu_crop
            )
        }

        // Close service
        menuBinding.btnCloseService.setOnClickListener {
            stopSelf()
        }

        // Mode Selection
        updateModeSelectionButtons()
        menuBinding.btnModeRepeat.setOnClickListener {
            setMacroMode(MacroMode.REPEAT)
        }
        menuBinding.btnModeHold.setOnClickListener {
            setMacroMode(MacroMode.ON_HOLD)
        }
        menuBinding.btnModeBurst.setOnClickListener {
            setMacroMode(MacroMode.BURST)
        }

        // Dispatch Speed Slider
        menuBinding.seekSpeed.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                dispatchDelayMs = progress.coerceAtLeast(10).toLong()
                val cps = 1000 / dispatchDelayMs
                menuBinding.tvSpeedLabel.text = "DISPATCH_DELAY: ${dispatchDelayMs} ms (~$cps CPS)"
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Opacity Slider
        menuBinding.seekOpacity.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                currentOpacity = progress / 100f
                menuBinding.tvOpacityLabel.text = "HUD_OPACITY: $progress%"
                menuBinding.root.alpha = currentOpacity
                triggerBinding.root.alpha = currentOpacity
                pointerBinding.root.alpha = currentOpacity
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Scale Slider
        menuBinding.seekScale.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                currentScale = progress / 100f
                menuBinding.tvScaleLabel.text = "CONTROL_SCALE: $progress%"
                triggerBinding.root.scaleX = currentScale
                triggerBinding.root.scaleY = currentScale
                pointerBinding.root.scaleX = currentScale
                pointerBinding.root.scaleY = currentScale
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        // Reset Counter Button
        menuBinding.btnResetStats.setOnClickListener {
            totalTapCount = 0
            updateTapCountDisplay()
        }

        // Toggle Targets Visibility
        menuBinding.btnToggleTargets.setOnClickListener {
            isPointerVisible = !isPointerVisible
            pointerBinding.root.visibility = if (isPointerVisible) View.VISIBLE else View.GONE
            menuBinding.btnToggleTargets.text = if (isPointerVisible) "HIDE_TARGET" else "SHOW_TARGET"
        }
    }

    private fun setMacroMode(mode: MacroMode) {
        currentMode = mode
        if (isClickingActive && mode != MacroMode.REPEAT) {
            stopClickingLoop()
        }
        updateModeSelectionButtons()
    }

    private fun updateModeSelectionButtons() {
        val activeBg = ContextCompat.getDrawable(this, R.drawable.bg_status_badge_green)
        val inactiveBg = ContextCompat.getDrawable(this, R.drawable.bg_neon_button)

        menuBinding.btnModeRepeat.background = if (currentMode == MacroMode.REPEAT) activeBg else inactiveBg
        menuBinding.btnModeRepeat.setTextColor(if (currentMode == MacroMode.REPEAT) 0xFF00FF66.toInt() else 0xFFE0F7FA.toInt())

        menuBinding.btnModeHold.background = if (currentMode == MacroMode.ON_HOLD) activeBg else inactiveBg
        menuBinding.btnModeHold.setTextColor(if (currentMode == MacroMode.ON_HOLD) 0xFF00FF66.toInt() else 0xFFE0F7FA.toInt())

        menuBinding.btnModeBurst.background = if (currentMode == MacroMode.BURST) activeBg else inactiveBg
        menuBinding.btnModeBurst.setTextColor(if (currentMode == MacroMode.BURST) 0xFF00FF66.toInt() else 0xFFE0F7FA.toInt())
    }

    private fun updateEngineStatusBadge() {
        when (ShizukuDispatcher.getActiveEngine()) {
            ShizukuDispatcher.EngineType.SHIZUKU -> {
                menuBinding.tvEngineStatus.text = "⚡ SHIZUKU_LINK_ACTIVE [GREEN]"
                menuBinding.tvEngineStatus.setBackgroundResource(R.drawable.bg_status_badge_green)
                menuBinding.tvEngineStatus.setTextColor(0xFF00FF66.toInt())
            }
            ShizukuDispatcher.EngineType.ACCESSIBILITY -> {
                menuBinding.tvEngineStatus.text = "🛡️ ACCESSIBILITY_FALLBACK [AMBER]"
                menuBinding.tvEngineStatus.setBackgroundResource(R.drawable.bg_status_badge_amber)
                menuBinding.tvEngineStatus.setTextColor(0xFFFFB700.toInt())
            }
            ShizukuDispatcher.EngineType.NONE -> {
                menuBinding.tvEngineStatus.text = "⚠️ NO_ENGINE_BOUND [RED]"
                menuBinding.tvEngineStatus.setBackgroundResource(R.drawable.bg_status_badge_red)
                menuBinding.tvEngineStatus.setTextColor(0xFFFF0055.toInt())
            }
        }
    }

    private fun setupTriggerButton() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f
        var isDragging = false
        val touchSlop = 12f

        triggerBinding.triggerFrame.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = triggerParams.x
                    initialY = triggerParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false

                    if (currentMode == MacroMode.ON_HOLD) {
                        startClickingLoop()
                    }
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (abs(dx) > touchSlop || abs(dy) > touchSlop) {
                        isDragging = true
                        triggerParams.x = (initialX + dx).toInt()
                        triggerParams.y = (initialY + dy).toInt()
                        try {
                            windowManager.updateViewLayout(triggerBinding.root, triggerParams)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error updating trigger layout", e)
                        }
                    }
                    true
                }

                MotionEvent.ACTION_UP -> {
                    if (currentMode == MacroMode.ON_HOLD) {
                        stopClickingLoop()
                    } else if (!isDragging) {
                        // Click event triggered
                        when (currentMode) {
                            MacroMode.REPEAT -> {
                                if (isClickingActive) {
                                    stopClickingLoop()
                                } else {
                                    startClickingLoop()
                                }
                            }
                            MacroMode.BURST -> {
                                fireBurstClicks(10)
                            }
                            else -> {}
                        }
                    }
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    if (currentMode == MacroMode.ON_HOLD) {
                        stopClickingLoop()
                    }
                    true
                }

                else -> false
            }
        }
    }

    private fun setupPointerTarget() {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        pointerBinding.root.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = pointerParams.x
                    initialY = pointerParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    pointerParams.x = (initialX + dx).toInt()
                    pointerParams.y = (initialY + dy).toInt()

                    try {
                        windowManager.updateViewLayout(pointerBinding.root, pointerParams)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error updating pointer layout", e)
                    }

                    updateTargetCoordinates(pointerParams.x, pointerParams.y)
                    true
                }

                else -> true
            }
        }
    }

    private fun updateTargetCoordinates(paramX: Int, paramY: Int) {
        // Calculate center coordinate of reticle
        val reticleWidth = (60 * resources.displayMetrics.density).toInt()
        val reticleHeight = (60 * resources.displayMetrics.density).toInt()
        val badgeHeight = (22 * resources.displayMetrics.density).toInt()

        pointerTargetX = (paramX + reticleWidth / 2f).coerceAtLeast(0f)
        pointerTargetY = (paramY + badgeHeight + reticleHeight / 2f).coerceAtLeast(0f)

        val coordText = "X: ${pointerTargetX.toInt()} | Y: ${pointerTargetY.toInt()}"
        pointerBinding.tvTargetCoords.text = coordText
        menuBinding.tvHudTelemetryCoords.text = "TARGET: (${pointerTargetX.toInt()}, ${pointerTargetY.toInt()})"
    }

    private fun startClickingLoop() {
        if (isClickingActive) return
        isClickingActive = true
        setVisualActiveState(true)

        clickDispatcherJob = serviceScope.launch {
            while (isActive && isClickingActive) {
                dispatchSingleTap()
                delay(dispatchDelayMs)
            }
        }
    }

    private fun stopClickingLoop() {
        isClickingActive = false
        clickDispatcherJob?.cancel()
        clickDispatcherJob = null
        setVisualActiveState(false)
    }

    private fun fireBurstClicks(count: Int) {
        if (isClickingActive) return
        isClickingActive = true
        setVisualActiveState(true)

        serviceScope.launch {
            for (i in 1..count) {
                dispatchSingleTap()
                delay(dispatchDelayMs)
            }
            isClickingActive = false
            setVisualActiveState(false)
        }
    }

    private suspend fun dispatchSingleTap() {
        totalTapCount++
        updateTapCountDisplay()
        triggerSonarPulseAnimation()
        triggerGreenGlowPulse()

        // Execute click dispatch via Shizuku or Accessibility
        ShizukuDispatcher.dispatchClick(pointerTargetX, pointerTargetY)
    }

    private fun updateTapCountDisplay() {
        triggerBinding.tvTapCounter.text = "$totalTapCount"
        menuBinding.tvHudTelemetryTaps.text = "TAPS: $totalTapCount"
    }

    private fun setVisualActiveState(active: Boolean) {
        if (active) {
            triggerBinding.viewPulseGlow.visibility = View.VISIBLE
            triggerBinding.tvTriggerGlyph.setTextColor(0xFF00FF66.toInt())
            triggerBinding.tvTriggerGlyph.setShadowLayer(8f, 0f, 0f, 0xFF00FF66.toInt())
        } else {
            triggerBinding.viewPulseGlow.visibility = View.GONE
            triggerBinding.tvTriggerGlyph.setTextColor(0xFFFF0055.toInt())
            triggerBinding.tvTriggerGlyph.setShadowLayer(8f, 0f, 0f, 0xFFFF0055.toInt())
        }
    }

    private fun triggerGreenGlowPulse() {
        val glow = triggerBinding.viewPulseGlow
        glow.alpha = 1f
        glow.scaleX = 1f
        glow.scaleY = 1f

        val scaleX = ObjectAnimator.ofFloat(glow, View.SCALE_X, 1f, 1.35f, 1f).setDuration(120)
        val scaleY = ObjectAnimator.ofFloat(glow, View.SCALE_Y, 1f, 1.35f, 1f).setDuration(120)
        val alpha = ObjectAnimator.ofFloat(glow, View.ALPHA, 1f, 0.4f, 0.8f).setDuration(120)

        AnimatorSet().apply {
            playTogether(scaleX, scaleY, alpha)
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun triggerSonarPulseAnimation() {
        val sonar = pointerBinding.viewSonarPulse
        sonar.alpha = 0.9f
        sonar.scaleX = 0.8f
        sonar.scaleY = 0.8f

        val scaleX = ObjectAnimator.ofFloat(sonar, View.SCALE_X, 0.8f, 1.8f).setDuration(220)
        val scaleY = ObjectAnimator.ofFloat(sonar, View.SCALE_Y, 0.8f, 1.8f).setDuration(220)
        val alpha = ObjectAnimator.ofFloat(sonar, View.ALPHA, 0.9f, 0f).setDuration(220)

        AnimatorSet().apply {
            playTogether(scaleX, scaleY, alpha)
            interpolator = AccelerateDecelerateInterpolator()
            start()
        }
    }

    private fun attachDragListener(
        touchView: View,
        params: WindowManager.LayoutParams,
        rootView: View
    ) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        touchView.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    params.x = (initialX + (event.rawX - initialTouchX)).toInt()
                    params.y = (initialY + (event.rawY - initialTouchY)).toInt()
                    try {
                        windowManager.updateViewLayout(rootView, params)
                    } catch (e: Exception) {
                        Log.e(TAG, "Error updating window layout for $rootView", e)
                    }
                    true
                }

                else -> false
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopClickingLoop()
        serviceScope.cancel()

        _isOverlayRunning.value = false

        try {
            _menuBinding?.let { windowManager.removeView(it.root) }
            _triggerBinding?.let { windowManager.removeView(it.root) }
            _pointerBinding?.let { windowManager.removeView(it.root) }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing overlay views on destroy", e)
        }

        _menuBinding = null
        _triggerBinding = null
        _pointerBinding = null

        Log.i(TAG, "Floating Cyber Macro Service Destroyed")
    }
}
