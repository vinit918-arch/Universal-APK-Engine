package com.example.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MacroAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "MacroAccessibility"
        
        private val _isServiceRunning = MutableStateFlow(false)
        val isServiceRunning: StateFlow<Boolean> = _isServiceRunning.asStateFlow()

        @Volatile
        var instance: MacroAccessibilityService? = null
            private set

        fun dispatchTap(
            x: Float,
            y: Float,
            durationMs: Long = 15L,
            onComplete: ((Boolean) -> Unit)? = null
        ): Boolean {
            val service = instance ?: return false
            return service.performTapGesture(x, y, durationMs, onComplete)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        _isServiceRunning.value = true
        Log.i(TAG, "Cyber Macro Accessibility Service Connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No event interception required for pure gesture dispatch
    }

    override fun onInterrupt() {
        Log.w(TAG, "Cyber Macro Accessibility Service Interrupted")
        _isServiceRunning.value = false
    }

    override fun onDestroy() {
        super.onDestroy()
        if (instance == this) {
            instance = null
            _isServiceRunning.value = false
        }
        Log.i(TAG, "Cyber Macro Accessibility Service Destroyed")
    }

    fun performTapGesture(
        x: Float,
        y: Float,
        durationMs: Long = 15L,
        onComplete: ((Boolean) -> Unit)? = null
    ): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            onComplete?.invoke(false)
            return false
        }

        val path = Path().apply {
            moveTo(x.coerceAtLeast(0f), y.coerceAtLeast(0f))
        }

        val stroke = GestureDescription.StrokeDescription(
            path,
            0,
            durationMs.coerceIn(1L, 100L)
        )

        val gesture = GestureDescription.Builder()
            .addStroke(stroke)
            .build()

        return dispatchGesture(
            gesture,
            object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                    onComplete?.invoke(true)
                }

                override fun onCancelled(gestureDescription: GestureDescription?) {
                    super.onCancelled(gestureDescription)
                    onComplete?.invoke(false)
                }
            },
            null
        )
    }
}
