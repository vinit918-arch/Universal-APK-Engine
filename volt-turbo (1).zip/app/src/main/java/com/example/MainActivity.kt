package com.example

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AutoClickConfig
import com.example.data.model.ClickPoint
import com.example.data.model.ClickStats
import com.example.data.model.ClickerMode
import com.example.service.FloatingControlService
import com.example.shizuku.ShizukuState
import com.example.shizuku.ShizukuStateRepository
import com.example.shizuku.ShizukuTouchEngine
import com.example.ui.theme.VoltBackgroundDark
import com.example.ui.theme.VoltBorder
import com.example.ui.theme.VoltBorderCyan
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltGreen
import com.example.ui.theme.VoltOrange
import com.example.ui.theme.VoltRed
import com.example.ui.theme.VoltSurface
import com.example.ui.theme.VoltSurfaceElevated
import com.example.ui.theme.VoltTextPrimary
import com.example.ui.theme.VoltTextSecondary
import com.example.ui.theme.VoltTextTertiary
import com.example.ui.theme.VoltTurboTheme
import com.example.ui.theme.VoltViolet

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        ShizukuStateRepository.init(this)

        setContent {
            VoltTurboTheme {
                AutoClickerMainScreen(
                    activity = this,
                    onGrantShizuku = {
                        ShizukuStateRepository.requestPermission(this)
                    },
                    onRequestOverlayPermission = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:$packageName")
                            )
                            startActivity(intent)
                        }
                    }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        ShizukuStateRepository.checkState(this)
    }

    override fun onDestroy() {
        super.onDestroy()
        ShizukuStateRepository.cleanup()
    }
}

@Composable
fun AutoClickerMainScreen(
    activity: Activity,
    onGrantShizuku: () -> Unit,
    onRequestOverlayPermission: () -> Unit
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current

    val shizukuState by ShizukuStateRepository.state.collectAsState()
    val stats by ShizukuTouchEngine.stats.collectAsState()
    val isOverlayActive by FloatingControlService.isOverlayActive.collectAsState()
    val activeConfig by FloatingControlService.activeConfig.collectAsState()

    var hasOverlayPermission by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(context) else true
        )
    }

    // Polling overlay permission status
    LaunchedEffect(Unit) {
        while (true) {
            hasOverlayPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Settings.canDrawOverlays(context)
            } else true
            kotlinx.coroutines.delay(1000)
        }
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("CONTROLS", "SETTINGS", "SANDBOX", "SHIZUKU")

    var testTargetClicks by remember { mutableLongStateOf(0L) }

    Scaffold(
        containerColor = VoltBackgroundDark,
        topBar = {
            TopAppBarHeader(
                shizukuReady = shizukuState is ShizukuState.Ready,
                isClicking = stats.isRunning
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Tab Selector
            TabRow(
                selectedTabIndex = selectedTab,
                containerColor = Color(0xFF10101C),
                contentColor = VoltCyan,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                        color = VoltCyan,
                        height = 3.dp
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        text = {
                            Text(
                                text = title,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                // Permission Warning Banners
                if (shizukuState !is ShizukuState.Ready) {
                    item {
                        ShizukuPermissionBanner(
                            state = shizukuState,
                            onGrant = onGrantShizuku,
                            onRefresh = { ShizukuStateRepository.checkState(context) }
                        )
                    }
                }

                if (!hasOverlayPermission) {
                    item {
                        OverlayPermissionBanner(onRequest = onRequestOverlayPermission)
                    }
                }

                // TAB 0: PRIMARY CONTROLS & FLOATING OVERLAY TOGGLE
                if (selectedTab == 0) {
                    item {
                        FloatingOverlayMasterCard(
                            isOverlayActive = isOverlayActive,
                            hasOverlayPermission = hasOverlayPermission,
                            onToggleOverlay = {
                                if (isOverlayActive) {
                                    FloatingControlService.stopService(context)
                                } else {
                                    if (hasOverlayPermission) {
                                        FloatingControlService.startService(context)
                                    } else {
                                        onRequestOverlayPermission()
                                    }
                                }
                            },
                            onRequestOverlayPermission = onRequestOverlayPermission
                        )
                    }

                    item {
                        LiveTelemetryCard(stats = stats)
                    }

                    item {
                        QuickExecutionCard(
                            config = activeConfig,
                            stats = stats,
                            onStartStop = {
                                if (stats.isRunning) {
                                    ShizukuTouchEngine.stopClickLoop()
                                } else {
                                    ShizukuTouchEngine.startClickLoop(activeConfig)
                                }
                            }
                        )
                    }
                }

                // TAB 1: ADVANCED CONFIGURATION
                if (selectedTab == 1) {
                    item {
                        ConfigurationCard(
                            config = activeConfig,
                            onConfigChanged = { FloatingControlService.updateConfig(it) }
                        )
                    }
                }

                // TAB 2: SANDBOX TEST AREA
                if (selectedTab == 2) {
                    item {
                        SandboxTestCard(
                            clickCount = testTargetClicks,
                            onClick = { testTargetClicks++ },
                            onReset = { testTargetClicks = 0 }
                        )
                    }
                }

                // TAB 3: SHIZUKU ADB MANAGER & GUIDE
                if (selectedTab == 3) {
                    item {
                        ShizukuManagerCard(
                            state = shizukuState,
                            onGrant = onGrantShizuku,
                            onCopyCommand = { cmd ->
                                clipboardManager.setText(AnnotatedString(cmd))
                                Toast.makeText(context, "Copied ADB command to clipboard!", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }

                item {
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }
    }
}

// ---------------------------------------------------------------------------
// UI Components & Subviews
// ---------------------------------------------------------------------------

@Composable
fun TopAppBarHeader(shizukuReady: Boolean, isClicking: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Brush.linearGradient(listOf(VoltViolet, VoltCyan))),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = null,
                    tint = Color.Black,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "AUTO",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = VoltTextPrimary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "CLICKER",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = VoltCyan,
                        letterSpacing = 1.sp
                    )
                }
                Text(
                    text = "ROOTLESS SHIZUKU TOUCH ENGINE",
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = VoltTextSecondary,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Status Badge
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(
                    when {
                        isClicking -> Color(0xFF3B1525)
                        shizukuReady -> Color(0xFF142B20)
                        else -> Color(0xFF332014)
                    }
                )
                .border(
                    1.dp,
                    when {
                        isClicking -> VoltRed
                        shizukuReady -> VoltGreen
                        else -> VoltOrange
                    },
                    RoundedCornerShape(12.dp)
                )
                .padding(horizontal = 10.dp, vertical = 4.dp)
        ) {
            Text(
                text = when {
                    isClicking -> "CLICKING"
                    shizukuReady -> "ADB READY"
                    else -> "NO SHIZUKU"
                },
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = when {
                    isClicking -> VoltRed
                    shizukuReady -> VoltGreen
                    else -> VoltOrange
                }
            )
        }
    }
}

@Composable
fun ShizukuPermissionBanner(
    state: ShizukuState,
    onGrant: () -> Unit,
    onRefresh: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF281810)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, VoltOrange.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = Icons.Default.Security, contentDescription = null, tint = VoltOrange, modifier = Modifier.size(18.dp))
                Text(
                    text = "SHIZUKU PRIVILEGE REQUIRED",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = VoltOrange
                )
            }

            Text(
                text = when (state) {
                    is ShizukuState.PermissionDenied -> "Shizuku service is running, but touch execution permission is not granted."
                    is ShizukuState.NotRunning -> "Shizuku ADB service is not active. Start Shizuku via wireless debugging on your device."
                    is ShizukuState.NotInstalled -> "Shizuku app is not installed. Install Shizuku to enable rootless low-latency touch injection."
                    is ShizukuState.VersionWarning -> "Shizuku version v${state.version} detected. Please update to v11+."
                    else -> "Grant Shizuku permission to inject touch events without Accessibility lag."
                },
                fontSize = 11.sp,
                color = VoltTextSecondary,
                lineHeight = 15.sp
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (state is ShizukuState.PermissionDenied) {
                    Button(
                        onClick = onGrant,
                        colors = ButtonDefaults.buttonColors(containerColor = VoltOrange, contentColor = Color.Black),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.weight(1f).testTag("grant_shizuku_btn")
                    ) {
                        Text("GRANT PERMISSION", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    }
                }

                OutlinedButton(
                    onClick = onRefresh,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Icon(imageVector = Icons.Default.Refresh, contentDescription = null, tint = VoltOrange, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("RECHECK", color = VoltOrange, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                }
            }
        }
    }
}

@Composable
fun OverlayPermissionBanner(onRequest: () -> Unit) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E102E)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, VoltViolet.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = Icons.Default.Layers, contentDescription = null, tint = VoltViolet, modifier = Modifier.size(18.dp))
                Text(
                    text = "FLOATING OVERLAY PERMISSION",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = VoltViolet
                )
            }

            Text(
                text = "Enable 'Display over other apps' to allow the floating widget and draggable crosshair coordinate picker to appear over games and apps.",
                fontSize = 11.sp,
                color = VoltTextSecondary,
                lineHeight = 15.sp
            )

            Button(
                onClick = onRequest,
                colors = ButtonDefaults.buttonColors(containerColor = VoltViolet, contentColor = Color.White),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().testTag("enable_overlay_permission_btn")
            ) {
                Text("ENABLE OVERLAY PERMISSION", fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
            }
        }
    }
}

@Composable
fun FloatingOverlayMasterCard(
    isOverlayActive: Boolean,
    hasOverlayPermission: Boolean,
    onToggleOverlay: () -> Unit,
    onRequestOverlayPermission: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = VoltSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.5.dp,
                if (isOverlayActive) VoltCyan else VoltBorder,
                RoundedCornerShape(14.dp)
            )
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(if (isOverlayActive) VoltCyan else VoltTextTertiary)
                    )
                    Text(
                        text = "FLOATING CONTROLLER WIDGET",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = VoltTextPrimary
                    )
                }

                Text(
                    text = if (isOverlayActive) "ACTIVE" else "OFFLINE",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = if (isOverlayActive) VoltCyan else VoltTextTertiary
                )
            }

            Text(
                text = "Draws a floating draggable button on your screen. Tap it while inside any game or app to open the mini settings menu, position the target crosshair, and control auto-clicking in real time.",
                fontSize = 11.sp,
                color = VoltTextSecondary,
                lineHeight = 16.sp
            )

            Button(
                onClick = onToggleOverlay,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isOverlayActive) Color(0xFF3F1520) else VoltCyan,
                    contentColor = if (isOverlayActive) VoltRed else Color.Black
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .border(
                        1.dp,
                        if (isOverlayActive) VoltRed else VoltCyan,
                        RoundedCornerShape(10.dp)
                    )
                    .testTag("toggle_floating_service_btn")
            ) {
                Icon(
                    imageVector = if (isOverlayActive) Icons.Default.Stop else Icons.Default.Layers,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isOverlayActive) "STOP FLOATING CONTROLLER" else "START FLOATING CONTROLLER",
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
            }
        }
    }
}

@Composable
fun LiveTelemetryCard(stats: ClickStats) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF0F0F1A)),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, VoltBorderCyan, RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(imageVector = Icons.Default.Speed, contentDescription = null, tint = VoltCyan, modifier = Modifier.size(16.dp))
                Text(
                    text = "EXECUTION TELEMETRY",
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = VoltCyan
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                TelemetryBox(
                    label = "TOTAL CLICKS",
                    value = "${stats.totalClicks}",
                    color = VoltCyan,
                    modifier = Modifier.weight(1f)
                )
                TelemetryBox(
                    label = "SPEED (CPS)",
                    value = String.format("%.1f", stats.currentCps),
                    color = VoltGreen,
                    modifier = Modifier.weight(1f)
                )
                TelemetryBox(
                    label = "LAST TARGET",
                    value = "${stats.lastClickX}, ${stats.lastClickY}",
                    color = VoltViolet,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun TelemetryBox(
    label: String,
    value: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF161626))
            .border(1.dp, Color(0xFF222234), RoundedCornerShape(8.dp))
            .padding(8.dp)
    ) {
        Column {
            Text(text = label, fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = VoltTextSecondary)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = value, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = color)
        }
    }
}

@Composable
fun QuickExecutionCard(
    config: AutoClickConfig,
    stats: ClickStats,
    onStartStop: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = VoltSurfaceElevated),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, VoltBorder, RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ACTIVE CONFIGURATION",
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = VoltTextPrimary
                )

                Text(
                    text = "${config.intervalMs}ms Interval | Target (${config.singlePoint.x}, ${config.singlePoint.y})",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    color = VoltCyan
                )
            }

            Button(
                onClick = onStartStop,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (stats.isRunning) VoltRed else VoltCyan,
                    contentColor = if (stats.isRunning) Color.White else Color.Black
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("main_screen_start_stop_btn")
            ) {
                Icon(
                    imageVector = if (stats.isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (stats.isRunning) "STOP AUTO CLICKING" else "START AUTO CLICKING",
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun ConfigurationCard(
    config: AutoClickConfig,
    onConfigChanged: (AutoClickConfig) -> Unit
) {
    var xInput by remember(config.singlePoint.x) { mutableStateOf(config.singlePoint.x.toString()) }
    var yInput by remember(config.singlePoint.y) { mutableStateOf(config.singlePoint.y.toString()) }
    var intervalInput by remember(config.intervalMs) { mutableStateOf(config.intervalMs.toString()) }
    var repeatInput by remember(config.repeatCount) { mutableStateOf(config.repeatCount.toString()) }
    var jitterInput by remember(config.jitterRadiusPx) { mutableStateOf(config.jitterRadiusPx.toString()) }

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = VoltSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, VoltBorder, RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "TARGET COORDINATES (X, Y)",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = VoltCyan
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = xInput,
                    onValueChange = {
                        xInput = it
                        it.toIntOrNull()?.let { x ->
                            onConfigChanged(config.copy(singlePoint = config.singlePoint.copy(x = x)))
                        }
                    },
                    label = { Text("Target X (px)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = VoltTextPrimary,
                        unfocusedTextColor = VoltTextPrimary,
                        focusedBorderColor = VoltCyan
                    ),
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = yInput,
                    onValueChange = {
                        yInput = it
                        it.toIntOrNull()?.let { y ->
                            onConfigChanged(config.copy(singlePoint = config.singlePoint.copy(y = y)))
                        }
                    },
                    label = { Text("Target Y (px)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = VoltTextPrimary,
                        unfocusedTextColor = VoltTextPrimary,
                        focusedBorderColor = VoltCyan
                    ),
                    modifier = Modifier.weight(1f)
                )
            }

            Text(
                text = "CLICK INTERVAL (MS)",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = VoltCyan
            )

            OutlinedTextField(
                value = intervalInput,
                onValueChange = {
                    intervalInput = it
                    it.toLongOrNull()?.let { ms ->
                        if (ms > 0) onConfigChanged(config.copy(intervalMs = ms))
                    }
                },
                label = { Text("Interval delay") },
                trailingIcon = { Text("ms", color = VoltCyan, fontFamily = FontFamily.Monospace, modifier = Modifier.padding(end = 12.dp)) },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = VoltTextPrimary,
                    unfocusedTextColor = VoltTextPrimary,
                    focusedBorderColor = VoltCyan
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Preset Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(20L, 50L, 100L, 250L, 500L, 1000L).forEach { preset ->
                    val isSel = config.intervalMs == preset
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSel) VoltCyan else Color(0xFF1C1C2C))
                            .clickable {
                                intervalInput = preset.toString()
                                onConfigChanged(config.copy(intervalMs = preset))
                            }
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${preset}ms",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSel) Color.Black else VoltTextSecondary
                        )
                    }
                }
            }

            Text(
                text = "ANTI-DETECTION & HUMANIZER (OPTIONAL)",
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = VoltViolet
            )

            OutlinedTextField(
                value = jitterInput,
                onValueChange = {
                    jitterInput = it
                    it.toIntOrNull()?.let { r ->
                        onConfigChanged(config.copy(jitterRadiusPx = r))
                    }
                },
                label = { Text("Random coordinate jitter radius (px, 0 = exact)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = VoltTextPrimary,
                    unfocusedTextColor = VoltTextPrimary,
                    focusedBorderColor = VoltViolet
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun SandboxTestCard(
    clickCount: Long,
    onClick: () -> Unit,
    onReset: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = VoltSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, VoltBorderCyan, RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Text(
                text = "IN-APP TARGET TEST SANDBOX",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = VoltCyan
            )

            Text(
                text = "Drag the floating crosshair directly over this target button and tap Start. The auto clicker will execute taps via Shizuku shell injection!",
                fontSize = 11.sp,
                color = VoltTextSecondary,
                lineHeight = 15.sp
            )

            // Large Target Button
            Box(
                modifier = Modifier
                    .size(160.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(listOf(VoltViolet, Color(0xFF220844)))
                    )
                    .border(2.dp, VoltCyan, CircleShape)
                    .clickable { onClick() }
                    .testTag("sandbox_interactive_target"),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(imageVector = Icons.Default.CrisisAlert, contentDescription = null, tint = VoltCyan, modifier = Modifier.size(36.dp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$clickCount",
                        fontSize = 24.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Black,
                        color = Color.White
                    )
                    Text(
                        text = "CLICKS DETECTED",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        color = VoltCyan
                    )
                }
            }

            OutlinedButton(
                onClick = onReset,
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("RESET COUNTER", fontFamily = FontFamily.Monospace, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun ShizukuManagerCard(
    state: ShizukuState,
    onGrant: () -> Unit,
    onCopyCommand: (String) -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = VoltSurface),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, VoltBorder, RoundedCornerShape(14.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "SHIZUKU ADB PRIVILEGE ENGINE",
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = VoltCyan
            )

            Text(
                text = "Why Shizuku instead of Accessibility Service?\n• Zero latency direct kernel touch injection (`input tap`)\n• Does not trigger screen recording/accessibility detection flags\n• Runs rootlessly via standard Android Wireless Debugging.",
                fontSize = 11.sp,
                color = VoltTextSecondary,
                lineHeight = 16.sp
            )

            Text(
                text = "SETUP VIA WIRELESS DEBUGGING (ON-DEVICE)",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = VoltTextPrimary
            )

            Text(
                text = "1. Enable Developer Options & Wireless Debugging.\n2. Open Shizuku and tap 'Pairing' using the split-screen pairing code.\n3. Tap 'Start' in Shizuku, then return here and grant permission.",
                fontSize = 11.sp,
                color = VoltTextSecondary,
                lineHeight = 15.sp
            )

            Text(
                text = "SETUP VIA PC ADB (ONE-TIME PER BOOT)",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = VoltTextPrimary
            )

            val adbCmd = "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh"
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF0C0C14))
                    .border(1.dp, VoltBorderCyan, RoundedCornerShape(6.dp))
                    .clickable { onCopyCommand(adbCmd) }
                    .padding(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = adbCmd,
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = VoltCyan,
                        modifier = Modifier.weight(1f)
                    )
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = VoltCyan, modifier = Modifier.size(16.dp))
                }
            }

            if (state is ShizukuState.PermissionDenied) {
                Button(
                    onClick = onGrant,
                    colors = ButtonDefaults.buttonColors(containerColor = VoltCyan, contentColor = Color.Black),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("GRANT SHIZUKU PERMISSION", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                }
            }
        }
    }
}
