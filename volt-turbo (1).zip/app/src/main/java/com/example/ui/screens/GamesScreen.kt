package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.ActiveSessionInfo
import com.example.data.model.GameItem
import com.example.data.model.InstalledAppInfo
import com.example.service.GameSessionService
import com.example.shizuku.ShizukuShellExecutor
import com.example.ui.components.PowerCoreLaunchButton
import com.example.ui.components.VoltGlassCard
import com.example.ui.theme.VoltBackgroundDark
import com.example.ui.theme.VoltBorder
import com.example.ui.theme.VoltBorderBright
import com.example.ui.theme.VoltBorderCyan
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltGreen
import com.example.ui.theme.VoltOrange
import com.example.ui.theme.VoltRed
import com.example.ui.theme.VoltSurface
import com.example.ui.theme.VoltSurfaceElevated
import com.example.ui.theme.VoltTextPrimary
import com.example.ui.theme.VoltTextSecondary
import com.example.ui.theme.VoltTextTertiary
import com.example.ui.theme.VoltViolet
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GamesScreen(
    games: List<GameItem>,
    activeSession: ActiveSessionInfo?,
    onAddGame: (GameItem) -> Unit,
    onRemoveGame: (String) -> Unit,
    onOptimizeGame: (String) -> Unit,
    onLaunchGame: (GameItem) -> Unit,
    onRestoreSession: () -> Unit,
    onScanApps: suspend () -> List<InstalledAppInfo>,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    var showAddGameSheet by remember { mutableStateOf(false) }
    var installedApps by remember { mutableStateOf<List<InstalledAppInfo>>(emptyList()) }
    var searchQuery by remember { mutableStateOf("") }
    var isOptimizingPkg by remember { mutableStateOf<String?>(null) }
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }

    LaunchedEffect(Unit) {
        hasOverlayPermission = Settings.canDrawOverlays(context)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Hero Header Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, VoltBorderCyan, RoundedCornerShape(16.dp))
            ) {
                Image(
                    painter = painterResource(id = R.drawable.volt_hero_banner_1787919171979),
                    contentDescription = "Volt Turbo Engine",
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.Crop
                )

                // Overlay gradient for readability
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.horizontalGradient(
                                colors = listOf(
                                    Color(0xF00A0A10),
                                    Color(0xB00D0D18),
                                    Color(0x33000000)
                                )
                            )
                        )
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.Center
                    ) {
                        Text(
                            text = "GAME LAUNCHER",
                            fontSize = 11.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = VoltCyan
                        )
                        Text(
                            text = "Precision Performance Core",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Black,
                            color = VoltTextPrimary
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Launch games with full hardware tweaks & dual in-game HUD overlay.",
                            fontSize = 11.sp,
                            color = VoltTextSecondary,
                            maxLines = 2
                        )
                    }
                }
            }
        }

        // Active Session Status Card
        if (activeSession != null) {
            item {
                VoltGlassCard(
                    isActive = true,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(VoltGreen)
                            )
                            Column {
                                Text(
                                    text = "ACTIVE TURBO SESSION",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = VoltGreen
                                )
                                Text(
                                    text = activeSession.gameName,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VoltTextPrimary
                                )
                                Text(
                                    text = "${activeSession.appliedToggleIds.size} system tweaks applied",
                                    fontSize = 11.sp,
                                    color = VoltTextSecondary
                                )
                            }
                        }

                        Button(
                            onClick = onRestoreSession,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF3F1422),
                                contentColor = VoltRed
                            ),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier
                                .border(1.dp, Color(0x66FF1744), RoundedCornerShape(8.dp))
                                .testTag("session_restore_now_button")
                        ) {
                            Text(
                                text = "RESTORE NOW",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // Floating Overlay Permission Rationale Banner
        if (!hasOverlayPermission) {
            item {
                VoltGlassCard(
                    isWarning = true,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            modifier = Modifier.weight(1f),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Layers,
                                contentDescription = null,
                                tint = VoltOrange,
                                modifier = Modifier.size(24.dp)
                            )
                            Column {
                                Text(
                                    text = "Floating Overlay Permission",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = VoltTextPrimary
                                )
                                Text(
                                    text = "Enable 'Display over other apps' to access live FPS, crosshair & quick tools during matches.",
                                    fontSize = 11.sp,
                                    color = VoltTextSecondary,
                                    lineHeight = 15.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = {
                                val intent = Intent(
                                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                    Uri.parse("package:${context.packageName}")
                                )
                                context.startActivity(intent)
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VoltOrange,
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "ENABLE",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }
        }

        // Library Title & Add Game Button
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "SAVED GAMES",
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = VoltCyan,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "(${games.size})",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        color = VoltTextSecondary
                    )
                }

                Button(
                    onClick = {
                        coroutineScope.launch {
                            installedApps = onScanApps()
                            showAddGameSheet = true
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF1E1E30),
                        contentColor = VoltCyan
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .border(1.dp, VoltBorderCyan, RoundedCornerShape(8.dp))
                        .testTag("add_game_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Add Game",
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "ADD GAME",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Games List
        if (games.isEmpty()) {
            item {
                VoltGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.SportsEsports,
                            contentDescription = null,
                            tint = VoltTextTertiary,
                            modifier = Modifier.size(48.dp)
                        )
                        Text(
                            text = "No Games Saved Yet",
                            fontWeight = FontWeight.Bold,
                            color = VoltTextPrimary,
                            fontSize = 16.sp
                        )
                        Text(
                            text = "Tap 'ADD GAME' to import games from your installed apps library.",
                            color = VoltTextSecondary,
                            fontSize = 12.sp
                        )
                    }
                }
            }
        } else {
            items(games, key = { it.packageName }) { game ->
                GameCardItem(
                    game = game,
                    isOptimizing = isOptimizingPkg == game.packageName,
                    onLaunch = { onLaunchGame(game) },
                    onOptimize = {
                        isOptimizingPkg = game.packageName
                        coroutineScope.launch {
                            val cmd = "cmd package compile -m speed -f ${game.packageName}"
                            val result = ShizukuShellExecutor.execute(cmd)
                            isOptimizingPkg = null
                            if (result.isSuccess) {
                                onOptimizeGame(game.packageName)
                                Toast.makeText(context, "${game.name} AOT Compiled (Speed Mode)!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Optimization: ${result.output}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    },
                    onRemove = { onRemoveGame(game.packageName) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Modal Bottom Sheet: Add Installed Game Picker
    if (showAddGameSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        val filteredApps = remember(installedApps, searchQuery) {
            if (searchQuery.isBlank()) {
                installedApps
            } else {
                installedApps.filter {
                    it.name.contains(searchQuery, ignoreCase = true) ||
                    it.packageName.contains(searchQuery, ignoreCase = true)
                }
            }
        }

        ModalBottomSheet(
            onDismissRequest = { showAddGameSheet = false },
            sheetState = sheetState,
            containerColor = Color(0xFF10101A)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .height(480.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "SELECT APP OR GAME TO ADD",
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = VoltCyan
                )

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search installed packages...", fontSize = 13.sp, color = VoltTextSecondary) },
                    leadingIcon = {
                        Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = VoltCyan)
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VoltCyan,
                        unfocusedBorderColor = VoltBorder,
                        focusedTextColor = VoltTextPrimary,
                        unfocusedTextColor = VoltTextPrimary,
                        cursorColor = VoltCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredApps, key = { it.packageName }) { app ->
                        val alreadyAdded = games.any { it.packageName == app.packageName }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (alreadyAdded) Color(0xFF161622) else Color(0xFF1C1C2C))
                                .border(1.dp, if (app.isGame) VoltBorderCyan else VoltBorder, RoundedCornerShape(8.dp))
                                .clickable(enabled = !alreadyAdded) {
                                    onAddGame(
                                        GameItem(
                                            packageName = app.packageName,
                                            name = app.name,
                                            isOptimized = false
                                        )
                                    )
                                    showAddGameSheet = false
                                }
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = app.name,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (alreadyAdded) VoltTextTertiary else VoltTextPrimary
                                    )
                                    if (app.isGame) {
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color(0x3300E5FF))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "GAME",
                                                fontSize = 8.sp,
                                                fontFamily = FontFamily.Monospace,
                                                color = VoltCyan,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                                Text(
                                    text = app.packageName,
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = VoltTextSecondary
                                )
                            }

                            if (alreadyAdded) {
                                Text(
                                    text = "ADDED",
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = VoltTextTertiary
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Add",
                                    tint = VoltCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GameCardItem(
    game: GameItem,
    isOptimizing: Boolean,
    onLaunch: () -> Unit,
    onOptimize: () -> Unit,
    onRemove: () -> Unit
) {
    VoltGlassCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Game Details & Actions
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Game Icon Representation
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(Color(0xFF2C1654), Color(0xFF141426))
                            )
                        )
                        .border(1.dp, VoltBorderBright, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.SportsEsports,
                        contentDescription = game.name,
                        tint = VoltCyan,
                        modifier = Modifier.size(26.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = game.name,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = VoltTextPrimary
                    )

                    Text(
                        text = game.packageName,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = VoltTextSecondary,
                        maxLines = 1
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // Badges & Optimize button
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        // Optimize Button (AOT Compilation)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (game.isOptimized) Color(0x3300E676) else Color(0xFF1E1E2C))
                                .border(
                                    1.dp,
                                    if (game.isOptimized) VoltGreen else VoltBorder,
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable(enabled = !isOptimizing, onClick = onOptimize)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                                .testTag("optimize_game_${game.packageName}")
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Icon(
                                    imageVector = if (game.isOptimized) Icons.Default.CheckCircle else Icons.Default.Build,
                                    contentDescription = "AOT Optimize",
                                    tint = if (game.isOptimized) VoltGreen else VoltViolet,
                                    modifier = Modifier.size(12.dp)
                                )
                                Text(
                                    text = if (isOptimizing) "COMPILING..." else if (game.isOptimized) "AOT SPEED" else "OPTIMIZE",
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold,
                                    color = if (game.isOptimized) VoltGreen else VoltViolet
                                )
                            }
                        }

                        // Remove Game
                        IconButton(
                            onClick = onRemove,
                            modifier = Modifier.size(22.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Remove game",
                                tint = VoltTextTertiary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.width(10.dp))

            // Power-Core Circular LAUNCH Button
            PowerCoreLaunchButton(
                onClick = onLaunch,
                size = 56.dp
            )
        }
    }
}
