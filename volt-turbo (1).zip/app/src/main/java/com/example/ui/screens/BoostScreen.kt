package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameItem
import com.example.data.repository.DeviceUptimeInfo
import com.example.data.repository.UptimeHelper
import com.example.shizuku.ShizukuShellExecutor
import com.example.ui.components.VoltGlassCard
import com.example.ui.theme.VoltBorder
import com.example.ui.theme.VoltBorderBright
import com.example.ui.theme.VoltBorderCyan
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltGreen
import com.example.ui.theme.VoltOrange
import com.example.ui.theme.VoltRed
import com.example.ui.theme.VoltSurface
import com.example.ui.theme.VoltSurfaceElevated
import com.example.ui.theme.VoltTextPrimary
import com.example.ui.theme.VoltTextSecondary
import com.example.ui.theme.VoltTextTertiary
import com.example.ui.theme.VoltViolet
import kotlinx.coroutines.launch

data class BoostChecklistItem(
    val id: String,
    val title: String,
    val description: String,
    val command: String,
    val isChecked: Boolean = true
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BoostScreen(
    savedGames: List<GameItem>,
    onLaunchGameWithBoost: (GameItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    var uptimeInfo by remember { mutableStateOf<DeviceUptimeInfo?>(null) }
    var isRunningBoost by remember { mutableStateOf(false) }
    var boostOutputLogs by remember { mutableStateOf<List<String>>(emptyList()) }
    var showGamePickerSheet by remember { mutableStateOf(false) }

    var checklistItems by remember {
        mutableStateOf(
            listOf(
                BoostChecklistItem(
                    id = "kill_background",
                    title = "Clear Background Processes",
                    description = "Terminates cached non-critical background apps to free kernel memory (am kill-all).",
                    command = "am kill-all",
                    isChecked = true
                ),
                BoostChecklistItem(
                    id = "trim_caches",
                    title = "Trim System & App Caches",
                    description = "Frees temporary dalvik and system cache pages (cmd package trim-caches 4096G).",
                    command = "cmd package trim-caches 4096G",
                    isChecked = true
                )
            )
        )
    }

    LaunchedEffect(Unit) {
        uptimeInfo = UptimeHelper.getDeviceUptime()
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Device Uptime & Restart Recommendation Card
        item {
            VoltGlassCard(
                isWarning = uptimeInfo?.isRestartRecommended == true,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Timer,
                                contentDescription = null,
                                tint = if (uptimeInfo?.isRestartRecommended == true) VoltOrange else VoltCyan,
                                modifier = Modifier.size(20.dp)
                            )
                            Text(
                                text = "DEVICE UPTIME",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (uptimeInfo?.isRestartRecommended == true) VoltOrange else VoltCyan
                            )
                        }

                        Text(
                            text = uptimeInfo?.formattedUptime ?: "Detecting...",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = VoltTextPrimary
                        )
                    }

                    if (uptimeInfo?.isRestartRecommended == true) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x33FF9100))
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.RestartAlt,
                                contentDescription = null,
                                tint = VoltOrange,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = "Restart recommended (uptime > 3h) to purge kernel RAM fragmentation.",
                                fontSize = 11.sp,
                                color = VoltTextPrimary
                            )
                        }
                    } else {
                        Text(
                            text = "Clean memory state. One-shot post-restart boost will clear residual background daemons.",
                            fontSize = 11.sp,
                            color = VoltTextSecondary
                        )
                    }
                }
            }
        }

        // Section Title
        item {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(width = 4.dp, height = 24.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(VoltViolet)
                )
                Column {
                    Text(
                        text = "ONE-SHOT POST-RESTART BOOST",
                        fontSize = 13.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = VoltViolet,
                        letterSpacing = 0.5.sp
                    )
                    Text(
                        text = "Checklist runs once before launching your selected game",
                        fontSize = 11.sp,
                        color = VoltTextSecondary
                    )
                }
            }
        }

        // Checklist items
        items(checklistItems, key = { it.id }) { item ->
            VoltGlassCard(
                isActive = item.isChecked,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.Top
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E1E2C)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (item.id == "kill_background") Icons.Default.DeleteSweep else Icons.Default.CleaningServices,
                                contentDescription = null,
                                tint = if (item.isChecked) VoltCyan else VoltTextSecondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.title,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = VoltTextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = item.description,
                                fontSize = 11.sp,
                                color = VoltTextSecondary,
                                lineHeight = 15.sp
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "$ ${item.command}",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = VoltTextTertiary
                            )
                        }
                    }

                    Checkbox(
                        checked = item.isChecked,
                        onCheckedChange = { checked ->
                            checklistItems = checklistItems.map {
                                if (it.id == item.id) it.copy(isChecked = checked) else it
                            }
                        },
                        colors = CheckboxDefaults.colors(
                            checkedColor = VoltViolet,
                            uncheckedColor = VoltBorder,
                            checkmarkColor = VoltTextPrimary
                        ),
                        modifier = Modifier.testTag("checkbox_${item.id}")
                    )
                }
            }
        }

        // Action Button: "Run & Launch Game"
        item {
            Spacer(modifier = Modifier.height(6.dp))

            Button(
                onClick = {
                    coroutineScope.launch {
                        isRunningBoost = true
                        val logs = mutableListOf<String>()

                        for (item in checklistItems.filter { it.isChecked }) {
                            logs.add("Executing: ${item.command}...")
                            boostOutputLogs = logs.toList()
                            val result = ShizukuShellExecutor.execute(item.command)
                            logs.add("Output: ${result.output} (exit ${result.exitCode})")
                            boostOutputLogs = logs.toList()
                        }

                        isRunningBoost = false
                        showGamePickerSheet = true
                    }
                },
                enabled = !isRunningBoost && checklistItems.any { it.isChecked },
                colors = ButtonDefaults.buttonColors(
                    containerColor = VoltViolet,
                    contentColor = VoltTextPrimary
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .border(1.dp, VoltBorderCyan, RoundedCornerShape(12.dp))
                    .testTag("run_and_launch_game_button")
            ) {
                Icon(
                    imageVector = Icons.Default.RocketLaunch,
                    contentDescription = null,
                    tint = VoltCyan,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isRunningBoost) "EXECUTING BOOST..." else "RUN & LAUNCH GAME",
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )
            }
        }

        // Live Boost Output Logs
        if (boostOutputLogs.isNotEmpty()) {
            item {
                VoltGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "EXECUTION RESULT",
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = VoltCyan
                        )
                        boostOutputLogs.forEach { log ->
                            Text(
                                text = log,
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (log.contains("Output:")) VoltGreen else VoltTextSecondary
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Modal Game Picker to launch after boost execution
    if (showGamePickerSheet) {
        val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

        ModalBottomSheet(
            onDismissRequest = { showGamePickerSheet = false },
            sheetState = sheetState,
            containerColor = Color(0xFF10101A)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "SELECT GAME TO LAUNCH WITH VOLT TURBO",
                    fontSize = 13.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    color = VoltCyan
                )

                if (savedGames.isEmpty()) {
                    Text(
                        text = "No saved games found. Please add a game in the Games tab first.",
                        color = VoltTextSecondary,
                        fontSize = 13.sp
                    )
                } else {
                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.height(320.dp)
                    ) {
                        items(savedGames, key = { it.packageName }) { game ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(Color(0xFF1C1C2C))
                                    .border(1.dp, VoltBorderCyan, RoundedCornerShape(10.dp))
                                    .clickable {
                                        showGamePickerSheet = false
                                        onLaunchGameWithBoost(game)
                                    }
                                    .padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.SportsEsports,
                                        contentDescription = null,
                                        tint = VoltCyan,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Column {
                                        Text(
                                            text = game.name,
                                            fontSize = 15.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = VoltTextPrimary
                                        )
                                        Text(
                                            text = game.packageName,
                                            fontSize = 10.sp,
                                            fontFamily = FontFamily.Monospace,
                                            color = VoltTextSecondary
                                        )
                                    }
                                }

                                Icon(
                                    imageVector = Icons.Default.RocketLaunch,
                                    contentDescription = "Launch",
                                    tint = VoltCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
