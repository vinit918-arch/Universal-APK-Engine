package com.example.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.CropFree
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ColorGradingConfig
import com.example.data.model.CrosshairConfig
import com.example.data.model.CrosshairStyle
import com.example.ui.theme.VoltBackgroundDark
import com.example.ui.theme.VoltBorderCyan
import com.example.ui.theme.VoltBorderBright
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltGreen
import com.example.ui.theme.VoltOrange
import com.example.ui.theme.VoltRed
import com.example.ui.theme.VoltSurfaceGlass
import com.example.ui.theme.VoltTextPrimary
import com.example.ui.theme.VoltTextSecondary
import com.example.ui.theme.VoltViolet

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OverlayRightPanel(
    crosshairConfig: CrosshairConfig,
    onCrosshairChange: (CrosshairConfig) -> Unit,
    colorGradingConfig: ColorGradingConfig,
    onColorGradingChange: (ColorGradingConfig) -> Unit,
    onTakeScreenshot: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scrollState = rememberScrollState()

    val colorPresets = listOf(
        0xFFFF1744 to "Red",
        0xFF00E676 to "Green",
        0xFF00E5FF to "Cyan",
        0xFFFFFFFF to "White",
        0xFFFFD600 to "Yellow"
    )

    Box(
        modifier = modifier
            .width(280.dp)
            .clip(RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(VoltBackgroundDark, VoltSurfaceGlass)
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(VoltViolet, VoltBorderCyan)),
                shape = RoundedCornerShape(topStart = 16.dp, bottomStart = 16.dp)
            )
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(scrollState),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(28.dp).testTag("close_right_panel")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close Visual Tools",
                        tint = VoltTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "VISUAL TOOLS",
                        fontWeight = FontWeight.Black,
                        color = VoltViolet,
                        fontSize = 14.sp,
                        letterSpacing = 1.sp
                    )
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(VoltViolet)
                    )
                }
            }

            // SECTION 1: CROSSHAIR OVERLAY (Pure visual HUD)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF161624))
                    .border(1.dp, Color(0xFF28283E), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.CropFree,
                                contentDescription = "Crosshair",
                                tint = VoltCyan,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Crosshair HUD",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = VoltTextPrimary
                            )
                        }

                        Switch(
                            checked = crosshairConfig.enabled,
                            onCheckedChange = { onCrosshairChange(crosshairConfig.copy(enabled = it)) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = VoltCyan,
                                checkedTrackColor = Color(0xFF003844)
                            ),
                            modifier = Modifier.size(width = 38.dp, height = 22.dp)
                        )
                    }

                    if (crosshairConfig.enabled) {
                        // Style Picker (8 Styles)
                        Text(
                            text = "STYLE",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = VoltTextSecondary
                        )

                        FlowRow(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            CrosshairStyle.entries.forEach { style ->
                                val isSelected = crosshairConfig.style == style
                                Box(
                                    modifier = Modifier
                                        .size(34.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) Color(0xFF282444) else Color(0xFF1E1E2E))
                                        .border(
                                            width = if (isSelected) 1.5.dp else 1.dp,
                                            color = if (isSelected) VoltCyan else Color(0xFF333348),
                                            shape = RoundedCornerShape(6.dp)
                                        )
                                        .clickable { onCrosshairChange(crosshairConfig.copy(style = style)) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    CrosshairCanvas(
                                        config = crosshairConfig.copy(
                                            style = style,
                                            sizeDp = 18f,
                                            opacity = 1f
                                        )
                                    )
                                }
                            }
                        }

                        // Size Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "SIZE", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = VoltTextSecondary)
                            Text(text = "${crosshairConfig.sizeDp.toInt()}dp", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = VoltCyan)
                        }
                        Slider(
                            value = crosshairConfig.sizeDp,
                            onValueChange = { onCrosshairChange(crosshairConfig.copy(sizeDp = it)) },
                            valueRange = 8f..40f,
                            colors = SliderDefaults.colors(
                                thumbColor = VoltCyan,
                                activeTrackColor = VoltCyan,
                                inactiveTrackColor = Color(0xFF28283A)
                            ),
                            modifier = Modifier.height(20.dp)
                        )

                        // Color Presets
                        Text(text = "COLOR", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = VoltTextSecondary)
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            colorPresets.forEach { (colorHex, _) ->
                                val isSelected = crosshairConfig.colorHex == colorHex
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(Color(colorHex))
                                        .border(
                                            width = if (isSelected) 2.dp else 1.dp,
                                            color = if (isSelected) VoltTextPrimary else Color.Transparent,
                                            shape = CircleShape
                                        )
                                        .clickable { onCrosshairChange(crosshairConfig.copy(colorHex = colorHex)) }
                                )
                            }
                        }

                        // Opacity Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "OPACITY", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = VoltTextSecondary)
                            Text(text = "${(crosshairConfig.opacity * 100).toInt()}%", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = VoltCyan)
                        }
                        Slider(
                            value = crosshairConfig.opacity,
                            onValueChange = { onCrosshairChange(crosshairConfig.copy(opacity = it)) },
                            valueRange = 0.3f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = VoltCyan,
                                activeTrackColor = VoltCyan,
                                inactiveTrackColor = Color(0xFF28283A)
                            ),
                            modifier = Modifier.height(20.dp)
                        )

                        // Lock / Unlock Reposition
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF1C1C2C))
                                .clickable {
                                    onCrosshairChange(crosshairConfig.copy(isUnlocked = !crosshairConfig.isUnlocked))
                                }
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (crosshairConfig.isUnlocked) "Reposition: UNLOCKED" else "Reposition: LOCKED",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (crosshairConfig.isUnlocked) VoltOrange else VoltTextSecondary
                            )
                            Icon(
                                imageVector = if (crosshairConfig.isUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                                contentDescription = null,
                                tint = if (crosshairConfig.isUnlocked) VoltOrange else VoltTextSecondary,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }

            // SECTION 2: SCREEN COLOR GRADING
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF161624))
                    .border(1.dp, Color(0xFF28283E), RoundedCornerShape(10.dp))
                    .padding(10.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ColorLens,
                                contentDescription = "Color Filter",
                                tint = VoltViolet,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Color Grading",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = VoltTextPrimary
                            )
                        }

                        Switch(
                            checked = colorGradingConfig.enabled,
                            onCheckedChange = { onColorGradingChange(colorGradingConfig.copy(enabled = it)) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = VoltViolet,
                                checkedTrackColor = Color(0xFF2B1648)
                            ),
                            modifier = Modifier.size(width = 38.dp, height = 22.dp)
                        )
                    }

                    if (colorGradingConfig.enabled) {
                        // Saturation Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "SATURATION", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = VoltTextSecondary)
                            Text(text = "${String.format("%.1f", colorGradingConfig.saturation)}x", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = VoltViolet)
                        }
                        Slider(
                            value = colorGradingConfig.saturation,
                            onValueChange = { onColorGradingChange(colorGradingConfig.copy(saturation = it)) },
                            valueRange = 0.5f..2.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = VoltViolet,
                                activeTrackColor = VoltViolet,
                                inactiveTrackColor = Color(0xFF28283A)
                            ),
                            modifier = Modifier.height(20.dp)
                        )

                        // Contrast Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = "CONTRAST", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = VoltTextSecondary)
                            Text(text = "${String.format("%.1f", colorGradingConfig.contrast)}x", fontSize = 9.sp, fontFamily = FontFamily.Monospace, color = VoltViolet)
                        }
                        Slider(
                            value = colorGradingConfig.contrast,
                            onValueChange = { onColorGradingChange(colorGradingConfig.copy(contrast = it)) },
                            valueRange = 0.5f..2.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = VoltViolet,
                                activeTrackColor = VoltViolet,
                                inactiveTrackColor = Color(0xFF28283A)
                            ),
                            modifier = Modifier.height(20.dp)
                        )
                    }
                }
            }

            // SECTION 3: SCREENSHOT TRIGGER
            Button(
                onClick = onTakeScreenshot,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF1D1B36),
                    contentColor = VoltCyan
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0x6600E5FF), RoundedCornerShape(8.dp))
                    .testTag("screenshot_button")
            ) {
                Icon(
                    imageVector = Icons.Default.CameraAlt,
                    contentDescription = "Capture Screenshot",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "CAPTURE SCREENSHOT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}
