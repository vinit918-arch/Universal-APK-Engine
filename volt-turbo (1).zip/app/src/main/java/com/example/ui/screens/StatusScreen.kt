package com.example.ui.screens

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.DeviceUptimeInfo
import com.example.data.repository.UptimeHelper
import com.example.shizuku.CommandLogEntry
import com.example.shizuku.ShizukuShellExecutor
import com.example.shizuku.ShizukuState
import com.example.shizuku.ShizukuStateRepository
import com.example.ui.components.VoltGlassCard
import com.example.ui.theme.VoltBorder
import com.example.ui.theme.VoltBorderCyan
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltGreen
import com.example.ui.theme.VoltOrange
import com.example.ui.theme.VoltRed
import com.example.ui.theme.VoltTextPrimary
import com.example.ui.theme.VoltTextSecondary
import com.example.ui.theme.VoltTextTertiary
import com.example.ui.theme.VoltViolet

@Composable
fun StatusScreen(
    shizukuState: ShizukuState,
    animationsEnabled: Boolean,
    onToggleAnimations: (Boolean) -> Unit,
    onRequestShizukuPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val commandLogs: List<CommandLogEntry> by ShizukuShellExecutor.logs.collectAsState()

    var showSetupHelpDialog by remember { mutableStateOf(false) }
    var uptimeInfo by remember { mutableStateOf<DeviceUptimeInfo?>(null) }

    LaunchedEffect(Unit) {
        uptimeInfo = UptimeHelper.getDeviceUptime()
    }

    // Memory Info
    val memInfo = remember {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val memoryInfo = ActivityManager.MemoryInfo()
        am.getMemoryInfo(memoryInfo)
        val totalGb = memoryInfo.totalMem / (1024 * 1024 * 1024.0)
        val availGb = memoryInfo.availMem / (1024 * 1024 * 1024.0)
        val usedGb = totalGb - availGb
        Triple(totalGb, usedGb, availGb)
    }

    // Battery Info
    val batteryInfo = remember {
        val batteryStatus: Intent? = IntentFilter(Intent.ACTION_BATTERY_CHANGED).let { filter ->
            context.registerReceiver(null, filter)
        }
        val level: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val tempRaw: Int = batteryStatus?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0
        val tempC = tempRaw / 10.0
        val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else 0
        Pair(batteryPct, tempC)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. SHIZUKU CONNECTION STATE CARD
        item {
            VoltGlassCard(
                isActive = shizukuState is ShizukuState.Ready,
                isWarning = shizukuState !is ShizukuState.Ready,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (shizukuState) {
                                            is ShizukuState.Ready -> VoltGreen
                                            is ShizukuState.PermissionDenied -> VoltOrange
                                            is ShizukuState.VersionWarning -> VoltOrange
                                            else -> VoltRed
                                        }
                                    )
                            )
                            Text(
                                text = "SHIZUKU ADB BRIDGE",
                                fontSize = 12.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = VoltTextPrimary
                            )
                        }

                        Text(
                            text = when (shizukuState) {
                                is ShizukuState.Ready -> "CONNECTED"
                                is ShizukuState.PermissionDenied -> "PERMISSION REQUIRED"
                                is ShizukuState.VersionWarning -> "VERSION WARNING"
                                is ShizukuState.NotRunning -> "SERVICE STOPPED"
                                is ShizukuState.NotInstalled -> "NOT INSTALLED"
                            },
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = when (shizukuState) {
                                is ShizukuState.Ready -> VoltGreen
                                is ShizukuState.PermissionDenied -> VoltOrange
                                is ShizukuState.VersionWarning -> VoltOrange
                                else -> VoltRed
                            }
                        )
                    }

                    when (shizukuState) {
                        is ShizukuState.Ready -> {
                            Text(
                                text = "ADB privileged binder is active (v${shizukuState.version}, UID: ${shizukuState.uid}). System tweaks execute seamlessly without root.",
                                fontSize = 12.sp,
                                color = VoltTextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                        is ShizukuState.PermissionDenied -> {
                            Text(
                                text = "Shizuku service is active, but permission has not been granted to Volt Turbo. Tap 'Grant Permission' below.",
                                fontSize = 12.sp,
                                color = VoltTextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                        is ShizukuState.VersionWarning -> {
                            Text(
                                text = "Shizuku version v${shizukuState.version} detected. Recommend updating to v11+ for full feature compatibility.",
                                fontSize = 12.sp,
                                color = VoltTextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                        else -> {
                            Text(
                                text = "Shizuku enables ADB-level shell commands without root or a PC cable. Start the Shizuku app or launch via wireless debugging.",
                                fontSize = 12.sp,
                                color = VoltTextSecondary,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    // Shizuku Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (shizukuState is ShizukuState.PermissionDenied) {
                            Button(
                                onClick = onRequestShizukuPermission,
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = VoltCyan,
                                    contentColor = Color.Black
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f).testTag("grant_shizuku_permission_button")
                            ) {
                                Text("GRANT PERMISSION", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                            }
                        } else if (shizukuState !is ShizukuState.Ready) {
                            Button(
                                onClick = {
                                    ShizukuStateRepository.checkState(context)
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = VoltViolet,
                                    contentColor = VoltTextPrimary
                                ),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(imageVector = Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("RETRY DETECT", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                            }
                        }

                        OutlinedButton(
                            onClick = { showSetupHelpDialog = true },
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(imageVector = Icons.Default.HelpOutline, contentDescription = null, tint = VoltCyan, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SETUP GUIDE", color = VoltCyan, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // 2. HARDWARE & SYSTEM TELEMETRY CARD
        item {
            VoltGlassCard(modifier = Modifier.fillMaxWidth()) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Devices, contentDescription = null, tint = VoltCyan, modifier = Modifier.size(18.dp))
                        Text(
                            text = "SYSTEM TELEMETRY",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = VoltCyan
                        )
                    }

                    // Grid specs
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TelemetryItem(
                            label = "DEVICE",
                            value = "${Build.MANUFACTURER.uppercase()} ${Build.MODEL}",
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryItem(
                            label = "ANDROID",
                            value = "v${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TelemetryItem(
                            label = "RAM USAGE",
                            value = "${String.format("%.1f", memInfo.second)} / ${String.format("%.1f", memInfo.first)} GB",
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryItem(
                            label = "BATTERY TEMP",
                            value = "${batteryInfo.first}% (${batteryInfo.second}°C)",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 3. APP ANIMATIONS PREFERENCE CARD (PART 7 MANDATE)
        item {
            VoltGlassCard(
                isActive = animationsEnabled,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0xFF1E1E2C)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Animation,
                                contentDescription = null,
                                tint = if (animationsEnabled) VoltCyan else VoltTextSecondary,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Column {
                            Text(
                                text = "App Visual Animations",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = VoltTextPrimary
                            )
                            Text(
                                text = if (animationsEnabled) "Smooth transitions and glowing borders enabled." else "Instant zero-animation mode active (saves CPU/RAM).",
                                fontSize = 11.sp,
                                color = VoltTextSecondary
                            )
                        }
                    }

                    Switch(
                        checked = animationsEnabled,
                        onCheckedChange = onToggleAnimations,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = VoltCyan,
                            checkedTrackColor = Color(0xFF003844)
                        ),
                        modifier = Modifier.testTag("app_animations_toggle_switch")
                    )
                }
            }
        }

        // 4. COMMAND EXECUTION TERMINAL LOG
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(imageVector = Icons.Default.Terminal, contentDescription = null, tint = VoltViolet, modifier = Modifier.size(18.dp))
                    Text(
                        text = "COMMAND EXECUTION LOG",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = VoltViolet
                    )
                }

                IconButton(
                    onClick = { ShizukuShellExecutor.clearLogs() },
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(imageVector = Icons.Default.ClearAll, contentDescription = "Clear logs", tint = VoltTextTertiary, modifier = Modifier.size(16.dp))
                }
            }
        }

        if (commandLogs.isEmpty()) {
            item {
                VoltGlassCard(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = "No shell commands executed yet in this session. Toggles and optimizations will log here in real time.",
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        color = VoltTextSecondary
                    )
                }
            }
        } else {
            items(commandLogs, key = { it.id }) { entry ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF101018))
                        .border(1.dp, if (entry.isSuccess) Color(0xFF223328) else Color(0xFF442222), RoundedCornerShape(8.dp))
                        .padding(10.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "$ ${entry.command}",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold,
                                color = if (entry.isSuccess) VoltCyan else VoltRed,
                                modifier = Modifier.weight(1f)
                            )

                            Text(
                                text = if (entry.isSuccess) "EXIT 0" else "EXIT ${entry.exitCode}",
                                fontSize = 9.sp,
                                fontFamily = FontFamily.Monospace,
                                color = if (entry.isSuccess) VoltGreen else VoltRed
                            )
                        }

                        if (entry.stdout.isNotBlank()) {
                            Text(
                                text = entry.stdout.trim(),
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = VoltTextSecondary
                            )
                        }
                        if (entry.stderr.isNotBlank()) {
                            Text(
                                text = "ERR: ${entry.stderr.trim()}",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = VoltRed
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Setup Guide Dialog
    if (showSetupHelpDialog) {
        AlertDialog(
            onDismissRequest = { showSetupHelpDialog = false },
            containerColor = Color(0xFF141422),
            title = {
                Text(
                    text = "Shizuku ADB Setup Guide",
                    fontWeight = FontWeight.Bold,
                    color = VoltCyan,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 16.sp
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "1. Install the official Shizuku app (from GitHub or Google Play).",
                        fontSize = 12.sp,
                        color = VoltTextPrimary
                    )
                    Text(
                        text = "2. Enable Developer Options & Wireless Debugging on your device.",
                        fontSize = 12.sp,
                        color = VoltTextPrimary
                    )
                    Text(
                        text = "3. Pair & start Shizuku directly via Wireless Debugging on device, OR run this ADB command from a PC:",
                        fontSize = 12.sp,
                        color = VoltTextPrimary
                    )

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFF0C0C14))
                            .border(1.dp, VoltBorderCyan, RoundedCornerShape(6.dp))
                            .clickable {
                                clipboardManager.setText(
                                    AnnotatedString("adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh")
                                )
                                Toast.makeText(context, "Command copied to clipboard!", Toast.LENGTH_SHORT).show()
                            }
                            .padding(8.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "adb shell sh /sdcard/Android/data/moe.shizuku.privileged.api/start.sh",
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace,
                                color = VoltCyan
                            )
                            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = VoltCyan, modifier = Modifier.size(16.dp))
                        }
                    }

                    Text(
                        text = "4. Open Volt Turbo and grant Shizuku binder permission.",
                        fontSize = 12.sp,
                        color = VoltTextPrimary
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = { showSetupHelpDialog = false }) {
                    Text("CLOSE", color = VoltCyan, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            }
        )
    }
}

@Composable
private fun TelemetryItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFF161626))
            .border(1.dp, VoltBorder, RoundedCornerShape(8.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(
                text = label,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                color = VoltTextSecondary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = value,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = VoltTextPrimary
            )
        }
    }
}
