package com.example.ui.viewmodel

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.ActiveSessionInfo
import com.example.data.model.GameItem
import com.example.data.model.InstalledAppInfo
import com.example.data.model.SystemToggle
import com.example.data.repository.GamesRepository
import com.example.data.repository.SettingsRepository
import com.example.data.repository.TogglesRepository
import com.example.service.GameSessionService
import com.example.shizuku.ShizukuState
import com.example.shizuku.ShizukuStateRepository
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class VoltMainViewModel(application: Application) : AndroidViewModel(application) {

    private val context: Context get() = getApplication<Application>().applicationContext

    val shizukuState: StateFlow<ShizukuState> = ShizukuStateRepository.state

    private val togglesRepo = TogglesRepository(context)
    val toggles: StateFlow<List<SystemToggle>> = togglesRepo.togglesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val gamesRepo = GamesRepository(context)
    val games: StateFlow<List<GameItem>> = gamesRepo.gamesFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val settingsRepo = SettingsRepository(context)
    val appAnimationsEnabled: StateFlow<Boolean> = settingsRepo.appAnimationsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), true)

    val activeSessionState: StateFlow<ActiveSessionInfo?> = GameSessionService.sessionState

    init {
        ShizukuStateRepository.init(context)
    }

    fun toggleSystemSetting(toggleId: String, enabled: Boolean) {
        viewModelScope.launch {
            togglesRepo.setToggleEnabled(toggleId, enabled)
        }
    }

    fun applyPreset(preset: String) {
        viewModelScope.launch {
            togglesRepo.applyPreset(preset)
        }
    }

    fun setAppAnimationsEnabled(enabled: Boolean) {
        viewModelScope.launch {
            settingsRepo.setAppAnimationsEnabled(enabled)
        }
    }

    fun addGame(game: GameItem) {
        viewModelScope.launch {
            gamesRepo.addGame(game)
        }
    }

    fun removeGame(packageName: String) {
        viewModelScope.launch {
            gamesRepo.removeGame(packageName)
        }
    }

    fun markGameOptimized(packageName: String) {
        viewModelScope.launch {
            gamesRepo.setGameOptimized(packageName, true)
        }
    }

    suspend fun scanInstalledApps(): List<InstalledAppInfo> {
        return gamesRepo.scanInstalledApps()
    }

    fun launchGameWithOptimizations(game: GameItem) {
        viewModelScope.launch {
            gamesRepo.updateLastPlayed(game.packageName)

            // Start Foreground Session Service
            GameSessionService.startSession(context, game.packageName, game.name)

            // Launch target application intent
            val pm = context.packageManager
            val launchIntent = pm.getLaunchIntentForPackage(game.packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
            } else {
                Toast.makeText(context, "Launched Volt Turbo session for ${game.name}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun restoreSessionAndResetToggles() {
        viewModelScope.launch {
            GameSessionService.restoreAndStop(context)
            Toast.makeText(context, "All system tweaks restored to default state!", Toast.LENGTH_SHORT).show()
        }
    }

    fun requestShizukuPermission(activity: Activity) {
        ShizukuStateRepository.requestPermission(activity)
    }
}
