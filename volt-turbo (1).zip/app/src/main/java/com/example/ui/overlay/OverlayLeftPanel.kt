package com.example.ui.overlay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.ScreenRotation
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shizuku.ShizukuShellExecutor
import com.example.ui.theme.VoltBackgroundDark
import com.example.ui.theme.VoltBorderCyan
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltGreen
import com.example.ui.theme.VoltOrange
import com.example.ui.theme.VoltRed
import com.example.ui.theme.VoltSurfaceGlass
import com.example.ui.theme.VoltTextPrimary
import com.example.ui.theme.VoltTextSecondary
import com.example.ui.theme.VoltViolet
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

@Composable
fun OverlayLeftPanel(
    sessionStartTime: Long,
    onClose: () -> Unit,
    onRestoreAndExit: () -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()
    val fps by FpsTracker.fps.collectAsState()

    var elapsedSeconds by remember { mutableLongStateOf(0L) }
    LaunchedEffect(sessionStartTime) {
        while (isActive) {
            elapsedSeconds = (System.currentTimeMillis() - sessionStartTime) / 1000L
            delay(1000)
        }
    }

    val formattedTime = remember(elapsedSeconds) {
        val hrs = elapsedSeconds / 3600
        val mins = (elapsedSeconds % 3600) / 60
        val secs = elapsedSeconds % 60
        if (hrs > 0) {
            String.format("%02d:%02d:%02d", hrs, mins, secs)
        } else {
            String.format("%02d:%02d", mins, secs)
        }
    }

    var dndEnabled by remember { mutableStateOf(true) }
    var rotationLockEnabled by remember { mutableStateOf(false) }
    var wifiEnabled by remember { mutableStateOf(true) }
    var timeoutExtended by remember { mutableStateOf(true) }

    Box(
        modifier = modifier
            .width(260.dp)
            .clip(RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp))
            .background(
                Brush.horizontalGradient(
                    colors = listOf(VoltSurfaceGlass, VoltBackgroundDark)
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(listOf(VoltBorderCyan, VoltViolet)),
                shape = RoundedCornerShape(topEnd = 16.dp, bottomEnd = 16.dp)
            )
            .padding(14.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(VoltGreen)
                    )
                    Text(
                        text = "VOLT HUD",
                        fontWeight = FontWeight.Black,
                        color = VoltCyan,
                        fontSize = 14.sp,
                        letterSpacing = 1.sp
                    )
                }

                IconButton(
                    onClick = onClose,
                    modifier = Modifier.size(28.dp).testTag("close_left_panel")
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close HUD",
                        tint = VoltTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Real-Time FPS & Session Duration Readouts
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                // FPS Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF181826))
                        .border(1.dp, Color(0xFF2C2C44), RoundedCornerShape(8.dp))
                        .padding(vertical = 8.dp, horizontal = 10.dp)
                ) {
                    Column {
                        Text(
                            text = "EST. FPS",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = VoltTextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.Bottom) {
                            Text(
                                text = "$fps",
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold,
                                fontFamily = FontFamily.Monospace,
                                color = if (fps >= 55) VoltGreen else if (fps >= 30) VoltOrange else VoltRed
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "Hz",
                                fontSize = 10.sp,
                                color = VoltTextSecondary,
                                modifier = Modifier.padding(bottom = 2.dp)
                            )
                        }
                    }
                }

                // Session Duration Card
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF181826))
                        .border(1.dp, Color(0xFF2C2C44), RoundedCornerShape(8.dp))
                        .padding(vertical = 8.dp, horizontal = 10.dp)
                ) {
                    Column {
                        Text(
                            text = "SESSION",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            color = VoltTextSecondary
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = formattedTime,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = VoltCyan
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "QUICK TOGGLES",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace,
                color = VoltTextSecondary,
                letterSpacing = 0.5.sp
            )

            // Quick Switches List
            QuickToggleRow(
                icon = Icons.Default.DoNotDisturbOn,
                title = "Do Not Disturb",
                checked = dndEnabled,
                onCheckedChange = { checked ->
                    dndEnabled = checked
                    coroutineScope.launch {
                        ShizukuShellExecutor.execute(
                            if (checked) "cmd notification set_dnd on" else "cmd notification set_dnd off"
                        )
                    }
                }
            )

            QuickToggleRow(
                icon = Icons.Default.ScreenRotation,
                title = "Lock Rotation",
                checked = rotationLockEnabled,
                onCheckedChange = { checked ->
                    rotationLockEnabled = checked
                    coroutineScope.launch {
                        ShizukuShellExecutor.execute(
                            if (checked) "settings put system accelerometer_rotation 0" else "settings put system accelerometer_rotation 1"
                        )
                    }
                }
            )

            QuickToggleRow(
                icon = Icons.Default.Wifi,
                title = "WiFi Radio",
                checked = wifiEnabled,
                onCheckedChange = { checked ->
                    wifiEnabled = checked
                    coroutineScope.launch {
                        ShizukuShellExecutor.execute(
                            if (checked) "settings put global wifi_on 1" else "settings put global wifi_on 0"
                        )
                    }
                }
            )

            QuickToggleRow(
                icon = Icons.Default.Timer,
                title = "Keep Screen On",
                checked = timeoutExtended,
                onCheckedChange = { checked ->
                    timeoutExtended = checked
                    coroutineScope.launch {
                        ShizukuShellExecutor.execute(
                            if (checked) "settings put system screen_off_timeout 1800000" else "settings put system screen_off_timeout 60000"
                        )
                    }
                }
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Restore & Exit Button
            Button(
                onClick = onRestoreAndExit,
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF3B101E),
                    contentColor = VoltRed
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0x66FF1744), RoundedCornerShape(8.dp))
                    .testTag("restore_exit_button")
            ) {
                Icon(
                    imageVector = Icons.Default.PowerSettingsNew,
                    contentDescription = "Restore & Exit",
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "RESTORE & EXIT",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
private fun QuickToggleRow(
    icon: ImageVector,
    title: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF161624))
            .padding(horizontal = 8.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (checked) VoltCyan else VoltTextSecondary,
                modifier = Modifier.size(16.dp)
            )
            Text(
                text = title,
                fontSize = 11.sp,
                color = VoltTextPrimary
            )
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = VoltCyan,
                checkedTrackColor = Color(0xFF003844),
                uncheckedThumbColor = VoltTextSecondary,
                uncheckedTrackColor = Color(0xFF222230)
            ),
            modifier = Modifier.size(width = 38.dp, height = 22.dp)
        )
    }
}
