package com.example.ui.overlay

import android.view.Choreographer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

object FpsTracker {
    private var isTracking = false
    private var lastFrameTimeNanos: Long = 0
    private var frameCount = 0
    private var lastSampleTimeMs = 0L

    private val _fps = MutableStateFlow(60)
    val fps: StateFlow<Int> = _fps.asStateFlow()

    private val frameCallback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!isTracking) return

            if (lastFrameTimeNanos > 0) {
                val deltaMs = (frameTimeNanos - lastFrameTimeNanos) / 1_000_000.0
                frameCount++

                val currentTimeMs = System.currentTimeMillis()
                if (currentTimeMs - lastSampleTimeMs >= 500) {
                    val timeSpanSec = (currentTimeMs - lastSampleTimeMs) / 1000.0
                    val calculatedFps = (frameCount / timeSpanSec).toInt().coerceIn(10, 144)
                    _fps.value = calculatedFps
                    frameCount = 0
                    lastSampleTimeMs = currentTimeMs
                }
            } else {
                lastSampleTimeMs = System.currentTimeMillis()
            }

            lastFrameTimeNanos = frameTimeNanos
            if (isTracking) {
                Choreographer.getInstance().postFrameCallback(this)
            }
        }
    }

    fun startTracking() {
        if (isTracking) return
        isTracking = true
        lastFrameTimeNanos = 0
        frameCount = 0
        lastSampleTimeMs = System.currentTimeMillis()
        try {
            Choreographer.getInstance().postFrameCallback(frameCallback)
        } catch (e: Exception) {
            // Ignore if called off-main thread
        }
    }

    fun stopTracking() {
        isTracking = false
        try {
            Choreographer.getInstance().removeFrameCallback(frameCallback)
        } catch (e: Exception) {
            // Ignore
        }
    }
}
