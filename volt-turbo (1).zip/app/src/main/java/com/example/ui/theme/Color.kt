package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Volt Turbo Cyber Dark Palette
val VoltBackground = Color(0xFF0A0A0F)
val VoltBackgroundDark = Color(0xFF040406)
val VoltSurface = Color(0xFF13131D)
val VoltSurfaceElevated = Color(0xFF1B1B2A)
val VoltSurfaceGlass = Color(0xD8131320)
val VoltSurfaceGlassHighlight = Color(0x227C4DFF)

// Dual Accent Colors
val VoltViolet = Color(0xFF7C4DFF)
val VoltVioletLight = Color(0xFFB388FF)
val VoltVioletDark = Color(0xFF651FFF)
val VoltCyan = Color(0xFF00E5FF)
val VoltCyanLight = Color(0xFF84FFFF)
val VoltCyanDark = Color(0xFF00B0FF)

// High Impact / Warning Accents
val VoltOrange = Color(0xFFFF9100)
val VoltOrangeGlow = Color(0x33FF9100)
val VoltRed = Color(0xFFFF1744)
val VoltGreen = Color(0xFF00E676)
val VoltGreenGlow = Color(0x3300E676)

// Text Colors
val VoltTextPrimary = Color(0xFFF0F0F8)
val VoltTextSecondary = Color(0xFFA0A0B8)
val VoltTextTertiary = Color(0xFF62627A)
val VoltBorder = Color(0xFF262638)
val VoltBorderBright = Color(0x557C4DFF)
val VoltBorderCyan = Color(0x5500E5FF)
