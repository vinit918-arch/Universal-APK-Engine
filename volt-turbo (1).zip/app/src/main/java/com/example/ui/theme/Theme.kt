package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf

private val VoltColorScheme = darkColorScheme(
    primary = VoltViolet,
    onPrimary = VoltTextPrimary,
    primaryContainer = VoltSurfaceElevated,
    onPrimaryContainer = VoltVioletLight,
    secondary = VoltCyan,
    onSecondary = VoltBackground,
    secondaryContainer = VoltSurfaceElevated,
    onSecondaryContainer = VoltCyanLight,
    tertiary = VoltOrange,
    onTertiary = VoltBackground,
    background = VoltBackground,
    onBackground = VoltTextPrimary,
    surface = VoltSurface,
    onSurface = VoltTextPrimary,
    surfaceVariant = VoltSurfaceElevated,
    onSurfaceVariant = VoltTextSecondary,
    outline = VoltBorder,
    outlineVariant = VoltBorderBright,
    error = VoltRed,
    onError = VoltTextPrimary
)

val LocalAppAnimationsEnabled = staticCompositionLocalOf { true }

@Composable
fun VoltTurboTheme(
    animationsEnabled: Boolean = true,
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(
        LocalAppAnimationsEnabled provides animationsEnabled
    ) {
        MaterialTheme(
            colorScheme = VoltColorScheme,
            typography = VoltTypography,
            content = content
        )
    }
}
