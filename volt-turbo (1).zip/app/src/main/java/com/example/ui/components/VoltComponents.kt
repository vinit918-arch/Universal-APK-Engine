package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.shizuku.ShizukuState
import com.example.ui.theme.LocalAppAnimationsEnabled
import com.example.ui.theme.VoltBackgroundDark
import com.example.ui.theme.VoltBorder
import com.example.ui.theme.VoltBorderCyan
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltGreen
import com.example.ui.theme.VoltOrange
import com.example.ui.theme.VoltRed
import com.example.ui.theme.VoltSurface
import com.example.ui.theme.VoltSurfaceElevated
import com.example.ui.theme.VoltTextPrimary
import com.example.ui.theme.VoltTextSecondary
import com.example.ui.theme.VoltTextTertiary
import com.example.ui.theme.VoltViolet

@Composable
fun VoltGlassCard(
    modifier: Modifier = Modifier,
    isActive: Boolean = false,
    isWarning: Boolean = false,
    shape: RoundedCornerShape = RoundedCornerShape(14.dp),
    content: @Composable () -> Unit
) {
    val animsEnabled = LocalAppAnimationsEnabled.current

    val infiniteTransition = rememberInfiniteTransition(label = "border_pulse")
    val alphaAnim by if (animsEnabled && isActive) {
        infiniteTransition.animateFloat(
            initialValue = 0.35f,
            targetValue = 0.95f,
            animationSpec = infiniteRepeatable(
                animation = tween(1200, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse_alpha"
        )
    } else {
        remember { androidx.compose.runtime.mutableFloatStateOf(0.5f) }
    }

    val borderColor = when {
        isWarning && isActive -> VoltOrange.copy(alpha = alphaAnim)
        isWarning -> VoltOrange.copy(alpha = 0.4f)
        isActive -> VoltViolet.copy(alpha = alphaAnim)
        else -> VoltBorder
    }

    Box(
        modifier = modifier
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        if (isActive) Color(0xFF18182B) else VoltSurface,
                        if (isActive) Color(0xFF10101C) else VoltSurfaceElevated
                    )
                )
            )
            .border(
                width = if (isActive) 1.5.dp else 1.dp,
                color = borderColor,
                shape = shape
            )
            .padding(14.dp)
    ) {
        content()
    }
}

@Composable
fun PowerCoreLaunchButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 64.dp,
    label: String = "LAUNCH"
) {
    val animsEnabled = LocalAppAnimationsEnabled.current
    val infiniteTransition = rememberInfiniteTransition(label = "power_core")
    
    val ringPulse by if (animsEnabled) {
        infiniteTransition.animateFloat(
            initialValue = 0.85f,
            targetValue = 1.15f,
            animationSpec = infiniteRepeatable(
                animation = tween(1400, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
            ),
            label = "ring_pulse"
        )
    } else {
        remember { androidx.compose.runtime.mutableFloatStateOf(1f) }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = modifier
    ) {
        Box(
            modifier = Modifier
                .size(size)
                .clip(CircleShape)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick
                )
                .testTag("power_core_launch_button"),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(size)) {
                val cx = this.size.width / 2f
                val cy = this.size.height / 2f
                val maxRadius = this.size.width / 2f

                // Outer Glowing Ambient Ring
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(VoltCyan.copy(alpha = 0.4f * ringPulse), Color.Transparent),
                        center = Offset(cx, cy),
                        radius = maxRadius
                    ),
                    radius = maxRadius
                )

                // Middle Power Ring
                drawCircle(
                    color = VoltViolet,
                    radius = maxRadius * 0.82f,
                    style = Stroke(width = 2.dp.toPx())
                )

                // Inner Accent Core Ring
                drawCircle(
                    color = VoltCyan.copy(alpha = 0.8f),
                    radius = maxRadius * 0.65f,
                    style = Stroke(width = 1.5.dp.toPx())
                )

                // Core Solid Button
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(VoltViolet, Color(0xFF321268)),
                        center = Offset(cx, cy),
                        radius = maxRadius * 0.52f
                    ),
                    radius = maxRadius * 0.52f
                )
            }

            Icon(
                imageVector = Icons.Default.RocketLaunch,
                contentDescription = label,
                tint = VoltCyan,
                modifier = Modifier
                    .size(24.dp)
                    .scale(if (animsEnabled) ringPulse.coerceIn(0.95f, 1.08f) else 1f)
            )
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            color = VoltCyan,
            letterSpacing = 1.sp
        )
    }
}

@Composable
fun VoltTopHeader(
    shizukuState: ShizukuState,
    isSessionActive: Boolean,
    onRestoreAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(
                        Brush.linearGradient(listOf(VoltViolet, VoltCyan))
                    ),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Bolt,
                    contentDescription = null,
                    tint = VoltBackgroundDark,
                    modifier = Modifier.size(22.dp)
                )
            }

            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "VOLT",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = VoltTextPrimary,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "TURBO",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Black,
                        color = VoltCyan,
                        letterSpacing = 1.sp
                    )
                }

                Text(
                    text = "GAME PERFORMANCE SUITE",
                    fontSize = 8.sp,
                    fontFamily = FontFamily.Monospace,
                    color = VoltTextSecondary,
                    letterSpacing = 0.5.sp
                )
            }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = onRestoreAll,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isSessionActive) Color(0xFF3F1422) else Color(0xFF1E1E2C),
                    contentColor = if (isSessionActive) VoltRed else VoltTextSecondary
                ),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier
                    .border(
                        1.dp,
                        if (isSessionActive) VoltRed.copy(alpha = 0.6f) else VoltBorder,
                        RoundedCornerShape(8.dp)
                    )
                    .testTag("restore_all_top_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Restore All",
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isSessionActive) "RESTORE" else "RESET",
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

enum class VoltNavTab(val title: String, val icon: ImageVector) {
    TOGGLES("TOGGLES", Icons.Default.Tune),
    GAMES("GAMES", Icons.Default.SportsEsports),
    BOOST("BOOST", Icons.Default.RocketLaunch),
    STATUS("STATUS", Icons.Default.Info)
}

@Composable
fun VoltBottomBar(
    currentTab: VoltNavTab,
    onTabSelected: (VoltNavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        color = VoltBackgroundDark,
        tonalElevation = 8.dp,
        modifier = modifier
            .fillMaxWidth()
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(listOf(VoltBorder, Color.Transparent)),
                shape = RoundedCornerShape(0.dp)
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 8.dp, horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceAround,
            verticalAlignment = Alignment.CenterVertically
        ) {
            VoltNavTab.entries.forEach { tab ->
                val isSelected = currentTab == tab
                val animsEnabled = LocalAppAnimationsEnabled.current

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { onTabSelected(tab) }
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                        .testTag("nav_tab_${tab.name.lowercase()}"),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(3.dp)
                    ) {
                        Icon(
                            imageVector = tab.icon,
                            contentDescription = tab.title,
                            tint = if (isSelected) VoltCyan else VoltTextTertiary,
                            modifier = Modifier
                                .size(22.dp)
                                .scale(if (isSelected && animsEnabled) 1.1f else 1f)
                        )

                        Text(
                            text = tab.title,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) VoltCyan else VoltTextTertiary,
                            letterSpacing = 0.5.sp
                        )

                        if (isSelected) {
                            Box(
                                modifier = Modifier
                                    .size(width = 16.dp, height = 2.dp)
                                    .clip(RoundedCornerShape(1.dp))
                                    .background(VoltCyan)
                            )
                        } else {
                            Spacer(modifier = Modifier.height(2.dp))
                        }
                    }
                }
            }
        }
    }
}
