package com.example.ui.overlay

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.data.model.CrosshairConfig
import com.example.data.model.CrosshairStyle

@Composable
fun CrosshairCanvas(
    config: CrosshairConfig,
    modifier: Modifier = Modifier
) {
    val color = Color(config.colorHex).copy(alpha = config.opacity)
    val sizeDp = config.sizeDp.dp

    Canvas(modifier = modifier.size(sizeDp)) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f
        val strokeWidth = (w * 0.08f).coerceAtLeast(2f)

        when (config.style) {
            CrosshairStyle.DOT -> {
                drawCircle(
                    color = color,
                    radius = w * 0.22f,
                    center = Offset(cx, cy)
                )
            }
            CrosshairStyle.CROSS -> {
                drawLine(
                    color = color,
                    start = Offset(cx, 0f),
                    end = Offset(cx, h),
                    strokeWidth = strokeWidth
                )
                drawLine(
                    color = color,
                    start = Offset(0f, cy),
                    end = Offset(w, cy),
                    strokeWidth = strokeWidth
                )
            }
            CrosshairStyle.CIRCLE -> {
                drawCircle(
                    color = color,
                    radius = (w / 2f) - strokeWidth,
                    center = Offset(cx, cy),
                    style = Stroke(width = strokeWidth)
                )
            }
            CrosshairStyle.CIRCLE_DOT -> {
                drawCircle(
                    color = color,
                    radius = (w / 2f) - strokeWidth,
                    center = Offset(cx, cy),
                    style = Stroke(width = strokeWidth)
                )
                drawCircle(
                    color = color,
                    radius = w * 0.12f,
                    center = Offset(cx, cy)
                )
            }
            CrosshairStyle.CROSS_WITH_GAP -> {
                val gap = w * 0.2f
                // Top line
                drawLine(color, Offset(cx, 0f), Offset(cx, cy - gap), strokeWidth)
                // Bottom line
                drawLine(color, Offset(cx, cy + gap), Offset(cx, h), strokeWidth)
                // Left line
                drawLine(color, Offset(0f, cy), Offset(cx - gap, cy), strokeWidth)
                // Right line
                drawLine(color, Offset(cx + gap, cy), Offset(w, cy), strokeWidth)
                // Center dot
                drawCircle(color, strokeWidth * 0.75f, Offset(cx, cy))
            }
            CrosshairStyle.T_SHAPE -> {
                val gap = w * 0.15f
                // Bottom line
                drawLine(color, Offset(cx, cy + gap), Offset(cx, h), strokeWidth)
                // Left line
                drawLine(color, Offset(0f, cy), Offset(cx - gap, cy), strokeWidth)
                // Right line
                drawLine(color, Offset(cx + gap, cy), Offset(w, cy), strokeWidth)
                // Dot
                drawCircle(color, strokeWidth * 0.8f, Offset(cx, cy))
            }
            CrosshairStyle.SQUARE -> {
                val boxSize = w * 0.6f
                drawRect(
                    color = color,
                    topLeft = Offset((w - boxSize) / 2f, (h - boxSize) / 2f),
                    size = Size(boxSize, boxSize),
                    style = Stroke(width = strokeWidth)
                )
                drawCircle(color, strokeWidth * 0.75f, Offset(cx, cy))
            }
            CrosshairStyle.CHEVRON -> {
                val path = Path().apply {
                    moveTo(cx - w * 0.35f, cy + h * 0.2f)
                    lineTo(cx, cy - h * 0.2f)
                    lineTo(cx + w * 0.35f, cy + h * 0.2f)
                }
                drawPath(
                    path = path,
                    color = color,
                    style = Stroke(width = strokeWidth)
                )
                drawCircle(color, strokeWidth * 0.8f, Offset(cx, cy))
            }
        }
    }
}
