package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.BrightnessMedium
import androidx.compose.material.icons.filled.DoNotDisturbOn
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SyncDisabled
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material.icons.filled.WifiTetheringOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SystemToggle
import com.example.data.model.ToggleTier
import com.example.ui.components.VoltGlassCard
import com.example.ui.theme.VoltBackgroundDark
import com.example.ui.theme.VoltBorder
import com.example.ui.theme.VoltBorderBright
import com.example.ui.theme.VoltBorderCyan
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltGreen
import com.example.ui.theme.VoltOrange
import com.example.ui.theme.VoltRed
import com.example.ui.theme.VoltSurface
import com.example.ui.theme.VoltSurfaceElevated
import com.example.ui.theme.VoltTextPrimary
import com.example.ui.theme.VoltTextSecondary
import com.example.ui.theme.VoltTextTertiary
import com.example.ui.theme.VoltViolet

@Composable
fun TogglesScreen(
    toggles: List<SystemToggle>,
    onToggleChange: (String, Boolean) -> Unit,
    onApplyPreset: (String) -> Unit,
    animationsEnabled: Boolean,
    onToggleAnimations: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var dangerousTogglePending by remember { mutableStateOf<SystemToggle?>(null) }

    val tier1Toggles = remember(toggles) { toggles.filter { it.tier == ToggleTier.TIER_1_ESSENTIALS } }
    val tier2Toggles = remember(toggles) { toggles.filter { it.tier == ToggleTier.TIER_2_HIGH_IMPACT } }
    val activeCount = remember(toggles) { toggles.count { it.isEnabled } }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Top Overview Banner
        item {
            VoltGlassCard(
                isActive = activeCount > 0,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "SYSTEM TUNING ENGINE",
                                fontSize = 11.sp,
                                fontFamily = FontFamily.Monospace,
                                color = VoltCyan,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "$activeCount / ${toggles.size} Tweaks Armed",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = VoltTextPrimary
                            )
                        }

                        // Presets Row
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            PresetChip(
                                label = "MAX",
                                onClick = { onApplyPreset("max_performance") }
                            )
                            PresetChip(
                                label = "BALANCED",
                                onClick = { onApplyPreset("balanced") }
                            )
                            PresetChip(
                                label = "RESET",
                                onClick = { onApplyPreset("reset") }
                            )
                        }
                    }

                    Text(
                        text = "Armed tweaks apply automatically on game launch via Shizuku ADB and auto-revert upon exit.",
                        fontSize = 12.sp,
                        color = VoltTextSecondary,
                        lineHeight = 16.sp
                    )
                }
            }
        }

        // TIER 1 SECTION: Essentials
        item {
            SectionHeader(
                title = "TIER 1 — ESSENTIALS",
                subtitle = "Safe, always-recommended tweaks with zero risk",
                accentColor = VoltCyan
            )
        }

        items(tier1Toggles, key = { it.id }) { toggle ->
            ToggleItemCard(
                toggle = toggle,
                onCheckedChange = { checked ->
                    onToggleChange(toggle.id, checked)
                }
            )
        }

        // TIER 2 SECTION: High Impact
        item {
            Spacer(modifier = Modifier.height(6.dp))
            SectionHeader(
                title = "TIER 2 — HIGH IMPACT",
                subtitle = "Aggressive power & kernel governors (Orange Warning)",
                accentColor = VoltOrange,
                isWarning = true
            )
        }

        items(tier2Toggles, key = { it.id }) { toggle ->
            ToggleItemCard(
                toggle = toggle,
                isWarningAccent = true,
                onCheckedChange = { checked ->
                    if (checked && toggle.isDangerous) {
                        dangerousTogglePending = toggle
                    } else {
                        onToggleChange(toggle.id, checked)
                    }
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Confirmation Dialog for Dangerous Toggle (Override Thermal Throttling)
    dangerousTogglePending?.let { toggle ->
        AlertDialog(
            onDismissRequest = { dangerousTogglePending = null },
            containerColor = Color(0xFF1E141E),
            icon = {
                Icon(
                    imageVector = Icons.Default.Warning,
                    contentDescription = null,
                    tint = VoltOrange,
                    modifier = Modifier.size(32.dp)
                )
            },
            title = {
                Text(
                    text = "Thermal Override Warning",
                    fontWeight = FontWeight.Bold,
                    color = VoltTextPrimary
                )
            },
            text = {
                Text(
                    text = toggle.warningMessage ?: "Disables thermal throttling protection. Only use with active external cooling. Continue?",
                    color = VoltTextSecondary,
                    fontSize = 13.sp,
                    lineHeight = 18.sp
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onToggleChange(toggle.id, true)
                        dangerousTogglePending = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = VoltOrange,
                        contentColor = Color.Black
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text("ARM OVERRIDE", fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { dangerousTogglePending = null }
                ) {
                    Text("CANCEL", color = VoltTextSecondary)
                }
            }
        )
    }
}

@Composable
private fun SectionHeader(
    title: String,
    subtitle: String,
    accentColor: Color,
    isWarning: Boolean = false
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
    ) {
        Box(
            modifier = Modifier
                .size(width = 4.dp, height = 24.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(accentColor)
        )
        Column {
            Text(
                text = title,
                fontSize = 13.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = accentColor,
                letterSpacing = 0.5.sp
            )
            Text(
                text = subtitle,
                fontSize = 11.sp,
                color = VoltTextSecondary
            )
        }
    }
}

@Composable
private fun ToggleItemCard(
    toggle: SystemToggle,
    isWarningAccent: Boolean = false,
    onCheckedChange: (Boolean) -> Unit
) {
    val icon = getIconForToggle(toggle.iconName)

    VoltGlassCard(
        isActive = toggle.isEnabled,
        isWarning = isWarningAccent,
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(
                            if (toggle.isEnabled) {
                                if (isWarningAccent) Color(0x33FF9100) else Color(0x337C4DFF)
                            } else {
                                Color(0xFF1E1E2C)
                            }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = toggle.name,
                        tint = if (toggle.isEnabled) {
                            if (isWarningAccent) VoltOrange else VoltCyan
                        } else {
                            VoltTextSecondary
                        },
                        modifier = Modifier.size(20.dp)
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = toggle.name,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = VoltTextPrimary
                        )
                        if (toggle.isDangerous) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0x33FF1744))
                                    .border(1.dp, VoltRed, RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "HIGH HEAT",
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = VoltRed,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = toggle.description,
                        fontSize = 12.sp,
                        color = VoltTextSecondary,
                        lineHeight = 16.sp
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "$ ${toggle.applyCommand}",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        color = VoltTextTertiary
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Switch(
                checked = toggle.isEnabled,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = if (isWarningAccent) VoltOrange else VoltCyan,
                    checkedTrackColor = if (isWarningAccent) Color(0xFF4A2B00) else Color(0xFF003844),
                    uncheckedThumbColor = VoltTextSecondary,
                    uncheckedTrackColor = Color(0xFF222230)
                ),
                modifier = Modifier.testTag("switch_${toggle.id}")
            )
        }
    }
}

@Composable
private fun PresetChip(
    label: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF1E1E2C))
            .border(1.dp, VoltBorder, RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            color = VoltCyan
        )
    }
}

private fun getIconForToggle(name: String): ImageVector {
    return when (name) {
        "sync_disabled" -> Icons.Default.SyncDisabled
        "do_not_disturb_on" -> Icons.Default.DoNotDisturbOn
        "brightness_medium" -> Icons.Default.BrightnessMedium
        "bluetooth_disabled" -> Icons.Default.BluetoothDisabled
        "wifi_tethering_off" -> Icons.Default.WifiTetheringOff
        "timer" -> Icons.Default.Timer
        "vibration" -> Icons.Default.Vibration
        "speed" -> Icons.Default.Speed
        "battery_charging_full" -> Icons.Default.BatteryChargingFull
        "flash_on" -> Icons.Default.FlashOn
        "power_settings_new" -> Icons.Default.PowerSettingsNew
        "memory" -> Icons.Default.Memory
        "touch_app" -> Icons.Default.TouchApp
        "whatshot" -> Icons.Default.Whatshot
        else -> Icons.Default.FlashOn
    }
}
