package com.example

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import com.example.service.FloatingControlService
import com.example.service.GameOverlayService
import com.example.service.GameSessionService
import com.example.shizuku.ShizukuStateRepository

class VoltApplication : Application() {

    companion object {
        private const val TAG = "VoltApplication"
        lateinit var instance: VoltApplication
            private set
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        createNotificationChannels()
        initializeShizuku()
    }

    private fun initializeShizuku() {
        try {
            ShizukuStateRepository.init(this)
            Log.d(TAG, "ShizukuStateRepository initialized successfully")
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to initialize ShizukuStateRepository", e)
        }
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

            val channels = listOf(
                NotificationChannel(
                    FloatingControlService.CHANNEL_ID,
                    "Volt Auto Clicker Overlay",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Foreground notification for floating auto-clicker overlay controls"
                    setShowBadge(false)
                },
                NotificationChannel(
                    GameSessionService.CHANNEL_ID,
                    "Volt Game Optimization",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Foreground notification for active game performance optimization sessions"
                    setShowBadge(false)
                },
                NotificationChannel(
                    GameOverlayService.OVERLAY_CHANNEL_ID,
                    "Volt Gaming HUD",
                    NotificationManager.IMPORTANCE_LOW
                ).apply {
                    description = "Foreground notification for in-game HUD and crosshair overlay"
                    setShowBadge(false)
                }
            )

            channels.forEach { channel ->
                try {
                    notificationManager.createNotificationChannel(channel)
                } catch (e: Throwable) {
                    Log.e(TAG, "Failed to create notification channel ${channel.id}", e)
                }
            }
        }
    }
}
