package com.example.shizuku

import android.util.Log
import com.example.data.model.AutoClickConfig
import com.example.data.model.ClickStats
import com.example.data.model.ClickerMode
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedWriter
import java.io.OutputStreamWriter
import java.lang.reflect.Method
import kotlin.random.Random

object ShizukuTouchEngine {
    private const val TAG = "VoltTouchEngine"

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var clickLoopJob: Job? = null

    private val _stats = MutableStateFlow(ClickStats())
    val stats: StateFlow<ClickStats> = _stats.asStateFlow()

    private var activeShProcess: Process? = null
    private var shellWriter: BufferedWriter? = null
    private var newProcessMethod: Method? = null

    init {
        try {
            val methods = Shizuku::class.java.declaredMethods
            for (m in methods) {
                if (m.name == "newProcess" && m.parameterTypes.size == 3) {
                    m.isAccessible = true
                    newProcessMethod = m
                    break
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Could not reflect Shizuku.newProcess: ${e.message}")
        }
    }

    /**
     * Initializes or gets a high-performance interactive shell process
     */
    private fun getOrCreateShell(): BufferedWriter? {
        if (shellWriter != null && activeShProcess?.isAlive == true) {
            return shellWriter
        }

        try {
            closeShell()
            val isBinderAlive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }

            val process = if (isBinderAlive && newProcessMethod != null) {
                newProcessMethod!!.invoke(null, arrayOf("sh"), null, null) as Process
            } else {
                Runtime.getRuntime().exec("sh")
            }

            activeShProcess = process
            shellWriter = BufferedWriter(OutputStreamWriter(process.outputStream))
            Log.d(TAG, "Persistent shell process established successfully.")
            return shellWriter
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to start shell process", e)
            return null
        }
    }

    private fun closeShell() {
        try {
            shellWriter?.write("exit\n")
            shellWriter?.flush()
            shellWriter?.close()
        } catch (_: Throwable) {}
        shellWriter = null

        try {
            activeShProcess?.destroy()
        } catch (_: Throwable) {}
        activeShProcess = null
    }

    /**
     * Performs a single tap at (x, y) coordinates.
     */
    suspend fun performSingleTap(x: Int, y: Int): Boolean = withContext(Dispatchers.IO) {
        val writer = getOrCreateShell()
        if (writer != null) {
            try {
                writer.write("input tap $x $y\n")
                writer.flush()
                return@withContext true
            } catch (e: Throwable) {
                Log.e(TAG, "Error writing tap to shell, recreating shell", e)
                closeShell()
            }
        }

        // Fallback to one-shot execution
        val result = ShizukuShellExecutor.execute("input tap $x $y")
        return@withContext result.isSuccess
    }

    /**
     * Performs a swipe gesture.
     */
    suspend fun performSwipe(
        x1: Int,
        y1: Int,
        x2: Int,
        y2: Int,
        durationMs: Long = 300L
    ): Boolean = withContext(Dispatchers.IO) {
        val cmd = "input swipe $x1 $y1 $x2 $y2 $durationMs"
        val writer = getOrCreateShell()
        if (writer != null) {
            try {
                writer.write("$cmd\n")
                writer.flush()
                return@withContext true
            } catch (e: Throwable) {
                Log.e(TAG, "Error writing swipe to shell", e)
                closeShell()
            }
        }
        val result = ShizukuShellExecutor.execute(cmd)
        return@withContext result.isSuccess
    }

    /**
     * Starts the auto-clicking loop in a dedicated background coroutine.
     */
    fun startClickLoop(config: AutoClickConfig) {
        if (_stats.value.isRunning) {
            stopClickLoop()
        }

        clickLoopJob = engineScope.launch {
            _stats.value = ClickStats(
                isRunning = true,
                totalClicks = 0,
                currentCps = 0.0,
                elapsedTimeMs = 0
            )

            val startTime = System.currentTimeMillis()
            var clickCount = 0L
            var lastCpsCalcTime = startTime
            var clicksInWindow = 0L

            try {
                when (config.mode) {
                    ClickerMode.SINGLE_POINT -> {
                        val basePt = config.singlePoint
                        while (isActive) {
                            if (config.repeatCount in 1..clickCount) {
                                break
                            }

                            val targetX = if (config.jitterRadiusPx > 0) {
                                basePt.x + Random.nextInt(-config.jitterRadiusPx, config.jitterRadiusPx + 1)
                            } else basePt.x

                            val targetY = if (config.jitterRadiusPx > 0) {
                                basePt.y + Random.nextInt(-config.jitterRadiusPx, config.jitterRadiusPx + 1)
                            } else basePt.y

                            // Execute touch
                            performSingleTap(targetX, targetY)

                            clickCount++
                            clicksInWindow++

                            val now = System.currentTimeMillis()
                            val elapsed = now - startTime
                            val windowElapsed = now - lastCpsCalcTime

                            var currentCps = _stats.value.currentCps
                            if (windowElapsed >= 500) {
                                currentCps = (clicksInWindow * 1000.0) / windowElapsed
                                lastCpsCalcTime = now
                                clicksInWindow = 0
                            }

                            _stats.value = _stats.value.copy(
                                totalClicks = clickCount,
                                currentCps = currentCps,
                                elapsedTimeMs = elapsed,
                                lastClickX = targetX,
                                lastClickY = targetY,
                                activePointIndex = 0
                            )

                            // Compute interval with optional random delay
                            val delayMs = config.intervalMs + if (config.randomDelayMs > 0) {
                                Random.nextLong(0, config.randomDelayMs + 1)
                            } else 0L

                            if (delayMs > 0) {
                                delay(delayMs.coerceAtLeast(1L))
                            }
                        }
                    }

                    ClickerMode.MULTI_POINT -> {
                        val points = config.multiPoints.ifEmpty { listOf(config.singlePoint) }
                        var pointIndex = 0

                        while (isActive) {
                            if (config.repeatCount in 1..clickCount) {
                                break
                            }

                            val pt = points[pointIndex % points.size]
                            val targetX = if (config.jitterRadiusPx > 0) {
                                pt.x + Random.nextInt(-config.jitterRadiusPx, config.jitterRadiusPx + 1)
                            } else pt.x

                            val targetY = if (config.jitterRadiusPx > 0) {
                                pt.y + Random.nextInt(-config.jitterRadiusPx, config.jitterRadiusPx + 1)
                            } else pt.y

                            performSingleTap(targetX, targetY)

                            clickCount++
                            clicksInWindow++

                            val now = System.currentTimeMillis()
                            val elapsed = now - startTime
                            val windowElapsed = now - lastCpsCalcTime

                            var currentCps = _stats.value.currentCps
                            if (windowElapsed >= 500) {
                                currentCps = (clicksInWindow * 1000.0) / windowElapsed
                                lastCpsCalcTime = now
                                clicksInWindow = 0
                            }

                            _stats.value = _stats.value.copy(
                                totalClicks = clickCount,
                                currentCps = currentCps,
                                elapsedTimeMs = elapsed,
                                lastClickX = targetX,
                                lastClickY = targetY,
                                activePointIndex = pointIndex % points.size
                            )

                            val delayMs = pt.delayAfterMs.coerceAtLeast(config.intervalMs) + if (config.randomDelayMs > 0) {
                                Random.nextLong(0, config.randomDelayMs + 1)
                            } else 0L

                            pointIndex++
                            if (delayMs > 0) {
                                delay(delayMs.coerceAtLeast(1L))
                            }
                        }
                    }

                    ClickerMode.SWIPE -> {
                        val swipe = config.swipe
                        while (isActive) {
                            if (config.repeatCount in 1..clickCount) {
                                break
                            }

                            performSwipe(
                                swipe.startX,
                                swipe.startY,
                                swipe.endX,
                                swipe.endY,
                                swipe.durationMs
                            )

                            clickCount++
                            val now = System.currentTimeMillis()
                            val elapsed = now - startTime

                            _stats.value = _stats.value.copy(
                                totalClicks = clickCount,
                                currentCps = 1000.0 / (swipe.durationMs + swipe.delayAfterMs).coerceAtLeast(1L),
                                elapsedTimeMs = elapsed,
                                lastClickX = swipe.endX,
                                lastClickY = swipe.endY
                            )

                            delay(swipe.delayAfterMs.coerceAtLeast(10L))
                        }
                    }
                }
            } catch (_: CancellationException) {
                // Normal job cancel
            } catch (e: Throwable) {
                Log.e(TAG, "Error in auto-click loop", e)
            } finally {
                _stats.value = _stats.value.copy(isRunning = false, currentCps = 0.0)
            }
        }
    }

    /**
     * Stops the active auto-clicking loop.
     */
    fun stopClickLoop() {
        clickLoopJob?.cancel()
        clickLoopJob = null
        _stats.value = _stats.value.copy(isRunning = false, currentCps = 0.0)
        closeShell()
    }
}
