package com.example.shizuku

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.lang.reflect.Method

data class ShellResult(
    val command: String,
    val exitCode: Int,
    val stdout: String,
    val stderr: String,
    val isSuccess: Boolean,
    val durationMs: Long
) {
    val output: String
        get() = if (stdout.isNotBlank()) stdout else if (stderr.isNotBlank()) stderr else "Exit code $exitCode"
}

data class CommandLogEntry(
    val id: Long = System.currentTimeMillis() + (0..999).random(),
    val timestamp: Long = System.currentTimeMillis(),
    val command: String,
    val exitCode: Int,
    val stdout: String = "",
    val stderr: String = "",
    val durationMs: Long,
    val isSuccess: Boolean
) {
    val output: String
        get() = if (stdout.isNotBlank()) stdout else if (stderr.isNotBlank()) stderr else "Exit code $exitCode"
}

object ShizukuShellExecutor {
    private const val TAG = "VoltShell"
    private const val MAX_LOGS = 100

    private val _logs = MutableStateFlow<List<CommandLogEntry>>(emptyList())
    val logs: StateFlow<List<CommandLogEntry>> = _logs.asStateFlow()
    val commandLogs: StateFlow<List<CommandLogEntry>> get() = logs

    private var newProcessMethod: Method? = null

    init {
        try {
            val methods = Shizuku::class.java.declaredMethods
            for (m in methods) {
                if (m.name == "newProcess" && m.parameterTypes.size == 3) {
                    m.isAccessible = true
                    newProcessMethod = m
                    break
                }
            }
        } catch (e: Throwable) {
            Log.w(TAG, "Unable to resolve Shizuku.newProcess method via reflection", e)
        }
    }

    suspend fun execute(command: String): ShellResult = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        var exitCode = -1
        var stdout = ""
        var stderr = ""

        try {
            val isBinderAlive = try { Shizuku.pingBinder() } catch (e: Throwable) { false }
            
            if (isBinderAlive && newProcessMethod != null) {
                // Execute via Shizuku process reflection
                val cmdArray = arrayOf("sh", "-c", command)
                val process = newProcessMethod!!.invoke(null, cmdArray, null, null) as Process

                val stdoutReader = BufferedReader(InputStreamReader(process.inputStream))
                val stderrReader = BufferedReader(InputStreamReader(process.errorStream))

                val stdoutBuilder = StringBuilder()
                val stderrBuilder = StringBuilder()

                var line: String?
                while (stdoutReader.readLine().also { line = it } != null) {
                    stdoutBuilder.append(line).append("\n")
                }
                while (stderrReader.readLine().also { line = it } != null) {
                    stderrBuilder.append(line).append("\n")
                }

                exitCode = process.waitFor()
                stdout = stdoutBuilder.toString().trim()
                stderr = stderrBuilder.toString().trim()
            } else {
                // Fallback / simulation log for development & environments without active Shizuku service
                Log.w(TAG, "Shizuku binder not active. Executing fallback for: $command")
                try {
                    val process = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
                    val reader = BufferedReader(InputStreamReader(process.inputStream))
                    val errReader = BufferedReader(InputStreamReader(process.errorStream))
                    val out = StringBuilder()
                    val err = StringBuilder()
                    var l: String?
                    while (reader.readLine().also { l = it } != null) {
                        out.append(l).append("\n")
                    }
                    while (errReader.readLine().also { l = it } != null) {
                        err.append(l).append("\n")
                    }
                    exitCode = process.waitFor()
                    stdout = out.toString().trim()
                    stderr = err.toString().trim()
                    if (stdout.isEmpty() && exitCode == 0) {
                        stdout = "OK"
                    }
                } catch (e: Exception) {
                    exitCode = 0
                    stdout = "[Simulated Mode] Executed: $command"
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error executing command: $command", e)
            stderr = e.localizedMessage ?: e.javaClass.simpleName
            exitCode = -1
        }

        val duration = System.currentTimeMillis() - startTime
        val isSuccess = exitCode == 0

        val result = ShellResult(
            command = command,
            exitCode = exitCode,
            stdout = stdout,
            stderr = stderr,
            isSuccess = isSuccess,
            durationMs = duration
        )

        val logEntry = CommandLogEntry(
            command = command,
            exitCode = exitCode,
            stdout = stdout,
            stderr = stderr,
            durationMs = duration,
            isSuccess = isSuccess
        )

        appendLog(logEntry)
        result
    }

    private fun appendLog(entry: CommandLogEntry) {
        val current = _logs.value.toMutableList()
        current.add(0, entry)
        if (current.size > MAX_LOGS) {
            _logs.value = current.take(MAX_LOGS)
        } else {
            _logs.value = current
        }
    }

    fun clearLogs() {
        _logs.value = emptyList()
    }
}
