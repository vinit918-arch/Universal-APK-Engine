package com.example.shizuku

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

object ShizukuStateRepository {
    private const val TAG = "VoltShizuku"
    const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001
    private const val MIN_REQUIRED_VERSION = 11

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val _state = MutableStateFlow<ShizukuState>(ShizukuState.NotRunning)
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    private var isInitialized = false

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku binder received")
        checkState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.d(TAG, "Shizuku binder dead")
        _state.value = ShizukuState.NotRunning
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                Log.d(TAG, "Shizuku permission result: $grantResult")
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    checkState()
                } else {
                    _state.value = ShizukuState.PermissionDenied
                }
            }
        }

    fun init(context: Context) {
        if (isInitialized) return
        isInitialized = true

        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error registering Shizuku listeners", e)
        }

        checkState(context)
    }

    fun checkState(context: Context? = null) {
        scope.launch {
            try {
                if (!Shizuku.pingBinder()) {
                    _state.value = ShizukuState.NotRunning
                    return@launch
                }

                val version = try {
                    Shizuku.getVersion()
                } catch (e: Throwable) {
                    -1
                }

                if (version < MIN_REQUIRED_VERSION && version != -1) {
                    _state.value = ShizukuState.VersionWarning(version)
                    return@launch
                }

                val hasPermission = try {
                    if (version < 11) {
                        false
                    } else {
                        Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                    }
                } catch (e: Throwable) {
                    false
                }

                if (hasPermission) {
                    val uid = try { Shizuku.getUid() } catch (e: Throwable) { -1 }
                    val isRoot = uid == 0
                    _state.value = ShizukuState.Ready(
                        version = version,
                        isRoot = isRoot,
                        uid = uid
                    )
                } else {
                    _state.value = ShizukuState.PermissionDenied
                }
            } catch (e: Throwable) {
                Log.e(TAG, "Error checking Shizuku state", e)
                _state.value = ShizukuState.NotRunning
            }
        }
    }

    fun requestPermission(activity: Activity? = null) {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
                } else {
                    checkState()
                }
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to request Shizuku permission", e)
        }
    }

    fun cleanup() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error cleaning up Shizuku listeners", e)
        }
    }
}
