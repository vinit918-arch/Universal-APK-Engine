package com.example.shizuku

sealed interface ShizukuState {
    data object NotInstalled : ShizukuState
    data object NotRunning : ShizukuState
    data object PermissionDenied : ShizukuState
    data class VersionWarning(val version: Int) : ShizukuState
    data class Ready(
        val version: Int,
        val isRoot: Boolean,
        val uid: Int
    ) : ShizukuState
}
