package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color as AndroidColor
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Choreographer
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CrisisAlert
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import android.provider.Settings
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.MainActivity
import com.example.R
import com.example.data.model.AutoClickConfig
import com.example.data.model.ClickPoint
import com.example.data.model.ClickStats
import com.example.data.model.ClickerMode
import com.example.shizuku.ShizukuTouchEngine
import com.example.ui.theme.VoltBorder
import com.example.ui.theme.VoltBorderCyan
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltGreen
import com.example.ui.theme.VoltOrange
import com.example.ui.theme.VoltRed
import com.example.ui.theme.VoltSurface
import com.example.ui.theme.VoltSurfaceElevated
import com.example.ui.theme.VoltTextPrimary
import com.example.ui.theme.VoltTextSecondary
import com.example.ui.theme.VoltTextTertiary
import com.example.ui.theme.VoltViolet
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.roundToInt

data class PerformanceTelemetry(
    val fps: Int = 0,
    val memoryUsageMb: Long = 0L,
    val maxMemoryMb: Long = 0L,
    val isSampling: Boolean = false
)

@Composable
fun rememberActivePerformanceTelemetry(isActive: Boolean): PerformanceTelemetry {
    var telemetry by remember { mutableStateOf(PerformanceTelemetry()) }

    LaunchedEffect(isActive) {
        if (!isActive) {
            telemetry = PerformanceTelemetry(fps = 0, memoryUsageMb = 0L, maxMemoryMb = 0L, isSampling = false)
            return@LaunchedEffect
        }

        var frameCount = 0
        var lastSampleTimeNs = System.nanoTime()

        val frameCallback = object : Choreographer.FrameCallback {
            override fun doFrame(frameTimeNanos: Long) {
                if (!isActive) return
                frameCount++
                val elapsedNs = frameTimeNanos - lastSampleTimeNs
                if (elapsedNs >= 500_000_000L) { // 500ms sampling window
                    val calculatedFps = ((frameCount * 1_000_000_000.0) / elapsedNs).roundToInt().coerceIn(1, 240)
                    frameCount = 0
                    lastSampleTimeNs = frameTimeNanos

                    val runtime = Runtime.getRuntime()
                    val usedMemMb = (runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)
                    val maxMemMb = runtime.maxMemory() / (1024 * 1024)

                    telemetry = PerformanceTelemetry(
                        fps = calculatedFps,
                        memoryUsageMb = usedMemMb,
                        maxMemoryMb = maxMemMb,
                        isSampling = true
                    )
                }
                try {
                    Choreographer.getInstance().postFrameCallback(this)
                } catch (_: Throwable) {}
            }
        }

        try {
            Choreographer.getInstance().postFrameCallback(frameCallback)
            awaitCancellation()
        } finally {
            try {
                Choreographer.getInstance().removeFrameCallback(frameCallback)
            } catch (_: Throwable) {}
        }
    }

    return telemetry
}

class FloatingControlService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner {

    companion object {
        const val CHANNEL_ID = "volt_autoclicker_overlay"
        const val NOTIFICATION_ID = 2001
        const val ACTION_START_OVERLAY = "com.example.action.START_OVERLAY"
        const val ACTION_STOP_OVERLAY = "com.example.action.STOP_OVERLAY"

        private val _isOverlayActive = MutableStateFlow(false)
        val isOverlayActive: StateFlow<Boolean> = _isOverlayActive.asStateFlow()

        private val _activeConfig = MutableStateFlow(AutoClickConfig())
        val activeConfig: StateFlow<AutoClickConfig> = _activeConfig.asStateFlow()

        fun updateConfig(config: AutoClickConfig) {
            _activeConfig.value = config
        }

        fun startService(context: Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(context)) {
                return
            }
            val intent = Intent(context, FloatingControlService::class.java).apply {
                action = ACTION_START_OVERLAY
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(intent)
                } else {
                    context.startService(intent)
                }
            } catch (_: Throwable) {}
        }

        fun stopService(context: Context) {
            val intent = Intent(context, FloatingControlService::class.java).apply {
                action = ACTION_STOP_OVERLAY
            }
            try {
                context.startService(intent)
            } catch (_: Throwable) {}
        }
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    override val savedStateRegistry: SavedStateRegistry
        get() = savedStateRegistryController.savedStateRegistry

    private val appViewModelStore = ViewModelStore()
    override val viewModelStore: ViewModelStore get() = appViewModelStore

    private var windowManager: WindowManager? = null
    
    // View references
    private var floatingBubbleView: View? = null
    private var crosshairView: View? = null
    private var settingsMenuView: View? = null

    // Window Layout Params
    private var bubbleLayoutParams: WindowManager.LayoutParams? = null
    private var crosshairLayoutParams: WindowManager.LayoutParams? = null
    private var settingsLayoutParams: WindowManager.LayoutParams? = null

    // Screen dimensions
    private var screenWidth = 1080
    private var screenHeight = 2400

    // Dynamic states
    private var isCrosshairVisible by mutableStateOf(true)
    private var isSettingsMenuOpen by mutableStateOf(false)
    private var targetX by mutableIntStateOf(540)
    private var targetY by mutableIntStateOf(1200)

    override fun onCreate() {
        super.onCreate()
        try {
            savedStateRegistryController.performRestore(null)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

            windowManager = getSystemService(Context.WINDOW_SERVICE) as? WindowManager

            val displayMetrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager?.defaultDisplay?.getMetrics(displayMetrics)
            screenWidth = displayMetrics.widthPixels.coerceAtLeast(320)
            screenHeight = displayMetrics.heightPixels.coerceAtLeast(480)

            // Initialize target coordinates to center of screen
            targetX = screenWidth / 2
            targetY = screenHeight / 2

            createNotificationChannel()
        } catch (_: Throwable) {}
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_OVERLAY -> {
                stopSelf()
                return START_NOT_STICKY
            }
            else -> {
                try {
                    startForeground(NOTIFICATION_ID, buildNotification())
                    _isOverlayActive.value = true
                    setupFloatingViews()
                } catch (_: Throwable) {
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    private fun setupFloatingViews() {
        if (floatingBubbleView != null) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
            return
        }

        val overlayFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        // 1. Setup Floating Bubble Pill View
        bubbleLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = screenHeight / 3
        }

        floatingBubbleView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingControlService)
            setViewTreeSavedStateRegistryOwner(this@FloatingControlService)
            setViewTreeViewModelStoreOwner(this@FloatingControlService)
            setContent {
                FloatingBubbleBar(
                    onToggleMenu = {
                        isSettingsMenuOpen = !isSettingsMenuOpen
                        updateSettingsViewVisibility()
                    },
                    onToggleCrosshair = {
                        isCrosshairVisible = !isCrosshairVisible
                        updateCrosshairViewVisibility()
                    },
                    onTogglePlay = {
                        toggleClicker()
                    },
                    onCloseService = {
                        stopSelf()
                    },
                    onDragDelta = { dx, dy ->
                        bubbleLayoutParams?.let { params ->
                            params.x = (params.x + dx.toInt()).coerceIn(0, screenWidth - 100)
                            params.y = (params.y + dy.toInt()).coerceIn(0, screenHeight - 100)
                            try {
                                if (floatingBubbleView?.isAttachedToWindow == true) {
                                    windowManager?.updateViewLayout(floatingBubbleView, params)
                                }
                            } catch (_: Throwable) {}
                        }
                    }
                )
            }
        }
        try {
            windowManager?.addView(floatingBubbleView, bubbleLayoutParams)
        } catch (_: Throwable) {}

        // 2. Setup Draggable Crosshair Target Picker
        setupCrosshairPicker(overlayFlag)

        // 3. Setup Mini Settings Dialog Overlay
        setupSettingsMenu(overlayFlag)
    }

    private fun setupCrosshairPicker(overlayFlag: Int) {
        val sizePx = (72 * resources.displayMetrics.density).roundToInt()
        crosshairLayoutParams = WindowManager.LayoutParams(
            sizePx,
            sizePx,
            overlayFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = targetX - (sizePx / 2)
            y = targetY - (sizePx / 2)
        }

        crosshairView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingControlService)
            setViewTreeSavedStateRegistryOwner(this@FloatingControlService)
            setViewTreeViewModelStoreOwner(this@FloatingControlService)
            setContent {
                CrosshairPickerWidget(
                    targetX = targetX,
                    targetY = targetY,
                    onDragDelta = { dx, dy ->
                        crosshairLayoutParams?.let { params ->
                            params.x = (params.x + dx.toInt()).coerceIn(0, (screenWidth - sizePx).coerceAtLeast(0))
                            params.y = (params.y + dy.toInt()).coerceIn(0, (screenHeight - sizePx).coerceAtLeast(0))
                            targetX = params.x + (sizePx / 2)
                            targetY = params.y + (sizePx / 2)
                            _activeConfig.value = _activeConfig.value.copy(
                                singlePoint = _activeConfig.value.singlePoint.copy(x = targetX, y = targetY)
                            )
                            try {
                                if (crosshairView?.isAttachedToWindow == true) {
                                    windowManager?.updateViewLayout(crosshairView, params)
                                }
                            } catch (_: Throwable) {}
                        }
                    }
                )
            }
        }

        if (isCrosshairVisible) {
            try {
                windowManager?.addView(crosshairView, crosshairLayoutParams)
            } catch (_: Throwable) {}
        }
    }

    private fun setupSettingsMenu(overlayFlag: Int) {
        settingsLayoutParams = WindowManager.LayoutParams(
            (screenWidth * 0.90).roundToInt().coerceAtMost((400 * resources.displayMetrics.density).roundToInt()),
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayFlag,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.CENTER
            x = 0
            y = 0
        }

        settingsMenuView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@FloatingControlService)
            setViewTreeSavedStateRegistryOwner(this@FloatingControlService)
            setViewTreeViewModelStoreOwner(this@FloatingControlService)
            setContent {
                MiniSettingsMenuDialog(
                    targetX = targetX,
                    targetY = targetY,
                    isCrosshairVisible = isCrosshairVisible,
                    onUpdateCoords = { x, y ->
                        targetX = x
                        targetY = y
                        updateCrosshairPosition(x, y)
                        _activeConfig.value = _activeConfig.value.copy(
                            singlePoint = _activeConfig.value.singlePoint.copy(x = x, y = y)
                        )
                    },
                    onToggleCrosshair = {
                        isCrosshairVisible = !isCrosshairVisible
                        updateCrosshairViewVisibility()
                    },
                    onCloseMenu = {
                        isSettingsMenuOpen = false
                        updateSettingsViewVisibility()
                    },
                    onStartStopClicking = {
                        toggleClicker()
                    }
                )
            }
        }

        if (isSettingsMenuOpen) {
            try {
                windowManager?.addView(settingsMenuView, settingsLayoutParams)
            } catch (_: Throwable) {}
        }
    }

    private fun updateCrosshairPosition(x: Int, y: Int) {
        crosshairLayoutParams?.let { params ->
            val sizePx = (72 * resources.displayMetrics.density).roundToInt()
            params.x = (x - (sizePx / 2)).coerceIn(0, (screenWidth - sizePx).coerceAtLeast(0))
            params.y = (y - (sizePx / 2)).coerceIn(0, (screenHeight - sizePx).coerceAtLeast(0))
            try {
                if (crosshairView != null && crosshairView?.isAttachedToWindow == true) {
                    windowManager?.updateViewLayout(crosshairView, params)
                }
            } catch (_: Throwable) {}
        }
    }

    private fun updateCrosshairViewVisibility() {
        try {
            if (isCrosshairVisible) {
                if (crosshairView != null && crosshairView?.isAttachedToWindow != true) {
                    windowManager?.addView(crosshairView, crosshairLayoutParams)
                }
            } else {
                if (crosshairView != null && crosshairView?.isAttachedToWindow == true) {
                    windowManager?.removeView(crosshairView)
                }
            }
        } catch (_: Throwable) {}
    }

    private fun updateSettingsViewVisibility() {
        try {
            if (isSettingsMenuOpen) {
                if (settingsMenuView != null && settingsMenuView?.isAttachedToWindow != true) {
                    windowManager?.addView(settingsMenuView, settingsLayoutParams)
                }
            } else {
                if (settingsMenuView != null && settingsMenuView?.isAttachedToWindow == true) {
                    windowManager?.removeView(settingsMenuView)
                }
            }
        } catch (_: Throwable) {}
    }

    private fun toggleClicker() {
        val stats = ShizukuTouchEngine.stats.value
        if (stats.isRunning) {
            ShizukuTouchEngine.stopClickLoop()
        } else {
            val cfg = _activeConfig.value.copy(
                singlePoint = _activeConfig.value.singlePoint.copy(x = targetX, y = targetY)
            )
            _activeConfig.value = cfg
            ShizukuTouchEngine.startClickLoop(cfg)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Auto Clicker Overlay Controller",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows active floating Auto Clicker status and controls"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, FloatingControlService::class.java).apply {
            action = ACTION_STOP_OVERLAY
        }
        val pendingStop = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Auto Clicker Overlay Active")
            .setContentText("Tap to open controller or manage target points")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingOpen)
            .addAction(android.R.drawable.ic_delete, "Stop Overlay", pendingStop)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        ShizukuTouchEngine.stopClickLoop()
        _isOverlayActive.value = false

        try {
            if (floatingBubbleView != null && floatingBubbleView?.isAttachedToWindow == true) {
                windowManager?.removeView(floatingBubbleView)
            }
            if (crosshairView != null && crosshairView?.isAttachedToWindow == true) {
                windowManager?.removeView(crosshairView)
            }
            if (settingsMenuView != null && settingsMenuView?.isAttachedToWindow == true) {
                windowManager?.removeView(settingsMenuView)
            }
        } catch (_: Throwable) {}

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        appViewModelStore.clear()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

// ---------------------------------------------------------------------------
// Composable Overlay Views
// ---------------------------------------------------------------------------

@Composable
fun FloatingBubbleBar(
    onToggleMenu: () -> Unit,
    onToggleCrosshair: () -> Unit,
    onTogglePlay: () -> Unit,
    onCloseService: () -> Unit,
    onDragDelta: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val stats by ShizukuTouchEngine.stats.collectAsState()
    val perfTelemetry = rememberActivePerformanceTelemetry(stats.isRunning)
    val infiniteTransition = rememberInfiniteTransition(label = "pulse_active")

    val glowAlpha by if (stats.isRunning) {
        infiniteTransition.animateFloat(
            initialValue = 0.4f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                animation = tween(600),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse_glow"
        )
    } else {
        remember { mutableFloatStateOf(0.4f) }
    }

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(24.dp))
            .background(
                Brush.horizontalGradient(
                    listOf(
                        if (stats.isRunning) Color(0xFF003844) else Color(0xFF141422),
                        if (stats.isRunning) Color(0xFF1E1035) else Color(0xFF101018)
                    )
                )
            )
            .border(
                width = 1.5.dp,
                color = if (stats.isRunning) VoltCyan.copy(alpha = glowAlpha) else VoltViolet.copy(alpha = 0.6f),
                shape = RoundedCornerShape(24.dp)
            )
            .padding(horizontal = 6.dp, vertical = 4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Drag Grip Handle
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .pointerInput(Unit) {
                        detectDragGestures { change, dragAmount ->
                            change.consume()
                            onDragDelta(dragAmount.x, dragAmount.y)
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.OpenWith,
                    contentDescription = "Drag overlay",
                    tint = VoltTextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Play / Pause Button
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (stats.isRunning) VoltRed else VoltCyan)
                    .clickable { onTogglePlay() }
                    .testTag("floating_play_pause_button"),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (stats.isRunning) Icons.Default.Pause else Icons.Default.PlayArrow,
                    contentDescription = if (stats.isRunning) "Stop" else "Start",
                    tint = Color.Black,
                    modifier = Modifier.size(20.dp)
                )
            }

            // Live Performance Telemetry Pill (Visible and active when running)
            AnimatedVisibility(
                visible = stats.isRunning,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color(0xDD080812))
                        .border(1.dp, VoltCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (perfTelemetry.fps > 0) "${perfTelemetry.fps} FPS" else "-- FPS",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = VoltGreen
                    )
                    Text(
                        text = "•",
                        fontSize = 8.sp,
                        color = VoltTextTertiary
                    )
                    Text(
                        text = if (perfTelemetry.memoryUsageMb > 0) "${perfTelemetry.memoryUsageMb}MB" else "--MB",
                        fontSize = 9.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = VoltCyan
                    )
                }
            }

            // Crosshair picker toggle
            IconButton(
                onClick = onToggleCrosshair,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.CrisisAlert,
                    contentDescription = "Toggle Crosshair",
                    tint = VoltCyan,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Settings Menu Toggle
            IconButton(
                onClick = onToggleMenu,
                modifier = Modifier.size(30.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = VoltViolet,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Close
            IconButton(
                onClick = onCloseService,
                modifier = Modifier.size(26.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Close,
                    contentDescription = "Close overlay",
                    tint = VoltTextTertiary,
                    modifier = Modifier.size(14.dp)
                )
            }
        }
    }
}

@Composable
fun CrosshairPickerWidget(
    targetX: Int,
    targetY: Int,
    onDragDelta: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val stats by ShizukuTouchEngine.stats.collectAsState()

    Box(
        modifier = modifier
            .size(72.dp)
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    onDragDelta(dragAmount.x, dragAmount.y)
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = size.width * 0.35f

            // Outer Target Circle
            drawCircle(
                color = if (stats.isRunning) VoltCyan else VoltViolet,
                radius = radius,
                style = Stroke(width = 2.dp.toPx())
            )

            // Inner Center Dot
            drawCircle(
                color = if (stats.isRunning) VoltGreen else VoltCyan,
                radius = 3.5.dp.toPx()
            )

            // Crosshair tick marks
            drawLine(
                color = if (stats.isRunning) VoltCyan else VoltViolet,
                start = Offset(cx, cy - radius - 6.dp.toPx()),
                end = Offset(cx, cy - radius + 4.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = if (stats.isRunning) VoltCyan else VoltViolet,
                start = Offset(cx, cy + radius - 4.dp.toPx()),
                end = Offset(cx, cy + radius + 6.dp.toPx()),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = if (stats.isRunning) VoltCyan else VoltViolet,
                start = Offset(cx - radius - 6.dp.toPx(), cy),
                end = Offset(cx - radius + 4.dp.toPx(), cy),
                strokeWidth = 2.dp.toPx()
            )
            drawLine(
                color = if (stats.isRunning) VoltCyan else VoltViolet,
                start = Offset(cx + radius - 4.dp.toPx(), cy),
                end = Offset(cx + radius + 6.dp.toPx(), cy),
                strokeWidth = 2.dp.toPx()
            )
        }

        // Live Coordinate Badge
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 12.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xEE080810))
                .border(1.dp, VoltCyan.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = "${targetX}, ${targetY}",
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = VoltCyan
            )
        }
    }
}

@Composable
fun MiniSettingsMenuDialog(
    targetX: Int,
    targetY: Int,
    isCrosshairVisible: Boolean,
    onUpdateCoords: (Int, Int) -> Unit,
    onToggleCrosshair: () -> Unit,
    onCloseMenu: () -> Unit,
    onStartStopClicking: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stats by ShizukuTouchEngine.stats.collectAsState()
    val perfTelemetry = rememberActivePerformanceTelemetry(stats.isRunning)
    val activeConfig by FloatingControlService.activeConfig.collectAsState()

    var inputX by remember(targetX) { mutableStateOf(targetX.toString()) }
    var inputY by remember(targetY) { mutableStateOf(targetY.toString()) }
    var intervalInput by remember(activeConfig.intervalMs) { mutableStateOf(activeConfig.intervalMs.toString()) }
    var repeatInput by remember(activeConfig.repeatCount) { mutableStateOf(activeConfig.repeatCount.toString()) }

    val presetIntervals = listOf(20L, 50L, 100L, 250L, 500L, 1000L)

    Surface(
        shape = RoundedCornerShape(16.dp),
        color = Color(0xFF12121E),
        tonalElevation = 12.dp,
        modifier = modifier
            .border(1.5.dp, VoltBorderCyan, RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (stats.isRunning) VoltGreen else VoltViolet)
                    )
                    Text(
                        text = "AUTO CLICKER CONTROLLER",
                        fontSize = 12.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = VoltCyan
                    )
                }

                IconButton(
                    onClick = onCloseMenu,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(imageVector = Icons.Default.KeyboardArrowDown, contentDescription = "Close", tint = VoltTextSecondary)
                }
            }

            // Target Coordinates Row
            Text(
                text = "TARGET COORDINATES (X, Y)",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = VoltTextSecondary
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputX,
                    onValueChange = {
                        inputX = it
                        val xVal = it.toIntOrNull()
                        if (xVal != null) onUpdateCoords(xVal, targetY)
                    },
                    label = { Text("X (px)", fontSize = 10.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = VoltTextPrimary,
                        unfocusedTextColor = VoltTextPrimary,
                        focusedBorderColor = VoltCyan,
                        unfocusedBorderColor = VoltTextTertiary
                    ),
                    modifier = Modifier.weight(1f)
                )

                OutlinedTextField(
                    value = inputY,
                    onValueChange = {
                        inputY = it
                        val yVal = it.toIntOrNull()
                        if (yVal != null) onUpdateCoords(targetX, yVal)
                    },
                    label = { Text("Y (px)", fontSize = 10.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = VoltTextPrimary,
                        unfocusedTextColor = VoltTextPrimary,
                        focusedBorderColor = VoltCyan,
                        unfocusedBorderColor = VoltTextTertiary
                    ),
                    modifier = Modifier.weight(1f)
                )

                Button(
                    onClick = onToggleCrosshair,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isCrosshairVisible) VoltViolet else Color(0xFF222234),
                        contentColor = VoltTextPrimary
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.height(52.dp)
                ) {
                    Icon(imageVector = Icons.Default.GpsFixed, contentDescription = "Target", modifier = Modifier.size(16.dp))
                }
            }

            // Click Interval Section
            Text(
                text = "CLICK INTERVAL (MILLISECONDS)",
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                color = VoltTextSecondary
            )

            OutlinedTextField(
                value = intervalInput,
                onValueChange = {
                    intervalInput = it
                    val ms = it.toLongOrNull()
                    if (ms != null && ms > 0) {
                        FloatingControlService.updateConfig(
                            activeConfig.copy(intervalMs = ms)
                        )
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                trailingIcon = {
                    Text("ms", fontFamily = FontFamily.Monospace, color = VoltCyan, fontSize = 11.sp, modifier = Modifier.padding(end = 12.dp))
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = VoltTextPrimary,
                    unfocusedTextColor = VoltTextPrimary,
                    focusedBorderColor = VoltCyan,
                    unfocusedBorderColor = VoltTextTertiary
                ),
                modifier = Modifier.fillMaxWidth()
            )

            // Preset chips
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                presetIntervals.forEach { preset ->
                    val isSelected = activeConfig.intervalMs == preset
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) VoltCyan else Color(0xFF1E1E2E))
                            .clickable {
                                intervalInput = preset.toString()
                                FloatingControlService.updateConfig(
                                    activeConfig.copy(intervalMs = preset)
                                )
                            }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "${preset}ms",
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color.Black else VoltTextSecondary
                        )
                    }
                }
            }

            // Real-Time System Telemetry (Non-blocking FPS & RAM - updates only when active)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (stats.isRunning) Color(0xFF0B1924) else Color(0xFF0C0C14))
                    .border(
                        1.dp,
                        if (stats.isRunning) VoltCyan.copy(alpha = 0.5f) else Color(0xFF222234),
                        RoundedCornerShape(8.dp)
                    )
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // FPS Telemetry
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = "FPS",
                        tint = if (stats.isRunning) VoltGreen else VoltTextTertiary,
                        modifier = Modifier.size(16.dp)
                    )
                    Column {
                        Text(
                            text = "FRAME RATE",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = VoltTextSecondary
                        )
                        Text(
                            text = if (stats.isRunning) "${if (perfTelemetry.fps > 0) perfTelemetry.fps else "--"} FPS" else "PAUSED",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (stats.isRunning) VoltGreen else VoltTextTertiary
                        )
                    }
                }

                // Memory Telemetry
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Memory,
                        contentDescription = "RAM",
                        tint = if (stats.isRunning) VoltCyan else VoltTextTertiary,
                        modifier = Modifier.size(16.dp)
                    )
                    Column {
                        Text(
                            text = "HEAP MEMORY",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            color = VoltTextSecondary
                        )
                        Text(
                            text = if (stats.isRunning) "${if (perfTelemetry.memoryUsageMb > 0) perfTelemetry.memoryUsageMb else "--"} MB" else "STANDBY",
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = if (stats.isRunning) VoltCyan else VoltTextTertiary
                        )
                    }
                }

                // Live Active Tag
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (stats.isRunning) VoltCyan.copy(alpha = 0.15f) else Color(0xFF1E1E28))
                        .padding(horizontal = 6.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (stats.isRunning) "ACTIVE" else "IDLE",
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        color = if (stats.isRunning) VoltCyan else VoltTextTertiary
                    )
                }
            }

            // Click Stats Readout
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color(0xFF0C0C14))
                    .border(1.dp, Color(0xFF222234), RoundedCornerShape(8.dp))
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("CLICKS", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = VoltTextSecondary)
                    Text("${stats.totalClicks}", fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = VoltCyan)
                }
                Column {
                    Text("CPS (SPEED)", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = VoltTextSecondary)
                    Text(String.format("%.1f", stats.currentCps), fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = VoltGreen)
                }
                Column {
                    Text("ELAPSED", fontSize = 8.sp, fontFamily = FontFamily.Monospace, color = VoltTextSecondary)
                    Text("${stats.elapsedTimeMs / 1000}s", fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = VoltTextPrimary)
                }
            }

            // Primary Start/Stop Action Button
            Button(
                onClick = onStartStopClicking,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (stats.isRunning) VoltRed else VoltCyan,
                    contentColor = if (stats.isRunning) Color.White else Color.Black
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(44.dp)
                    .testTag("dialog_start_stop_button")
            ) {
                Icon(
                    imageVector = if (stats.isRunning) Icons.Default.Stop else Icons.Default.PlayArrow,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (stats.isRunning) "STOP AUTO CLICKER" else "START AUTO CLICKER",
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    letterSpacing = 0.5.sp
                )
            }
        }
    }
}
