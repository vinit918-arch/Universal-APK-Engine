package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.model.ActiveSessionInfo
import com.example.data.model.DefaultToggles
import com.example.data.model.SystemToggle
import com.example.data.repository.GamesRepository
import com.example.data.repository.TogglesRepository
import com.example.shizuku.ShizukuShellExecutor
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class GameSessionService : Service() {

    companion object {
        private const val TAG = "VoltSessionService"
        const val CHANNEL_ID = "volt_game_session_channel"
        const val NOTIFICATION_ID = 2001

        const val ACTION_START_SESSION = "com.example.ACTION_START_SESSION"
        const val ACTION_RESTORE_ALL = "com.example.ACTION_RESTORE_ALL"
        const val EXTRA_PACKAGE_NAME = "extra_package_name"
        const val EXTRA_GAME_NAME = "extra_game_name"

        private val _sessionState = MutableStateFlow<ActiveSessionInfo?>(null)
        val sessionState: StateFlow<ActiveSessionInfo?> = _sessionState.asStateFlow()

        fun isSessionActive(): Boolean = _sessionState.value != null

        fun startSession(context: Context, packageName: String, gameName: String) {
            val intent = Intent(context, GameSessionService::class.java).apply {
                action = ACTION_START_SESSION
                putExtra(EXTRA_PACKAGE_NAME, packageName)
                putExtra(EXTRA_GAME_NAME, gameName)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun restoreAndStop(context: Context) {
            val intent = Intent(context, GameSessionService::class.java).apply {
                action = ACTION_RESTORE_ALL
            }
            context.startService(intent)
        }
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var pollingJob: Job? = null
    private lateinit var togglesRepo: TogglesRepository
    private lateinit var gamesRepo: GamesRepository

    private var activePkg: String? = null
    private var activeGameName: String? = null
    private val appliedToggles = mutableListOf<SystemToggle>()

    override fun onCreate() {
        super.onCreate()
        togglesRepo = TogglesRepository(applicationContext)
        gamesRepo = GamesRepository(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START_SESSION -> {
                val pkg = intent.getStringExtra(EXTRA_PACKAGE_NAME) ?: ""
                val name = intent.getStringExtra(EXTRA_GAME_NAME) ?: "Game"
                if (pkg.isNotEmpty()) {
                    handleStartSession(pkg, name)
                }
            }
            ACTION_RESTORE_ALL -> {
                handleRestoreAll()
            }
        }
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Volt Turbo Active Session",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active game optimization and floating HUD service"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(gameName: String): Notification {
        val appIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val appPendingIntent = PendingIntent.getActivity(
            this,
            0,
            appIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val restoreIntent = Intent(this, GameSessionService::class.java).apply {
            action = ACTION_RESTORE_ALL
        }
        val restorePendingIntent = PendingIntent.getService(
            this,
            1,
            restoreIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Volt Turbo Active — $gameName")
            .setContentText("Performance optimizations applied. Tap to open HUD controls.")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentIntent(appPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                android.R.drawable.ic_menu_revert,
                "Restore Now",
                restorePendingIntent
            )
            .build()
    }

    private fun handleStartSession(packageName: String, gameName: String) {
        activePkg = packageName
        activeGameName = gameName

        startForeground(NOTIFICATION_ID, buildNotification(gameName))

        serviceScope.launch {
            // Read enabled toggles
            val currentToggles = togglesRepo.togglesFlow.first()
            val toApply = currentToggles.filter { it.isEnabled }
            appliedToggles.clear()
            appliedToggles.addAll(toApply)

            // Apply each toggle command via Shizuku
            for (toggle in toApply) {
                Log.d(TAG, "Applying toggle: ${toggle.name} -> ${toggle.applyCommand}")
                ShizukuShellExecutor.execute(toggle.applyCommand)
            }

            // Update session state
            _sessionState.value = ActiveSessionInfo(
                packageName = packageName,
                gameName = gameName,
                startTime = System.currentTimeMillis(),
                appliedToggleIds = toApply.map { it.id }
            )

            // Start Floating Overlay if overlay permission is granted
            if (Settings.canDrawOverlays(this@GameSessionService)) {
                GameOverlayService.startOverlay(this@GameSessionService)
            }

            // Start polling to detect when the game process terminates
            startProcessMonitor(packageName)
        }
    }

    private fun startProcessMonitor(targetPackage: String) {
        pollingJob?.cancel()
        pollingJob = serviceScope.launch {
            delay(10000) // Initial warmup delay
            var consecutiveNotRunningCount = 0

            while (isActive) {
                delay(6000) // Poll process every 6 seconds as specified (5-8s)
                val isRunning = checkIsPackageRunning(targetPackage)
                if (!isRunning) {
                    consecutiveNotRunningCount++
                    if (consecutiveNotRunningCount >= 2) {
                        Log.i(TAG, "Target game $targetPackage no longer running. Auto-restoring system tweaks.")
                        handleRestoreAll()
                        break
                    }
                } else {
                    consecutiveNotRunningCount = 0
                }
            }
        }
    }

    private suspend fun checkIsPackageRunning(pkg: String): Boolean {
        return try {
            // Check via pidof / ps
            val result = ShizukuShellExecutor.execute("pidof $pkg")
            if (result.isSuccess && result.stdout.isNotBlank()) {
                true
            } else {
                // Fallback check
                val result2 = ShizukuShellExecutor.execute("ps -A | grep $pkg")
                result2.isSuccess && result2.stdout.contains(pkg)
            }
        } catch (e: Exception) {
            true // If check fails, stay active until manual restore
        }
    }

    private fun handleRestoreAll() {
        pollingJob?.cancel()
        serviceScope.launch {
            Log.i(TAG, "Restoring all system tweaks...")

            // Revert all applied toggles
            val togglesToRevert = if (appliedToggles.isNotEmpty()) {
                appliedToggles.toList()
            } else {
                DefaultToggles.list
            }

            for (toggle in togglesToRevert) {
                Log.d(TAG, "Reverting: ${toggle.name} -> ${toggle.revertCommand}")
                ShizukuShellExecutor.execute(toggle.revertCommand)
            }

            appliedToggles.clear()
            _sessionState.value = null

            // Stop Floating Overlay
            GameOverlayService.stopOverlay(this@GameSessionService)

            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        pollingJob?.cancel()
        serviceScope.cancel()
        _sessionState.value = null
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
