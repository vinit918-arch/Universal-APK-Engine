package com.example.data.model

enum class ToggleTier {
    TIER_1_ESSENTIALS,
    TIER_2_HIGH_IMPACT
}

data class SystemToggle(
    val id: String,
    val name: String,
    val description: String,
    val tier: ToggleTier,
    val applyCommand: String,
    val revertCommand: String,
    val isEnabled: Boolean = false,
    val isDangerous: Boolean = false,
    val warningMessage: String? = null,
    val iconName: String = "bolt"
)

object DefaultToggles {
    val list: List<SystemToggle> = listOf(
        // Tier 1 - Essentials
        SystemToggle(
            id = "disable_sync",
            name = "Disable Background Sync",
            description = "Halts cloud background sync tasks to prevent CPU thread interrupts during matches.",
            tier = ToggleTier.TIER_1_ESSENTIALS,
            applyCommand = "settings put global sync_enabled 0",
            revertCommand = "settings put global sync_enabled 1",
            iconName = "sync_disabled"
        ),
        SystemToggle(
            id = "dnd_mode",
            name = "Do Not Disturb Mode",
            description = "Silences incoming popups, call banners, and notification vibrations while gaming.",
            tier = ToggleTier.TIER_1_ESSENTIALS,
            applyCommand = "cmd notification set_dnd on",
            revertCommand = "cmd notification set_dnd off",
            iconName = "do_not_disturb_on"
        ),
        SystemToggle(
            id = "disable_auto_brightness",
            name = "Disable Auto-Brightness",
            description = "Locks brightness sensor daemon to stop sudden ambient screen flickering.",
            tier = ToggleTier.TIER_1_ESSENTIALS,
            applyCommand = "settings put system screen_brightness_mode 0",
            revertCommand = "settings put system screen_brightness_mode 1",
            iconName = "brightness_medium"
        ),
        SystemToggle(
            id = "disable_bluetooth_scan",
            name = "Disable Bluetooth Scanning",
            description = "Prevents BLE background beacon telemetry scans and radio polling spikes.",
            tier = ToggleTier.TIER_1_ESSENTIALS,
            applyCommand = "settings put global bluetooth_on 0",
            revertCommand = "settings put global bluetooth_on 1",
            iconName = "bluetooth_disabled"
        ),
        SystemToggle(
            id = "disable_wifi_always_scan",
            name = "Disable WiFi Always-Scan",
            description = "Restricts background WiFi geolocation sweeps that introduce packet jitter.",
            tier = ToggleTier.TIER_1_ESSENTIALS,
            applyCommand = "settings put global wifi_scan_always_enabled 0",
            revertCommand = "settings put global wifi_scan_always_enabled 1",
            iconName = "wifi_tethering_off"
        ),
        SystemToggle(
            id = "extend_screen_timeout",
            name = "Extend Screen Timeout",
            description = "Keeps screen active for 30 minutes during long loading screens and cutscenes.",
            tier = ToggleTier.TIER_1_ESSENTIALS,
            applyCommand = "settings put system screen_off_timeout 1800000",
            revertCommand = "settings put system screen_off_timeout 60000",
            iconName = "timer"
        ),
        SystemToggle(
            id = "disable_haptics",
            name = "Disable System Haptics",
            description = "Disables UI vibration motor calls to save power and prevent frame pacing drops.",
            tier = ToggleTier.TIER_1_ESSENTIALS,
            applyCommand = "settings put system haptic_feedback_enabled 0",
            revertCommand = "settings put system haptic_feedback_enabled 1",
            iconName = "vibration"
        ),

        // Tier 2 - High Impact
        SystemToggle(
            id = "fixed_performance_mode",
            name = "Fixed Performance Mode",
            description = "Requests Android PowerHAL to pin sustained CPU/GPU frequency scaling governors.",
            tier = ToggleTier.TIER_2_HIGH_IMPACT,
            applyCommand = "cmd power set-fixed-performance-mode-enabled true",
            revertCommand = "cmd power set-fixed-performance-mode-enabled false",
            iconName = "speed"
        ),
        SystemToggle(
            id = "disable_adaptive_power_saver",
            name = "Disable Adaptive Power Saver",
            description = "Prevents OS battery manager from down-throttling app compute budgets.",
            tier = ToggleTier.TIER_2_HIGH_IMPACT,
            applyCommand = "cmd power set-adaptive-power-saver-enabled false",
            revertCommand = "cmd power set-adaptive-power-saver-enabled true",
            iconName = "battery_charging_full"
        ),
        SystemToggle(
            id = "force_perf_power_mode",
            name = "Force Performance Power Mode",
            description = "Sets kernel power governor mode to sustained maximum performance level (0).",
            tier = ToggleTier.TIER_2_HIGH_IMPACT,
            applyCommand = "cmd power set-mode 0",
            revertCommand = "cmd power set-mode 1",
            iconName = "flash_on"
        ),
        SystemToggle(
            id = "disable_doze",
            name = "Disable Doze / App Standby",
            description = "Temporarily disables system deviceidle maintenance windows and thread freezing.",
            tier = ToggleTier.TIER_2_HIGH_IMPACT,
            applyCommand = "cmd deviceidle disable all",
            revertCommand = "cmd deviceidle enable all",
            iconName = "power_settings_new"
        ),
        SystemToggle(
            id = "force_game_driver",
            name = "Force Game Driver (GPU)",
            description = "Forces Vulkan/OpenGL graphics pipeline to route through system Game Driver.",
            tier = ToggleTier.TIER_2_HIGH_IMPACT,
            applyCommand = "settings put global game_driver_all_apps 1",
            revertCommand = "settings put global game_driver_all_apps 0",
            iconName = "memory"
        ),
        SystemToggle(
            id = "disable_power_idleness",
            name = "Disable Power Idleness Factor",
            description = "Eliminates low-power idle latency penalties for rapid touch input responses.",
            tier = ToggleTier.TIER_2_HIGH_IMPACT,
            applyCommand = "settings put global power_idleness_factor 0",
            revertCommand = "settings put global power_idleness_factor 1",
            iconName = "touch_app"
        ),
        SystemToggle(
            id = "override_thermal_throttling",
            name = "Override Thermal Throttling",
            description = "Overrides thermal service status to prevent temperature-based FPS drops. High heat warning.",
            tier = ToggleTier.TIER_2_HIGH_IMPACT,
            applyCommand = "cmd thermalservice override-status 0",
            revertCommand = "cmd thermalservice override-status -1",
            isDangerous = true,
            warningMessage = "Disables thermal throttling protection. Only use with active external cooling. Continue?",
            iconName = "whatshot"
        )
    )
}
