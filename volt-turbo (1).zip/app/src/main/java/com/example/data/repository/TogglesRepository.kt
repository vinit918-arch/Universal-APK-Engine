package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.DefaultToggles
import com.example.data.model.SystemToggle
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.togglesDataStore: DataStore<Preferences> by preferencesDataStore(name = "volt_toggles_pref")

class TogglesRepository(private val context: Context) {

    val togglesFlow: Flow<List<SystemToggle>> = context.togglesDataStore.data.map { preferences ->
        DefaultToggles.list.map { toggle ->
            val key = booleanPreferencesKey("toggle_${toggle.id}")
            val isEnabled = preferences[key] ?: (toggle.id == "disable_sync" || toggle.id == "dnd_mode" || toggle.id == "disable_auto_brightness")
            toggle.copy(isEnabled = isEnabled)
        }
    }

    suspend fun setToggleEnabled(toggleId: String, enabled: Boolean) {
        context.togglesDataStore.edit { preferences ->
            val key = booleanPreferencesKey("toggle_$toggleId")
            preferences[key] = enabled
        }
    }

    suspend fun applyPreset(profile: String) {
        context.togglesDataStore.edit { preferences ->
            when (profile) {
                "max_performance" -> {
                    DefaultToggles.list.forEach { toggle ->
                        val key = booleanPreferencesKey("toggle_${toggle.id}")
                        // Enable all except dangerous thermal unless explicitly confirmed later
                        preferences[key] = !toggle.isDangerous
                    }
                }
                "balanced" -> {
                    DefaultToggles.list.forEach { toggle ->
                        val key = booleanPreferencesKey("toggle_${toggle.id}")
                        preferences[key] = toggle.tier == com.example.data.model.ToggleTier.TIER_1_ESSENTIALS
                    }
                }
                "reset" -> {
                    DefaultToggles.list.forEach { toggle ->
                        val key = booleanPreferencesKey("toggle_${toggle.id}")
                        preferences[key] = false
                    }
                }
            }
        }
    }

    suspend fun saveOriginalSetting(key: String, value: String) {
        context.togglesDataStore.edit { preferences ->
            preferences[stringPreferencesKey("orig_$key")] = value
        }
    }

    suspend fun getOriginalSetting(key: String, default: String): String {
        var result = default
        context.togglesDataStore.edit { preferences ->
            result = preferences[stringPreferencesKey("orig_$key")] ?: default
        }
        return result
    }
}
