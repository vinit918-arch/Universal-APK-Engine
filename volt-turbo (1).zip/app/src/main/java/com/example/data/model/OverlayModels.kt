package com.example.data.model

enum class CrosshairStyle {
    DOT,
    CROSS,
    CIRCLE,
    CIRCLE_DOT,
    CROSS_WITH_GAP,
    T_SHAPE,
    SQUARE,
    CHEVRON
}

data class CrosshairConfig(
    val enabled: Boolean = false,
    val style: CrosshairStyle = CrosshairStyle.CROSS_WITH_GAP,
    val sizeDp: Float = 22f, // 8dp - 40dp
    val colorHex: Long = 0xFF00E5FF, // Presets: Red, Green, Cyan, White, Yellow
    val opacity: Float = 0.85f, // 0.3 - 1.0
    val offsetX: Float = 0f,
    val offsetY: Float = 0f,
    val isUnlocked: Boolean = false // Long press unlock to drag
)

/**
 * Screen color adjustment configuration.
 * Note on implementation tradeoff:
 * Android system-wide `settings put secure accessibility_display_color_matrix` or `display_color_mode`
 * requires OEM-specific permissions and has high fragmentation across Android versions.
 * In contrast, a semi-transparent hardware-accelerated overlay surface using ColorMatrix / graphicsLayer
 * delivers immediate, broadly compatible, and fully reversible color grading without OS vendor restrictions.
 */
data class ColorGradingConfig(
    val enabled: Boolean = false,
    val saturation: Float = 1.25f, // 0.5 - 2.0
    val contrast: Float = 1.15f,   // 0.5 - 2.0
    val brightness: Float = 1.05f  // 0.8 - 1.4
)

data class OverlayPositions(
    val leftTabYRatio: Float = 0.35f,
    val rightTabYRatio: Float = 0.35f
)
