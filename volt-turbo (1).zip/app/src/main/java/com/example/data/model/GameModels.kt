package com.example.data.model

data class GameItem(
    val packageName: String,
    val name: String,
    val activityName: String? = null,
    val addedTimestamp: Long = System.currentTimeMillis(),
    val lastPlayedTimestamp: Long = 0L,
    val isOptimized: Boolean = false
)

data class InstalledAppInfo(
    val packageName: String,
    val name: String,
    val isGame: Boolean = false
)

data class ActiveSessionInfo(
    val packageName: String,
    val gameName: String,
    val startTime: Long = System.currentTimeMillis(),
    val appliedToggleIds: List<String> = emptyList()
)
