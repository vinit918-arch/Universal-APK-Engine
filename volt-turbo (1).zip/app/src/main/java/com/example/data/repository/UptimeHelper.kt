package com.example.data.repository

import android.os.SystemClock
import com.example.shizuku.ShizukuShellExecutor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class DeviceUptimeInfo(
    val uptimeSeconds: Long,
    val formattedUptime: String,
    val isRestartRecommended: Boolean
)

object UptimeHelper {
    private const val THREE_HOURS_IN_SECONDS = 3 * 3600L

    suspend fun getDeviceUptime(): DeviceUptimeInfo = withContext(Dispatchers.IO) {
        var uptimeSec = 0L

        // Try /proc/uptime via shell executor
        try {
            val result = ShizukuShellExecutor.execute("cat /proc/uptime")
            if (result.isSuccess && result.stdout.isNotEmpty()) {
                val firstToken = result.stdout.split("\\s+".toRegex()).firstOrNull()
                val parsed = firstToken?.toDoubleOrNull()
                if (parsed != null) {
                    uptimeSec = parsed.toLong()
                }
            }
        } catch (e: Exception) {
            // fallback
        }

        if (uptimeSec <= 0L) {
            uptimeSec = SystemClock.elapsedRealtime() / 1000L
        }

        val hours = uptimeSec / 3600
        val minutes = (uptimeSec % 3600) / 60
        val seconds = uptimeSec % 60

        val formatted = if (hours > 0) {
            String.format("%dh %02dm", hours, minutes)
        } else {
            String.format("%dm %02ds", minutes, seconds)
        }

        val isRestartRecommended = uptimeSec >= THREE_HOURS_IN_SECONDS

        DeviceUptimeInfo(
            uptimeSeconds = uptimeSec,
            formattedUptime = formatted,
            isRestartRecommended = isRestartRecommended
        )
    }
}
