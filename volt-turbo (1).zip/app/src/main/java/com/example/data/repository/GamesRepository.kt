package com.example.data.repository

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.GameItem
import com.example.data.model.InstalledAppInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private val Context.gamesDataStore: DataStore<Preferences> by preferencesDataStore(name = "volt_games_pref")

class GamesRepository(private val context: Context) {
    private val gamesKey = stringPreferencesKey("saved_games_json")

    val gamesFlow: Flow<List<GameItem>> = context.gamesDataStore.data.map { preferences ->
        val jsonStr = preferences[gamesKey]
        if (jsonStr.isNullOrEmpty()) {
            // Default sample games for immediate out-of-the-box experience
            getDefaultSampleGames()
        } else {
            try {
                val list = mutableListOf<GameItem>()
                val array = JSONArray(jsonStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    list.add(
                        GameItem(
                            packageName = obj.getString("pkg"),
                            name = obj.getString("name"),
                            activityName = obj.optString("act", null),
                            addedTimestamp = obj.optLong("added", System.currentTimeMillis()),
                            lastPlayedTimestamp = obj.optLong("last", 0L),
                            isOptimized = obj.optBoolean("opt", false)
                        )
                    )
                }
                if (list.isEmpty()) getDefaultSampleGames() else list
            } catch (e: Exception) {
                getDefaultSampleGames()
            }
        }
    }

    private fun getDefaultSampleGames(): List<GameItem> {
        return listOf(
            GameItem(
                packageName = "com.dts.freefireth",
                name = "Free Fire Max",
                activityName = null,
                isOptimized = false
            ),
            GameItem(
                packageName = "com.pubg.imobile",
                name = "Battlegrounds Mobile",
                activityName = null,
                isOptimized = true
            ),
            GameItem(
                packageName = "com.riotgames.league.wildrift",
                name = "Wild Rift",
                activityName = null,
                isOptimized = false
            ),
            GameItem(
                packageName = "com.miHoYo.GenshinImpact",
                name = "Genshin Impact",
                activityName = null,
                isOptimized = false
            )
        )
    }

    suspend fun addGame(game: GameItem) {
        context.gamesDataStore.edit { preferences ->
            val currentList = getGamesList(preferences[gamesKey]).toMutableList()
            if (currentList.none { it.packageName == game.packageName }) {
                currentList.add(0, game)
                preferences[gamesKey] = serializeGames(currentList)
            }
        }
    }

    suspend fun removeGame(packageName: String) {
        context.gamesDataStore.edit { preferences ->
            val currentList = getGamesList(preferences[gamesKey]).filter { it.packageName != packageName }
            preferences[gamesKey] = serializeGames(currentList)
        }
    }

    suspend fun setGameOptimized(packageName: String, optimized: Boolean) {
        context.gamesDataStore.edit { preferences ->
            val currentList = getGamesList(preferences[gamesKey]).map {
                if (it.packageName == packageName) it.copy(isOptimized = optimized) else it
            }
            preferences[gamesKey] = serializeGames(currentList)
        }
    }

    suspend fun updateLastPlayed(packageName: String) {
        context.gamesDataStore.edit { preferences ->
            val currentList = getGamesList(preferences[gamesKey]).map {
                if (it.packageName == packageName) it.copy(lastPlayedTimestamp = System.currentTimeMillis()) else it
            }
            preferences[gamesKey] = serializeGames(currentList)
        }
    }

    private fun getGamesList(jsonStr: String?): List<GameItem> {
        if (jsonStr.isNullOrEmpty()) return getDefaultSampleGames()
        return try {
            val list = mutableListOf<GameItem>()
            val array = JSONArray(jsonStr)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    GameItem(
                        packageName = obj.getString("pkg"),
                        name = obj.getString("name"),
                        activityName = obj.optString("act", null),
                        addedTimestamp = obj.optLong("added", System.currentTimeMillis()),
                        lastPlayedTimestamp = obj.optLong("last", 0L),
                        isOptimized = obj.optBoolean("opt", false)
                    )
                )
            }
            list
        } catch (e: Exception) {
            getDefaultSampleGames()
        }
    }

    private fun serializeGames(list: List<GameItem>): String {
        val array = JSONArray()
        for (g in list) {
            val obj = JSONObject()
            obj.put("pkg", g.packageName)
            obj.put("name", g.name)
            obj.put("act", g.activityName)
            obj.put("added", g.addedTimestamp)
            obj.put("last", g.lastPlayedTimestamp)
            obj.put("opt", g.isOptimized)
            array.put(obj)
        }
        return array.toString()
    }

    suspend fun scanInstalledApps(): List<InstalledAppInfo> = withContext(Dispatchers.IO) {
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolveInfos = pm.queryIntentActivities(intent, 0)
        val result = mutableListOf<InstalledAppInfo>()

        for (resolveInfo in resolveInfos) {
            val pkg = resolveInfo.activityInfo.packageName
            if (pkg == context.packageName) continue

            val label = resolveInfo.loadLabel(pm).toString()
            val isGame = try {
                val appInfo = pm.getApplicationInfo(pkg, 0)
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    appInfo.category == ApplicationInfo.CATEGORY_GAME
                } else {
                    false
                }
            } catch (e: Exception) {
                false
            }
            result.add(InstalledAppInfo(packageName = pkg, name = label, isGame = isGame))
        }

        result.sortedWith(compareByDescending<InstalledAppInfo> { it.isGame }.thenBy { it.name })
    }
}
