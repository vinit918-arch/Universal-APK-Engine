package com.example.data.model

data class ClickPoint(
    val id: Int = 1,
    val x: Int = 540,
    val y: Int = 1200,
    val delayAfterMs: Long = 100L,
    val durationMs: Long = 20L,
    val label: String = "Target 1"
)

enum class ClickerMode {
    SINGLE_POINT,
    MULTI_POINT,
    SWIPE
}

data class SwipeGesture(
    val startX: Int = 300,
    val startY: Int = 1500,
    val endX: Int = 300,
    val endY: Int = 600,
    val durationMs: Long = 300L,
    val delayAfterMs: Long = 500L
)

data class AutoClickConfig(
    val mode: ClickerMode = ClickerMode.SINGLE_POINT,
    val singlePoint: ClickPoint = ClickPoint(1, 540, 1200, 100L),
    val multiPoints: List<ClickPoint> = listOf(
        ClickPoint(1, 540, 1000, 100L, label = "Point 1"),
        ClickPoint(2, 540, 1400, 100L, label = "Point 2")
    ),
    val swipe: SwipeGesture = SwipeGesture(),
    val intervalMs: Long = 100L,
    val repeatCount: Int = 0, // 0 = Infinite loop
    val jitterRadiusPx: Int = 0, // Humanized random radius (0 = exact)
    val randomDelayMs: Long = 0L // Humanized delay variation
)

data class ClickStats(
    val isRunning: Boolean = false,
    val totalClicks: Long = 0L,
    val currentCps: Double = 0.0,
    val elapsedTimeMs: Long = 0L,
    val lastClickX: Int = 0,
    val lastClickY: Int = 0,
    val activePointIndex: Int = 0
)
