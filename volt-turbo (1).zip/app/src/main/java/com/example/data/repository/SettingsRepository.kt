package com.example.data.repository

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.data.model.ColorGradingConfig
import com.example.data.model.CrosshairConfig
import com.example.data.model.CrosshairStyle
import com.example.data.model.OverlayPositions
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.settingsDataStore: DataStore<Preferences> by preferencesDataStore(name = "volt_settings_pref")

class SettingsRepository(private val context: Context) {

    private val appAnimationsKey = booleanPreferencesKey("app_animations_enabled")
    
    // Crosshair Keys
    private val crosshairEnabledKey = booleanPreferencesKey("crosshair_enabled")
    private val crosshairStyleKey = stringPreferencesKey("crosshair_style")
    private val crosshairSizeKey = floatPreferencesKey("crosshair_size")
    private val crosshairColorKey = longPreferencesKey("crosshair_color")
    private val crosshairOpacityKey = floatPreferencesKey("crosshair_opacity")
    private val crosshairOffsetXKey = floatPreferencesKey("crosshair_offset_x")
    private val crosshairOffsetYKey = floatPreferencesKey("crosshair_offset_y")

    // Color Grading Keys
    private val colorGradingEnabledKey = booleanPreferencesKey("color_grading_enabled")
    private val saturationKey = floatPreferencesKey("color_saturation")
    private val contrastKey = floatPreferencesKey("color_contrast")
    private val brightnessKey = floatPreferencesKey("color_brightness")

    // Tab Positions
    private val leftTabYKey = floatPreferencesKey("left_tab_y_ratio")
    private val rightTabYKey = floatPreferencesKey("right_tab_y_ratio")

    val appAnimationsFlow: Flow<Boolean> = context.settingsDataStore.data.map { preferences ->
        preferences[appAnimationsKey] ?: true
    }

    val crosshairFlow: Flow<CrosshairConfig> = context.settingsDataStore.data.map { preferences ->
        val styleName = preferences[crosshairStyleKey] ?: CrosshairStyle.CROSS_WITH_GAP.name
        val style = try { CrosshairStyle.valueOf(styleName) } catch (e: Exception) { CrosshairStyle.CROSS_WITH_GAP }
        CrosshairConfig(
            enabled = preferences[crosshairEnabledKey] ?: false,
            style = style,
            sizeDp = preferences[crosshairSizeKey] ?: 22f,
            colorHex = preferences[crosshairColorKey] ?: 0xFF00E5FF,
            opacity = preferences[crosshairOpacityKey] ?: 0.85f,
            offsetX = preferences[crosshairOffsetXKey] ?: 0f,
            offsetY = preferences[crosshairOffsetYKey] ?: 0f
        )
    }

    val colorGradingFlow: Flow<ColorGradingConfig> = context.settingsDataStore.data.map { preferences ->
        ColorGradingConfig(
            enabled = preferences[colorGradingEnabledKey] ?: false,
            saturation = preferences[saturationKey] ?: 1.25f,
            contrast = preferences[contrastKey] ?: 1.15f,
            brightness = preferences[brightnessKey] ?: 1.05f
        )
    }

    val overlayPositionsFlow: Flow<OverlayPositions> = context.settingsDataStore.data.map { preferences ->
        OverlayPositions(
            leftTabYRatio = preferences[leftTabYKey] ?: 0.35f,
            rightTabYRatio = preferences[rightTabYKey] ?: 0.35f
        )
    }

    suspend fun setAppAnimationsEnabled(enabled: Boolean) {
        context.settingsDataStore.edit { preferences ->
            preferences[appAnimationsKey] = enabled
        }
    }

    suspend fun updateCrosshairConfig(config: CrosshairConfig) {
        context.settingsDataStore.edit { preferences ->
            preferences[crosshairEnabledKey] = config.enabled
            preferences[crosshairStyleKey] = config.style.name
            preferences[crosshairSizeKey] = config.sizeDp
            preferences[crosshairColorKey] = config.colorHex
            preferences[crosshairOpacityKey] = config.opacity
            preferences[crosshairOffsetXKey] = config.offsetX
            preferences[crosshairOffsetYKey] = config.offsetY
        }
    }

    suspend fun updateColorGradingConfig(config: ColorGradingConfig) {
        context.settingsDataStore.edit { preferences ->
            preferences[colorGradingEnabledKey] = config.enabled
            preferences[saturationKey] = config.saturation
            preferences[contrastKey] = config.contrast
            preferences[brightnessKey] = config.brightness
        }
    }

    suspend fun updateTabPosition(isLeft: Boolean, yRatio: Float) {
        context.settingsDataStore.edit { preferences ->
            if (isLeft) {
                preferences[leftTabYKey] = yRatio.coerceIn(0.1f, 0.9f)
            } else {
                preferences[rightTabYKey] = yRatio.coerceIn(0.1f, 0.9f)
            }
        }
    }
}
