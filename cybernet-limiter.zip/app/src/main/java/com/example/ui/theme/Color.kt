package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyberpunk Palette
val CyberBlack = Color(0xFF0D1117)
val CyberDarkSurface = Color(0xFF161B22)
val CyberCardBg = Color(0xFF1B202A)
val CyberCardBorder = Color(0xFF263238)

// Neon Accents
val NeonCyan = Color(0xFF00F3FF)
val NeonCyanGlow = Color(0x3300F3FF)
val NeonGreen = Color(0xFF00FF66)
val NeonGreenGlow = Color(0x3300FF66)
val DeepPurple = Color(0xFF8A2BE2)
val ElectricViolet = Color(0xFFB026FF)
val CyberPink = Color(0xFFFF0055)
val CyberPinkGlow = Color(0x33FF0055)
val WarningAmber = Color(0xFFFFB800)

// Text Colors
val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B949E)
val TextMuted = Color(0xFF586069)
val TerminalGreen = Color(0xFF39FF14)
