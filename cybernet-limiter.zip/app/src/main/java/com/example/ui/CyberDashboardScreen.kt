package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.NetworkCheck
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import com.example.model.CommandLogEntry
import com.example.model.LimiterConfig
import com.example.model.ShizukuState
import com.example.model.UsageStatsData
import com.example.ui.theme.CyberBlack
import com.example.ui.theme.CyberCardBg
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberDarkSurface
import com.example.ui.theme.CyberPink
import com.example.ui.theme.DeepPurple
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.NeonCyanGlow
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenGlow
import com.example.ui.theme.TerminalGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.CyberViewModel
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun CyberDashboardScreen(
    viewModel: CyberViewModel,
    modifier: Modifier = Modifier
) {
    val usageStats by viewModel.usageStats.collectAsState()
    val config by viewModel.config.collectAsState()
    val shizukuStatus by viewModel.shizukuStatus.collectAsState()
    val countdownText by viewModel.countdownText.collectAsState()
    val commandLogs by viewModel.commandLogs.collectAsState()
    val hasUsagePermission by viewModel.hasUsagePermission.collectAsState()
    val isExecuting by viewModel.isExecuting.collectAsState()

    var customCommandText by remember { mutableStateOf("") }

    // Cyber background grid styling
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBlack)
            .drawBehind {
                drawCyberGrid(this)
            }
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Top Futuristic Header with Live Shizuku Indicator
            item {
                CyberHeaderCard(
                    shizukuStatus = shizukuStatus,
                    onRequestPermission = { viewModel.requestShizukuPermission() },
                    onRefresh = {
                        viewModel.refreshShizukuStatus()
                        viewModel.checkUsagePermission()
                    }
                )
            }

            // 2. Permission Banner (if Usage Access missing)
            if (!hasUsagePermission) {
                item {
                    UsagePermissionBanner(onGrantClick = { viewModel.openUsageAccessSettings() })
                }
            }

            // 3. Radial Speedometer / Progress Gauge & Countdown Timer
            item {
                CyberRadialGaugeCard(
                    usageStats = usageStats,
                    config = config,
                    countdownText = countdownText
                )
            }

            // 4. Cyber Control Toggles (Mobile & Wi-Fi Restrictions)
            item {
                CyberControlTogglesCard(
                    config = config,
                    onMobileToggle = { viewModel.setMobileRestricted(it) },
                    onWifiToggle = { viewModel.setWifiRestricted(it) }
                )
            }

            // 5. Daily Data Quota Configuration Card
            item {
                CyberQuotaConfigCard(
                    currentLimitBytes = config.dailyLimitBytes,
                    onLimitChange = { viewModel.setDailyLimit(it) }
                )
            }

            // 6. Live Usage Telemetry Cards (Mobile vs Wi-Fi)
            item {
                CyberLiveUsageCards(usageStats = usageStats)
            }

            // 7. Manual Network Lockdown & Sentinel Controls
            item {
                CyberSentinelControlsCard(
                    isLocked = config.isNetworkLocked,
                    isExecuting = isExecuting,
                    onEmergencyLock = { viewModel.emergencyLockdown() },
                    onEmergencyRelease = { viewModel.emergencyRelease() }
                )
            }

            // 8. Shizuku ADB Command Terminal & Execution Console
            item {
                CyberTerminalCard(
                    logs = commandLogs,
                    customCommand = customCommandText,
                    onCommandChange = { customCommandText = it },
                    onExecuteCommand = {
                        viewModel.executeCustomAdbCommand(customCommandText)
                        customCommandText = ""
                    },
                    onClearLogs = { viewModel.clearLogs() }
                )
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 1: Top Futuristic Header with Shizuku Indicator
// -------------------------------------------------------------
@Composable
fun CyberHeaderCard(
    shizukuStatus: ShizukuState,
    onRequestPermission: () -> Unit,
    onRefresh: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "header_pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_alpha"
    )

    val (statusColor, statusLabel, isConnected) = when (shizukuStatus) {
        ShizukuState.CONNECTED_AUTHORIZED -> Triple(NeonGreen, "SHIZUKU ACTIVE", true)
        ShizukuState.CONNECTED_NO_PERMISSION -> Triple(WarningAmber, "PERM REQUIRED", false)
        ShizukuState.CONNECTING -> Triple(NeonCyan, "CONNECTING...", false)
        ShizukuState.DISCONNECTED -> Triple(CyberPink, "DISCONNECTED", false)
        ShizukuState.UNSUPPORTED -> Triple(CyberPink, "NOT DETECTED", false)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberCardBorder, CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp)),
        shape = CutCornerShape(topStart = 16.dp, bottomEnd = 16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "CYBERNET",
                        color = NeonCyan,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LIMITER",
                        color = DeepPurple,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 2.sp
                    )
                }
                Text(
                    text = "ADB SYSTEM SENTINEL • NO-VPN CORE",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace,
                    letterSpacing = 1.sp
                )
            }

            // Live Connection Badge
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberCardBg)
                    .border(1.dp, statusColor.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                    .clickable {
                        if (shizukuStatus == ShizukuState.CONNECTED_NO_PERMISSION || shizukuStatus == ShizukuState.DISCONNECTED) {
                            onRequestPermission()
                        } else {
                            onRefresh()
                        }
                    }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
                    .testTag("shizuku_status_badge")
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(statusColor.copy(alpha = pulseAlpha))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = statusLabel,
                    color = statusColor,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(4.dp))
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh Shizuku",
                    tint = statusColor,
                    modifier = Modifier.size(12.dp)
                )
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 2: Permission Helper Banner
// -------------------------------------------------------------
@Composable
fun UsagePermissionBanner(onGrantClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, WarningAmber.copy(alpha = 0.6f), RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkSurface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = WarningAmber,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "USAGE ACCESS REQUIRED",
                    color = WarningAmber,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Enable Usage Access to query NetworkStatsManager hardware counters accurately.",
                    color = TextSecondary,
                    fontSize = 11.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onGrantClick,
                colors = ButtonDefaults.buttonColors(containerColor = WarningAmber),
                shape = RoundedCornerShape(6.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("grant_usage_perm_button")
            ) {
                Text("GRANT", color = CyberBlack, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 3: Radial Speedometer / Progress Gauge & Reset Countdown
// -------------------------------------------------------------
@Composable
fun CyberRadialGaugeCard(
    usageStats: UsageStatsData,
    config: LimiterConfig,
    countdownText: String
) {
    val totalBytes = usageStats.grandTotalBytes
    val limitBytes = config.dailyLimitBytes
    val progressFraction = if (limitBytes > 0) {
        (totalBytes.toFloat() / limitBytes.toFloat()).coerceIn(0f, 1f)
    } else 0f

    val animatedProgress by animateFloatAsState(
        targetValue = progressFraction,
        animationSpec = tween(durationMillis = 800, easing = FastOutSlowInEasing),
        label = "radial_progress"
    )

    val percentage = (progressFraction * 100).toInt()
    val totalGB = totalBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
    val limitGB = limitBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)

    val stateColor = when {
        config.isNetworkLocked -> CyberPink
        percentage >= 90 -> WarningAmber
        percentage >= 75 -> ElectricViolet
        else -> NeonCyan
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, stateColor.copy(alpha = 0.3f), RoundedCornerShape(16.dp)),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Speedometer Canvas
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(240.dp)
                    .padding(8.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    drawCyberRadialGauge(
                        progress = animatedProgress,
                        primaryColor = stateColor,
                        isLocked = config.isNetworkLocked
                    )
                }

                // Center Digital Readout
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "$percentage%",
                        color = stateColor,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Black,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Text(
                        text = if (config.isNetworkLocked) "SYSTEM LOCKED" else "USED OF QUOTA",
                        color = if (config.isNetworkLocked) CyberPink else TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = String.format("%.2f GB / %.2f GB", totalGB, limitGB),
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Countdown Timer Pill Card
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = CyberCardBg,
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.25f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = null,
                        tint = NeonCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = countdownText.uppercase(),
                        color = NeonCyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace,
                        letterSpacing = 1.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 4: Control Toggles (Cyber Switch Cards)
// -------------------------------------------------------------
@Composable
fun CyberControlTogglesCard(
    config: LimiterConfig,
    onMobileToggle: (Boolean) -> Unit,
    onWifiToggle: (Boolean) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberCardBorder, RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = NeonGreen,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "TARGET RESTRICTION INTERFACES",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Text(
                text = "When daily data limit hits, Shizuku ADB will block only the enabled interfaces without VPN.",
                color = TextSecondary,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
            )

            // Mobile Data Toggle Item
            CyberToggleRow(
                title = "Mobile Data Restriction",
                subtitle = "Enforce netd/firewall cutoff on Cellular when limit reached",
                icon = Icons.Default.SignalCellularAlt,
                isChecked = config.mobileRestricted,
                accentColor = NeonCyan,
                testTag = "mobile_data_toggle",
                onCheckedChange = onMobileToggle
            )

            // Wi-Fi Toggle Item
            CyberToggleRow(
                title = "Wi-Fi Restriction",
                subtitle = "Enforce netd/firewall cutoff on Wi-Fi when limit reached",
                icon = Icons.Default.Wifi,
                isChecked = config.wifiRestricted,
                accentColor = NeonGreen,
                testTag = "wifi_data_toggle",
                onCheckedChange = onWifiToggle
            )
        }
    }
}

@Composable
fun CyberToggleRow(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isChecked: Boolean,
    accentColor: Color,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CyberCardBg)
            .border(1.dp, if (isChecked) accentColor.copy(alpha = 0.4f) else CyberCardBorder, RoundedCornerShape(10.dp))
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (isChecked) accentColor.copy(alpha = 0.15f) else CyberDarkSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isChecked) accentColor else TextMuted,
                    modifier = Modifier.size(20.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    color = if (isChecked) TextPrimary else TextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = subtitle,
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = accentColor,
                checkedTrackColor = accentColor.copy(alpha = 0.3f),
                uncheckedThumbColor = TextMuted,
                uncheckedTrackColor = CyberDarkSurface
            )
        )
    }
}

// -------------------------------------------------------------
// COMPONENT 5: Daily Data Quota Configuration Card (Custom Input)
// -------------------------------------------------------------
@Composable
fun CyberQuotaConfigCard(
    currentLimitBytes: Long,
    onLimitChange: (Long) -> Unit
) {
    val focusManager = LocalFocusManager.current

    var selectedUnit by remember {
        mutableStateOf(if (currentLimitBytes < 1024L * 1024 * 1024) "MB" else "GB")
    }

    fun formatBytesToInput(bytes: Long, unit: String): String {
        return if (unit == "MB") {
            val mb = bytes.toDouble() / (1024.0 * 1024.0)
            if (mb == mb.toLong().toDouble()) mb.toLong().toString() else String.format(Locale.US, "%.1f", mb)
        } else {
            val gb = bytes.toDouble() / (1024.0 * 1024.0 * 1024.0)
            if (gb == gb.toLong().toDouble()) gb.toLong().toString() else String.format(Locale.US, "%.2f", gb)
        }
    }

    var inputText by remember {
        mutableStateOf(formatBytesToInput(currentLimitBytes, selectedUnit))
    }

    // Keep inputText in sync if limit changes externally (e.g. from slider or service)
    androidx.compose.runtime.LaunchedEffect(currentLimitBytes, selectedUnit) {
        val currentParsedBytes = if (selectedUnit == "MB") {
            ((inputText.toDoubleOrNull() ?: 0.0) * 1024.0 * 1024.0).toLong()
        } else {
            ((inputText.toDoubleOrNull() ?: 0.0) * 1024.0 * 1024.0 * 1024.0).toLong()
        }
        if (Math.abs(currentParsedBytes - currentLimitBytes) > 1024 * 1024) {
            inputText = formatBytesToInput(currentLimitBytes, selectedUnit)
        }
    }

    val currentGB = (currentLimitBytes.toDouble() / (1024.0 * 1024.0 * 1024.0)).toFloat()
    val maxSliderGB = maxOf(10f, currentGB.coerceAtLeast(1f))

    // Top right dynamic display text
    val parsedInput = inputText.toDoubleOrNull()
    val displayTopRight = if (parsedInput != null && parsedInput > 0) {
        if (selectedUnit == "MB") {
            if (parsedInput == parsedInput.toLong().toDouble()) "${parsedInput.toLong()} MB" else String.format(Locale.US, "%.1f MB", parsedInput)
        } else {
            if (parsedInput == parsedInput.toLong().toDouble()) "${parsedInput.toLong()}.00 GB" else String.format(Locale.US, "%.2f GB", parsedInput)
        }
    } else {
        if (selectedUnit == "MB") {
            val mb = currentLimitBytes.toDouble() / (1024.0 * 1024.0)
            if (mb == mb.toLong().toDouble()) "${mb.toLong()} MB" else String.format(Locale.US, "%.1f MB", mb)
        } else {
            String.format(Locale.US, "%.2f GB", currentGB)
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberCardBorder, RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header Row: Shield Icon, Label, and Dynamic Number Display
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Security,
                        contentDescription = null,
                        tint = DeepPurple,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "DAILY DATA CEILING",
                        color = TextPrimary,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = displayTopRight,
                    color = NeonCyan,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Black,
                    fontFamily = FontFamily.Monospace
                )
            }

            // Custom Input Row: Numeric Text Field + MB/GB Unit Selector Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Numeric Input Field
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { raw ->
                        val filtered = raw.filter { it.isDigit() || it == '.' }
                        if (filtered.count { it == '.' } <= 1 && filtered.length <= 7) {
                            inputText = filtered
                            val parsed = filtered.toDoubleOrNull()
                            if (parsed != null && parsed > 0.0) {
                                val bytes = if (selectedUnit == "MB") {
                                    (parsed * 1024.0 * 1024.0).toLong()
                                } else {
                                    (parsed * 1024.0 * 1024.0 * 1024.0).toLong()
                                }.coerceIn(1024L * 1024L, 999L * 1024 * 1024 * 1024)
                                onLimitChange(bytes)
                            }
                        }
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("quota_custom_input"),
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        color = TextPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    ),
                    placeholder = {
                        Text(
                            text = if (selectedUnit == "MB") "e.g. 750" else "e.g. 1.5",
                            color = TextMuted,
                            fontSize = 14.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Decimal,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(
                        onDone = {
                            focusManager.clearFocus()
                            if (inputText.toDoubleOrNull() == null || (inputText.toDoubleOrNull() ?: 0.0) <= 0.0) {
                                inputText = formatBytesToInput(currentLimitBytes, selectedUnit)
                            }
                        }
                    ),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = CyberCardBg,
                        unfocusedContainerColor = CyberCardBg,
                        focusedBorderColor = NeonCyan,
                        unfocusedBorderColor = CyberCardBorder,
                        cursorColor = NeonCyan
                    )
                )

                // MB / GB Unit Selector Toggle
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .background(CyberCardBg)
                        .border(1.dp, CyberCardBorder, RoundedCornerShape(10.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    listOf("MB", "GB").forEach { unit ->
                        val isSelected = (selectedUnit == unit)
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) NeonCyan else Color.Transparent)
                                .clickable {
                                    if (selectedUnit != unit) {
                                        selectedUnit = unit
                                        inputText = formatBytesToInput(currentLimitBytes, unit)
                                    }
                                }
                                .padding(horizontal = 14.dp, vertical = 12.dp)
                                .testTag("unit_toggle_${unit.lowercase()}"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = unit,
                                color = if (isSelected) CyberBlack else TextSecondary,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }
            }

            // Fine tuning slider (reflects custom value 0.1 to dynamic max)
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(2.dp)
            ) {
                Slider(
                    value = currentGB.coerceIn(0.1f, maxSliderGB),
                    onValueChange = { newGB ->
                        val bytes = (newGB * 1024 * 1024 * 1024).toLong()
                        onLimitChange(bytes)
                        inputText = formatBytesToInput(bytes, selectedUnit)
                    },
                    valueRange = 0.1f..maxSliderGB,
                    colors = SliderDefaults.colors(
                        thumbColor = NeonCyan,
                        activeTrackColor = NeonCyan,
                        inactiveTrackColor = CyberCardBorder
                    ),
                    modifier = Modifier.testTag("quota_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "SLIDER ADJUST (0.1 - ${String.format(Locale.US, "%.0f", maxSliderGB)} GB)",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "CAP: 999 GB",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 6: Live Usage Cards (Mobile vs Wi-Fi) with graphs
// -------------------------------------------------------------
@Composable
fun CyberLiveUsageCards(usageStats: UsageStatsData) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Mobile Data Card
        CyberInterfaceCard(
            title = "MOBILE DATA",
            icon = Icons.Default.SignalCellularAlt,
            accentColor = NeonCyan,
            rxBytes = usageStats.mobileRxBytes,
            txBytes = usageStats.mobileTxBytes,
            speedBps = usageStats.mobileSpeedBps,
            modifier = Modifier.weight(1f)
        )

        // Wi-Fi Card
        CyberInterfaceCard(
            title = "WI-FI STREAM",
            icon = Icons.Default.Wifi,
            accentColor = NeonGreen,
            rxBytes = usageStats.wifiRxBytes,
            txBytes = usageStats.wifiTxBytes,
            speedBps = usageStats.wifiSpeedBps,
            modifier = Modifier.weight(1f)
        )
    }
}

@Composable
fun CyberInterfaceCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    rxBytes: Long,
    txBytes: Long,
    speedBps: Long,
    modifier: Modifier = Modifier
) {
    val totalBytes = rxBytes + txBytes
    val formattedTotal = formatBytes(totalBytes)
    val formattedRx = formatBytes(rxBytes)
    val formattedTx = formatBytes(txBytes)
    val formattedSpeed = formatSpeed(speedBps)

    Card(
        modifier = modifier.border(1.dp, accentColor.copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = title,
                        color = accentColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Text(
                    text = formattedSpeed,
                    color = NeonGreen,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = formattedTotal,
                color = TextPrimary,
                fontSize = 18.sp,
                fontWeight = FontWeight.Black,
                fontFamily = FontFamily.Monospace
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Mini waveform sparkline Canvas
            Canvas(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(28.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(CyberCardBg)
            ) {
                drawCyberWaveform(this, accentColor, speedBps)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "↓ $formattedRx",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "↑ $formattedTx",
                    color = TextSecondary,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 7: Manual Network Lockdown Controls
// -------------------------------------------------------------
@Composable
fun CyberSentinelControlsCard(
    isLocked: Boolean,
    isExecuting: Boolean,
    onEmergencyLock: () -> Unit,
    onEmergencyRelease: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isLocked) CyberPink.copy(alpha = 0.6f) else CyberCardBorder,
                RoundedCornerShape(14.dp)
            ),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberDarkSurface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = if (isLocked) Icons.Default.Lock else Icons.Default.LockOpen,
                    contentDescription = null,
                    tint = if (isLocked) CyberPink else NeonCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "MANUAL OVERRIDE & SENTINEL LOCK",
                    color = TextPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Button(
                    onClick = onEmergencyLock,
                    enabled = !isExecuting && !isLocked,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberPink,
                        disabledContainerColor = CyberCardBg
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("emergency_lock_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Block,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "LOCKDOWN",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                Button(
                    onClick = onEmergencyRelease,
                    enabled = !isExecuting,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = NeonGreen,
                        contentColor = CyberBlack,
                        disabledContainerColor = CyberCardBg
                    ),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("emergency_release_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.NetworkCheck,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "RELEASE NET",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// COMPONENT 8: Shizuku Terminal Console & Command Runner
// -------------------------------------------------------------
@Composable
fun CyberTerminalCard(
    logs: List<CommandLogEntry>,
    customCommand: String,
    onCommandChange: (String) -> Unit,
    onExecuteCommand: () -> Unit,
    onClearLogs: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, NeonGreen.copy(alpha = 0.3f), RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberBlack)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Code,
                        contentDescription = null,
                        tint = TerminalGreen,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "SHIZUKU ADB TERMINAL",
                        color = TerminalGreen,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }

                IconButton(
                    onClick = onClearLogs,
                    modifier = Modifier.size(24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear logs",
                        tint = TextSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // Command output window
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(CyberDarkSurface)
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                if (logs.isEmpty()) {
                    Text(
                        text = "> Sentinel active. Waiting for system events...\n> Ready to execute commands: 'cmd connectivity set-chain3-enabled true', 'svc data disable', 'svc wifi disable'",
                        color = TextMuted,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        lineHeight = 14.sp
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize(),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        items(logs, key = { it.id }) { log ->
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "> ",
                                        color = if (log.isSuccess) TerminalGreen else CyberPink,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = log.command,
                                        color = TextPrimary,
                                        fontSize = 10.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Text(
                                    text = "  ${log.output}",
                                    color = if (log.isSuccess) TextSecondary else CyberPink,
                                    fontSize = 9.sp,
                                    fontFamily = FontFamily.Monospace
                                )
                            }
                        }
                    }
                }
            }

            // Custom ADB command input field
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = customCommand,
                    onValueChange = onCommandChange,
                    placeholder = {
                        Text(
                            "e.g. cmd connectivity set-chain3-enabled false",
                            fontSize = 11.sp,
                            color = TextMuted,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(
                        fontSize = 11.sp,
                        color = TextPrimary,
                        fontFamily = FontFamily.Monospace
                    ),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { onExecuteCommand() }),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("terminal_input"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = NeonGreen,
                        unfocusedBorderColor = CyberCardBorder,
                        focusedContainerColor = CyberDarkSurface,
                        unfocusedContainerColor = CyberDarkSurface
                    )
                )

                IconButton(
                    onClick = onExecuteCommand,
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(NeonGreen)
                        .size(44.dp)
                        .testTag("terminal_send_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = "Execute ADB",
                        tint = CyberBlack,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

// -------------------------------------------------------------
// CUSTOM CANVAS DRAWINGS (Cyber Grid, Radial Speedometer, Waveform)
// -------------------------------------------------------------
fun drawCyberGrid(scope: DrawScope) {
    val step = 48f
    val gridColor = Color(0x0A00F3FF)
    val width = scope.size.width
    val height = scope.size.height

    var x = 0f
    while (x <= width) {
        scope.drawLine(
            color = gridColor,
            start = Offset(x, 0f),
            end = Offset(x, height),
            strokeWidth = 1f
        )
        x += step
    }

    var y = 0f
    while (y <= height) {
        scope.drawLine(
            color = gridColor,
            start = Offset(0f, y),
            end = Offset(width, y),
            strokeWidth = 1f
        )
        y += step
    }
}

fun DrawScope.drawCyberRadialGauge(
    progress: Float,
    primaryColor: Color,
    isLocked: Boolean
) {
    val center = Offset(size.width / 2f, size.height / 2f)
    val radius = size.minDimension / 2f - 24f

    val startAngle = 135f
    val sweepAngle = 270f
    val currentSweep = sweepAngle * progress

    // Outer cyber track
    drawArc(
        color = Color(0xFF1E2633),
        startAngle = startAngle,
        sweepAngle = sweepAngle,
        useCenter = false,
        topLeft = Offset(center.x - radius, center.y - radius),
        size = Size(radius * 2, radius * 2),
        style = Stroke(width = 16f, cap = StrokeCap.Round)
    )

    // Glowing active progress arc
    if (progress > 0f) {
        // Outer glow
        drawArc(
            color = primaryColor.copy(alpha = 0.35f),
            startAngle = startAngle,
            sweepAngle = currentSweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = 24f, cap = StrokeCap.Round)
        )

        // Core bright arc
        drawArc(
            brush = Brush.sweepGradient(
                colors = listOf(NeonCyan, DeepPurple, primaryColor),
                center = center
            ),
            startAngle = startAngle,
            sweepAngle = currentSweep,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = Size(radius * 2, radius * 2),
            style = Stroke(width = 14f, cap = StrokeCap.Round)
        )
    }

    // Digital tick marks
    val totalTicks = 24
    for (i in 0..totalTicks) {
        val angleDeg = startAngle + (sweepAngle / totalTicks) * i
        val angleRad = Math.toRadians(angleDeg.toDouble())
        val isMajor = (i % 4 == 0)
        val tickLength = if (isMajor) 12f else 6f
        val tickColor = if (progress >= (i.toFloat() / totalTicks)) primaryColor else Color(0xFF3B485A)

        val innerR = radius - 20f
        val outerR = innerR - tickLength

        val startX = center.x + (innerR * cos(angleRad)).toFloat()
        val startY = center.y + (innerR * sin(angleRad)).toFloat()
        val endX = center.x + (outerR * cos(angleRad)).toFloat()
        val endY = center.y + (outerR * sin(angleRad)).toFloat()

        drawLine(
            color = tickColor,
            start = Offset(startX, startY),
            end = Offset(endX, endY),
            strokeWidth = if (isMajor) 3f else 1.5f,
            cap = StrokeCap.Round
        )
    }
}

fun drawCyberWaveform(scope: DrawScope, color: Color, speedBps: Long) {
    val width = scope.size.width
    val height = scope.size.height
    val path = Path()
    val count = 12
    val dx = width / count

    path.moveTo(0f, height / 2f)

    for (i in 1..count) {
        val x = i * dx
        val amp = if (speedBps > 0) {
            (sin(i * 1.3) * (height / 2.5f)).toFloat()
        } else {
            (sin(i * 0.8) * 4f).toFloat()
        }
        val y = (height / 2f) + amp
        path.lineTo(x, y)
    }

    scope.drawPath(
        path = path,
        color = color,
        style = Stroke(width = 2.5f, cap = StrokeCap.Round)
    )
}

// -------------------------------------------------------------
// HELPER UTILITIES
// -------------------------------------------------------------
fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format("%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format("%.2f MB", mb)
    val gb = mb / 1024.0
    return String.format("%.2f GB", gb)
}

fun formatSpeed(bytesPerSec: Long): String {
    if (bytesPerSec <= 0) return "0.0 KB/s"
    val kb = bytesPerSec / 1024.0
    if (kb < 1024) return String.format("%.1f KB/s", kb)
    val mb = kb / 1024.0
    return String.format("%.2f MB/s", mb)
}
