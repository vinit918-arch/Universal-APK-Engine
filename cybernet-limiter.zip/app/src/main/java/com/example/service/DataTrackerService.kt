package com.example.service

import android.app.AppOpsManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.os.Build
import android.os.IBinder
import android.os.Process
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.model.UsageStatsData
import com.example.preferences.PreferencesManager
import com.example.shizuku.ShizukuManager
import com.example.util.AlarmHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class DataTrackerService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private var trackingJob: Job? = null

    private lateinit var prefsManager: PreferencesManager
    private lateinit var shizukuManager: ShizukuManager
    private lateinit var networkStatsManager: NetworkStatsManager

    private var lastMobileBytes: Long = 0L
    private var lastWifiBytes: Long = 0L
    private var lastSampleTime: Long = 0L

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "DataTrackerService onCreate")
        prefsManager = PreferencesManager.getInstance(this)
        shizukuManager = ShizukuManager.getInstance(this)
        networkStatsManager = getSystemService(Context.NETWORK_STATS_SERVICE) as NetworkStatsManager

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildNotification("Initializing Sentinel Stream...", false))

        // Schedule 12:02 AM Daily Reset Alarm
        AlarmHelper.scheduleDailyReset(this)

        startTrackingLoop()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_REFRESH) {
            checkAndEnforceQuota()
        }
        return START_STICKY
    }

    private fun startTrackingLoop() {
        trackingJob?.cancel()
        trackingJob = serviceScope.launch {
            while (isActive) {
                try {
                    val stats = measureCurrentUsage()
                    _liveUsageStats.value = stats

                    // Check if quota limit reached
                    checkAndEnforceQuota()

                    // Update persistent notification
                    val config = prefsManager.loadConfig()
                    val totalGB = stats.grandTotalBytes.toDouble() / (1024 * 1024 * 1024)
                    val limitGB = config.dailyLimitBytes.toDouble() / (1024 * 1024 * 1024)
                    val pct = if (config.dailyLimitBytes > 0) {
                        ((stats.grandTotalBytes.toDouble() / config.dailyLimitBytes) * 100).toInt().coerceIn(0, 100)
                    } else 0

                    val notifText = String.format(
                        "%.2f GB / %.2f GB (%d%%) • %s",
                        totalGB,
                        limitGB,
                        if (config.isNetworkLocked) "LOCKED" else "ACTIVE"
                    )
                    updateNotification(notifText, config.isNetworkLocked)

                } catch (e: Exception) {
                    Log.e(TAG, "Error in tracking loop", e)
                }
                delay(2000) // 2-second telemetry pulse
            }
        }
    }

    private fun measureCurrentUsage(): UsageStatsData {
        val startTime = AlarmHelper.getTodayStartCalendar().timeInMillis
        val endTime = System.currentTimeMillis()

        var mobRx = 0L
        var mobTx = 0L
        var wifiRx = 0L
        var wifiTx = 0L

        if (hasUsageStatsPermission(this)) {
            try {
                // Query Mobile Data summary
                val mobileBucket = networkStatsManager.querySummaryForDevice(
                    ConnectivityManager.TYPE_MOBILE,
                    null,
                    startTime,
                    endTime
                )
                mobRx = mobileBucket.rxBytes
                mobTx = mobileBucket.txBytes
            } catch (e: Exception) {
                Log.w(TAG, "Error querying mobile stats: ${e.message}")
            }

            try {
                // Query Wi-Fi summary
                val wifiBucket = networkStatsManager.querySummaryForDevice(
                    ConnectivityManager.TYPE_WIFI,
                    "",
                    startTime,
                    endTime
                )
                wifiRx = wifiBucket.rxBytes
                wifiTx = wifiBucket.txBytes
            } catch (e: Exception) {
                Log.w(TAG, "Error querying wifi stats: ${e.message}")
            }
        } else {
            // Fallback using TrafficStats
            val totalMobRx = TrafficStats.getMobileRxBytes()
            val totalMobTx = TrafficStats.getMobileTxBytes()
            val totalRx = TrafficStats.getTotalRxBytes()
            val totalTx = TrafficStats.getTotalTxBytes()

            mobRx = if (totalMobRx != TrafficStats.UNSUPPORTED.toLong()) totalMobRx else 0L
            mobTx = if (totalMobTx != TrafficStats.UNSUPPORTED.toLong()) totalMobTx else 0L

            val nonMobRx = if (totalRx != TrafficStats.UNSUPPORTED.toLong()) (totalRx - mobRx).coerceAtLeast(0L) else 0L
            val nonMobTx = if (totalTx != TrafficStats.UNSUPPORTED.toLong()) (totalTx - mobTx).coerceAtLeast(0L) else 0L
            wifiRx = nonMobRx
            wifiTx = nonMobTx
        }

        // Live speed calculation
        val now = System.currentTimeMillis()
        val timeDeltaSec = if (lastSampleTime > 0) (now - lastSampleTime) / 1000.0 else 2.0
        val currentMobTotal = mobRx + mobTx
        val currentWifiTotal = wifiRx + wifiTx

        val mobSpeed = if (lastMobileBytes > 0 && timeDeltaSec > 0) {
            ((currentMobTotal - lastMobileBytes).coerceAtLeast(0L) / timeDeltaSec).toLong()
        } else 0L

        val wifiSpeed = if (lastWifiBytes > 0 && timeDeltaSec > 0) {
            ((currentWifiTotal - lastWifiBytes).coerceAtLeast(0L) / timeDeltaSec).toLong()
        } else 0L

        lastMobileBytes = currentMobTotal
        lastWifiBytes = currentWifiTotal
        lastSampleTime = now

        return UsageStatsData(
            mobileRxBytes = mobRx,
            mobileTxBytes = mobTx,
            wifiRxBytes = wifiRx,
            wifiTxBytes = wifiTx,
            mobileSpeedBps = mobSpeed,
            wifiSpeedBps = wifiSpeed,
            timestamp = now
        )
    }

    private fun checkAndEnforceQuota() {
        val config = prefsManager.loadConfig()
        val stats = _liveUsageStats.value

        // Check if restriction applies
        val relevantUsage = when {
            config.mobileRestricted && config.wifiRestricted -> stats.grandTotalBytes
            config.mobileRestricted -> stats.mobileTotalBytes
            config.wifiRestricted -> stats.wifiTotalBytes
            else -> 0L
        }

        if (relevantUsage >= config.dailyLimitBytes && config.dailyLimitBytes > 0) {
            if (!config.isNetworkLocked) {
                Log.w(TAG, "QUOTA EXCEEDED ($relevantUsage >= ${config.dailyLimitBytes})! Triggering Shizuku lockdown.")
                prefsManager.setNetworkLocked(true)
                serviceScope.launch {
                    shizukuManager.enforceRestrictions(config.mobileRestricted, config.wifiRestricted)
                }
            }
        } else {
            // Under limit: if it was locked automatically but limit was raised
            if (config.isNetworkLocked && relevantUsage < config.dailyLimitBytes) {
                Log.i(TAG, "Usage within quota ($relevantUsage < ${config.dailyLimitBytes}). Releasing lock.")
                prefsManager.setNetworkLocked(false)
                serviceScope.launch {
                    shizukuManager.liftAllRestrictions()
                }
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Cybernet Sentinel Monitor",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Live Bandwidth Sentinel and Shizuku ADB Limiter"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String, isLocked: Boolean): Notification {
        val launchIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            launchIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = if (isLocked) "🚨 CYBERNET LOCKDOWN ACTIVE" else "⚡ CYBERNET SENTINEL"

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()
    }

    private fun updateNotification(statusText: String, isLocked: Boolean) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, buildNotification(statusText, isLocked))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        trackingJob?.cancel()
    }

    companion object {
        private const val TAG = "DataTrackerService"
        const val CHANNEL_ID = "cybernet_tracker_channel"
        const val NOTIFICATION_ID = 4096
        const val ACTION_REFRESH = "com.example.ACTION_REFRESH_QUOTA"

        private val _liveUsageStats = MutableStateFlow(UsageStatsData())
        val liveUsageStats: StateFlow<UsageStatsData> = _liveUsageStats.asStateFlow()

        fun startService(context: Context) {
            val intent = Intent(context, DataTrackerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun hasUsageStatsPermission(context: Context): Boolean {
            val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as? AppOpsManager ?: return false
            val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                appOps.unsafeCheckOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            } else {
                @Suppress("DEPRECATION")
                appOps.checkOpNoThrow(
                    AppOpsManager.OPSTR_GET_USAGE_STATS,
                    Process.myUid(),
                    context.packageName
                )
            }
            return mode == AppOpsManager.MODE_ALLOWED
        }
    }
}
