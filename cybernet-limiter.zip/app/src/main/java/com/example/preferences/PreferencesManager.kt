package com.example.preferences

import android.content.Context
import android.content.SharedPreferences
import com.example.model.LimiterConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("cybernet_limiter_prefs", Context.MODE_PRIVATE)

    private val _configFlow = MutableStateFlow(loadConfig())
    val configFlow: StateFlow<LimiterConfig> = _configFlow.asStateFlow()

    fun loadConfig(): LimiterConfig {
        val limit = prefs.getLong(KEY_DAILY_LIMIT, 2L * 1024 * 1024 * 1024)
        val mobileRestricted = prefs.getBoolean(KEY_MOBILE_RESTRICTED, true)
        val wifiRestricted = prefs.getBoolean(KEY_WIFI_RESTRICTED, true)
        val isLocked = prefs.getBoolean(KEY_IS_LOCKED, false)
        val lastReset = prefs.getLong(KEY_LAST_RESET, 0L)
        return LimiterConfig(
            dailyLimitBytes = limit,
            mobileRestricted = mobileRestricted,
            wifiRestricted = wifiRestricted,
            isNetworkLocked = isLocked,
            lastResetTime = lastReset
        )
    }

    fun setDailyLimit(limitBytes: Long) {
        prefs.edit().putLong(KEY_DAILY_LIMIT, limitBytes).apply()
        _configFlow.value = _configFlow.value.copy(dailyLimitBytes = limitBytes)
    }

    fun setMobileRestricted(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_MOBILE_RESTRICTED, enabled).apply()
        _configFlow.value = _configFlow.value.copy(mobileRestricted = enabled)
    }

    fun setWifiRestricted(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_WIFI_RESTRICTED, enabled).apply()
        _configFlow.value = _configFlow.value.copy(wifiRestricted = enabled)
    }

    fun setNetworkLocked(isLocked: Boolean) {
        prefs.edit().putBoolean(KEY_IS_LOCKED, isLocked).apply()
        _configFlow.value = _configFlow.value.copy(isNetworkLocked = isLocked)
    }

    fun setLastResetTime(timestamp: Long) {
        prefs.edit().putLong(KEY_LAST_RESET, timestamp).apply()
        _configFlow.value = _configFlow.value.copy(lastResetTime = timestamp)
    }

    fun getTodayBaseUsageTime(): Long {
        return prefs.getLong(KEY_TODAY_BASE_TIME, 0L)
    }

    fun setTodayBaseUsageTime(timeMs: Long) {
        prefs.edit().putLong(KEY_TODAY_BASE_TIME, timeMs).apply()
    }

    companion object {
        private const val KEY_DAILY_LIMIT = "daily_limit_bytes"
        private const val KEY_MOBILE_RESTRICTED = "mobile_restricted"
        private const val KEY_WIFI_RESTRICTED = "wifi_restricted"
        private const val KEY_IS_LOCKED = "is_network_locked"
        private const val KEY_LAST_RESET = "last_reset_time"
        private const val KEY_TODAY_BASE_TIME = "today_base_time"

        @Volatile
        private var INSTANCE: PreferencesManager? = null

        fun getInstance(context: Context): PreferencesManager {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: PreferencesManager(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
