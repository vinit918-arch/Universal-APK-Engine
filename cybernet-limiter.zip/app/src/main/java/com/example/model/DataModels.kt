package com.example.model

data class UsageStatsData(
    val mobileRxBytes: Long = 0L,
    val mobileTxBytes: Long = 0L,
    val wifiRxBytes: Long = 0L,
    val wifiTxBytes: Long = 0L,
    val mobileSpeedBps: Long = 0L,
    val wifiSpeedBps: Long = 0L,
    val timestamp: Long = System.currentTimeMillis()
) {
    val mobileTotalBytes: Long get() = mobileRxBytes + mobileTxBytes
    val wifiTotalBytes: Long get() = wifiRxBytes + wifiTxBytes
    val grandTotalBytes: Long get() = mobileTotalBytes + wifiTotalBytes
}

data class LimiterConfig(
    val dailyLimitBytes: Long = 2L * 1024 * 1024 * 1024, // Default 2.0 GB
    val mobileRestricted: Boolean = true,
    val wifiRestricted: Boolean = true,
    val isNetworkLocked: Boolean = false,
    val lastResetTime: Long = 0L
)

enum class ShizukuState {
    DISCONNECTED,
    CONNECTING,
    CONNECTED_NO_PERMISSION,
    CONNECTED_AUTHORIZED,
    UNSUPPORTED
}

data class CommandLogEntry(
    val id: String = java.util.UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val command: String,
    val output: String,
    val exitCode: Int,
    val isSuccess: Boolean
)
