package com.example.util

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import com.example.receiver.DailyResetReceiver
import java.util.Calendar

object AlarmHelper {
    private const val TAG = "AlarmHelper"
    const val REQUEST_CODE_DAILY_RESET = 1202

    fun getNextResetCalendar(): Calendar {
        val now = Calendar.getInstance()
        val resetCal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 2)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (now.after(resetCal)) {
            // If already past 12:02 AM today, schedule for tomorrow 12:02 AM
            resetCal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return resetCal
    }

    fun getTodayStartCalendar(): Calendar {
        // Today's 12:02 AM (or 00:00 AM) start point for data calculation
        val now = Calendar.getInstance()
        val todayReset = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 2)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        if (now.before(todayReset)) {
            // If it's before 12:02 AM today, the cycle started yesterday at 12:02 AM
            todayReset.add(Calendar.DAY_OF_YEAR, -1)
        }
        return todayReset
    }

    fun scheduleDailyReset(context: Context) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val targetCalendar = getNextResetCalendar()
        val triggerTimeMs = targetCalendar.timeInMillis

        val intent = Intent(context, DailyResetReceiver::class.java).apply {
            action = DailyResetReceiver.ACTION_DAILY_RESET
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            REQUEST_CODE_DAILY_RESET,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTimeMs,
                        pendingIntent
                    )
                } else {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerTimeMs,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTimeMs,
                    pendingIntent
                )
            }
            Log.d(TAG, "Scheduled 12:02 AM Daily Reset for: ${targetCalendar.time}")
        } catch (e: SecurityException) {
            Log.w(TAG, "Exact alarm permission missing, fallback to standard alarm", e)
            alarmManager.set(AlarmManager.RTC_WAKEUP, triggerTimeMs, pendingIntent)
        }
    }

    fun formatRemainingTime(targetMillis: Long): String {
        val diff = targetMillis - System.currentTimeMillis()
        if (diff <= 0) return "Reset in 0h 00m at 12:02 AM"

        val hours = diff / (1000 * 60 * 60)
        val minutes = (diff / (1000 * 60)) % 60
        val seconds = (diff / 1000) % 60
        return if (hours > 0) {
            "Reset in ${hours}h ${String.format("%02d", minutes)}m at 12:02 AM"
        } else {
            "Reset in ${minutes}m ${String.format("%02d", seconds)}s at 12:02 AM"
        }
    }
}
