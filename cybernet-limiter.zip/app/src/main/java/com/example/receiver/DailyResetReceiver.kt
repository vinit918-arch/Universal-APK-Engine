package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import com.example.preferences.PreferencesManager
import com.example.service.DataTrackerService
import com.example.shizuku.ShizukuManager
import com.example.util.AlarmHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DailyResetReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action
        Log.d(TAG, "Received broadcast action: $action")

        val prefs = PreferencesManager.getInstance(context)
        val shizukuManager = ShizukuManager.getInstance(context)

        when (action) {
            ACTION_DAILY_RESET -> {
                Log.i(TAG, "12:02 AM Daily Reset Triggered: Resetting quota and restoring network...")

                val now = System.currentTimeMillis()
                prefs.setLastResetTime(now)
                prefs.setTodayBaseUsageTime(now)
                prefs.setNetworkLocked(false)

                // Execute ADB command to unblock connectivity
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        shizukuManager.liftAllRestrictions()
                        Log.i(TAG, "12:02 AM Unblock command executed successfully via Shizuku ADB.")
                    } catch (e: Throwable) {
                        Log.e(TAG, "Failed to unlock network during daily reset", e)
                    }
                }

                // Reschedule for next day 12:02 AM
                AlarmHelper.scheduleDailyReset(context)

                // Refresh foreground service
                val serviceIntent = Intent(context, DataTrackerService::class.java).apply {
                    this.action = DataTrackerService.ACTION_REFRESH
                }
                try {
                    context.startService(serviceIntent)
                } catch (e: Throwable) {
                    Log.w(TAG, "Could not start service: ${e.message}")
                }
            }

            Intent.ACTION_BOOT_COMPLETED -> {
                Log.d(TAG, "Device booted. Rescheduling 12:02 AM alarm and restarting sentinel service.")
                AlarmHelper.scheduleDailyReset(context)
                DataTrackerService.startService(context)
            }
        }
    }

    companion object {
        private const val TAG = "DailyResetReceiver"
        const val ACTION_DAILY_RESET = "com.example.ACTION_DAILY_RESET"
    }
}
