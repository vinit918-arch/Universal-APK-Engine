package com.example.viewmodel

import android.app.Application
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.CommandLogEntry
import com.example.model.LimiterConfig
import com.example.model.ShizukuState
import com.example.model.UsageStatsData
import com.example.preferences.PreferencesManager
import com.example.service.DataTrackerService
import com.example.shizuku.ShizukuManager
import com.example.util.AlarmHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class CyberViewModel(application: Application) : AndroidViewModel(application) {

    private val prefsManager = PreferencesManager.getInstance(application)
    private val shizukuManager = ShizukuManager.getInstance(application)

    val config: StateFlow<LimiterConfig> = prefsManager.configFlow
    val usageStats: StateFlow<UsageStatsData> = DataTrackerService.liveUsageStats
    val shizukuStatus: StateFlow<ShizukuState> = shizukuManager.statusFlow
    val commandLogs: StateFlow<List<CommandLogEntry>> = shizukuManager.commandLogs

    private val _countdownText = MutableStateFlow(AlarmHelper.formatRemainingTime(AlarmHelper.getNextResetCalendar().timeInMillis))
    val countdownText: StateFlow<String> = _countdownText.asStateFlow()

    private val _hasUsagePermission = MutableStateFlow(DataTrackerService.hasUsageStatsPermission(application))
    val hasUsagePermission: StateFlow<Boolean> = _hasUsagePermission.asStateFlow()

    private val _isExecuting = MutableStateFlow(false)
    val isExecuting: StateFlow<Boolean> = _isExecuting.asStateFlow()

    init {
        // Start countdown ticker
        viewModelScope.launch {
            while (isActive) {
                val nextResetTime = AlarmHelper.getNextResetCalendar().timeInMillis
                _countdownText.value = AlarmHelper.formatRemainingTime(nextResetTime)
                _hasUsagePermission.value = DataTrackerService.hasUsageStatsPermission(getApplication())
                delay(1000)
            }
        }
    }

    fun checkUsagePermission() {
        _hasUsagePermission.value = DataTrackerService.hasUsageStatsPermission(getApplication())
    }

    fun requestShizukuPermission() {
        shizukuManager.requestPermission()
    }

    fun refreshShizukuStatus() {
        shizukuManager.checkStatus()
    }

    fun setDailyLimit(limitBytes: Long) {
        prefsManager.setDailyLimit(limitBytes)
        // Check quota immediately
        val intent = Intent(getApplication(), DataTrackerService::class.java).apply {
            action = DataTrackerService.ACTION_REFRESH
        }
        getApplication<Application>().startService(intent)
    }

    fun setMobileRestricted(enabled: Boolean) {
        prefsManager.setMobileRestricted(enabled)
        val intent = Intent(getApplication(), DataTrackerService::class.java).apply {
            action = DataTrackerService.ACTION_REFRESH
        }
        getApplication<Application>().startService(intent)
    }

    fun setWifiRestricted(enabled: Boolean) {
        prefsManager.setWifiRestricted(enabled)
        val intent = Intent(getApplication(), DataTrackerService::class.java).apply {
            action = DataTrackerService.ACTION_REFRESH
        }
        getApplication<Application>().startService(intent)
    }

    fun emergencyLockdown() {
        viewModelScope.launch {
            _isExecuting.value = true
            prefsManager.setNetworkLocked(true)
            shizukuManager.lockGlobalNetwork()
            _isExecuting.value = false
        }
    }

    fun emergencyRelease() {
        viewModelScope.launch {
            _isExecuting.value = true
            prefsManager.setNetworkLocked(false)
            shizukuManager.liftAllRestrictions()
            _isExecuting.value = false
        }
    }

    fun executeCustomAdbCommand(cmd: String) {
        if (cmd.isBlank()) return
        viewModelScope.launch {
            _isExecuting.value = true
            shizukuManager.executeCommand(cmd.trim())
            _isExecuting.value = false
        }
    }

    fun clearLogs() {
        shizukuManager.clearLogs()
    }

    fun openUsageAccessSettings() {
        val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        getApplication<Application>().startActivity(intent)
    }
}
