package com.example

import android.app.Application
import com.example.service.DataTrackerService
import com.example.shizuku.ShizukuManager
import com.example.util.AlarmHelper

class CybernetApp : Application() {

    override fun onCreate() {
        super.onCreate()
        // Initialize Shizuku binder listener
        ShizukuManager.getInstance(this)

        // Schedule 12:02 AM Daily Alarm
        AlarmHelper.scheduleDailyReset(this)

        // Start Foreground monitoring service
        DataTrackerService.startService(this)
    }
}
