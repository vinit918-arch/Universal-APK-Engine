package com.example.service.views

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import com.example.data.TargetPoint
import kotlin.math.abs

/**
 * State B: Draggable precision crosshair target marker.
 * Pinpoints the exact screen coordinate that will receive simulated taps.
 */
@SuppressLint("ViewConstructor")
class TargetMarkerView(
    context: Context,
    private val windowManager: WindowManager,
    val layoutParams: WindowManager.LayoutParams,
    var targetPoint: TargetPoint,
    private val onTargetMoved: (point: TargetPoint) -> Unit
) : View(context) {

    private val density = context.resources.displayMetrics.density
    val markerSize = (64 * density).toInt()

    var isLocked: Boolean = false
    var isDimmed: Boolean = false
        set(value) {
            field = value
            alpha = if (value) 0.22f else 1.0f
            invalidate()
        }

    var isHighlighted: Boolean = false
        set(value) {
            field = value
            invalidate()
        }

    // Reticle styling
    private val outerRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F43F5E") // Rose red / high contrast
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
    }

    private val highlightRingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#10B981") // Emerald green when tapped
        style = Paint.Style.STROKE
        strokeWidth = 3.5f * density
    }

    private val crosshairPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FFFFFF")
        style = Paint.Style.STROKE
        strokeWidth = 1.8f * density
    }

    private val centerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F43F5E")
        style = Paint.Style.FILL
    }

    private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F172A")
        style = Paint.Style.FILL
    }

    private val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 10f * density
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val coordTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E2E8F0")
        textSize = 8.5f * density
        textAlign = Paint.Align.CENTER
    }

    private val badgeRect = RectF()

    // Touch and drag tracking
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false
    private val touchSlop = 6 * density

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(markerSize, markerSize + (16 * density).toInt())
    }

    /**
     * Computes the exact screen coordinate at the center of the crosshair reticle.
     */
    fun getCenterScreenCoordinates(): Pair<Int, Int> {
        val cx = layoutParams.x + (markerSize / 2)
        val cy = layoutParams.y + (markerSize / 2)
        return Pair(cx, cy)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = markerSize / 2f
        val cy = markerSize / 2f
        val radius = (markerSize / 2f) - (8 * density)

        // Outer Reticle Circle
        val ring = if (isHighlighted) highlightRingPaint else outerRingPaint
        canvas.drawCircle(cx, cy, radius, ring)

        // Center Pinpoint Dot
        canvas.drawCircle(cx, cy, 3 * density, centerDotPaint)

        // Crosshair Lines with gap in center
        val gap = 5 * density
        val ext = radius + (4 * density)
        // Horizontal
        canvas.drawLine(cx - ext, cy, cx - gap, cy, crosshairPaint)
        canvas.drawLine(cx + gap, cy, cx + ext, cy, crosshairPaint)
        // Vertical
        canvas.drawLine(cx, cy - ext, cx, cy - gap, crosshairPaint)
        canvas.drawLine(cx, cy + gap, cx, cy + ext, crosshairPaint)

        // Target Number Badge (Top Right)
        val badgeRadius = 7 * density
        val badgeCx = cx + radius - (2 * density)
        val badgeCy = cy - radius + (2 * density)
        canvas.drawCircle(badgeCx, badgeCy, badgeRadius, badgeBgPaint)
        canvas.drawCircle(badgeCx, badgeCy, badgeRadius, outerRingPaint)
        canvas.drawText("${targetPoint.id}", badgeCx, badgeCy + (3.5f * density), badgeTextPaint)

        // Coordinate Label Tag at bottom
        if (!isDimmed) {
            val labelY = markerSize + (12 * density)
            val centerCoords = getCenterScreenCoordinates()
            val coordStr = "(${centerCoords.first}, ${centerCoords.second})"

            val pillWidth = coordTextPaint.measureText(coordStr) + (8 * density)
            badgeRect.set(
                cx - (pillWidth / 2f),
                markerSize + (2 * density),
                cx + (pillWidth / 2f),
                markerSize + (14 * density)
            )
            canvas.drawRoundRect(badgeRect, 4 * density, 4 * density, badgeBgPaint)
            canvas.drawText(coordStr, cx, labelY, coordTextPaint)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (isLocked) {
            // Immovable when locked
            return false
        }

        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = layoutParams.x
                initialY = layoutParams.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                isDragging = false
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY

                if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                    isDragging = true
                }

                if (isDragging) {
                    layoutParams.x = (initialX + dx).toInt()
                    layoutParams.y = (initialY + dy).toInt()

                    val center = getCenterScreenCoordinates()
                    targetPoint.x = center.first
                    targetPoint.y = center.second

                    try {
                        windowManager.updateViewLayout(this, layoutParams)
                        invalidate()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (isDragging) {
                    val center = getCenterScreenCoordinates()
                    targetPoint.x = center.first
                    targetPoint.y = center.second
                    onTargetMoved(targetPoint)
                }
                isDragging = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
