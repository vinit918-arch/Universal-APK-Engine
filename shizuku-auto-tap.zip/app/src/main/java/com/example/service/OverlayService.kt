package com.example.service

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.OverlayPreferences
import com.example.data.TargetPoint
import com.example.data.TriggerButtonSize
import com.example.service.views.BulletView
import com.example.service.views.SettingsHUDView
import com.example.service.views.TargetMarkerView
import com.example.service.views.TriggerView
import com.example.shizuku.ShizukuTapController
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

/**
 * Foreground service managing the floating overlay window views,
 * state machine (Collapsed / Expanded / Locked), and privileged tap dispatch via Shizuku.
 */
class OverlayService : Service(), SettingsHUDView.HUDCallbacks {

    companion object {
        private const val TAG = "OverlayService"
        const val NOTIFICATION_ID = 1010
        const val CHANNEL_ID = "autotap_overlay_channel"

        const val ACTION_START = "com.example.service.ACTION_START"
        const val ACTION_STOP = "com.example.service.ACTION_STOP"

        var isRunning: Boolean = false
            private set
    }

    enum class OverlayState {
        COLLAPSED, // State A: Single floating bullet snapped to screen edge
        EXPANDED   // State B: Trigger dot, target crosshair(s), and settings HUD
    }

    private lateinit var windowManager: WindowManager
    private lateinit var prefs: OverlayPreferences
    private lateinit var vibratorHelper: VibratorHelper
    private val shizukuController = ShizukuTapController.getInstance()

    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())

    private var currentState = OverlayState.EXPANDED

    // Floating Views
    private var bulletView: BulletView? = null
    private var triggerView: TriggerView? = null
    private val targetViews = mutableListOf<TargetMarkerView>()
    private var hudView: SettingsHUDView? = null

    private var screenWidth = 1080
    private var screenHeight = 2400

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        isRunning = true
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = OverlayPreferences(this)
        vibratorHelper = VibratorHelper(this)

        updateScreenDimensions()
        createNotificationChannel()
        startForegroundServiceNotification()

        shizukuController.registerListeners()
        observeShizukuStatus()

        // Initialize and display overlay views
        showExpandedOverlay()
    }

    private fun updateScreenDimensions() {
        val displayMetrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        screenWidth = displayMetrics.widthPixels
        screenHeight = displayMetrics.heightPixels
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                Log.d(TAG, "Stopping OverlayService via intent action")
                stopSelf()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    // ==================== NOTIFICATION SETUP ====================

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Auto Tap Overlay Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps the privileged Auto Tap Assistant floating overlay active."
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun startForegroundServiceNotification() {
        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openAppPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, OverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Auto Tap Assistant Active")
            .setContentText("Overlay running. Press-and-hold trigger to automate taps.")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(openAppPendingIntent)
            .addAction(android.R.drawable.ic_delete, "Stop Overlay", stopPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    // ==================== SHIZUKU MONITORING ====================

    private fun observeShizukuStatus() {
        serviceScope.launch {
            shizukuController.connectionState.collectLatest { state ->
                val isReady = state is ShizukuTapController.ConnectionState.Ready
                val statusText = when (state) {
                    is ShizukuTapController.ConnectionState.Ready -> "Ready"
                    is ShizukuTapController.ConnectionState.PermissionRequired -> "Permission Required"
                    is ShizukuTapController.ConnectionState.ShizukuNotRunning -> "Service Disconnected"
                    is ShizukuTapController.ConnectionState.Error -> state.message
                    else -> "Checking..."
                }

                hudView?.updateShizukuStatus(isReady, statusText)
                triggerView?.isEnabledState = isReady

                if (!isReady && isRunning) {
                    Toast.makeText(
                        this@OverlayService,
                        "Shizuku: $statusText",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }

    // ==================== STATE MACHINE & VIEW MANAGEMENT ====================

    private fun createOverlayLayoutParams(
        width: Int = WindowManager.LayoutParams.WRAP_CONTENT,
        height: Int = WindowManager.LayoutParams.WRAP_CONTENT,
        x: Int = 0,
        y: Int = 0
    ): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        return WindowManager.LayoutParams(
            width,
            height,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            this.x = x
            this.y = y
        }
    }

    /**
     * Switches to State A: Collapsed mode.
     */
    private fun showCollapsedOverlay() {
        currentState = OverlayState.COLLAPSED
        removeExpandedViews()

        val savedBulletPos = prefs.bulletPosition
        val lp = createOverlayLayoutParams(
            x = savedBulletPos.first,
            y = savedBulletPos.second
        )

        bulletView = BulletView(
            context = this,
            windowManager = windowManager,
            layoutParams = lp,
            onExpandClicked = { showExpandedOverlay() },
            onPositionChanged = { x, y -> prefs.bulletPosition = Pair(x, y) }
        )

        try {
            windowManager.addView(bulletView, lp)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding bullet view", e)
        }
    }

    /**
     * Switches to State B: Expanded mode.
     */
    private fun showExpandedOverlay() {
        currentState = OverlayState.EXPANDED
        removeCollapsedView()

        // 1. Target Markers
        val targetPoints = prefs.getTargetPoints(screenWidth, screenHeight)
        targetViews.clear()

        for (point in targetPoints) {
            addTargetMarkerView(point)
        }

        // 2. Trigger Dot View
        val savedTriggerPos = prefs.triggerPosition
        val triggerLp = createOverlayLayoutParams(
            x = savedTriggerPos.first,
            y = savedTriggerPos.second
        )

        triggerView = TriggerView(
            context = this,
            windowManager = windowManager,
            layoutParams = triggerLp,
            buttonSize = prefs.triggerButtonSize,
            onStartTapping = { handleStartContinuousTapping() },
            onStopTapping = { handleStopContinuousTapping() },
            onPositionChanged = { x, y -> prefs.triggerPosition = Pair(x, y) }
        ).apply {
            isLocked = prefs.isLocked
            isDimmed = prefs.isDimmed
            isEnabledState = shizukuController.isReady()
        }

        try {
            windowManager.addView(triggerView, triggerLp)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding trigger view", e)
        }

        // 3. Floating Settings HUD Panel
        val hudLp = createOverlayLayoutParams(
            x = (screenWidth * 0.1f).toInt().coerceAtLeast(20),
            y = (screenHeight * 0.58f).toInt().coerceAtLeast(300)
        )

        hudView = SettingsHUDView(
            context = this,
            windowManager = windowManager,
            layoutParams = hudLp,
            prefs = prefs,
            callbacks = this
        ).apply {
            setLockState(prefs.isLocked)
            updateTargetCount(targetViews.size)
            updateShizukuStatus(
                shizukuController.isReady(),
                if (shizukuController.isReady()) "Ready" else "Disconnected"
            )
        }

        try {
            windowManager.addView(hudView, hudLp)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding HUD view", e)
        }
    }

    private fun addTargetMarkerView(point: TargetPoint) {
        val density = resources.displayMetrics.density
        val markerHalfSize = (32 * density).toInt()

        // Convert center point to layout x, y
        val lp = createOverlayLayoutParams(
            x = (point.x - markerHalfSize).coerceAtLeast(0),
            y = (point.y - markerHalfSize).coerceAtLeast(0)
        )

        val targetView = TargetMarkerView(
            context = this,
            windowManager = windowManager,
            layoutParams = lp,
            targetPoint = point,
            onTargetMoved = { updated ->
                saveAllTargetPoints()
            }
        ).apply {
            isLocked = prefs.isLocked
            isDimmed = prefs.isDimmed
        }

        targetViews.add(targetView)
        try {
            windowManager.addView(targetView, lp)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding target marker view", e)
        }
    }

    private fun saveAllTargetPoints() {
        val points = targetViews.map { it.targetPoint }
        prefs.saveTargetPoints(points)
    }

    private fun removeCollapsedView() {
        bulletView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            bulletView = null
        }
    }

    private fun removeExpandedViews() {
        triggerView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            triggerView = null
        }

        for (targetView in targetViews) {
            try {
                windowManager.removeView(targetView)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
        targetViews.clear()

        hudView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            hudView = null
        }
    }

    // ==================== TAP DISPATCHING ====================

    private fun handleStartContinuousTapping() {
        if (!shizukuController.isReady()) {
            Toast.makeText(this, "Shizuku not ready! Open app to connect.", Toast.LENGTH_SHORT).show()
            return
        }

        val coordinates: List<Pair<Int, Int>> = if (prefs.isMultiTargetCyclingEnabled && targetViews.size > 1) {
            targetViews.map { it.getCenterScreenCoordinates() }
        } else {
            // Use primary / first target coordinate
            listOf(targetViews.firstOrNull()?.getCenterScreenCoordinates() ?: Pair(500, 800))
        }

        shizukuController.startContinuousTapping(
            scope = serviceScope,
            targetCoordinates = coordinates,
            speedHz = prefs.tapSpeedHz,
            safetyLimit = prefs.safetyLimit,
            onEachTap = { count, tappedCoord ->
                // Update live count badge on trigger
                triggerView?.updateTapCount(count)

                // Dispatch tactile feedback
                if (prefs.isVibrationEnabled) {
                    vibratorHelper.triggerTapHaptic()
                }

                // Briefly highlight the active target marker
                targetViews.forEach { marker ->
                    val center = marker.getCenterScreenCoordinates()
                    marker.isHighlighted = (center == tappedCoord)
                }
            },
            onComplete = { totalTaps ->
                targetViews.forEach { it.isHighlighted = false }
            }
        )
    }

    private fun handleStopContinuousTapping() {
        shizukuController.stopTapping()
        targetViews.forEach { it.isHighlighted = false }
    }

    // ==================== HUD CALLBACKS ====================

    override fun onLockToggled(isLocked: Boolean) {
        prefs.isLocked = isLocked
        triggerView?.isLocked = isLocked
        targetViews.forEach { it.isLocked = isLocked }
        hudView?.setLockState(isLocked)
    }

    override fun onSpeedChanged(speedHz: Int) {
        prefs.tapSpeedHz = speedHz
    }

    override fun onDimToggled(isDimmed: Boolean) {
        prefs.isDimmed = isDimmed
        triggerView?.isDimmed = isDimmed
        targetViews.forEach { it.isDimmed = isDimmed }
    }

    override fun onTriggerSizeChanged(size: TriggerButtonSize) {
        prefs.triggerButtonSize = size
        triggerView?.let { tv ->
            tv.buttonSize = size
            tv.requestLayout()
            tv.invalidate()
        }
    }

    override fun onAddTargetPoint() {
        if (targetViews.size >= 8) {
            Toast.makeText(this, "Maximum 8 targets allowed", Toast.LENGTH_SHORT).show()
            return
        }

        val newId = targetViews.size + 1
        val lastPoint = targetViews.lastOrNull()?.targetPoint
        val newX = (lastPoint?.x ?: 500) + 120
        val newY = (lastPoint?.y ?: 800) + 120

        val newPoint = TargetPoint(newId, newX, newY, "Target $newId")
        addTargetMarkerView(newPoint)
        saveAllTargetPoints()
        hudView?.updateTargetCount(targetViews.size)
    }

    override fun onRemoveTargetPoint() {
        if (targetViews.size <= 1) {
            Toast.makeText(this, "At least 1 target point is required", Toast.LENGTH_SHORT).show()
            return
        }

        val lastView = targetViews.removeAt(targetViews.size - 1)
        try {
            windowManager.removeView(lastView)
        } catch (e: Exception) {
            e.printStackTrace()
        }
        saveAllTargetPoints()
        hudView?.updateTargetCount(targetViews.size)
    }

    override fun onCycleTargetsToggled(enabled: Boolean) {
        prefs.isMultiTargetCyclingEnabled = enabled
    }

    override fun onVibrationToggled(enabled: Boolean) {
        prefs.isVibrationEnabled = enabled
    }

    override fun onSafetyLimitChanged(limit: Int) {
        prefs.safetyLimit = limit
    }

    override fun onCollapseClicked() {
        showCollapsedOverlay()
    }

    override fun onCloseServiceClicked() {
        stopSelf()
    }

    override fun onPositionChanged(x: Int, y: Int) {
        // HUD moved
    }

    // ==================== CLEANUP ====================

    override fun onDestroy() {
        super.onDestroy()
        isRunning = false
        shizukuController.stopTapping()
        shizukuController.unregisterListeners()
        serviceScope.cancel()

        removeCollapsedView()
        removeExpandedViews()
        Log.d(TAG, "OverlayService destroyed and all views cleared")
    }
}
