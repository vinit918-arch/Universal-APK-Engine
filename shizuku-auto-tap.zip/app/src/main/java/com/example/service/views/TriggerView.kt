package com.example.service.views

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import com.example.data.TriggerButtonSize
import kotlin.math.abs

/**
 * State B: Large dot "Trigger" button.
 * - In Unlocked state: Draggable to reposition anywhere.
 * - In Locked state: Press-and-hold repeatedly dispatches tap commands at target coordinate(s).
 *   Releasing immediately ceases tap execution.
 */
@SuppressLint("ViewConstructor")
class TriggerView(
    context: Context,
    private val windowManager: WindowManager,
    val layoutParams: WindowManager.LayoutParams,
    var buttonSize: TriggerButtonSize = TriggerButtonSize.MEDIUM,
    private val onStartTapping: () -> Unit,
    private val onStopTapping: () -> Unit,
    private val onPositionChanged: (x: Int, y: Int) -> Unit
) : View(context) {

    private val density = context.resources.displayMetrics.density

    var isLocked: Boolean = false
    var isDimmed: Boolean = false
        set(value) {
            field = value
            alpha = if (value) 0.25f else 1.0f
            invalidate()
        }

    var isEnabledState: Boolean = true
        set(value) {
            field = value
            invalidate()
        }

    private var tapCount: Int = 0
    private var isPressHeld: Boolean = false

    // Paints
    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#4F46E5") // Indigo-600
        style = Paint.Style.FILL
        setShadowLayer(10 * density, 0f, 4 * density, Color.parseColor("#99000000"))
    }

    private val activeGlowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#06B6D4") // Cyan glow
        style = Paint.Style.STROKE
        strokeWidth = 3 * density
    }

    private val disabledBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#64748B") // Muted slate when Shizuku disconnected
        style = Paint.Style.FILL
    }

    private val innerDotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val counterBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#0F172A")
        style = Paint.Style.FILL
    }

    private val counterTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#38BDF8")
        textSize = 12 * density
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }

    private val labelTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E2E8F0")
        textSize = 9 * density
        textAlign = Paint.Align.CENTER
    }

    private val counterRect = RectF()

    // Touch and drag tracking
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false
    private val touchSlop = 8 * density

    // Pulse animation for active hold
    private var pulseRadius = 0f
    private var pulseAnimator: ValueAnimator? = null

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null)
    }

    fun getPixelSize(): Int = (buttonSize.dpValue * density).toInt()

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val size = getPixelSize()
        // Extra vertical space for the live tap counter badge above button
        setMeasuredDimension(size, size + (26 * density).toInt())
    }

    fun updateTapCount(count: Int) {
        this.tapCount = count
        invalidate()
    }

    private fun startPulseAnimation() {
        val baseRadius = (getPixelSize() / 2f) - (8 * density)
        pulseAnimator?.cancel()
        pulseAnimator = ValueAnimator.ofFloat(baseRadius, baseRadius + (12 * density)).apply {
            duration = 400
            repeatCount = ValueAnimator.INFINITE
            repeatMode = ValueAnimator.REVERSE
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                pulseRadius = anim.animatedValue as Float
                invalidate()
            }
        }
        pulseAnimator?.start()
    }

    private fun stopPulseAnimation() {
        pulseAnimator?.cancel()
        pulseAnimator = null
        pulseRadius = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = getPixelSize()
        val cx = size / 2f
        val cy = (24 * density) + (size / 2f)
        val radius = (size / 2f) - (8 * density)

        // Draw active pulsing ring if holding
        if (isPressHeld && pulseRadius > 0) {
            activeGlowPaint.alpha = 180
            canvas.drawCircle(cx, cy, pulseRadius, activeGlowPaint)
        }

        // Draw Trigger Circle Body
        val bodyPaint = if (!isEnabledState) disabledBgPaint else bgPaint
        canvas.drawCircle(cx, cy, radius, bodyPaint)

        // Inner glowing ring
        if (isEnabledState) {
            canvas.drawCircle(cx, cy, radius - (4 * density), activeGlowPaint)
        }

        // Center dot / indicator
        if (isLocked) {
            // Center tap dot
            canvas.drawCircle(cx, cy, 6 * density, innerDotPaint)
        } else {
            // Drag icon / cross hint
            canvas.drawCircle(cx, cy, 4 * density, innerDotPaint)
            canvas.drawText("DRAG", cx, cy + (12 * density), labelTextPaint)
        }

        // Live Tap Counter Badge floating at the top of the trigger button
        if (isPressHeld || tapCount > 0) {
            val countStr = "⚡ $tapCount"
            val badgeWidth = counterTextPaint.measureText(countStr) + (14 * density)
            val badgeHeight = 18 * density
            val badgeTop = 2 * density
            val badgeBottom = badgeTop + badgeHeight

            counterRect.set(
                cx - (badgeWidth / 2f),
                badgeTop,
                cx + (badgeWidth / 2f),
                badgeBottom
            )
            canvas.drawRoundRect(counterRect, 8 * density, 8 * density, counterBgPaint)
            canvas.drawRoundRect(counterRect, 8 * density, 8 * density, activeGlowPaint)
            canvas.drawText(countStr, cx, badgeTop + (13 * density), counterTextPaint)
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (!isEnabledState) {
            return false
        }

        if (isLocked) {
            // LOCKED MODE: Press-and-hold triggers continuous auto-tapping
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    isPressHeld = true
                    tapCount = 0
                    startPulseAnimation()
                    onStartTapping()
                    invalidate()
                    return true
                }

                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (isPressHeld) {
                        isPressHeld = false
                        stopPulseAnimation()
                        onStopTapping()
                        invalidate()
                    }
                    return true
                }
            }
        } else {
            // UNLOCKED MODE: Draggable repositioning
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = layoutParams.x
                    initialY = layoutParams.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    isDragging = false
                    return true
                }

                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY

                    if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                        isDragging = true
                    }

                    if (isDragging) {
                        layoutParams.x = (initialX + dx).toInt()
                        layoutParams.y = (initialY + dy).toInt()
                        try {
                            windowManager.updateViewLayout(this, layoutParams)
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                    return true
                }

                MotionEvent.ACTION_UP -> {
                    if (isDragging) {
                        onPositionChanged(layoutParams.x, layoutParams.y)
                    }
                    isDragging = false
                    return true
                }
            }
        }
        return super.onTouchEvent(event)
    }
}
