package com.example.service.views

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import com.example.data.OverlayPreferences
import com.example.data.TriggerButtonSize
import kotlin.math.abs

/**
 * Floating Settings Panel & HUD for the Auto Tap Assistant overlay.
 * Controls speed, lock/unlock state, dim visibility, multi-target points, and service termination.
 */
@SuppressLint("ViewConstructor")
class SettingsHUDView(
    context: Context,
    private val windowManager: WindowManager,
    val layoutParams: WindowManager.LayoutParams,
    private val prefs: OverlayPreferences,
    private val callbacks: HUDCallbacks
) : FrameLayout(context) {

    interface HUDCallbacks {
        fun onLockToggled(isLocked: Boolean)
        fun onSpeedChanged(speedHz: Int)
        fun onDimToggled(isDimmed: Boolean)
        fun onTriggerSizeChanged(size: TriggerButtonSize)
        fun onAddTargetPoint()
        fun onRemoveTargetPoint()
        fun onCycleTargetsToggled(enabled: Boolean)
        fun onVibrationToggled(enabled: Boolean)
        fun onSafetyLimitChanged(limit: Int)
        fun onCollapseClicked()
        fun onCloseServiceClicked()
        fun onPositionChanged(x: Int, y: Int)
    }

    private val density = context.resources.displayMetrics.density

    // Containers
    private val fullPanel: LinearLayout
    private val miniPanel: LinearLayout

    // UI elements
    private val speedValueLabel: TextView
    private val speedSeekBar: SeekBar
    private val lockBtn: TextView
    private val miniUnlockBtn: TextView
    private val dimSwitch: Switch
    private val vibrationSwitch: Switch
    private val cycleSwitch: Switch
    private val safetyLimitLabel: TextView
    private val targetCountLabel: TextView
    private val shizukuStatusBadge: TextView
    private val sizeSmallBtn: TextView
    private val sizeMediumBtn: TextView
    private val sizeLargeBtn: TextView

    // Drag tracking for HUD card
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false
    private val touchSlop = 8 * density

    init {
        // Root container styling
        val bgDrawable = GradientDrawable().apply {
            setColor(Color.parseColor("#0F172A")) // Slate 900
            cornerRadius = 16 * density
            setStroke((1.5f * density).toInt(), Color.parseColor("#334155")) // Slate 700
        }
        background = bgDrawable
        setPadding(
            (12 * density).toInt(),
            (10 * density).toInt(),
            (12 * density).toInt(),
            (12 * density).toInt()
        )

        // ==================== MINI BAR (When Locked) ====================
        miniPanel = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            visibility = View.GONE

            val miniTitle = TextView(context).apply {
                text = "⚡ Tap Locked"
                setTextColor(Color.parseColor("#38BDF8"))
                textSize = 12f
                typeface = android.graphics.Typeface.DEFAULT_BOLD
                setPadding(0, 0, (12 * density).toInt(), 0)
            }
            addView(miniTitle)

            miniUnlockBtn = createButton("🔓 Unlock", Color.parseColor("#4F46E5")) {
                callbacks.onLockToggled(false)
            }
            addView(miniUnlockBtn)

            val miniCollapseBtn = createIconButton("🔽") {
                callbacks.onCollapseClicked()
            }
            addView(miniCollapseBtn)
        }
        addView(miniPanel)

        // ==================== FULL SETTINGS PANEL ====================
        fullPanel = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LayoutParams(
                (290 * density).toInt(),
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        addView(fullPanel)

        // 1. Header with title, Shizuku status, minimize and close
        val headerRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, (8 * density).toInt())
            }
        }

        val titleTv = TextView(context).apply {
            text = "⚡ Auto Tap HUD"
            setTextColor(Color.WHITE)
            textSize = 14f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        headerRow.addView(titleTv)

        shizukuStatusBadge = TextView(context).apply {
            text = "● Ready"
            setTextColor(Color.parseColor("#10B981"))
            textSize = 10f
            setPadding((6 * density).toInt(), (2 * density).toInt(), (6 * density).toInt(), (2 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = 6 * density
            }
        }
        headerRow.addView(shizukuStatusBadge)

        val collapseBtn = createIconButton("─") {
            callbacks.onCollapseClicked()
        }
        headerRow.addView(collapseBtn)

        val closeBtn = createIconButton("✕") {
            callbacks.onCloseServiceClicked()
        }
        headerRow.addView(closeBtn)

        fullPanel.addView(headerRow)

        // 2. Speed Slider Row (1 - 20 taps/sec)
        val speedHeader = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val speedTitle = TextView(context).apply {
            text = "Speed (taps/sec)"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        speedValueLabel = TextView(context).apply {
            text = "${prefs.tapSpeedHz} Hz (${prefs.tapSpeedHz} / sec)"
            setTextColor(Color.parseColor("#38BDF8"))
            textSize = 11f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        speedHeader.addView(speedTitle)
        speedHeader.addView(speedValueLabel)
        fullPanel.addView(speedHeader)

        speedSeekBar = SeekBar(context).apply {
            max = 19 // 0..19 corresponds to 1..20
            progress = prefs.tapSpeedHz - 1
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    val hz = progress + 1
                    speedValueLabel.text = "$hz Hz ($hz / sec)"
                    if (fromUser) {
                        prefs.tapSpeedHz = hz
                        callbacks.onSpeedChanged(hz)
                    }
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
            setPadding((4 * density).toInt(), (4 * density).toInt(), (4 * density).toInt(), (8 * density).toInt())
        }
        fullPanel.addView(speedSeekBar)

        // 3. Trigger Size Selector
        val sizeRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, (4 * density).toInt(), 0, (6 * density).toInt())
            }
        }
        val sizeLabel = TextView(context).apply {
            text = "Trigger Size:"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        sizeRow.addView(sizeLabel)

        sizeSmallBtn = createSizeChip("S", TriggerButtonSize.SMALL)
        sizeMediumBtn = createSizeChip("M", TriggerButtonSize.MEDIUM)
        sizeLargeBtn = createSizeChip("L", TriggerButtonSize.LARGE)
        sizeRow.addView(sizeSmallBtn)
        sizeRow.addView(sizeMediumBtn)
        sizeRow.addView(sizeLargeBtn)
        fullPanel.addView(sizeRow)
        updateSizeChipSelection(prefs.triggerButtonSize)

        // 4. Target Points Management (Add / Remove / Cycling)
        val targetSection = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, (2 * density).toInt(), 0, (6 * density).toInt())
            }
        }
        targetCountLabel = TextView(context).apply {
            text = "Targets: 1"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        targetSection.addView(targetCountLabel)

        val addTargetBtn = createButton("+ Add", Color.parseColor("#0284C7")) {
            callbacks.onAddTargetPoint()
        }
        val removeTargetBtn = createButton("- Del", Color.parseColor("#475569")) {
            callbacks.onRemoveTargetPoint()
        }
        targetSection.addView(addTargetBtn)
        targetSection.addView(removeTargetBtn)
        fullPanel.addView(targetSection)

        // Multi-target cycling switch
        val cycleRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, (2 * density).toInt(), 0, (4 * density).toInt())
            }
        }
        val cycleLabel = TextView(context).apply {
            text = "Sequence Cycle Targets"
            setTextColor(Color.parseColor("#CBD5E1"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        cycleSwitch = Switch(context).apply {
            isChecked = prefs.isMultiTargetCyclingEnabled
            setOnCheckedChangeListener { _, isChecked ->
                prefs.isMultiTargetCyclingEnabled = isChecked
                callbacks.onCycleTargetsToggled(isChecked)
            }
        }
        cycleRow.addView(cycleLabel)
        cycleRow.addView(cycleSwitch)
        fullPanel.addView(cycleRow)

        // 5. Visibility Dimming & Haptic switches
        val togglesRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, (2 * density).toInt(), 0, (6 * density).toInt())
            }
        }
        val dimLabel = TextView(context).apply {
            text = "Dim Overlays"
            setTextColor(Color.parseColor("#CBD5E1"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        dimSwitch = Switch(context).apply {
            isChecked = prefs.isDimmed
            setOnCheckedChangeListener { _, isChecked ->
                prefs.isDimmed = isChecked
                callbacks.onDimToggled(isChecked)
            }
        }
        togglesRow.addView(dimLabel)
        togglesRow.addView(dimSwitch)
        fullPanel.addView(togglesRow)

        // Haptic feedback row
        val vibRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, (2 * density).toInt(), 0, (6 * density).toInt())
            }
        }
        val vibLabel = TextView(context).apply {
            text = "Haptic Vibration"
            setTextColor(Color.parseColor("#CBD5E1"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        vibrationSwitch = Switch(context).apply {
            isChecked = prefs.isVibrationEnabled
            setOnCheckedChangeListener { _, isChecked ->
                prefs.isVibrationEnabled = isChecked
                callbacks.onVibrationToggled(isChecked)
            }
        }
        vibRow.addView(vibLabel)
        vibRow.addView(vibrationSwitch)
        fullPanel.addView(vibRow)

        // Safety Limit Row
        val safetyRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, (2 * density).toInt(), 0, (10 * density).toInt())
            }
        }
        val safetyTitle = TextView(context).apply {
            text = "Safety Auto-Stop:"
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 11f
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        }
        safetyLimitLabel = TextView(context).apply {
            text = if (prefs.safetyLimit == 0) "Unlimited" else "${prefs.safetyLimit} taps"
            setTextColor(Color.parseColor("#F59E0B"))
            textSize = 11f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            setPadding((6 * density).toInt(), (3 * density).toInt(), (6 * density).toInt(), (3 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E293B"))
                cornerRadius = 4 * density
            }
            setOnClickListener {
                // Cycle through safety limits: 0 (Off), 100, 250, 500, 1000
                val nextLimit = when (prefs.safetyLimit) {
                    0 -> 100
                    100 -> 250
                    250 -> 500
                    500 -> 1000
                    else -> 0
                }
                prefs.safetyLimit = nextLimit
                text = if (nextLimit == 0) "Unlimited" else "$nextLimit taps"
                callbacks.onSafetyLimitChanged(nextLimit)
            }
        }
        safetyRow.addView(safetyTitle)
        safetyRow.addView(safetyLimitLabel)
        fullPanel.addView(safetyRow)

        // 6. Master Lock Button
        lockBtn = TextView(context).apply {
            text = "🔒 Lock Position & Start"
            setTextColor(Color.WHITE)
            textSize = 13f
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, (10 * density).toInt(), 0, (10 * density).toInt())
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#4F46E5")) // Indigo
                cornerRadius = 8 * density
            }
            setOnClickListener {
                callbacks.onLockToggled(true)
            }
        }
        fullPanel.addView(lockBtn)
    }

    fun setLockState(isLocked: Boolean) {
        if (isLocked) {
            fullPanel.visibility = View.GONE
            miniPanel.visibility = View.VISIBLE
        } else {
            fullPanel.visibility = View.VISIBLE
            miniPanel.visibility = View.GONE
        }
    }

    fun updateTargetCount(count: Int) {
        targetCountLabel.text = "Targets: $count"
    }

    fun updateShizukuStatus(isReady: Boolean, statusText: String) {
        shizukuStatusBadge.text = if (isReady) "● Ready" else "● $statusText"
        shizukuStatusBadge.setTextColor(
            if (isReady) Color.parseColor("#10B981") else Color.parseColor("#EF4444")
        )
    }

    private fun updateSizeChipSelection(selectedSize: TriggerButtonSize) {
        val activeColor = Color.parseColor("#4F46E5")
        val inactiveColor = Color.parseColor("#1E293B")

        applyChipStyle(sizeSmallBtn, selectedSize == TriggerButtonSize.SMALL, activeColor, inactiveColor)
        applyChipStyle(sizeMediumBtn, selectedSize == TriggerButtonSize.MEDIUM, activeColor, inactiveColor)
        applyChipStyle(sizeLargeBtn, selectedSize == TriggerButtonSize.LARGE, activeColor, inactiveColor)
    }

    private fun applyChipStyle(tv: TextView, isSelected: Boolean, activeColor: Int, inactiveColor: Int) {
        tv.background = GradientDrawable().apply {
            setColor(if (isSelected) activeColor else inactiveColor)
            cornerRadius = 4 * density
        }
        tv.setTextColor(if (isSelected) Color.WHITE else Color.parseColor("#94A3B8"))
    }

    private fun createSizeChip(label: String, size: TriggerButtonSize): TextView {
        return TextView(context).apply {
            text = label
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding((10 * density).toInt(), (4 * density).toInt(), (10 * density).toInt(), (4 * density).toInt())
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins((4 * density).toInt(), 0, 0, 0)
            }
            setOnClickListener {
                prefs.triggerButtonSize = size
                updateSizeChipSelection(size)
                callbacks.onTriggerSizeChanged(size)
            }
        }
    }

    private fun createButton(label: String, color: Int, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = label
            setTextColor(Color.WHITE)
            textSize = 11f
            gravity = Gravity.CENTER
            setPadding((8 * density).toInt(), (4 * density).toInt(), (8 * density).toInt(), (4 * density).toInt())
            background = GradientDrawable().apply {
                setColor(color)
                cornerRadius = 6 * density
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins((4 * density).toInt(), 0, 0, 0)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun createIconButton(symbol: String, onClick: () -> Unit): TextView {
        return TextView(context).apply {
            text = symbol
            setTextColor(Color.parseColor("#94A3B8"))
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding((8 * density).toInt(), (2 * density).toInt(), (8 * density).toInt(), (2 * density).toInt())
            setOnClickListener { onClick() }
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        // Drag HUD header to reposition panel
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = layoutParams.x
                initialY = layoutParams.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                isDragging = false
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY

                if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                    isDragging = true
                }

                if (isDragging) {
                    layoutParams.x = (initialX + dx).toInt()
                    layoutParams.y = (initialY + dy).toInt()
                    try {
                        windowManager.updateViewLayout(this, layoutParams)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (isDragging) {
                    callbacks.onPositionChanged(layoutParams.x, layoutParams.y)
                }
                isDragging = false
                return true
            }
        }
        return super.onTouchEvent(event)
    }
}
