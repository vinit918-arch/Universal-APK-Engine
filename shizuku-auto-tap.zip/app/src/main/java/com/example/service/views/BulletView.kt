package com.example.service.views

import android.animation.ValueAnimator
import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.util.DisplayMetrics
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.DecelerateInterpolator
import kotlin.math.abs

/**
 * State A: Collapsed floating bullet icon.
 * Draggable anywhere on screen, smoothly snaps to left/right screen edge on finger release.
 */
@SuppressLint("ViewConstructor")
class BulletView(
    context: Context,
    private val windowManager: WindowManager,
    private val layoutParams: WindowManager.LayoutParams,
    private val onExpandClicked: () -> Unit,
    private val onPositionChanged: (x: Int, y: Int) -> Unit
) : View(context) {

    private val density = context.resources.displayMetrics.density
    val viewSize = (54 * density).toInt()

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#1E293B")
        style = Paint.Style.FILL
        setShadowLayer(8 * density, 0f, 4 * density, Color.parseColor("#80000000"))
    }

    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#06B6D4") // Cyan
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density
    }

    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#38BDF8") // Light cyan
        style = Paint.Style.FILL
    }

    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    // Touch and drag tracking
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isDragging = false
    private val touchSlop = 10 * density

    init {
        setLayerType(LAYER_TYPE_SOFTWARE, null) // Required for shadow layer rendering
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(viewSize, viewSize)
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val radius = (width / 2f) - (6 * density)

        // Background circle with elevation shadow
        canvas.drawCircle(cx, cy, radius, bgPaint)

        // Accent outer ring
        canvas.drawCircle(cx, cy, radius - (1 * density), ringPaint)

        // Center target reticle icon
        canvas.drawCircle(cx, cy, 4 * density, centerPaint)

        // Draw precision target crosshair lines
        val lineLen = 7 * density
        val offset = 6 * density
        // Top
        canvas.drawLine(cx, cy - offset - lineLen, cx, cy - offset, iconPaint)
        // Bottom
        canvas.drawLine(cx, cy + offset, cx, cy + offset + lineLen, iconPaint)
        // Left
        canvas.drawLine(cx - offset - lineLen, cy, cx - offset, cy, iconPaint)
        // Right
        canvas.drawLine(cx + offset, cy, cx + offset + lineLen, cy, iconPaint)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                initialX = layoutParams.x
                initialY = layoutParams.y
                initialTouchX = event.rawX
                initialTouchY = event.rawY
                isDragging = false
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                val dx = event.rawX - initialTouchX
                val dy = event.rawY - initialTouchY

                if (!isDragging && (abs(dx) > touchSlop || abs(dy) > touchSlop)) {
                    isDragging = true
                }

                if (isDragging) {
                    layoutParams.x = (initialX + dx).toInt()
                    layoutParams.y = (initialY + dy).toInt()
                    try {
                        windowManager.updateViewLayout(this, layoutParams)
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP -> {
                if (!isDragging) {
                    // Quick tap -> Expand overlay
                    onExpandClicked()
                } else {
                    // Snapping animation to nearest screen edge (left or right)
                    snapToNearestEdge()
                }
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    /**
     * Smoothly animates the bullet icon to snap to the left or right edge of the screen.
     */
    private fun snapToNearestEdge() {
        val displayMetrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getMetrics(displayMetrics)
        val screenWidth = displayMetrics.widthPixels

        val currentX = layoutParams.x
        val targetX = if (currentX + (viewSize / 2) < screenWidth / 2) {
            16 // Snap to left edge
        } else {
            screenWidth - viewSize - 16 // Snap to right edge
        }

        val animator = ValueAnimator.ofInt(currentX, targetX).apply {
            duration = 250
            interpolator = DecelerateInterpolator()
            addUpdateListener { animation ->
                layoutParams.x = animation.animatedValue as Int
                try {
                    windowManager.updateViewLayout(this@BulletView, layoutParams)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
        animator.start()
        onPositionChanged(targetX, layoutParams.y)
    }
}
