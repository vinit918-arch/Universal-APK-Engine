package com.example.data

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject

/**
 * Size options for the floating trigger button.
 */
enum class TriggerButtonSize(val dpValue: Int, val label: String) {
    SMALL(56, "Small"),
    MEDIUM(72, "Medium"),
    LARGE(88, "Large")
}

/**
 * A target coordinate on screen where taps will be dispatched.
 */
data class TargetPoint(
    val id: Int,
    var x: Int,
    var y: Int,
    var label: String = "Target $id"
)

/**
 * Manages persisting and retrieving user preferences and overlay positions across app launches.
 */
class OverlayPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "auto_tap_assistant_prefs"

        private const val KEY_TAP_SPEED = "pref_tap_speed_hz"
        private const val KEY_DIM_OVERLAY = "pref_dim_overlay"
        private const val KEY_TRIGGER_SIZE = "pref_trigger_size"
        private const val KEY_VIBRATION_ENABLED = "pref_vibration_enabled"
        private const val KEY_SAFETY_LIMIT = "pref_safety_limit"
        private const val KEY_IS_LOCKED = "pref_is_locked"
        private const val KEY_CYCLE_TARGETS = "pref_cycle_targets"

        // Positions
        private const val KEY_BULLET_X = "pos_bullet_x"
        private const val KEY_BULLET_Y = "pos_bullet_y"
        private const val KEY_TRIGGER_X = "pos_trigger_x"
        private const val KEY_TRIGGER_Y = "pos_trigger_y"
        private const val KEY_TARGET_POINTS_JSON = "pos_target_points_json"
    }

    var tapSpeedHz: Int
        get() = prefs.getInt(KEY_TAP_SPEED, 5).coerceIn(1, 20)
        set(value) = prefs.edit().putInt(KEY_TAP_SPEED, value.coerceIn(1, 20)).apply()

    var isDimmed: Boolean
        get() = prefs.getBoolean(KEY_DIM_OVERLAY, false)
        set(value) = prefs.edit().putBoolean(KEY_DIM_OVERLAY, value).apply()

    var triggerButtonSize: TriggerButtonSize
        get() {
            val name = prefs.getString(KEY_TRIGGER_SIZE, TriggerButtonSize.MEDIUM.name)
            return try {
                TriggerButtonSize.valueOf(name ?: TriggerButtonSize.MEDIUM.name)
            } catch (e: Exception) {
                TriggerButtonSize.MEDIUM
            }
        }
        set(value) = prefs.edit().putString(KEY_TRIGGER_SIZE, value.name).apply()

    var isVibrationEnabled: Boolean
        get() = prefs.getBoolean(KEY_VIBRATION_ENABLED, true)
        set(value) = prefs.edit().putBoolean(KEY_VIBRATION_ENABLED, value).apply()

    var safetyLimit: Int
        get() = prefs.getInt(KEY_SAFETY_LIMIT, 500) // Default 500 taps cap
        set(value) = prefs.edit().putInt(KEY_SAFETY_LIMIT, value).apply()

    var isLocked: Boolean
        get() = prefs.getBoolean(KEY_IS_LOCKED, false)
        set(value) = prefs.edit().putBoolean(KEY_IS_LOCKED, value).apply()

    var isMultiTargetCyclingEnabled: Boolean
        get() = prefs.getBoolean(KEY_CYCLE_TARGETS, false)
        set(value) = prefs.edit().putBoolean(KEY_CYCLE_TARGETS, value).apply()

    // Bullet Position (Collapsed icon)
    var bulletPosition: Pair<Int, Int>
        get() = Pair(prefs.getInt(KEY_BULLET_X, 40), prefs.getInt(KEY_BULLET_Y, 300))
        set(value) {
            prefs.edit()
                .putInt(KEY_BULLET_X, value.first)
                .putInt(KEY_BULLET_Y, value.second)
                .apply()
        }

    // Trigger Position (Large dot)
    var triggerPosition: Pair<Int, Int>
        get() = Pair(prefs.getInt(KEY_TRIGGER_X, 100), prefs.getInt(KEY_TRIGGER_Y, 700))
        set(value) {
            prefs.edit()
                .putInt(KEY_TRIGGER_X, value.first)
                .putInt(KEY_TRIGGER_Y, value.second)
                .apply()
        }

    /**
     * Loads saved target points, or provides a sensible default if empty.
     */
    fun getTargetPoints(screenWidth: Int = 1080, screenHeight: Int = 2400): MutableList<TargetPoint> {
        val json = prefs.getString(KEY_TARGET_POINTS_JSON, null)
        if (json.isNullOrEmpty()) {
            // Default single target point centered in upper third
            return mutableListOf(
                TargetPoint(
                    id = 1,
                    x = (screenWidth * 0.5f).toInt().coerceAtLeast(200),
                    y = (screenHeight * 0.45f).toInt().coerceAtLeast(300),
                    label = "Target 1"
                )
            )
        }

        val list = mutableListOf<TargetPoint>()
        try {
            val array = JSONArray(json)
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    TargetPoint(
                        id = obj.optInt("id", i + 1),
                        x = obj.optInt("x", 500),
                        y = obj.optInt("y", 800),
                        label = obj.optString("label", "Target ${i + 1}")
                    )
                )
            }
        } catch (e: Exception) {
            list.add(TargetPoint(1, 500, 800, "Target 1"))
        }

        if (list.isEmpty()) {
            list.add(TargetPoint(1, 500, 800, "Target 1"))
        }

        return list
    }

    /**
     * Saves target points array to JSON.
     */
    fun saveTargetPoints(points: List<TargetPoint>) {
        try {
            val array = JSONArray()
            for (point in points) {
                val obj = JSONObject().apply {
                    put("id", point.id)
                    put("x", point.x)
                    put("y", point.y)
                    put("label", point.label)
                }
                array.put(obj)
            }
            prefs.edit().putString(KEY_TARGET_POINTS_JSON, array.toString()).apply()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
