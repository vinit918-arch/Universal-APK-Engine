package com.example

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.data.OverlayPreferences
import com.example.data.TriggerButtonSize
import com.example.service.OverlayService
import com.example.shizuku.ShizukuTapController
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val shizukuController = ShizukuTapController.getInstance()
    private lateinit var prefs: OverlayPreferences

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(
                this,
                "Notification permission recommended for foreground service controls.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        prefs = OverlayPreferences(this)

        shizukuController.registerListeners()
        requestNotificationPermissionIfNeeded()

        setContent {
            MyApplicationTheme {
                MainScreen(
                    shizukuController = shizukuController,
                    prefs = prefs,
                    onRequestOverlayPermission = { requestOverlayPermission() },
                    onRequestShizukuPermission = { requestShizukuPermission() },
                    onStartService = { startOverlayService() },
                    onStopService = { stopOverlayService() },
                    onOpenShizukuApp = { openShizukuApp() }
                )
            }
        }
    }

    override fun onResume() {
        super.onResume()
        shizukuController.checkAndUpdateState()
    }

    override fun onDestroy() {
        super.onDestroy()
        shizukuController.unregisterListeners()
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun requestShizukuPermission() {
        if (shizukuController.connectionState.value is ShizukuTapController.ConnectionState.ShizukuNotRunning) {
            openShizukuApp()
        } else {
            shizukuController.requestPermission()
        }
    }

    private fun openShizukuApp() {
        val launchIntent = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (launchIntent != null) {
            startActivity(launchIntent)
        } else {
            // Open web or app store if Shizuku app is not installed
            try {
                startActivity(
                    Intent(
                        Intent.ACTION_VIEW,
                        Uri.parse("https://shizuku.rikka.app/download/")
                    )
                )
            } catch (e: Exception) {
                Toast.makeText(this, "Shizuku app not found", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startOverlayService() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Please grant Overlay permission first", Toast.LENGTH_SHORT).show()
            return
        }

        if (!shizukuController.isReady()) {
            Toast.makeText(this, "Please connect and authorize Shizuku first", Toast.LENGTH_SHORT).show()
            return
        }

        val serviceIntent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_START
        }
        ContextCompat.startForegroundService(this, serviceIntent)

        Toast.makeText(this, "Auto Tap Assistant started!", Toast.LENGTH_SHORT).show()

        // Minimize app so the user is ready to use it over their camera or target application
        moveTaskToBack(true)
    }

    private fun stopOverlayService() {
        val serviceIntent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_STOP
        }
        startService(serviceIntent)
        Toast.makeText(this, "Auto Tap Assistant stopped", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    shizukuController: ShizukuTapController,
    prefs: OverlayPreferences,
    onRequestOverlayPermission: () -> Unit,
    onRequestShizukuPermission: () -> Unit,
    onStartService: () -> Unit,
    onStopService: () -> Unit,
    onOpenShizukuApp: () -> Unit
) {
    val context = LocalContext.current
    var hasOverlayPermission by remember { mutableStateOf(Settings.canDrawOverlays(context)) }
    val shizukuState by shizukuController.connectionState.collectAsState()
    var isServiceActive by remember { mutableStateOf(OverlayService.isRunning) }

    // Periodic check for permission updates when user returns to app
    DisposableEffect(Unit) {
        hasOverlayPermission = Settings.canDrawOverlays(context)
        shizukuController.checkAndUpdateState()
        isServiceActive = OverlayService.isRunning
        onDispose { }
    }

    val isShizukuReady = shizukuState is ShizukuTapController.ConnectionState.Ready
    val canStart = hasOverlayPermission && isShizukuReady

    // User preferences states
    var tapSpeed by remember { mutableFloatStateOf(prefs.tapSpeedHz.toFloat()) }
    var triggerSize by remember { mutableStateOf(prefs.triggerButtonSize) }
    var vibrationEnabled by remember { mutableStateOf(prefs.isVibrationEnabled) }
    var cycleTargetsEnabled by remember { mutableStateOf(prefs.isMultiTargetCyclingEnabled) }
    var safetyLimit by remember { mutableIntStateOf(prefs.safetyLimit) }
    var showGuide by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(MaterialTheme.colorScheme.primaryContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = "App Icon",
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Auto Tap Assistant",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }
                },
                actions = {
                    IconButton(onClick = {
                        hasOverlayPermission = Settings.canDrawOverlays(context)
                        shizukuController.checkAndUpdateState()
                        isServiceActive = OverlayService.isRunning
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh Status")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {

            // Service Running Status Banner
            if (isServiceActive) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer
                    ),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF10B981))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Floating Overlay Active",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    text = "Assistant is floating over your screen",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                )
                            }
                        }

                        Button(
                            onClick = {
                                onStopService()
                                isServiceActive = false
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.error
                            ),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Stop", fontSize = 12.sp)
                        }
                    }
                }
            }

            // ==================== PERMISSIONS STATUS CARD ====================
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "System Permissions & Access",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    // 1. Draw Over Other Apps Indicator
                    PermissionItem(
                        title = "Draw Over Other Apps",
                        subtitle = if (hasOverlayPermission) "Granted — Floating overlay allowed" else "Tap to grant SYSTEM_ALERT_WINDOW",
                        isGranted = hasOverlayPermission,
                        onClick = onRequestOverlayPermission,
                        testTag = "permission_overlay_card"
                    )

                    // 2. Shizuku Privileged Access Indicator
                    val shizukuSubtitle = when (shizukuState) {
                        is ShizukuTapController.ConnectionState.Ready -> "Connected & Authorized (Shell level)"
                        is ShizukuTapController.ConnectionState.PermissionRequired -> "Connected — Tap to grant permission"
                        is ShizukuTapController.ConnectionState.ShizukuNotRunning -> "Service not running — Tap to open Shizuku"
                        is ShizukuTapController.ConnectionState.Error -> (shizukuState as ShizukuTapController.ConnectionState.Error).message
                        else -> "Checking Shizuku binder status..."
                    }

                    PermissionItem(
                        title = "Shizuku Privileged Service",
                        subtitle = shizukuSubtitle,
                        isGranted = isShizukuReady,
                        onClick = onRequestShizukuPermission,
                        testTag = "permission_shizuku_card"
                    )
                }
            }

            // ==================== PRIMARY START / STOP CONTROLS ====================
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = {
                        onStartService()
                        isServiceActive = true
                    },
                    enabled = canStart,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("start_overlay_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.primary,
                        disabledContainerColor = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                    )
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(22.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Start Floating Overlay",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                if (isServiceActive) {
                    OutlinedButton(
                        onClick = {
                            onStopService()
                            isServiceActive = false
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("stop_overlay_button"),
                        shape = RoundedCornerShape(14.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = MaterialTheme.colorScheme.error
                        )
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Stop Floating Overlay", fontWeight = FontWeight.SemiBold)
                    }
                }
            }

            // ==================== PREFERENCES & PRESETS ====================
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                ),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Tap Execution Settings",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    // Speed Slider
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(text = "Tap Rate", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "${tapSpeed.toInt()} taps / sec (${tapSpeed.toInt()} Hz)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                        Slider(
                            value = tapSpeed,
                            onValueChange = {
                                tapSpeed = it
                                prefs.tapSpeedHz = it.toInt()
                            },
                            valueRange = 1f..20f,
                            steps = 18,
                            modifier = Modifier.testTag("speed_slider")
                        )
                    }

                    // Trigger Size Selection
                    Column {
                        Text(text = "Trigger Button Size", style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TriggerButtonSize.values().forEach { size ->
                                FilterChip(
                                    selected = triggerSize == size,
                                    onClick = {
                                        triggerSize = size
                                        prefs.triggerButtonSize = size
                                    },
                                    label = { Text(size.label) }
                                )
                            }
                        }
                    }

                    // Safety Limit
                    Column {
                        Text(text = "Safety Auto-Stop Limit", style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(0, 100, 250, 500, 1000).forEach { limit ->
                                FilterChip(
                                    selected = safetyLimit == limit,
                                    onClick = {
                                        safetyLimit = limit
                                        prefs.safetyLimit = limit
                                    },
                                    label = { Text(if (limit == 0) "Unlimited" else "$limit taps") }
                                )
                            }
                        }
                    }

                    // Haptic Vibration & Multi-target Cycling
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Haptic Vibration", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "Pulse on each tap dispatched",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = vibrationEnabled,
                            onCheckedChange = {
                                vibrationEnabled = it
                                prefs.isVibrationEnabled = it
                            }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Multi-Target Sequence Cycling", style = MaterialTheme.typography.bodyMedium)
                            Text(
                                text = "Cycle sequentially across all target crosshairs",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = cycleTargetsEnabled,
                            onCheckedChange = {
                                cycleTargetsEnabled = it
                                prefs.isMultiTargetCyclingEnabled = it
                            }
                        )
                    }
                }
            }

            // ==================== SHIZUKU SETUP GUIDE ====================
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { showGuide = !showGuide },
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f)
                ),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Info,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "How Shizuku Privileged Tap Works",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Icon(
                            imageVector = if (showGuide) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null
                        )
                    }

                    AnimatedVisibility(visible = showGuide) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "1. AccessibilityService vs Shizuku:\n" +
                                        "Standard accessibility auto-clickers simulate user touches that freeze UI dispatch and interfere with continuous camera bursts. Shizuku injects privileged direct shell taps without accessibility lag.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "2. Starting Shizuku on Device:\n" +
                                        "• Enable Developer Options & Wireless Debugging in Android Settings.\n" +
                                        "• Open the Shizuku app and tap 'Start' via Wireless Debugging (or run the one-line adb command from PC).\n" +
                                        "• Grant Shizuku access to Auto Tap Assistant when prompted.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(4.dp))
                            OutlinedButton(
                                onClick = onOpenShizukuApp,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Launch Shizuku App / Web Setup")
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}

@Composable
fun PermissionItem(
    title: String,
    subtitle: String,
    isGranted: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val statusColor by animateColorAsState(
        targetValue = if (isGranted) Color(0xFF10B981) else Color(0xFFEF4444),
        label = "status_color"
    )

    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(12.dp),
        color = MaterialTheme.colorScheme.surface,
        tonalElevation = 1.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(statusColor)
                )

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.width(8.dp))

            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(statusColor.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isGranted) Icons.Default.Check else Icons.Default.Close,
                    contentDescription = if (isGranted) "Granted" else "Not Granted",
                    tint = statusColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
