package com.example.shizuku

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.SystemClock
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger

/**
 * Shizuku connection and privileged command execution controller.
 *
 * Wraps Shizuku binder lifecycle, permission checks, and dispatches
 * shell-level `input tap <x> <y>` commands via Shizuku's privileged process.
 */
class ShizukuTapController private constructor() {

    companion object {
        private const val TAG = "ShizukuTapController"
        const val SHIZUKU_PERMISSION_REQUEST_CODE = 1001

        @Volatile
        private var instance: ShizukuTapController? = null

        fun getInstance(): ShizukuTapController {
            return instance ?: synchronized(this) {
                instance ?: ShizukuTapController().also { instance = it }
            }
        }
    }

    /**
     * UI-facing connection and permission status.
     */
    sealed class ConnectionState {
        object Unknown : ConnectionState()
        object ShizukuNotRunning : ConnectionState()
        object PermissionRequired : ConnectionState()
        object Ready : ConnectionState()
        data class Error(val message: String) : ConnectionState()
    }

    private val _connectionState = MutableStateFlow<ConnectionState>(ConnectionState.Unknown)
    val connectionState: StateFlow<ConnectionState> = _connectionState.asStateFlow()

    private val isBinderReceived = AtomicBoolean(false)
    private var isListening = false

    // Active tapping coroutine job & counters
    private var tapJob: Job? = null
    private val isTapping = AtomicBoolean(false)
    private val currentTapCount = AtomicInteger(0)

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku binder received")
        isBinderReceived.set(true)
        checkAndUpdateState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.w(TAG, "Shizuku binder died")
        isBinderReceived.set(false)
        _connectionState.value = ConnectionState.ShizukuNotRunning
        stopTapping()
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                Log.d(TAG, "Shizuku permission result: $grantResult")
                if (grantResult == PackageManager.PERMISSION_GRANTED) {
                    _connectionState.value = ConnectionState.Ready
                } else {
                    _connectionState.value = ConnectionState.PermissionRequired
                }
            }
        }

    /**
     * Register Shizuku listeners. Call during app/service initialization.
     */
    fun registerListeners() {
        if (isListening) return
        isListening = true
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
            checkAndUpdateState()
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to register Shizuku listeners", e)
            _connectionState.value = ConnectionState.ShizukuNotRunning
        }
    }

    /**
     * Unregister Shizuku listeners to prevent leaks.
     */
    fun unregisterListeners() {
        if (!isListening) return
        isListening = false
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
        } catch (e: Throwable) {
            Log.e(TAG, "Error unregistering Shizuku listeners", e)
        }
    }

    /**
     * Evaluates current Shizuku binder and permission availability.
     */
    fun checkAndUpdateState() {
        try {
            if (!Shizuku.pingBinder()) {
                _connectionState.value = ConnectionState.ShizukuNotRunning
                return
            }

            if (Shizuku.isPreV11()) {
                _connectionState.value = ConnectionState.Error("Unsupported Shizuku version (Pre-v11)")
                return
            }

            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                _connectionState.value = ConnectionState.Ready
            } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                _connectionState.value = ConnectionState.PermissionRequired
            } else {
                _connectionState.value = ConnectionState.PermissionRequired
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Error checking Shizuku state", e)
            _connectionState.value = ConnectionState.ShizukuNotRunning
        }
    }

    /**
     * Triggers Shizuku's permission grant dialog.
     */
    fun requestPermission() {
        try {
            if (Shizuku.pingBinder()) {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
            } else {
                _connectionState.value = ConnectionState.ShizukuNotRunning
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to request Shizuku permission", e)
        }
    }

    /**
     * Returns true if Shizuku is currently connected and granted permission.
     */
    fun isReady(): Boolean {
        return try {
            Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Throwable) {
            false
        }
    }

    /**
     * Spawns a privileged remote shell process via Shizuku.
     */
    private fun newProcessCompat(cmd: Array<String>): Process {
        val method = Shizuku::class.java.getMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        )
        method.isAccessible = true
        return method.invoke(null, cmd, null, null) as Process
    }

    /**
     * Executes a single privileged tap command: `input tap x y` via Shizuku.
     * Uses Shizuku.newProcess directly without spawning standard root shells.
     */
    fun executeSingleTap(x: Int, y: Int): Boolean {
        if (!isReady()) {
            Log.w(TAG, "Cannot tap: Shizuku not ready")
            return false
        }
        return try {
            val cmd = arrayOf("input", "tap", x.toString(), y.toString())
            val process = newProcessCompat(cmd)
            process.waitFor()
            process.destroy()
            true
        } catch (e: Throwable) {
            Log.e(TAG, "Error executing tap at ($x, $y)", e)
            false
        }
    }

    /**
     * Starts continuous auto-tapping loop on a background coroutine scope.
     *
     * @param scope CoroutineScope to launch tapping loop on.
     * @param targetCoordinates List of (x, y) coordinates to cycle through.
     * @param speedHz Number of taps per second (1 to 20).
     * @param safetyLimit Maximum taps to fire before auto-stopping (0 = unlimited).
     * @param onEachTap Callback executed on each tap with current count and coordinate tapped.
     * @param onComplete Callback invoked when tapping ends (manually or by safety limit).
     */
    fun startContinuousTapping(
        scope: CoroutineScope,
        targetCoordinates: List<Pair<Int, Int>>,
        speedHz: Int,
        safetyLimit: Int = 0,
        onEachTap: (count: Int, point: Pair<Int, Int>) -> Unit = { _, _ -> },
        onComplete: (totalTaps: Int) -> Unit = {}
    ) {
        if (targetCoordinates.isEmpty() || !isReady()) return

        stopTapping()
        isTapping.set(true)
        currentTapCount.set(0)

        val intervalMs = (1000L / speedHz.coerceIn(1, 20)).coerceAtLeast(40L)

        tapJob = scope.launch(Dispatchers.IO) {
            var targetIndex = 0
            val startTime = SystemClock.elapsedRealtime()

            try {
                while (isActive && isTapping.get()) {
                    val count = currentTapCount.incrementAndGet()
                    val target = targetCoordinates[targetIndex % targetCoordinates.size]
                    targetIndex++

                    // Execute privileged tap via Shizuku
                    val success = try {
                        val process = newProcessCompat(
                            arrayOf("input", "tap", target.first.toString(), target.second.toString())
                        )
                        process.waitFor()
                        process.destroy()
                        true
                    } catch (e: Throwable) {
                        Log.e(TAG, "Shizuku tap loop error", e)
                        false
                    }

                    if (success) {
                        withContext(Dispatchers.Main) {
                            onEachTap(count, target)
                        }
                    }

                    // Check safety limit cap
                    if (safetyLimit > 0 && count >= safetyLimit) {
                        Log.i(TAG, "Safety limit reached ($safetyLimit taps). Stopping loop.")
                        break
                    }

                    // Dynamic sleep accounting for execution time
                    val nextExpectedTime = startTime + (count * intervalMs)
                    val sleepTime = nextExpectedTime - SystemClock.elapsedRealtime()
                    if (sleepTime > 0) {
                        delay(sleepTime)
                    }
                }
            } finally {
                isTapping.set(false)
                withContext(Dispatchers.Main) {
                    onComplete(currentTapCount.get())
                }
            }
        }
    }

    /**
     * Immediately stops any running tap loop.
     */
    fun stopTapping() {
        isTapping.set(false)
        tapJob?.cancel()
        tapJob = null
    }

    /**
     * Checks if a tap loop is currently actively executing.
     */
    fun isTappingActive(): Boolean = isTapping.get()
}
