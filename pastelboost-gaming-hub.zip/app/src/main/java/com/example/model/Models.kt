package com.example.model

data class ProductItem(
  val id: String,
  val title: String,
  val category: String,
  val price: Int,
  val originalPrice: Int,
  val discountPercent: Int,
  val rating: Float,
  val reviewsCount: String,
  val badge: String,
  val iconEmoji: String,
  val shortDesc: String,
  val specs: List<String>,
  val freeDelivery: Boolean = true,
  val isCodAvailable: Boolean = true,
  val isBestSeller: Boolean = false
)

data class AdbCommand(
  val id: String,
  val title: String,
  val command: String,
  val category: String,
  val explanation: String,
  val riskLevel: RiskLevel,
  val impactTag: String,
  val expectedOutput: String,
  val isCustom: Boolean = false
)

enum class RiskLevel(val label: String) {
  SAFE("100% Safe"),
  TURBO_BOOST("Turbo Boost"),
  TWEAKER("Tweaker Only")
}

data class CartItem(
  val product: ProductItem,
  val quantity: Int = 1
)

data class NotificationItem(
  val id: String,
  val title: String,
  val description: String,
  val timestamp: String,
  val isUnread: Boolean = true,
  val type: String = "turbo"
)

data class GamingTelemetry(
  val currentFps: Int = 120,
  val targetFps: Int = 120,
  val cpuUsagePercent: Int = 42,
  val gpuUsagePercent: Int = 58,
  val batteryTempCelsius: Float = 33.4f,
  val ramFreedMb: Int = 940,
  val pingMs: Int = 22,
  val touchSamplingRateHz: Int = 480,
  val thermalThrottlingDisabled: Boolean = true,
  val ultraTouchActive: Boolean = true,
  val forceGpuActive: Boolean = true
)

enum class AppNavTab(val title: String, val iconName: String) {
  HOME("Shop & Deals", "shop"),
  GAMING_HUB("BGMI Hub", "sports_esports"),
  SHIZUKU_ADB("Shizuku ADB", "terminal"),
  CART("Bag", "shopping_bag"),
  PROFILE("Account", "person")
}
