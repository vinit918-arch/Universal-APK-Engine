package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ProductItem
import com.example.ui.theme.MeeshoDeepPink
import com.example.ui.theme.MeeshoLightPink
import com.example.ui.theme.MeeshoPastelPink
import com.example.ui.theme.MeeshoPrimaryPink
import com.example.ui.theme.MeeshoPurple
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted

@Composable
fun ProductGridSection(
  products: List<ProductItem>,
  wishlistIds: Set<String>,
  onProductClick: (ProductItem) -> Unit,
  onAddToCart: (ProductItem) -> Unit,
  onToggleWishlist: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Section Header
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = "🛍️ Gaming Essentials Store",
          fontSize = 17.sp,
          fontWeight = FontWeight.Black,
          color = TextDark
        )
      }

      Surface(
        shape = RoundedCornerShape(8.dp),
        color = MeeshoLightPink
      ) {
        Text(
          text = "${products.size} Products",
          color = MeeshoPrimaryPink,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // 2-Column Responsive Grid
    val rows = products.chunked(2)
    Column(
      verticalArrangement = Arrangement.spacedBy(12.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      rows.forEach { rowProducts ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          rowProducts.forEach { product ->
            Box(modifier = Modifier.weight(1f)) {
              ProductCardItem(
                product = product,
                isWishlisted = wishlistIds.contains(product.id),
                onClick = { onProductClick(product) },
                onAddToCart = { onAddToCart(product) },
                onToggleWishlist = { onToggleWishlist(product.id) }
              )
            }
          }
          if (rowProducts.size == 1) {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }
    }
  }
}

@Composable
fun ProductCardItem(
  product: ProductItem,
  isWishlisted: Boolean,
  onClick: () -> Unit,
  onAddToCart: () -> Unit,
  onToggleWishlist: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(20.dp),
    color = Color.White,
    shadowElevation = 3.dp,
    border = androidx.compose.foundation.BorderStroke(1.dp, MeeshoLightPink.copy(alpha = 0.8f)),
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(20.dp))
      .clickable { onClick() }
      .testTag("product_card_${product.id}")
  ) {
    Column(
      modifier = Modifier.fillMaxWidth()
    ) {
      // Top Image / Visual Area with Badges & Wishlist
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(125.dp)
          .background(
            Brush.verticalGradient(
              colors = listOf(
                MeeshoPastelPink,
                MeeshoLightPink.copy(alpha = 0.35f)
              )
            )
          ),
        contentAlignment = Alignment.Center
      ) {
        // Big Emoji / Icon Visual
        Text(
          text = product.iconEmoji,
          fontSize = 52.sp
        )

        // Top Left Badge
        Surface(
          shape = RoundedCornerShape(bottomEnd = 10.dp, topStart = 18.dp),
          color = MeeshoPrimaryPink,
          modifier = Modifier.align(Alignment.TopStart)
        ) {
          Text(
            text = product.badge,
            color = Color.White,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
          )
        }

        // Top Right Wishlist Icon
        IconButton(
          onClick = onToggleWishlist,
          modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(4.dp)
            .size(30.dp)
        ) {
          Icon(
            imageVector = if (isWishlisted) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
            contentDescription = "Wishlist",
            tint = if (isWishlisted) MeeshoPrimaryPink else Color.Gray,
            modifier = Modifier.size(18.dp)
          )
        }

        // Discount Percent Pill Bottom Left
        Surface(
          shape = RoundedCornerShape(8.dp),
          color = Color(0xFF10B981),
          modifier = Modifier
            .align(Alignment.BottomStart)
            .padding(6.dp)
        ) {
          Text(
            text = "${product.discountPercent}% OFF",
            color = Color.White,
            fontSize = 9.sp,
            fontWeight = FontWeight.ExtraBold,
            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
          )
        }
      }

      // Product Details Area
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(10.dp)
      ) {
        // Product Title
        Text(
          text = product.title,
          fontSize = 12.5.sp,
          fontWeight = FontWeight.SemiBold,
          color = TextDark,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
          lineHeight = 16.sp
        )

        Spacer(modifier = Modifier.height(4.dp))

        // Price Row
        Row(
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "₹${product.price}",
            fontSize = 15.sp,
            fontWeight = FontWeight.Black,
            color = TextDark
          )
          Spacer(modifier = Modifier.width(5.dp))
          Text(
            text = "₹${product.originalPrice}",
            fontSize = 11.sp,
            color = Color.Gray,
            textDecoration = TextDecoration.LineThrough
          )
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Ratings & Free Delivery
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFF2E7D32)
          ) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
            ) {
              Text(
                text = "${product.rating}",
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
              )
              Icon(
                imageVector = Icons.Default.Star,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(10.dp)
              )
            }
          }

          Text(
            text = "Free Delivery",
            color = Color.Gray,
            fontSize = 9.5.sp,
            fontWeight = FontWeight.Medium
          )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // Add to Cart Sweet Button
        Button(
          onClick = onAddToCart,
          shape = RoundedCornerShape(12.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MeeshoPrimaryPink
          ),
          contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 6.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(34.dp)
            .testTag("add_to_cart_${product.id}")
        ) {
          Icon(
            imageVector = Icons.Default.ShoppingBag,
            contentDescription = "Add",
            tint = Color.White,
            modifier = Modifier.size(14.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Add to Bag",
            color = Color.White,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
