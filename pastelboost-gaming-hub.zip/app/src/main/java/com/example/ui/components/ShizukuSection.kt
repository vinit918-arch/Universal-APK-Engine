package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AdbCommand
import com.example.model.RiskLevel
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GamingNeonCyan
import com.example.ui.theme.GamingNeonGreen
import com.example.ui.theme.GamingNeonPink
import com.example.ui.theme.MeeshoLightPink
import com.example.ui.theme.MeeshoLightPurple
import com.example.ui.theme.MeeshoPastelPink
import com.example.ui.theme.MeeshoPrimaryPink
import com.example.ui.theme.MeeshoPurple
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted

@Composable
fun ShizukuSection(
  commands: List<AdbCommand>,
  lastCopiedId: String?,
  onCopyCommand: (AdbCommand) -> Unit,
  onTestCommand: (AdbCommand) -> Unit,
  onAddNewCommandClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  var selectedCategory by remember { mutableStateOf("All") }
  val categories = listOf("All", "Display & GPU", "Thermal & FPS", "Touch & Sensitivity", "MIUI & Debloat", "Memory & Shizuku")

  val filteredCommands = remember(commands, selectedCategory) {
    if (selectedCategory == "All") commands
    else commands.filter { it.category == selectedCategory }
  }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
  ) {
    // Header with status badge & Add button
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "⚡ Shizuku & LADB Boosters",
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = MeeshoPurple
          )
        }
        Text(
          text = "No-Root ADB tweaks for Redmi, POCO, Realme & Snapdragon",
          fontSize = 11.5.sp,
          color = TextMuted
        )
      }

      Button(
        onClick = onAddNewCommandClick,
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MeeshoPrimaryPink),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 6.dp),
        modifier = Modifier.testTag("add_custom_cmd_button")
      ) {
        Icon(imageVector = Icons.Default.Add, contentDescription = "Add", modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text(text = "Custom", fontSize = 12.sp, fontWeight = FontWeight.Bold)
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Shizuku Quick Connection Status Card
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color(0xFF1E1430),
      border = androidx.compose.foundation.BorderStroke(1.dp, MeeshoPurple.copy(alpha = 0.4f)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier
            .size(36.dp)
            .clip(CircleShape)
            .background(GamingNeonGreen.copy(alpha = 0.2f)),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Terminal,
            contentDescription = "Terminal",
            tint = GamingNeonGreen,
            modifier = Modifier.size(20.dp)
          )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "Shizuku Shell Service",
              color = Color.White,
              fontSize = 13.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.width(6.dp))
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = GamingNeonGreen.copy(alpha = 0.2f)
            ) {
              Text(
                text = "ACTIVE",
                color = GamingNeonGreen,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp)
              )
            }
          }
          Text(
            text = "Copy commands directly or paste in LADB / Termux / Shizuku app.",
            color = Color.LightGray,
            fontSize = 10.5.sp
          )
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Category Selector
    LazyRow(
      horizontalArrangement = Arrangement.spacedBy(6.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      items(categories) { cat ->
        val isSelected = cat == selectedCategory
        val bg by animateColorAsState(if (isSelected) MeeshoPurple else MeeshoPastelPink, label = "cat_pill")
        val txtColor by animateColorAsState(if (isSelected) Color.White else MeeshoPurple, label = "cat_txt")

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(bg)
            .clickable { selectedCategory = cat }
            .padding(horizontal = 12.dp, vertical = 6.dp),
          contentAlignment = Alignment.Center
        ) {
          Text(text = cat, color = txtColor, fontSize = 11.5.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // List of ADB Command Cards
    Column(
      verticalArrangement = Arrangement.spacedBy(10.dp),
      modifier = Modifier.fillMaxWidth()
    ) {
      filteredCommands.forEach { cmd ->
        AdbCommandCard(
          command = cmd,
          isCopied = cmd.id == lastCopiedId,
          onCopy = { onCopyCommand(cmd) },
          onTest = { onTestCommand(cmd) }
        )
      }
    }
  }
}

@Composable
fun AdbCommandCard(
  command: AdbCommand,
  isCopied: Boolean,
  onCopy: () -> Unit,
  onTest: () -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(18.dp),
    color = Color.White,
    shadowElevation = 2.dp,
    border = androidx.compose.foundation.BorderStroke(1.dp, MeeshoLightPink),
    modifier = modifier.fillMaxWidth()
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp)
    ) {
      // Top Row: Title, Tag, Risk
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = command.title,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )
          Text(
            text = command.category,
            fontSize = 11.sp,
            color = MeeshoPurple,
            fontWeight = FontWeight.Medium
          )
        }

        Surface(
          shape = RoundedCornerShape(8.dp),
          color = when (command.riskLevel) {
            RiskLevel.SAFE -> Color(0xFFE8F5E9)
            RiskLevel.TURBO_BOOST -> Color(0xFFFFF3E0)
            RiskLevel.TWEAKER -> Color(0xFFFFEBEE)
          }
        ) {
          Text(
            text = command.impactTag,
            color = when (command.riskLevel) {
              RiskLevel.SAFE -> Color(0xFF2E7D32)
              RiskLevel.TURBO_BOOST -> Color(0xFFE65100)
              RiskLevel.TWEAKER -> Color(0xFFC62828)
            },
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = command.explanation,
        fontSize = 11.5.sp,
        color = TextMuted,
        lineHeight = 15.sp
      )

      Spacer(modifier = Modifier.height(10.dp))

      // ADB Code Box (Monospace & Dark Background)
      Surface(
        shape = RoundedCornerShape(12.dp),
        color = Color(0xFF1E152A),
        border = androidx.compose.foundation.BorderStroke(1.dp, MeeshoPurple.copy(alpha = 0.3f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 10.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Text(
            text = command.command,
            color = GamingNeonCyan,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.weight(1f)
          )

          Spacer(modifier = Modifier.width(6.dp))

          // 1-Tap Copy Action
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(8.dp))
              .background(if (isCopied) GamingNeonGreen else MeeshoPrimaryPink)
              .clickable { onCopy() }
              .padding(horizontal = 8.dp, vertical = 5.dp)
              .testTag("copy_btn_${command.id}"),
            contentAlignment = Alignment.Center
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = if (isCopied) Icons.Default.Check else Icons.Default.ContentCopy,
                contentDescription = "Copy",
                tint = Color.White,
                modifier = Modifier.size(13.dp)
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = if (isCopied) "Copied!" else "Copy",
                color = Color.White,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Action Row: Test in Terminal / Shizuku Simulation
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.End
      ) {
        OutlinedButton(
          onClick = onTest,
          shape = RoundedCornerShape(10.dp),
          border = androidx.compose.foundation.BorderStroke(1.dp, MeeshoPurple.copy(alpha = 0.4f)),
          contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 8.dp, vertical = 2.dp),
          modifier = Modifier.height(28.dp)
        ) {
          Icon(
            imageVector = Icons.Default.PlayArrow,
            contentDescription = "Run",
            tint = MeeshoPurple,
            modifier = Modifier.size(12.dp)
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = "Test in Terminal",
            color = MeeshoPurple,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
          )
        }
      }
    }
  }
}
