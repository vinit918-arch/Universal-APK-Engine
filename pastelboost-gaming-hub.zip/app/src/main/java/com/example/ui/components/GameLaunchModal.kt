package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.GamingTelemetry
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GamingNeonCyan
import com.example.ui.theme.GamingNeonGreen
import com.example.ui.theme.GamingNeonPink
import com.example.ui.theme.MeeshoDeepPurple
import com.example.ui.theme.MeeshoPrimaryPink
import com.example.ui.theme.MeeshoPurple

@Composable
fun GameLaunchModal(
  telemetry: GamingTelemetry,
  isLaunching: Boolean,
  terminalLogs: List<String>,
  onDismiss: () -> Unit,
  onLaunchGame: () -> Unit,
  modifier: Modifier = Modifier
) {
  var forceGpuEnabled by remember { mutableStateOf(true) }
  var disableThermalEnabled by remember { mutableStateOf(true) }
  var ultraTouchEnabled by remember { mutableStateOf(true) }
  var frameRateLock120 by remember { mutableStateOf(true) }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(28.dp),
      color = DarkBackground,
      border = androidx.compose.foundation.BorderStroke(1.5.dp, MeeshoPrimaryPink.copy(alpha = 0.5f)),
      modifier = modifier
        .fillMaxWidth(0.94f)
        .padding(vertical = 24.dp)
        .shadow(16.dp, RoundedCornerShape(28.dp), spotColor = MeeshoPrimaryPink)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Modal Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(
                  Brush.linearGradient(
                    listOf(MeeshoPrimaryPink, MeeshoPurple)
                  )
                ),
              contentAlignment = Alignment.Center
            ) {
              Text(text = "🎯", fontSize = 22.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
              Text(
                text = "BGMI Performance Booster",
                color = Color.White,
                fontSize = 17.sp,
                fontWeight = FontWeight.Black
              )
              Text(
                text = "Shizuku Kernel Injection • 90/120 FPS",
                color = GamingNeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.Medium
              )
            }
          }

          IconButton(
            onClick = onDismiss,
            modifier = Modifier.size(32.dp).testTag("close_game_modal_button")
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = Color.LightGray
            )
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Hardware Gauges Row (CPU, GPU, FPS)
        Surface(
          shape = RoundedCornerShape(18.dp),
          color = DarkSurface,
          border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.08f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = "REAL-TIME TELEMETRY & BOOST STATUS",
              color = Color.Gray,
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.5.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceEvenly
            ) {
              CircularMetricDial(
                label = "FPS",
                value = "${telemetry.currentFps}",
                progress = telemetry.currentFps / 120f,
                accentColor = GamingNeonCyan
              )
              CircularMetricDial(
                label = "CPU Load",
                value = "${telemetry.cpuUsagePercent}%",
                progress = telemetry.cpuUsagePercent / 100f,
                accentColor = GamingNeonGreen
              )
              CircularMetricDial(
                label = "GPU Clock",
                value = "${telemetry.gpuUsagePercent}%",
                progress = telemetry.gpuUsagePercent / 100f,
                accentColor = GamingNeonPink
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // RAM and Temp Bars
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Text(
                text = "⚡ Cleaned RAM: +${telemetry.ramFreedMb} MB freed",
                color = GamingNeonGreen,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
              Text(
                text = "❄️ ${telemetry.batteryTempCelsius}°C (Thermal Cool)",
                color = GamingNeonCyan,
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Shizuku & ADB Shell Optimization Toggles
        Text(
          text = "ONE-TAP SHIZUKU ADB OPTIMIZATIONS",
          color = Color.LightGray,
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(8.dp))

        Column(
          verticalArrangement = Arrangement.spacedBy(8.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          BoosterToggleRow(
            title = "Extreme 120Hz Refresh Lock",
            subtitle = "settings put system min_refresh_rate 120.0",
            checked = frameRateLock120,
            onCheckedChange = { frameRateLock120 = it }
          )
          BoosterToggleRow(
            title = "Force GPU 2D Rendering",
            subtitle = "settings put global force_gpu_rendering 1",
            checked = forceGpuEnabled,
            onCheckedChange = { forceGpuEnabled = it }
          )
          BoosterToggleRow(
            title = "Bypass Thermal Throttle Cap",
            subtitle = "settings put global thermal_limit_management_enabled 0",
            checked = disableThermalEnabled,
            onCheckedChange = { disableThermalEnabled = it }
          )
          BoosterToggleRow(
            title = "Ultra Touch Response (1ms Fling)",
            subtitle = "settings put system max_fling_velocity 20000",
            checked = ultraTouchEnabled,
            onCheckedChange = { ultraTouchEnabled = it }
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Interactive Terminal Output Box
        Surface(
          shape = RoundedCornerShape(14.dp),
          color = Color.Black,
          border = androidx.compose.foundation.BorderStroke(1.dp, GamingNeonCyan.copy(alpha = 0.3f)),
          modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Row(
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                  imageVector = Icons.Default.Terminal,
                  contentDescription = "Console",
                  tint = GamingNeonCyan,
                  modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                  text = "shizuku@android-shell ~ $",
                  color = GamingNeonCyan,
                  fontSize = 11.sp,
                  fontFamily = FontFamily.Monospace,
                  fontWeight = FontWeight.Bold
                )
              }
              Text(
                text = "LIVE",
                color = GamingNeonGreen,
                fontSize = 9.sp,
                fontWeight = FontWeight.ExtraBold
              )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Column(
              verticalArrangement = Arrangement.spacedBy(2.dp),
              modifier = Modifier.verticalScroll(rememberScrollState())
            ) {
              terminalLogs.takeLast(5).forEach { log ->
                Text(
                  text = log,
                  color = if (log.contains("FPS") || log.contains("TURBO")) GamingNeonGreen else Color(0xFFCE93D8),
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Big Launch Action Button
        Button(
          onClick = onLaunchGame,
          enabled = !isLaunching,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(
            containerColor = MeeshoPrimaryPink
          ),
          modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .testTag("confirm_launch_bgmi")
        ) {
          if (isLaunching) {
            CircularProgressIndicator(
              color = Color.White,
              modifier = Modifier.size(22.dp),
              strokeWidth = 2.5.dp
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "INJECTING TWEAKS...",
              color = Color.White,
              fontWeight = FontWeight.Black,
              fontSize = 14.sp
            )
          } else {
            Icon(
              imageVector = Icons.Default.PlayArrow,
              contentDescription = "Play",
              tint = Color.White
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "START BGMI (TURBO READY)",
              color = Color.White,
              fontWeight = FontWeight.Black,
              fontSize = 14.sp,
              letterSpacing = 0.5.sp
            )
          }
        }
      }
    }
  }
}

@Composable
private fun CircularMetricDial(
  label: String,
  value: String,
  progress: Float,
  accentColor: Color
) {
  val animatedProgress by animateFloatAsState(
    targetValue = progress.coerceIn(0f, 1f),
    animationSpec = tween(600, easing = FastOutSlowInEasing),
    label = "dial_progress"
  )

  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Box(
      contentAlignment = Alignment.Center,
      modifier = Modifier.size(68.dp)
    ) {
      CircularProgressIndicator(
        progress = { 1f },
        color = Color.White.copy(alpha = 0.1f),
        strokeWidth = 5.dp,
        modifier = Modifier.size(68.dp)
      )
      CircularProgressIndicator(
        progress = { animatedProgress },
        color = accentColor,
        strokeWidth = 5.dp,
        modifier = Modifier.size(68.dp)
      )
      Text(
        text = value,
        color = Color.White,
        fontSize = 13.sp,
        fontWeight = FontWeight.Black
      )
    }
    Spacer(modifier = Modifier.height(6.dp))
    Text(
      text = label,
      color = Color.LightGray,
      fontSize = 10.sp,
      fontWeight = FontWeight.SemiBold
    )
  }
}

@Composable
private fun BoosterToggleRow(
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = DarkSurface,
    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.05f)),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = title,
          color = Color.White,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = subtitle,
          color = GamingNeonCyan.copy(alpha = 0.8f),
          fontSize = 9.5.sp,
          fontFamily = FontFamily.Monospace
        )
      }

      Switch(
        checked = checked,
        onCheckedChange = onCheckedChange,
        colors = SwitchDefaults.colors(
          checkedThumbColor = Color.White,
          checkedTrackColor = MeeshoPrimaryPink,
          uncheckedThumbColor = Color.Gray,
          uncheckedTrackColor = Color.DarkGray
        )
      )
    }
  }
}
