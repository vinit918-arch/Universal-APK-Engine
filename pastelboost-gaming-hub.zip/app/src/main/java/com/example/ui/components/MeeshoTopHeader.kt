package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MeeshoDeepPink
import com.example.ui.theme.MeeshoDeepPurple
import com.example.ui.theme.MeeshoLightPink
import com.example.ui.theme.MeeshoPrimaryPink
import com.example.ui.theme.MeeshoPurple

@Composable
fun MeeshoTopHeader(
  searchQuery: String,
  onSearchQueryChange: (String) -> Unit,
  cartCount: Int,
  unreadNotifs: Int,
  onCartClick: () -> Unit,
  onNotificationClick: () -> Unit,
  onProfileClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val headerGradient = Brush.verticalGradient(
    colors = listOf(
      MeeshoDeepPink,
      MeeshoPrimaryPink,
      MeeshoPurple
    )
  )

  Column(
    modifier = modifier
      .fillMaxWidth()
      .background(headerGradient)
      .statusBarsPadding()
      .padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    // Top Row: Logo, Slogan, Actions
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.clickable { onProfileClick() }
      ) {
        // App Icon Avatar
        Box(
          modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.25f)),
          contentAlignment = Alignment.Center
        ) {
          Text(text = "🛍️", fontSize = 20.sp)
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "meesho",
              color = Color.White,
              fontWeight = FontWeight.Black,
              fontSize = 20.sp,
              letterSpacing = (-0.5).sp
            )
            Spacer(modifier = Modifier.width(4.dp))
            Surface(
              color = Color.White,
              shape = RoundedCornerShape(6.dp)
            ) {
              Text(
                text = "PLAY",
                color = MeeshoPrimaryPink,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 11.sp,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
          Text(
            text = "Sweet Deals & BGMI Turbo Mode",
            color = Color.White.copy(alpha = 0.9f),
            fontSize = 10.sp,
            fontWeight = FontWeight.Medium
          )
        }
      }

      // Action Icons: Notifications, Cart, Profile
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        // Notifications
        IconButton(
          onClick = onNotificationClick,
          modifier = Modifier
            .size(40.dp)
            .testTag("notification_button")
        ) {
          BadgedBox(
            badge = {
              if (unreadNotifs > 0) {
                Badge(
                  containerColor = Color(0xFFFFD54F),
                  contentColor = Color.Black
                ) {
                  Text(text = "$unreadNotifs", fontWeight = FontWeight.Bold, fontSize = 10.sp)
                }
              }
            }
          ) {
            Icon(
              imageVector = Icons.Default.Notifications,
              contentDescription = "Notifications",
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
          }
        }

        // Shopping Cart
        IconButton(
          onClick = onCartClick,
          modifier = Modifier
            .size(40.dp)
            .testTag("cart_button")
        ) {
          BadgedBox(
            badge = {
              if (cartCount > 0) {
                Badge(
                  containerColor = Color.White,
                  contentColor = MeeshoPrimaryPink
                ) {
                  Text(text = "$cartCount", fontWeight = FontWeight.Black, fontSize = 10.sp)
                }
              }
            }
          ) {
            Icon(
              imageVector = Icons.Default.ShoppingBag,
              contentDescription = "Shopping Bag",
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
          }
        }

        // Profile Avatar
        IconButton(
          onClick = onProfileClick,
          modifier = Modifier
            .size(40.dp)
            .testTag("profile_button")
        ) {
          Box(
            modifier = Modifier
              .size(32.dp)
              .clip(CircleShape)
              .background(Color.White.copy(alpha = 0.3f)),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.Person,
              contentDescription = "User Profile",
              tint = Color.White,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    // Sweet Search Bar with rounded corners & glassmorphism
    Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      shadowElevation = 4.dp,
      modifier = Modifier
        .fillMaxWidth()
        .height(50.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(
          imageVector = Icons.Default.Search,
          contentDescription = "Search",
          tint = MeeshoPurple,
          modifier = Modifier.size(22.dp)
        )

        Spacer(modifier = Modifier.width(8.dp))

        TextField(
          value = searchQuery,
          onValueChange = onSearchQueryChange,
          placeholder = {
            Text(
              text = "Search 'Phone Cooler', 'ADB Tweaks', 'Triggers'...",
              color = Color.Gray,
              fontSize = 13.sp
            )
          },
          singleLine = true,
          colors = TextFieldDefaults.colors(
            focusedContainerColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            disabledContainerColor = Color.Transparent,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent
          ),
          modifier = Modifier
            .weight(1f)
            .testTag("search_input")
        )

        if (searchQuery.isNotEmpty()) {
          IconButton(
            onClick = { onSearchQueryChange("") },
            modifier = Modifier.size(32.dp)
          ) {
            Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Clear Search",
              tint = Color.Gray,
              modifier = Modifier.size(18.dp)
            )
          }
        } else {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Mic,
              contentDescription = "Voice Search",
              tint = MeeshoPrimaryPink,
              modifier = Modifier
                .size(20.dp)
                .clickable { /* hint */ }
            )
            Spacer(modifier = Modifier.width(10.dp))
            Icon(
              imageVector = Icons.Default.CameraAlt,
              contentDescription = "Image Search",
              tint = MeeshoPurple,
              modifier = Modifier
                .size(20.dp)
                .clickable { /* hint */ }
            )
          }
        }
      }
    }
  }
}
