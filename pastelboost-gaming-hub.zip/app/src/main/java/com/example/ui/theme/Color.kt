package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Sweet Meesho Pastel & Pink Gradients
val MeeshoPrimaryPink = Color(0xFFE91E63)
val MeeshoDeepPink = Color(0xFFD81B60)
val MeeshoDarkPink = Color(0xFF9C1D60)
val MeeshoLightPink = Color(0xFFFCE4EC)
val MeeshoPastelPink = Color(0xFFFFF0F5)

// Lavender & Purple Accents
val MeeshoPurple = Color(0xFF8E24AA)
val MeeshoDeepPurple = Color(0xFF6A1B9A)
val MeeshoLightPurple = Color(0xFFF3E5F5)
val MeeshoLavender = Color(0xFFCE93D8)

// Gaming Neon & Turbo Highlights
val GamingNeonCyan = Color(0xFF00E5FF)
val GamingNeonGreen = Color(0xFF00E676)
val GamingNeonPink = Color(0xFFFF4081)
val GamingNeonAmber = Color(0xFFFFAB00)

// Soft Neutrals & Glass
val SoftSurfaceLight = Color(0xFFFFF7FA)
val SoftSurfaceGlass = Color(0xEEFFFFFF)
val TextDark = Color(0xFF212121)
val TextMuted = Color(0xFF757575)
val CardBorderPink = Color(0xFFFFD1DC)

// Dark Theme Colors
val DarkBackground = Color(0xFF130E1E)
val DarkSurface = Color(0xFF201633)
val DarkSurfaceElevated = Color(0xFF2C1F45)
val DarkTextPrimary = Color(0xFFFCE4EC)
val DarkTextSecondary = Color(0xFFB39DDB)

