package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.AdbCommand
import com.example.model.NotificationItem
import com.example.model.ProductItem
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GamingNeonCyan
import com.example.ui.theme.GamingNeonGreen
import com.example.ui.theme.GamingNeonPink
import com.example.ui.theme.MeeshoDeepPurple
import com.example.ui.theme.MeeshoLightPink
import com.example.ui.theme.MeeshoPastelPink
import com.example.ui.theme.MeeshoPrimaryPink
import com.example.ui.theme.MeeshoPurple
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted

@Composable
fun ProductDetailModal(
  product: ProductItem,
  onDismiss: () -> Unit,
  onAddToCart: (ProductItem) -> Unit,
  modifier: Modifier = Modifier
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = Color.White,
      modifier = modifier
        .fillMaxWidth(0.92f)
        .padding(vertical = 20.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        // Top Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Surface(
            shape = RoundedCornerShape(8.dp),
            color = MeeshoLightPink
          ) {
            Text(
              text = product.badge,
              color = MeeshoPrimaryPink,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
          }
        }

        // Product Banner
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .clip(RoundedCornerShape(16.dp))
            .background(
              Brush.verticalGradient(
                listOf(MeeshoPastelPink, MeeshoLightPink.copy(alpha = 0.5f))
              )
            ),
          contentAlignment = Alignment.Center
        ) {
          Text(text = product.iconEmoji, fontSize = 64.sp)
        }

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = product.title,
          fontSize = 16.sp,
          fontWeight = FontWeight.Black,
          color = TextDark
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Price Row
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "₹${product.price}",
            fontSize = 22.sp,
            fontWeight = FontWeight.Black,
            color = TextDark
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "₹${product.originalPrice}",
            fontSize = 14.sp,
            color = Color.Gray,
            textDecoration = TextDecoration.LineThrough
          )
          Spacer(modifier = Modifier.width(8.dp))
          Surface(
            shape = RoundedCornerShape(6.dp),
            color = Color(0xFF10B981)
          ) {
            Text(
              text = "${product.discountPercent}% OFF",
              color = Color.White,
              fontSize = 11.sp,
              fontWeight = FontWeight.ExtraBold,
              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Description
        Text(
          text = product.shortDesc,
          fontSize = 12.sp,
          color = TextMuted,
          lineHeight = 17.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Key Specs Chips
        Text(
          text = "Key Specifications:",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = TextDark
        )
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          product.specs.take(3).forEach { spec ->
            Surface(
              shape = RoundedCornerShape(8.dp),
              color = MeeshoPastelPink,
              border = androidx.compose.foundation.BorderStroke(1.dp, MeeshoLightPink)
            ) {
              Text(
                text = "✓ $spec",
                color = MeeshoPurple,
                fontSize = 10.5.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = {
            onAddToCart(product)
            onDismiss()
          },
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MeeshoPrimaryPink),
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
        ) {
          Icon(imageVector = Icons.Default.ShoppingBag, contentDescription = null, tint = Color.White)
          Spacer(modifier = Modifier.width(8.dp))
          Text(text = "ADD TO BAG (₹${product.price})", color = Color.White, fontWeight = FontWeight.Black)
        }
      }
    }
  }
}

@Composable
fun TerminalSimulationModal(
  command: AdbCommand,
  onCopy: () -> Unit,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = DarkBackground,
      border = androidx.compose.foundation.BorderStroke(1.5.dp, GamingNeonCyan.copy(alpha = 0.5f)),
      modifier = modifier
        .fillMaxWidth(0.92f)
        .padding(vertical = 20.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(18.dp)
      ) {
        // Header
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Terminal,
              contentDescription = null,
              tint = GamingNeonCyan,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Shizuku Shell Runner",
              color = Color.White,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Command Description
        Text(
          text = command.title,
          color = GamingNeonGreen,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold
        )
        Text(
          text = command.explanation,
          color = Color.LightGray,
          fontSize = 11.5.sp
        )

        Spacer(modifier = Modifier.height(12.dp))

        // Terminal Box
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color.Black,
          border = androidx.compose.foundation.BorderStroke(1.dp, GamingNeonCyan.copy(alpha = 0.3f)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Text(
              text = "$ ${command.command}",
              color = GamingNeonCyan,
              fontFamily = FontFamily.Monospace,
              fontSize = 11.5.sp,
              fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = "Executing with Shizuku daemon privileges...",
              color = Color.Gray,
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp
            )
            Text(
              text = "-> ${command.expectedOutput}",
              color = GamingNeonGreen,
              fontFamily = FontFamily.Monospace,
              fontSize = 10.5.sp,
              fontWeight = FontWeight.SemiBold
            )
            Text(
              text = "[SUCCESS] Return code: 0",
              color = GamingNeonGreen,
              fontFamily = FontFamily.Monospace,
              fontSize = 10.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Actions
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = {
              onCopy()
              onDismiss()
            },
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MeeshoPrimaryPink),
            modifier = Modifier.weight(1f).height(44.dp)
          ) {
            Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(text = "Copy Command", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }

          Button(
            onClick = onDismiss,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF374151)),
            modifier = Modifier.height(44.dp)
          ) {
            Text(text = "Close", color = Color.White, fontSize = 12.sp)
          }
        }
      }
    }
  }
}

@Composable
fun CustomCommandDialog(
  onDismiss: () -> Unit,
  onAddCommand: (String, String, String, String) -> Unit,
  modifier: Modifier = Modifier
) {
  var title by remember { mutableStateOf("") }
  var command by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("Custom Tweaks") }
  var explanation by remember { mutableStateOf("") }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = Color.White,
      modifier = modifier
        .fillMaxWidth(0.92f)
        .padding(vertical = 20.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "➕ Add Custom ADB Command",
            fontSize = 16.sp,
            fontWeight = FontWeight.Black,
            color = MeeshoPurple
          )
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = title,
          onValueChange = { title = it },
          label = { Text("Tweak Title (e.g. Set Max FPS)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = command,
          onValueChange = { command = it },
          label = { Text("ADB Shell Command (e.g. settings put...)") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          label = { Text("Category") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = explanation,
          onValueChange = { explanation = it },
          label = { Text("Description / What it does") },
          singleLine = false,
          maxLines = 3,
          modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = {
            onAddCommand(title, command, category, explanation)
          },
          enabled = title.isNotBlank() && command.isNotBlank(),
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MeeshoPrimaryPink),
          modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
        ) {
          Text(text = "Save ADB Command", color = Color.White, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
fun NotificationDialog(
  notifications: List<NotificationItem>,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = Color.White,
      modifier = modifier
        .fillMaxWidth(0.92f)
        .padding(vertical = 20.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.Notifications,
              contentDescription = null,
              tint = MeeshoPrimaryPink,
              modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Notifications (${notifications.size})",
              fontSize = 17.sp,
              fontWeight = FontWeight.Black,
              color = TextDark
            )
          }

          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
        ) {
          notifications.forEach { notif ->
            Surface(
              shape = RoundedCornerShape(14.dp),
              color = MeeshoPastelPink,
              border = androidx.compose.foundation.BorderStroke(1.dp, MeeshoLightPink),
              modifier = Modifier.fillMaxWidth()
            ) {
              Column(modifier = Modifier.padding(12.dp)) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text(
                    text = notif.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = MeeshoPurple
                  )
                  Text(
                    text = notif.timestamp,
                    fontSize = 10.sp,
                    color = Color.Gray
                  )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = notif.description,
                  fontSize = 11.5.sp,
                  color = TextDark,
                  lineHeight = 15.sp
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ProfileDialog(
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier
) {
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    Surface(
      shape = RoundedCornerShape(24.dp),
      color = Color.White,
      modifier = modifier
        .fillMaxWidth(0.92f)
        .padding(vertical = 20.dp)
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(20.dp)
          .verticalScroll(rememberScrollState())
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "Gamer & Meesho Profile",
            fontSize = 17.sp,
            fontWeight = FontWeight.Black,
            color = TextDark
          )
          IconButton(onClick = onDismiss) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Profile Avatar Card
        Surface(
          shape = RoundedCornerShape(16.dp),
          color = MeeshoPastelPink,
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(50.dp)
                .clip(CircleShape)
                .background(
                  Brush.linearGradient(listOf(MeeshoPrimaryPink, MeeshoPurple))
                ),
              contentAlignment = Alignment.Center
            ) {
              Text(text = "👑", fontSize = 24.sp)
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column {
              Text(
                text = "Vinite918 (BGMI Ace)",
                fontSize = 15.sp,
                fontWeight = FontWeight.Black,
                color = TextDark
              )
              Text(
                text = "Redmi Note 13 Pro+ 5G • Dimensity 7200",
                fontSize = 11.sp,
                color = MeeshoPurple,
                fontWeight = FontWeight.Medium
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // SuperCoins & Shizuku Status Cards
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFFFFF8E1),
            modifier = Modifier.weight(1f)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(text = "🪙 SuperCoins", fontSize = 11.sp, color = Color(0xFFF57F17), fontWeight = FontWeight.Bold)
              Text(text = "1,450", fontSize = 18.sp, fontWeight = FontWeight.Black, color = Color(0xFFE65100))
            }
          }

          Surface(
            shape = RoundedCornerShape(14.dp),
            color = Color(0xFFE8F5E9),
            modifier = Modifier.weight(1f)
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text(text = "⚡ Shizuku ADB", fontSize = 11.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
              Text(text = "Active v13.5", fontSize = 15.sp, fontWeight = FontWeight.Black, color = Color(0xFF1B5E20))
            }
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
          text = "Preset Optimization Tweak Profiles",
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          color = TextDark
        )

        Spacer(modifier = Modifier.height(8.dp))

        ProfileTweakRow("Redmi / POCO HyperOS Turbo", "Extreme 120Hz & Thermal Bypass")
        ProfileTweakRow("Snapdragon 8 Gen 2 / 8s", "Adreno GPU Frequency Lock")
        ProfileTweakRow("MediaTek Dimensity Boost", "Mali GPU Overclock & Touch Latency")

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = onDismiss,
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MeeshoPurple),
          modifier = Modifier.fillMaxWidth().height(46.dp)
        ) {
          Text(text = "Close Profile", color = Color.White, fontWeight = FontWeight.Bold)
        }
      }
    }
  }
}

@Composable
private fun ProfileTweakRow(title: String, desc: String) {
  Surface(
    shape = RoundedCornerShape(10.dp),
    color = MeeshoPastelPink,
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 3.dp)
  ) {
    Row(
      modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(text = "⚡", fontSize = 14.sp)
      Spacer(modifier = Modifier.width(8.dp))
      Column {
        Text(text = title, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextDark)
        Text(text = desc, fontSize = 10.sp, color = TextMuted)
      }
    }
  }
}
