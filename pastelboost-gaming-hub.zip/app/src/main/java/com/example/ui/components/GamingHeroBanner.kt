package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.GamingTelemetry
import com.example.ui.theme.GamingNeonCyan
import com.example.ui.theme.GamingNeonGreen
import com.example.ui.theme.GamingNeonPink
import com.example.ui.theme.MeeshoDeepPurple
import com.example.ui.theme.MeeshoPrimaryPink
import com.example.ui.theme.MeeshoPurple

@Composable
fun GamingHeroBanner(
  telemetry: GamingTelemetry,
  isBoostActive: Boolean,
  onLaunchGameClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  val infiniteTransition = rememberInfiniteTransition(label = "pulse_glow")
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.98f,
    targetValue = 1.03f,
    animationSpec = infiniteRepeatable(
      animation = tween(1000, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse_scale"
  )
  val glowAlpha by infiniteTransition.animateFloat(
    initialValue = 0.35f,
    targetValue = 0.75f,
    animationSpec = infiniteRepeatable(
      animation = tween(1200, easing = FastOutSlowInEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "glow_alpha"
  )

  val bannerGradient = Brush.horizontalGradient(
    colors = listOf(
      Color(0xFF28103F),
      Color(0xFF4A154B),
      Color(0xFF7A1C60)
    )
  )

  val buttonGradient = Brush.horizontalGradient(
    colors = listOf(
      MeeshoPrimaryPink,
      Color(0xFFFF4081),
      MeeshoPurple
    )
  )

  Box(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp)
  ) {
    // Outer glowing shadow box
    Box(
      modifier = Modifier
        .matchParentSize()
        .scale(pulseScale)
        .clip(RoundedCornerShape(24.dp))
        .background(
          Brush.radialGradient(
            colors = listOf(
              MeeshoPrimaryPink.copy(alpha = glowAlpha),
              Color.Transparent
            )
          )
        )
    )

    // Inner Banner Card
    Surface(
      shape = RoundedCornerShape(22.dp),
      color = Color.Transparent,
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(22.dp))
        .background(bannerGradient)
        .border(1.5.dp, MeeshoPrimaryPink.copy(alpha = 0.45f), RoundedCornerShape(22.dp))
        .padding(18.dp)
    ) {
      Column(
        modifier = Modifier.fillMaxWidth()
      ) {
        // Top Tag & Shizuku Status
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
              modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(if (isBoostActive) GamingNeonGreen else Color.Gray)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
              text = if (isBoostActive) "⚡ TURBO 120 FPS READY" else "⚪ ECO MODE",
              color = if (isBoostActive) GamingNeonGreen else Color.LightGray,
              fontSize = 11.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 0.5.sp
            )
          }

          Surface(
            shape = RoundedCornerShape(10.dp),
            color = Color.White.copy(alpha = 0.15f)
          ) {
            Text(
              text = "Shizuku ADB: Connected",
              color = GamingNeonCyan,
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Title & Description
        Text(
          text = "BGMI Extreme Performance Mode",
          color = Color.White,
          fontSize = 18.sp,
          fontWeight = FontWeight.Black
        )
        Text(
          text = "Zero frame drops, 1ms ultra touch response & Vulkan GPU pipeline.",
          color = Color.White.copy(alpha = 0.8f),
          fontSize = 12.sp,
          modifier = Modifier.padding(top = 2.dp)
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Live Hardware Telemetry Chips
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          // FPS Chip
          TelemetryMiniChip(
            icon = Icons.Default.Speed,
            label = "FPS",
            value = "${telemetry.currentFps}",
            unit = "FPS",
            valueColor = GamingNeonCyan,
            modifier = Modifier.weight(1f)
          )

          // Temp Chip
          TelemetryMiniChip(
            icon = Icons.Default.Thermostat,
            label = "TEMP",
            value = "${telemetry.batteryTempCelsius}°C",
            unit = "Cool",
            valueColor = GamingNeonGreen,
            modifier = Modifier.weight(1f)
          )

          // Latency Chip
          TelemetryMiniChip(
            icon = Icons.Default.Bolt,
            label = "PING",
            value = "${telemetry.pingMs}",
            unit = "ms",
            valueColor = GamingNeonPink,
            modifier = Modifier.weight(1f)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Pulsing Big Gradient Launch Button
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .scale(pulseScale)
            .shadow(
              elevation = 8.dp,
              shape = RoundedCornerShape(16.dp),
              spotColor = MeeshoPrimaryPink
            )
            .clip(RoundedCornerShape(16.dp))
            .background(buttonGradient)
            .clickable { onLaunchGameClick() }
            .padding(vertical = 14.dp)
            .testTag("launch_bgmi_button"),
          contentAlignment = Alignment.Center
        ) {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center
          ) {
            Icon(
              imageVector = Icons.Default.PlayArrow,
              contentDescription = "Launch",
              tint = Color.White,
              modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "⚡ LAUNCH GAME (BGMI)",
              color = Color.White,
              fontWeight = FontWeight.Black,
              fontSize = 15.sp,
              letterSpacing = 0.5.sp
            )
          }
        }
      }
    }
  }
}

@Composable
private fun TelemetryMiniChip(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  label: String,
  value: String,
  unit: String,
  valueColor: Color,
  modifier: Modifier = Modifier
) {
  Surface(
    shape = RoundedCornerShape(12.dp),
    color = Color.Black.copy(alpha = 0.35f),
    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(
          imageVector = icon,
          contentDescription = label,
          tint = valueColor,
          modifier = Modifier.size(12.dp)
        )
        Spacer(modifier = Modifier.width(3.dp))
        Text(
          text = label,
          color = Color.LightGray,
          fontSize = 9.sp,
          fontWeight = FontWeight.SemiBold
        )
      }
      Spacer(modifier = Modifier.height(2.dp))
      Text(
        text = value,
        color = valueColor,
        fontSize = 14.sp,
        fontWeight = FontWeight.ExtraBold
      )
    }
  }
}
