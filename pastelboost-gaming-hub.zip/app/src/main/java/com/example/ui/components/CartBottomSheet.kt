package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CartItem
import com.example.ui.theme.MeeshoLightPink
import com.example.ui.theme.MeeshoPastelPink
import com.example.ui.theme.MeeshoPrimaryPink
import com.example.ui.theme.MeeshoPurple
import com.example.ui.theme.TextDark
import com.example.ui.theme.TextMuted

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartBottomSheet(
  cartItems: List<CartItem>,
  appliedCoupon: String?,
  coinDiscount: Int,
  orderPlacedSuccess: Boolean,
  onDismiss: () -> Unit,
  onUpdateQuantity: (String, Int) -> Unit,
  onRemoveItem: (String) -> Unit,
  onPlaceOrder: () -> Unit,
  modifier: Modifier = Modifier
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  val subtotal = cartItems.sumOf { it.product.price * it.quantity }
  val couponDiscount = if (appliedCoupon != null && subtotal > 0) 50 else 0
  val finalTotal = (subtotal - couponDiscount - (if (subtotal > 0) coinDiscount else 0)).coerceAtLeast(0)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = Color.White,
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    modifier = modifier
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp)
        .navigationBarsPadding()
        .padding(bottom = 16.dp)
    ) {
      // Header
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
            modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(MeeshoLightPink),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.ShoppingBag,
              contentDescription = null,
              tint = MeeshoPrimaryPink,
              modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Text(
            text = "My Shopping Bag (${cartItems.size})",
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            color = TextDark
          )
        }

        IconButton(onClick = onDismiss) {
          Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = Color.Gray)
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (orderPlacedSuccess) {
        // Success celebration state
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 32.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "Success",
            tint = Color(0xFF10B981),
            modifier = Modifier.size(64.dp)
          )
          Spacer(modifier = Modifier.height(12.dp))
          Text(
            text = "🎉 Order Confirmed!",
            fontSize = 20.sp,
            fontWeight = FontWeight.Black,
            color = TextDark
          )
          Text(
            text = "BGMI Gaming Gadgets will arrive in 2 business days. Cash on Delivery is ready.",
            fontSize = 12.sp,
            color = TextMuted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
          )
        }
      } else if (cartItems.isEmpty()) {
        // Empty Cart State
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 40.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(text = "🛒", fontSize = 48.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Your Shopping Bag is Empty",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = TextDark
          )
          Text(
            text = "Explore sweet gaming deals and cooling accessories.",
            fontSize = 12.sp,
            color = TextMuted
          )
        }
      } else {
        // Free Delivery Banner
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = Color(0xFFE8F5E9),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.LocalShipping,
              contentDescription = null,
              tint = Color(0xFF2E7D32),
              modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Yay! You unlocked FREE Express Delivery on this order.",
              color = Color(0xFF2E7D32),
              fontSize = 11.5.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Items List
        LazyColumn(
          verticalArrangement = Arrangement.spacedBy(10.dp),
          modifier = Modifier
            .fillMaxWidth()
            .height(180.dp)
        ) {
          items(cartItems) { item ->
            CartItemRow(
              item = item,
              onIncrease = { onUpdateQuantity(item.product.id, 1) },
              onDecrease = { onUpdateQuantity(item.product.id, -1) },
              onDelete = { onRemoveItem(item.product.id) }
            )
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Coupon & Coins Banner
        Surface(
          shape = RoundedCornerShape(12.dp),
          color = MeeshoPastelPink,
          border = androidx.compose.foundation.BorderStroke(1.dp, MeeshoLightPink),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.LocalOffer,
                contentDescription = null,
                tint = MeeshoPrimaryPink,
                modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                text = "Coupon SWEET50 & Coins (-₹100)",
                color = MeeshoPrimaryPink,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold
              )
            }
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(0xFF10B981)
            ) {
              Text(
                text = "APPLIED",
                color = Color.White,
                fontSize = 9.sp,
                fontWeight = FontWeight.Black,
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Price Summary
        Column(
          verticalArrangement = Arrangement.spacedBy(4.dp),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Product Subtotal", color = TextMuted, fontSize = 12.sp)
            Text(text = "₹$subtotal", color = TextDark, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Special Coupon Discount", color = Color(0xFF10B981), fontSize = 12.sp)
            Text(text = "-₹$couponDiscount", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
          ) {
            Text(text = "Meesho SuperCoins Bonus", color = Color(0xFF10B981), fontSize = 12.sp)
            Text(text = "-₹$coinDiscount", color = Color(0xFF10B981), fontSize = 12.sp, fontWeight = FontWeight.Bold)
          }
          Divider(modifier = Modifier.padding(vertical = 4.dp), color = MeeshoLightPink)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(text = "Final Payable Amount", color = TextDark, fontSize = 15.sp, fontWeight = FontWeight.Black)
            Text(text = "₹$finalTotal", color = MeeshoPrimaryPink, fontSize = 18.sp, fontWeight = FontWeight.Black)
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Place Order Action
        Button(
          onClick = onPlaceOrder,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(containerColor = MeeshoPrimaryPink),
          modifier = Modifier
            .fillMaxWidth()
            .height(50.dp)
            .testTag("checkout_order_button")
        ) {
          Text(
            text = "PROCEED TO BUY (₹$finalTotal) ➔",
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Black
          )
        }
      }
    }
  }
}

@Composable
fun CartItemRow(
  item: CartItem,
  onIncrease: () -> Unit,
  onDecrease: () -> Unit,
  onDelete: () -> Unit
) {
  Surface(
    shape = RoundedCornerShape(14.dp),
    color = MeeshoPastelPink,
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(RoundedCornerShape(10.dp))
          .background(Color.White),
        contentAlignment = Alignment.Center
      ) {
        Text(text = item.product.iconEmoji, fontSize = 24.sp)
      }

      Spacer(modifier = Modifier.width(10.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = item.product.title,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = TextDark,
          maxLines = 1
        )
        Text(
          text = "₹${item.product.price} each",
          fontSize = 11.sp,
          color = MeeshoPrimaryPink,
          fontWeight = FontWeight.SemiBold
        )
      }

      // Quantity Controls
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        IconButton(
          onClick = onDecrease,
          modifier = Modifier.size(26.dp)
        ) {
          Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease", tint = MeeshoPurple, modifier = Modifier.size(14.dp))
        }

        Text(
          text = "${item.quantity}",
          fontSize = 12.sp,
          fontWeight = FontWeight.Black,
          color = TextDark
        )

        IconButton(
          onClick = onIncrease,
          modifier = Modifier.size(26.dp)
        ) {
          Icon(imageVector = Icons.Default.Add, contentDescription = "Increase", tint = MeeshoPurple, modifier = Modifier.size(14.dp))
        }

        IconButton(
          onClick = onDelete,
          modifier = Modifier.size(26.dp)
        ) {
          Icon(imageVector = Icons.Default.Delete, contentDescription = "Delete", tint = Color.Gray, modifier = Modifier.size(14.dp))
        }
      }
    }
  }
}
