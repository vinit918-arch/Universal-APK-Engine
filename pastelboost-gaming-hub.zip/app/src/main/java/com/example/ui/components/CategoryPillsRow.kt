package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MeeshoLightPink
import com.example.ui.theme.MeeshoPrimaryPink
import com.example.ui.theme.MeeshoPurple
import com.example.ui.theme.TextDark

@Composable
fun CategoryPillsRow(
  categories: List<String>,
  selectedCategory: String,
  onSelectCategory: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  LazyRow(
    modifier = modifier
      .fillMaxWidth()
      .padding(vertical = 10.dp),
    contentPadding = PaddingValues(horizontal = 16.dp),
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    items(categories) { category ->
      val isSelected = category == selectedCategory

      val backgroundColor by animateColorAsState(
        targetValue = if (isSelected) MeeshoPrimaryPink else Color.White,
        label = "category_bg"
      )

      val textColor by animateColorAsState(
        targetValue = if (isSelected) Color.White else TextDark,
        label = "category_text"
      )

      Box(
        modifier = Modifier
          .shadow(
            elevation = if (isSelected) 4.dp else 1.dp,
            shape = RoundedCornerShape(20.dp),
            spotColor = if (isSelected) MeeshoPrimaryPink.copy(alpha = 0.4f) else Color.Gray.copy(alpha = 0.2f)
          )
          .clip(RoundedCornerShape(20.dp))
          .background(backgroundColor)
          .then(
            if (!isSelected) {
              Modifier.border(1.dp, MeeshoLightPink, RoundedCornerShape(20.dp))
            } else {
              Modifier
            }
          )
          .clickable { onSelectCategory(category) }
          .padding(horizontal = 16.dp, vertical = 9.dp)
          .testTag("category_pill_${category.replace(" ", "_")}"),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = category,
          color = textColor,
          fontSize = 13.sp,
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
        )
      }
    }
  }
}
