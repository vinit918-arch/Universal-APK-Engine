package com.example.data

import com.example.model.AdbCommand
import com.example.model.NotificationItem
import com.example.model.ProductItem
import com.example.model.RiskLevel

object SampleData {

  val categories = listOf(
    "🔥 All Deals",
    "🎮 Gaming Hub",
    "⚡ Shizuku Boosters",
    "❄️ Phone Coolers",
    "🎧 TWS Audio",
    "🕹️ Triggers & Clips",
    "🔋 Fast Cables"
  )

  val adbCommands = listOf(
    AdbCommand(
      id = "cmd_1",
      title = "Force GPU Rendering",
      command = "settings put global force_gpu_rendering 1",
      category = "Display & GPU",
      explanation = "Forces hardware 2D rendering for all screen elements, offloading CPU overhead and fixing UI micro-stutters in BGMI.",
      riskLevel = RiskLevel.SAFE,
      impactTag = "+15% Smoothness",
      expectedOutput = "Done (global.force_gpu_rendering set to 1)"
    ),
    AdbCommand(
      id = "cmd_2",
      title = "Disable Thermal Limit",
      command = "settings put global thermal_limit_management_enabled 0",
      category = "Thermal & FPS",
      explanation = "Prevents aggressive CPU/GPU down-clocking during prolonged intense gaming sessions in warm conditions.",
      riskLevel = RiskLevel.TURBO_BOOST,
      impactTag = "No FPS Drops",
      expectedOutput = "Thermal throttling profile disabled successfully"
    ),
    AdbCommand(
      id = "cmd_3",
      title = "Disable HW Overlays",
      command = "settings put global disable_hw_overlays 1",
      category = "Display & GPU",
      explanation = "Uses GPU compositing for all window overlays, reducing frame tearing and input delay during rapid screen turns.",
      riskLevel = RiskLevel.SAFE,
      impactTag = "Zero Screen Tearing",
      expectedOutput = "Hardware overlays forced to GPU compositing"
    ),
    AdbCommand(
      id = "cmd_4",
      title = "Debloat MIUI / HyperOS Analytics",
      command = "pm uninstall -k --user 0 com.miui.analytics",
      category = "MIUI & Debloat",
      explanation = "Uninstalls background telemetry tracker package to free 200MB+ RAM and decrease background battery drain.",
      riskLevel = RiskLevel.SAFE,
      impactTag = "-200MB RAM Drain",
      expectedOutput = "Success (package com.miui.analytics removed for user 0)"
    ),
    AdbCommand(
      id = "cmd_5",
      title = "Touch Ultra Response",
      command = "settings put system max_fling_velocity 20000",
      category = "Touch & Sensitivity",
      explanation = "Increases touch panel flick response velocity cap to 20,000 for instant crosshair flick accuracy.",
      riskLevel = RiskLevel.SAFE,
      impactTag = "1ms Touch Polling",
      expectedOutput = "Touch max fling velocity calibrated to 20000"
    ),
    AdbCommand(
      id = "cmd_6",
      title = "Lock 120Hz Min Refresh Rate",
      command = "settings put system min_refresh_rate 120.0",
      category = "Display & GPU",
      explanation = "Locks the screen panel refresh rate to 120Hz minimum, preventing dynamic 60Hz drops in matchmaking.",
      riskLevel = RiskLevel.SAFE,
      impactTag = "Fixed 120Hz",
      expectedOutput = "Minimum system refresh rate set to 120.0 Hz"
    ),
    AdbCommand(
      id = "cmd_7",
      title = "Max Phantom Processes Fix",
      command = "settings put global max_phantom_processes 2147483647",
      category = "Memory & Shizuku",
      explanation = "Android 12+ killed background game helper tools. This raises the phantom process ceiling to maximum.",
      riskLevel = RiskLevel.SAFE,
      impactTag = "No Background Kills",
      expectedOutput = "Phantom process limit raised to INT_MAX"
    ),
    AdbCommand(
      id = "cmd_8",
      title = "High Performance Power Governor",
      command = "cmd power set-fixed-performance-mode-enabled true",
      category = "Thermal & FPS",
      explanation = "Activates sustained high-frequency CPU cores governor for rock-solid 90 FPS in combat drops.",
      riskLevel = RiskLevel.TURBO_BOOST,
      impactTag = "Max Clock Speed",
      expectedOutput = "Power manager: Fixed performance mode enabled"
    )
  )

  val products = listOf(
    ProductItem(
      id = "p1",
      title = "Black Shark Magnetic RGB Phone Cooler",
      category = "❄️ Phone Coolers",
      price = 899,
      originalPrice = 2999,
      discountPercent = 70,
      rating = 4.8f,
      reviewsCount = "1.2k",
      badge = "Meesho Mall",
      iconEmoji = "❄️",
      shortDesc = "Semiconductor Peltier Cryo-Cooling • Drops phone temp by 15°C in 30s • Silent Hydraulic Fan • RGB Aura Ring",
      specs = listOf("Peltier Chip", "RGB Lighting", "Type-C Powered", "Silent <25dB", "Magnetic Clamp"),
      isBestSeller = true
    ),
    ProductItem(
      id = "p2",
      title = "Carbon Fiber Gaming Finger Sleeves (4-Pack)",
      category = "🕹️ Triggers & Clips",
      price = 149,
      originalPrice = 499,
      discountPercent = 70,
      rating = 4.9f,
      reviewsCount = "4.5k",
      badge = "Best Price",
      iconEmoji = "🧤",
      shortDesc = "24-Needle Silver Fiber • Anti-Sweat Breathable Fabric • 0.25mm Ultra-Thin • High Sensitivity for BGMI Sniping",
      specs = listOf("24-Needle Knit", "Silver Fiber", "Zero Lag Touch", "Anti-Friction"),
      isBestSeller = true
    ),
    ProductItem(
      id = "p3",
      title = "CyberPink 35ms Ultra-Low Latency TWS Earbuds",
      category = "🎧 TWS Audio",
      price = 1299,
      originalPrice = 3499,
      discountPercent = 62,
      rating = 4.7f,
      reviewsCount = "890",
      badge = "Sweet Edition",
      iconEmoji = "🎧",
      shortDesc = "Game Mode 35ms Ultra-Low Latency • 13mm Bass Drivers • Quad-Mic ENC for Clear Squad Voice Chat • 32H Battery",
      specs = listOf("35ms Latency", "Bluetooth 5.3", "ENC Squad Mic", "IPX5 Splash Proof"),
      isBestSeller = true
    ),
    ProductItem(
      id = "p4",
      title = "Magnetic ARGB Dual-Fan Mobile Heat Sink",
      category = "❄️ Phone Coolers",
      price = 649,
      originalPrice = 1799,
      discountPercent = 64,
      rating = 4.6f,
      reviewsCount = "540",
      badge = "Verified Supplier",
      iconEmoji = "🌪️",
      shortDesc = "Aerospace Grade Aluminum Heat Fins • Dual 7000 RPM Turbine Fans • Universal Clamp fits all Redmi & Samsung Phones",
      specs = listOf("Dual Turbo Fans", "Aero Aluminum", "Digital Temp Display", "USB-C")
    ),
    ProductItem(
      id = "p5",
      title = "4-Trigger Capacitive Ergonomic Gamepad Clip",
      category = "🕹️ Triggers & Clips",
      price = 399,
      originalPrice = 999,
      discountPercent = 60,
      rating = 4.8f,
      reviewsCount = "2.1k",
      badge = "Top Rated",
      iconEmoji = "🎮",
      shortDesc = "Instant Mechanical Microswitch Clicks • 4-Finger Claw Grip in 1 Second • Silicone Pads Protect Screen from Scratches",
      specs = listOf("4 Triggers", "Mouse Click Feel", "Zero Delay", "No Ban Safe")
    ),
    ProductItem(
      id = "p6",
      title = "Graphene Super-Conductor Thermal Sheet",
      category = "❄️ Phone Coolers",
      price = 199,
      originalPrice = 499,
      discountPercent = 60,
      rating = 4.5f,
      reviewsCount = "310",
      badge = "Special Offer",
      iconEmoji = "🧊",
      shortDesc = "1800 W/m-K Heat Diffusion • Spreads Snapdragon CPU Heat Evenly across Back Cover • Ultra-Slim 0.15mm Fit under cases",
      specs = listOf("Pure Graphene", "Reusable Adhesive", "0.15mm Thin", "Case Compatible")
    ),
    ProductItem(
      id = "p7",
      title = "Sweet Pastel 66W 90° Elbow Gaming Cable",
      category = "🔋 Fast Cables",
      price = 299,
      originalPrice = 799,
      discountPercent = 62,
      rating = 4.7f,
      reviewsCount = "1.4k",
      badge = "Trending",
      iconEmoji = "⚡",
      shortDesc = "Right-Angle L-Shape Plug for Unhindered Hand Grip • 6A Fast Flash Charge • Braided Pastel Pink & Lavender Silicone Shield",
      specs = listOf("90° L-Shaped Plug", "66W Fast Charging", "Braided Silicone", "LED Indicator")
    ),
    ProductItem(
      id = "p8",
      title = "Ultra-Clear 120Hz Matte Gaming Tempered Glass",
      category = "🕹️ Triggers & Clips",
      price = 249,
      originalPrice = 599,
      discountPercent = 58,
      rating = 4.9f,
      reviewsCount = "980",
      badge = "Free Delivery",
      iconEmoji = "📱",
      shortDesc = "Silky Smooth Oleophobic Matte Finish • Anti-Oil & Sweat-Proof • 9H Hardness • Zero Glare under Sunlight",
      specs = listOf("9H Hardness", "Anti-Glare Matte", "120Hz Touch Flow", "Oleophobic Coating")
    )
  )

  val sampleNotifications = listOf(
    NotificationItem(
      id = "notif_1",
      title = "⚡ BGMI 90 FPS Turbo Mode Activated!",
      description = "RAM cleaned (+940 MB), GPU boost applied, and touch latency locked to 1ms.",
      timestamp = "2 mins ago"
    ),
    NotificationItem(
      id = "notif_2",
      title = "🎁 Special Sweet Meesho Coin Bonus",
      description = "You received 150 SuperCoins on your gaming gadget wishlist!",
      timestamp = "1 hour ago",
      type = "coins"
    ),
    NotificationItem(
      id = "notif_3",
      title = "🛒 Price Drop Alert!",
      description = "Black Shark RGB Phone Cooler dropped to ₹899 (70% OFF) for 3 hours only.",
      timestamp = "Yesterday",
      type = "price_drop"
    )
  )
}
