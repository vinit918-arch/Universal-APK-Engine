package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.SampleData
import com.example.model.AppNavTab
import com.example.ui.components.CartBottomSheet
import com.example.ui.components.CategoryPillsRow
import com.example.ui.components.CustomCommandDialog
import com.example.ui.components.GameLaunchModal
import com.example.ui.components.GamingHeroBanner
import com.example.ui.components.MeeshoTopHeader
import com.example.ui.components.NotificationDialog
import com.example.ui.components.ProductDetailModal
import com.example.ui.components.ProductGridSection
import com.example.ui.components.ProfileDialog
import com.example.ui.components.ShizukuSection
import com.example.ui.components.TerminalSimulationModal
import com.example.ui.theme.MeeshoLightPink
import com.example.ui.theme.MeeshoPastelPink
import com.example.ui.theme.MeeshoPrimaryPink
import com.example.ui.theme.MeeshoPurple
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.SoftSurfaceLight
import com.example.viewmodel.MeeshoGamingViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
  private val viewModel: MeeshoGamingViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        MeeshoMainScreen(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun MeeshoMainScreen(
  viewModel: MeeshoGamingViewModel,
  modifier: Modifier = Modifier
) {
  val state by viewModel.uiState.collectAsState()
  val listState = rememberLazyListState()
  val coroutineScope = rememberCoroutineScope()

  // Filter products by category & search query
  val filteredProducts = state.products.filter { product ->
    val matchesCategory = when (state.selectedCategory) {
      "🔥 All Deals" -> true
      "🎮 Gaming Hub" -> product.category.contains("Triggers") || product.category.contains("Coolers")
      "⚡ Shizuku Boosters" -> true
      else -> product.category == state.selectedCategory
    }
    val matchesQuery = state.searchQuery.isBlank() ||
      product.title.contains(state.searchQuery, ignoreCase = true) ||
      product.shortDesc.contains(state.searchQuery, ignoreCase = true)

    matchesCategory && matchesQuery
  }

  // Filter ADB commands by search query
  val filteredAdbCommands = state.adbCommands.filter { cmd ->
    state.searchQuery.isBlank() ||
      cmd.title.contains(state.searchQuery, ignoreCase = true) ||
      cmd.command.contains(state.searchQuery, ignoreCase = true) ||
      cmd.category.contains(state.searchQuery, ignoreCase = true)
  }

  Scaffold(
    modifier = modifier.fillMaxSize(),
    containerColor = SoftSurfaceLight,
    topBar = {
      MeeshoTopHeader(
        searchQuery = state.searchQuery,
        onSearchQueryChange = { viewModel.setSearchQuery(it) },
        cartCount = state.cartItems.sumOf { it.quantity },
        unreadNotifs = state.notifications.count { it.isUnread },
        onCartClick = { viewModel.openCartSheet() },
        onNotificationClick = { viewModel.openNotificationDialog() },
        onProfileClick = { viewModel.openProfileDialog() }
      )
    },
    bottomBar = {
      MeeshoBottomNavigation(
        currentTab = state.currentTab,
        cartCount = state.cartItems.sumOf { it.quantity },
        onSelectTab = { tab ->
          viewModel.setTab(tab)
          when (tab) {
            AppNavTab.HOME -> {
              coroutineScope.launch { listState.animateScrollToItem(0) }
            }
            AppNavTab.GAMING_HUB -> {
              viewModel.openGameLaunchModal()
            }
            AppNavTab.SHIZUKU_ADB -> {
              coroutineScope.launch { listState.animateScrollToItem(2) }
            }
            AppNavTab.CART -> {
              viewModel.openCartSheet()
            }
            AppNavTab.PROFILE -> {
              viewModel.openProfileDialog()
            }
          }
        }
      )
    }
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
      contentAlignment = Alignment.TopCenter
    ) {
      LazyColumn(
        state = listState,
        modifier = Modifier
          .fillMaxSize()
          .widthIn(max = 640.dp)
      ) {
        // 1. Interactive Category Pills
        item(key = "categories") {
          CategoryPillsRow(
            categories = SampleData.categories,
            selectedCategory = state.selectedCategory,
            onSelectCategory = { category ->
              viewModel.setCategory(category)
              if (category == "⚡ Shizuku Boosters") {
                coroutineScope.launch { listState.animateScrollToItem(2) }
              }
            }
          )
        }

        // 2. Gaming Launcher Hero Banner
        item(key = "hero_banner") {
          GamingHeroBanner(
            telemetry = state.telemetry,
            isBoostActive = state.isBoostActive,
            onLaunchGameClick = { viewModel.openGameLaunchModal() }
          )
        }

        // 3. Shizuku & LADB Performance Commands Section
        item(key = "shizuku_section") {
          ShizukuSection(
            commands = filteredAdbCommands,
            lastCopiedId = state.lastCopiedCommand,
            onCopyCommand = { cmd -> viewModel.copyAdbCommand(cmd) },
            onTestCommand = { cmd -> viewModel.testAdbCommandInTerminal(cmd) },
            onAddNewCommandClick = { viewModel.openCustomCommandDialog() }
          )
        }

        // 4. Meesho Sweet Product Grid
        item(key = "products_grid") {
          ProductGridSection(
            products = filteredProducts,
            wishlistIds = state.wishlistIds,
            onProductClick = { product -> viewModel.openProductDetail(product) },
            onAddToCart = { product -> viewModel.addToCart(product) },
            onToggleWishlist = { id -> viewModel.toggleWishlist(id) }
          )
        }

        // Bottom Spacer for scrolling comfort
        item(key = "bottom_space") {
          Spacer(modifier = Modifier.height(32.dp))
        }
      }
    }
  }

  // Modals & Dialogs
  if (state.isGameLaunchModalOpen) {
    GameLaunchModal(
      telemetry = state.telemetry,
      isLaunching = state.isLaunchingGame,
      terminalLogs = state.terminalOutputLogs,
      onDismiss = { viewModel.closeGameLaunchModal() },
      onLaunchGame = { viewModel.triggerBgmiLaunch() }
    )
  }

  if (state.isCartSheetOpen) {
    CartBottomSheet(
      cartItems = state.cartItems,
      appliedCoupon = state.appliedCoupon,
      coinDiscount = state.coinDiscount,
      orderPlacedSuccess = state.orderPlacedSuccess,
      onDismiss = { viewModel.closeCartSheet() },
      onUpdateQuantity = { id, delta -> viewModel.updateCartQuantity(id, delta) },
      onRemoveItem = { id -> viewModel.removeFromCart(id) },
      onPlaceOrder = { viewModel.placeOrder() }
    )
  }

  if (state.selectedProductDetail != null) {
    ProductDetailModal(
      product = state.selectedProductDetail!!,
      onDismiss = { viewModel.closeProductDetail() },
      onAddToCart = { product -> viewModel.addToCart(product) }
    )
  }

  if (state.isTerminalModalOpen && state.activeTerminalCommand != null) {
    TerminalSimulationModal(
      command = state.activeTerminalCommand!!,
      onCopy = { viewModel.copyAdbCommand(state.activeTerminalCommand!!) },
      onDismiss = { viewModel.closeTerminalModal() }
    )
  }

  if (state.isCustomCommandDialogOpen) {
    CustomCommandDialog(
      onDismiss = { viewModel.closeCustomCommandDialog() },
      onAddCommand = { title, cmd, cat, exp ->
        viewModel.addCustomAdbCommand(title, cmd, cat, exp)
      }
    )
  }

  if (state.isNotificationDialogOpen) {
    NotificationDialog(
      notifications = state.notifications,
      onDismiss = { viewModel.closeNotificationDialog() }
    )
  }

  if (state.isProfileDialogOpen) {
    ProfileDialog(
      onDismiss = { viewModel.closeProfileDialog() }
    )
  }
}

@Composable
fun MeeshoBottomNavigation(
  currentTab: AppNavTab,
  cartCount: Int,
  onSelectTab: (AppNavTab) -> Unit,
  modifier: Modifier = Modifier
) {
  Surface(
    color = Color.White,
    shadowElevation = 8.dp,
    border = androidx.compose.foundation.BorderStroke(1.dp, MeeshoLightPink.copy(alpha = 0.6f)),
    modifier = modifier.fillMaxWidth()
  ) {
    NavigationBar(
      containerColor = Color.White,
      tonalElevation = 0.dp,
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
    ) {
      // 1. Home / Shop
      NavigationBarItem(
        selected = currentTab == AppNavTab.HOME,
        onClick = { onSelectTab(AppNavTab.HOME) },
        icon = {
          Icon(imageVector = Icons.Default.Home, contentDescription = "Shop")
        },
        label = {
          Text(text = "Shop", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = MeeshoPrimaryPink,
          selectedTextColor = MeeshoPrimaryPink,
          indicatorColor = MeeshoPastelPink,
          unselectedIconColor = Color.Gray,
          unselectedTextColor = Color.Gray
        ),
        modifier = Modifier.testTag("nav_shop")
      )

      // 2. BGMI Hub
      NavigationBarItem(
        selected = currentTab == AppNavTab.GAMING_HUB,
        onClick = { onSelectTab(AppNavTab.GAMING_HUB) },
        icon = {
          Icon(imageVector = Icons.Default.SportsEsports, contentDescription = "BGMI Hub")
        },
        label = {
          Text(text = "BGMI Hub", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = MeeshoPrimaryPink,
          selectedTextColor = MeeshoPrimaryPink,
          indicatorColor = MeeshoPastelPink,
          unselectedIconColor = Color.Gray,
          unselectedTextColor = Color.Gray
        ),
        modifier = Modifier.testTag("nav_bgmi")
      )

      // 3. Shizuku ADB
      NavigationBarItem(
        selected = currentTab == AppNavTab.SHIZUKU_ADB,
        onClick = { onSelectTab(AppNavTab.SHIZUKU_ADB) },
        icon = {
          Icon(imageVector = Icons.Default.Terminal, contentDescription = "Shizuku ADB")
        },
        label = {
          Text(text = "Shizuku", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = MeeshoPrimaryPink,
          selectedTextColor = MeeshoPrimaryPink,
          indicatorColor = MeeshoPastelPink,
          unselectedIconColor = Color.Gray,
          unselectedTextColor = Color.Gray
        ),
        modifier = Modifier.testTag("nav_shizuku")
      )

      // 4. Cart / Bag
      NavigationBarItem(
        selected = currentTab == AppNavTab.CART,
        onClick = { onSelectTab(AppNavTab.CART) },
        icon = {
          BadgedBox(
            badge = {
              if (cartCount > 0) {
                Badge(
                  containerColor = MeeshoPrimaryPink,
                  contentColor = Color.White
                ) {
                  Text(text = "$cartCount", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
              }
            }
          ) {
            Icon(imageVector = Icons.Default.ShoppingBag, contentDescription = "Shopping Bag")
          }
        },
        label = {
          Text(text = "Bag", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = MeeshoPrimaryPink,
          selectedTextColor = MeeshoPrimaryPink,
          indicatorColor = MeeshoPastelPink,
          unselectedIconColor = Color.Gray,
          unselectedTextColor = Color.Gray
        ),
        modifier = Modifier.testTag("nav_cart")
      )

      // 5. Profile / Account
      NavigationBarItem(
        selected = currentTab == AppNavTab.PROFILE,
        onClick = { onSelectTab(AppNavTab.PROFILE) },
        icon = {
          Icon(imageVector = Icons.Default.Person, contentDescription = "Profile")
        },
        label = {
          Text(text = "Account", fontSize = 10.5.sp, fontWeight = FontWeight.Bold)
        },
        colors = NavigationBarItemDefaults.colors(
          selectedIconColor = MeeshoPrimaryPink,
          selectedTextColor = MeeshoPrimaryPink,
          indicatorColor = MeeshoPastelPink,
          unselectedIconColor = Color.Gray,
          unselectedTextColor = Color.Gray
        ),
        modifier = Modifier.testTag("nav_account")
      )
    }
  }
}
