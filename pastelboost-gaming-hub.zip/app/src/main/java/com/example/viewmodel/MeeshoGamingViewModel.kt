package com.example.viewmodel

import android.app.Application
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.SampleData
import com.example.model.AdbCommand
import com.example.model.AppNavTab
import com.example.model.CartItem
import com.example.model.GamingTelemetry
import com.example.model.NotificationItem
import com.example.model.ProductItem
import com.example.model.RiskLevel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlin.random.Random

data class MeeshoUiState(
  val currentTab: AppNavTab = AppNavTab.HOME,
  val searchQuery: String = "",
  val selectedCategory: String = "🔥 All Deals",
  val products: List<ProductItem> = SampleData.products,
  val adbCommands: List<AdbCommand> = SampleData.adbCommands,
  val cartItems: List<CartItem> = listOf(
    CartItem(SampleData.products[0], 1),
    CartItem(SampleData.products[1], 2)
  ),
  val wishlistIds: Set<String> = setOf("p1", "p3"),
  val notifications: List<NotificationItem> = SampleData.sampleNotifications,
  val telemetry: GamingTelemetry = GamingTelemetry(),
  val isGameLaunchModalOpen: Boolean = false,
  val isLaunchingGame: Boolean = false,
  val isBoostActive: Boolean = true,
  val terminalOutputLogs: List<String> = listOf(
    "[SYSTEM] Shizuku ADB daemon connected (v13.5.4)",
    "[TURBO] Qualcomm Adreno 650 GPU Frequency Locked @ 670MHz",
    "[TWEAK] BGMI target package: com.pubg.imobile (Priority: HIGH)",
    "[FPS] Screen min_refresh_rate set to 120.0 Hz"
  ),
  val activeTerminalCommand: AdbCommand? = null,
  val isTerminalModalOpen: Boolean = false,
  val isCartSheetOpen: Boolean = false,
  val isProfileDialogOpen: Boolean = false,
  val isNotificationDialogOpen: Boolean = false,
  val isCustomCommandDialogOpen: Boolean = false,
  val selectedProductDetail: ProductItem? = null,
  val appliedCoupon: String? = "SWEET50",
  val coinDiscount: Int = 50,
  val orderPlacedSuccess: Boolean = false,
  val lastCopiedCommand: String? = null
)

class MeeshoGamingViewModel(application: Application) : AndroidViewModel(application) {

  private val _uiState = MutableStateFlow(MeeshoUiState())
  val uiState: StateFlow<MeeshoUiState> = _uiState.asStateFlow()

  init {
    startTelemetryEngine()
  }

  private fun startTelemetryEngine() {
    viewModelScope.launch {
      while (true) {
        delay(1200)
        _uiState.update { state ->
          val baseFps = if (state.isBoostActive) 118 else 85
          val randomFps = (baseFps + Random.nextInt(-2, 3)).coerceIn(60, 120)
          val randomCpu = (38 + Random.nextInt(-5, 8)).coerceIn(20, 85)
          val randomGpu = (54 + Random.nextInt(-6, 9)).coerceIn(30, 95)
          val randomTemp = (33.2f + (Random.nextFloat() * 1.5f)).coerceIn(31f, 38f)
          val randomPing = (19 + Random.nextInt(-3, 5)).coerceIn(15, 45)

          state.copy(
            telemetry = state.telemetry.copy(
              currentFps = randomFps,
              cpuUsagePercent = randomCpu,
              gpuUsagePercent = randomGpu,
              batteryTempCelsius = (randomTemp * 10).toInt() / 10f,
              pingMs = randomPing
            )
          )
        }
      }
    }
  }

  fun setTab(tab: AppNavTab) {
    _uiState.update { it.copy(currentTab = tab) }
  }

  fun setSearchQuery(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
  }

  fun setCategory(category: String) {
    _uiState.update { it.copy(selectedCategory = category) }
  }

  fun openGameLaunchModal() {
    _uiState.update { it.copy(isGameLaunchModalOpen = true) }
  }

  fun closeGameLaunchModal() {
    _uiState.update { it.copy(isGameLaunchModalOpen = false, isLaunchingGame = false) }
  }

  fun triggerBgmiLaunch() {
    viewModelScope.launch {
      _uiState.update {
        it.copy(
          isLaunchingGame = true,
          terminalOutputLogs = it.terminalOutputLogs + listOf(
            "[TURBO] 🚀 Initializing BGMI Launch Engine...",
            "[ADB] Applying 'settings put global disable_hw_overlays 1'",
            "[SHIZUKU] Killing background tasks to free 1,120MB RAM...",
            "[GPU] Enabling Vulkan graphics API pipeline...",
            "[FPS] BGMI 90/120 FPS Turbo mode is LOCKED!"
          )
        )
      }
      delay(1800)
      _uiState.update {
        it.copy(
          isLaunchingGame = false,
          isBoostActive = true
        )
      }

      // Try launching BGMI intent or show success toast
      val context = getApplication<Application>().applicationContext
      val pm = context.packageManager
      val bgmiIntent = pm.getLaunchIntentForPackage("com.pubg.imobile")
        ?: pm.getLaunchIntentForPackage("com.tencent.ig")
        ?: pm.getLaunchIntentForPackage("com.dts.freefireth")

      if (bgmiIntent != null) {
        bgmiIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
          context.startActivity(bgmiIntent)
        } catch (e: Exception) {
          Toast.makeText(context, "BGMI Turbo Activated! Ready to play.", Toast.LENGTH_SHORT).show()
        }
      } else {
        Toast.makeText(
          context,
          "⚡ BGMI 90 FPS Turbo Booster Activated Successfully!",
          Toast.LENGTH_LONG
        ).show()
      }
    }
  }

  fun toggleBoostActive() {
    _uiState.update { it.copy(isBoostActive = !it.isBoostActive) }
  }

  fun copyAdbCommand(command: AdbCommand) {
    val context = getApplication<Application>().applicationContext
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("ADB Command", command.command)
    clipboard.setPrimaryClip(clip)

    _uiState.update { it.copy(lastCopiedCommand = command.id) }
    Toast.makeText(
      context,
      "📋 Copied '${command.title}' to clipboard for LADB / Shizuku!",
      Toast.LENGTH_SHORT
    ).show()
  }

  fun testAdbCommandInTerminal(command: AdbCommand) {
    viewModelScope.launch {
      _uiState.update {
        it.copy(
          activeTerminalCommand = command,
          isTerminalModalOpen = true
        )
      }
    }
  }

  fun closeTerminalModal() {
    _uiState.update { it.copy(isTerminalModalOpen = false, activeTerminalCommand = null) }
  }

  fun addCustomAdbCommand(title: String, command: String, category: String, explanation: String) {
    if (title.isBlank() || command.isBlank()) return
    val newCmd = AdbCommand(
      id = "custom_${System.currentTimeMillis()}",
      title = title,
      command = command,
      category = if (category.isBlank()) "Custom Shell" else category,
      explanation = if (explanation.isBlank()) "User custom ADB tweak." else explanation,
      riskLevel = RiskLevel.TURBO_BOOST,
      impactTag = "Custom Mod",
      expectedOutput = "Executed custom shell script ($command) successfully",
      isCustom = true
    )
    _uiState.update {
      it.copy(
        adbCommands = listOf(newCmd) + it.adbCommands,
        isCustomCommandDialogOpen = false
      )
    }
    Toast.makeText(getApplication(), "✅ Custom ADB Command Added!", Toast.LENGTH_SHORT).show()
  }

  fun openCustomCommandDialog() {
    _uiState.update { it.copy(isCustomCommandDialogOpen = true) }
  }

  fun closeCustomCommandDialog() {
    _uiState.update { it.copy(isCustomCommandDialogOpen = false) }
  }

  // Shopping Cart & Wishlist
  fun addToCart(product: ProductItem) {
    _uiState.update { state ->
      val existing = state.cartItems.find { it.product.id == product.id }
      val updated = if (existing != null) {
        state.cartItems.map {
          if (it.product.id == product.id) it.copy(quantity = it.quantity + 1) else it
        }
      } else {
        state.cartItems + CartItem(product, 1)
      }
      state.copy(cartItems = updated)
    }
    Toast.makeText(
      getApplication(),
      "🛍️ Added '${product.title}' to Bag!",
      Toast.LENGTH_SHORT
    ).show()
  }

  fun updateCartQuantity(productId: String, delta: Int) {
    _uiState.update { state ->
      val updated = state.cartItems.mapNotNull { item ->
        if (item.product.id == productId) {
          val newQty = item.quantity + delta
          if (newQty > 0) item.copy(quantity = newQty) else null
        } else item
      }
      state.copy(cartItems = updated)
    }
  }

  fun removeFromCart(productId: String) {
    _uiState.update { state ->
      state.copy(cartItems = state.cartItems.filterNot { it.product.id == productId })
    }
  }

  fun toggleWishlist(productId: String) {
    _uiState.update { state ->
      val updated = if (state.wishlistIds.contains(productId)) {
        state.wishlistIds - productId
      } else {
        state.wishlistIds + productId
      }
      state.copy(wishlistIds = updated)
    }
  }

  fun openProductDetail(product: ProductItem) {
    _uiState.update { it.copy(selectedProductDetail = product) }
  }

  fun closeProductDetail() {
    _uiState.update { it.copy(selectedProductDetail = null) }
  }

  fun openCartSheet() {
    _uiState.update { it.copy(isCartSheetOpen = true, orderPlacedSuccess = false) }
  }

  fun closeCartSheet() {
    _uiState.update { it.copy(isCartSheetOpen = false, orderPlacedSuccess = false) }
  }

  fun openProfileDialog() {
    _uiState.update { it.copy(isProfileDialogOpen = true) }
  }

  fun closeProfileDialog() {
    _uiState.update { it.copy(isProfileDialogOpen = false) }
  }

  fun openNotificationDialog() {
    _uiState.update { it.copy(isNotificationDialogOpen = true) }
  }

  fun closeNotificationDialog() {
    _uiState.update { it.copy(isNotificationDialogOpen = false) }
  }

  fun placeOrder() {
    viewModelScope.launch {
      _uiState.update { it.copy(orderPlacedSuccess = true) }
      delay(2200)
      _uiState.update { it.copy(cartItems = emptyList(), isCartSheetOpen = false, orderPlacedSuccess = false) }
      Toast.makeText(getApplication(), "🎉 Order Placed! Free Delivery in 2 Days.", Toast.LENGTH_LONG).show()
    }
  }
}
