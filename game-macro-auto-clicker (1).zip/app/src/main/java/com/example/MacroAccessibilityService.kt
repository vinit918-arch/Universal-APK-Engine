package com.example

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MacroAccessibilityService : AccessibilityService() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var clickLoopJob: Job? = null

    companion object {
        private const val TAG = "MacroAccessibility"
        var instance: MacroAccessibilityService? = null
            private set

        fun isServiceRunning(): Boolean = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        MacroManager.setAccessibilityEnabled(true)
        Log.d(TAG, "MacroAccessibilityService connected")

        // Observe clicking state changes
        serviceScope.launch {
            MacroManager.state.collect { state ->
                if (state.isClickingActive) {
                    startAutoClickLoop()
                } else {
                    stopAutoClickLoop()
                }
            }
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No specific event listening required for gesture macro execution
    }

    override fun onInterrupt() {
        stopAutoClickLoop()
        Log.d(TAG, "MacroAccessibilityService interrupted")
    }

    override fun onUnbind(intent: Intent?): Boolean {
        stopAutoClickLoop()
        instance = null
        MacroManager.setAccessibilityEnabled(false)
        serviceScope.cancel()
        Log.d(TAG, "MacroAccessibilityService unbound")
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        stopAutoClickLoop()
        instance = null
        MacroManager.setAccessibilityEnabled(false)
        serviceScope.cancel()
        Log.d(TAG, "MacroAccessibilityService destroyed")
    }

    private fun startAutoClickLoop() {
        // If Shizuku ADB is available, Shizuku handles rootless ADB injection directly on IO thread
        if (ShizukuTapEngine.isReadyForAdbInjection()) {
            Log.d(TAG, "Shizuku ADB active, skipping accessibility gesture loop")
            return
        }

        if (clickLoopJob?.isActive == true) return

        clickLoopJob = serviceScope.launch {
            while (isActive && MacroManager.state.value.isClickingActive) {
                // Check again in case Shizuku was enabled
                if (ShizukuTapEngine.isReadyForAdbInjection()) {
                    break
                }
                val state = MacroManager.state.value
                val targetX = state.targetX
                val targetY = state.targetY
                val interval = state.intervalMs.toLong().coerceAtLeast(10L)
                val duration = state.pressDurationMs.coerceAtLeast(1L).coerceAtMost(interval)

                dispatchTap(targetX, targetY, duration)
                MacroManager.incrementClickCount()

                delay(interval)
            }
        }
    }

    private fun stopAutoClickLoop() {
        clickLoopJob?.cancel()
        clickLoopJob = null
    }

    fun dispatchTap(x: Float, y: Float, durationMs: Long = 10L, callback: ((Boolean) -> Unit)? = null) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N) {
            callback?.invoke(false)
            return
        }

        try {
            val clickPath = Path().apply {
                moveTo(x.coerceAtLeast(0f), y.coerceAtLeast(0f))
            }
            val stroke = GestureDescription.StrokeDescription(
                clickPath,
                0,
                durationMs.coerceAtLeast(1L)
            )
            val gesture = GestureDescription.Builder()
                .addStroke(stroke)
                .build()

            dispatchGesture(
                gesture,
                object : GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        super.onCompleted(gestureDescription)
                        callback?.invoke(true)
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        super.onCancelled(gestureDescription)
                        callback?.invoke(false)
                    }
                },
                null
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error executing dispatchTap: ${e.message}", e)
            callback?.invoke(false)
        }
    }
}
