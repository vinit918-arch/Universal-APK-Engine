package com.example

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.HelpOutline
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.ui.theme.EditorialBorder
import com.example.ui.theme.EditorialBorderSubtle
import com.example.ui.theme.EditorialCard
import com.example.ui.theme.EditorialNoir
import com.example.ui.theme.EditorialSurface
import com.example.ui.theme.ElectricCyan
import com.example.ui.theme.ElectricCyanDark
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.RedMagicCrimson
import com.example.ui.theme.TextEditorialMuted
import com.example.ui.theme.TextEditorialMono
import com.example.ui.theme.TextEditorialPrimary
import com.example.ui.theme.TurboAmber
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                TriggerMainScreen()
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TriggerMainScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val macroState by MacroManager.state.collectAsState()
    val shizukuStatus by ShizukuTapEngine.status.collectAsState()

    var hasOverlayPermission by remember { mutableStateOf(checkOverlayPermission(context)) }
    var isAccessibilityServiceOn by remember { mutableStateOf(checkAccessibilityService(context)) }

    // Re-check permissions when returning from Settings or Shizuku dialogs
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                hasOverlayPermission = checkOverlayPermission(context)
                isAccessibilityServiceOn = checkAccessibilityService(context)
                ShizukuTapEngine.updateShizukuState()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Scaffold(
        containerColor = EditorialNoir
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Editorial Header Section
            item {
                EditorialHeader(
                    isClicking = macroState.isClickingActive,
                    isRunning = macroState.isOverlayServiceRunning,
                    isShizukuActive = shizukuStatus.isPermissionGranted
                )
            }

            // 1. Shizuku ADB Input Injection Engine Status Card
            item {
                ShizukuEngineStatusCard(
                    shizukuStatus = shizukuStatus,
                    onRequestPermission = {
                        ShizukuTapEngine.requestPermission()
                    }
                )
            }

            // 2. Overlay & Accessibility Status Bar
            item {
                EditorialStatusSection(
                    hasOverlayPermission = hasOverlayPermission,
                    isAccessibilityServiceOn = isAccessibilityServiceOn,
                    onGrantOverlay = { openOverlaySettings(context) },
                    onEnableAccessibility = { openAccessibilitySettings(context) }
                )
            }

            // 3. Game Mode (Locked Drag) vs Edit Mode (Draggable) Card
            item {
                GameModeLockCard(
                    isEditMode = macroState.isEditMode,
                    isRunning = macroState.isOverlayServiceRunning,
                    onToggleMode = {
                        MacroManager.toggleEditMode()
                    }
                )
            }

            // 4. Primary Terminal Configuration Card
            item {
                EditorialTerminalCard(
                    macroState = macroState,
                    shizukuStatus = shizukuStatus,
                    hasOverlayPermission = hasOverlayPermission,
                    isAccessibilityServiceOn = isAccessibilityServiceOn,
                    onModeChange = { MacroManager.updateMode(it) },
                    onIntervalChange = { MacroManager.updateInterval(it) },
                    onAlphaChange = { MacroManager.updateAlpha(it) },
                    onToggleA = { MacroManager.setTriggerAVisible(it) },
                    onTogglea = { MacroManager.setPointeraVisible(it) },
                    onToggleEngine = {
                        if (!hasOverlayPermission) {
                            Toast.makeText(context, "Please grant 'Display Over Other Apps' permission first", Toast.LENGTH_SHORT).show()
                            openOverlaySettings(context)
                        } else {
                            if (macroState.isOverlayServiceRunning) {
                                FloatingMacroService.stopService(context)
                            } else {
                                FloatingMacroService.startService(context)
                                Toast.makeText(context, "Trigger Overlay Launched!", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                )
            }

            // 5. Quick Gaming Profiles / Presets
            item {
                EditorialPresetsCard(
                    currentInterval = macroState.intervalMs,
                    currentMode = macroState.mode,
                    onSelectPreset = { MacroManager.applyPreset(it) }
                )
            }

            // 6. In-App Interactive Click Speed / Testing Arena
            item {
                EditorialTestArenaCard(
                    macroState = macroState
                )
            }

            // 7. Visual How-to-Use Guide
            item {
                EditorialGuideCard()
            }
        }
    }
}

@Composable
fun EditorialHeader(
    isClicking: Boolean,
    isRunning: Boolean,
    isShizukuActive: Boolean
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 8.dp, bottom = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "ADB INJECTION ENGINE",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    color = ElectricCyan
                )
                if (isShizukuActive) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(ElectricCyan.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "SHIZUKU ACTIVE",
                            fontSize = 8.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            color = ElectricCyan
                        )
                    }
                }
            }
            Text(
                text = "Trigger",
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                fontWeight = FontWeight.Light,
                fontSize = 32.sp,
                letterSpacing = (-0.5).sp,
                color = TextEditorialPrimary
            )
        }

        // Editorial Dashed Reticle Emblem
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(EditorialSurface)
                .border(1.dp, EditorialBorder, RoundedCornerShape(16.dp)),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(24.dp)) {
                val cx = size.width / 2f
                val cy = size.height / 2f
                val r = size.width / 2f - 2.dp.toPx()

                drawCircle(
                    color = if (isRunning) ElectricCyan else TextEditorialMuted.copy(alpha = 0.5f),
                    radius = r,
                    style = Stroke(
                        width = 1.5.dp.toPx(),
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 6f), 0f)
                    )
                )
                drawCircle(
                    color = if (isClicking) RedMagicCrimson else ElectricCyan.copy(alpha = if (isRunning) pulseAlpha else 0.4f),
                    radius = 3.dp.toPx()
                )
            }
        }
    }
}

@Composable
fun ShizukuEngineStatusCard(
    shizukuStatus: ShizukuStatus,
    onRequestPermission: () -> Unit
) {
    val isGranted = shizukuStatus.isPermissionGranted
    val isRunning = shizukuStatus.isInstalledOrRunning

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("shizuku_status_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = EditorialCard),
        border = BorderStroke(1.dp, if (isGranted) ElectricCyan.copy(alpha = 0.5f) else EditorialBorder)
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape)
                            .background(if (isGranted) ElectricCyan.copy(alpha = 0.15f) else EditorialNoir),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = if (isGranted) ElectricCyan else TextEditorialMuted,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    Column {
                        Text(
                            text = "Shizuku Rootless ADB Engine",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = TextEditorialPrimary
                        )
                        Text(
                            text = if (isGranted) "Direct ADB shell input tap • Zero frame lag" else if (isRunning) "Binder active • Permission required" else "Service not detected • Fallback mode active",
                            fontSize = 10.sp,
                            color = if (isGranted) ElectricCyan else TextEditorialMuted
                        )
                    }
                }

                if (isGranted) {
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(ElectricCyan.copy(alpha = 0.2f))
                            .padding(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = "READY",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            fontFamily = FontFamily.Monospace,
                            color = ElectricCyan
                        )
                    }
                } else if (isRunning) {
                    Button(
                        onClick = onRequestPermission,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = ElectricCyan),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "GRANT",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = ElectricCyanDark
                        )
                    }
                }
            }

            // Benefits & Multi-touch Notice
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(EditorialNoir)
                    .padding(10.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.TouchApp,
                        contentDescription = null,
                        tint = if (isGranted) ElectricCyan else TextEditorialMuted,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = if (isGranted) "Multi-touch gestures & in-game camera aiming remain 100% responsive while auto-tapping." else "Start Shizuku via Wireless Debugging on device to unlock rootless rapid injection.",
                        fontSize = 10.sp,
                        color = TextEditorialMuted,
                        lineHeight = 14.sp
                    )
                }
            }
        }
    }
}

@Composable
fun GameModeLockCard(
    isEditMode: Boolean,
    isRunning: Boolean,
    onToggleMode: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("game_mode_lock_card"),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = EditorialCard),
        border = BorderStroke(1.dp, if (isEditMode) TurboAmber.copy(alpha = 0.5f) else EditorialBorder)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isEditMode) TurboAmber.copy(alpha = 0.15f) else ElectricCyan.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isEditMode) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = null,
                        tint = if (isEditMode) TurboAmber else ElectricCyan,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = if (isEditMode) "Edit Mode (Draggable)" else "Game Mode (Locked & Pass-Through)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextEditorialPrimary
                    )
                    Text(
                        text = if (isEditMode) "Drag 'A' & 'a' widgets to reposition on screen" else "Widgets locked in position • Taps on 'a' pass directly through to game",
                        fontSize = 10.sp,
                        color = TextEditorialMuted
                    )
                }
            }

            Button(
                onClick = onToggleMode,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isEditMode) TurboAmber else EditorialSurface
                ),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = if (isEditMode) "LOCK" else "EDIT POSITIONS",
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isEditMode) EditorialNoir else ElectricCyan
                )
            }
        }
    }
}

@Composable
fun EditorialStatusSection(
    hasOverlayPermission: Boolean,
    isAccessibilityServiceOn: Boolean,
    onGrantOverlay: () -> Unit,
    onEnableAccessibility: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Overlay Card
        EditorialStatusCard(
            modifier = Modifier.weight(1f),
            label = "Overlay HUD",
            status = if (hasOverlayPermission) "Active" else "Required",
            isActive = hasOverlayPermission,
            accentColor = if (hasOverlayPermission) ElectricCyan else EditorialBorderSubtle,
            onClick = if (!hasOverlayPermission) onGrantOverlay else null
        )

        // Accessibility Card (Fallback)
        EditorialStatusCard(
            modifier = Modifier.weight(1f),
            label = "Accessibility (Backup)",
            status = if (isAccessibilityServiceOn) "Ready" else "Optional Backup",
            isActive = isAccessibilityServiceOn,
            accentColor = if (isAccessibilityServiceOn) ElectricCyan else EditorialBorderSubtle,
            onClick = if (!isAccessibilityServiceOn) onEnableAccessibility else null
        )
    }
}

@Composable
fun EditorialStatusCard(
    modifier: Modifier = Modifier,
    label: String,
    status: String,
    isActive: Boolean,
    accentColor: Color,
    onClick: (() -> Unit)? = null
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseDotAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseDot"
    )

    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .background(EditorialSurface)
            .border(BorderStroke(1.dp, EditorialBorder), RoundedCornerShape(16.dp))
            .then(if (onClick != null) Modifier.clickable { onClick() } else Modifier)
            .padding(14.dp)
    ) {
        // Left accent indicator line
        Box(
            modifier = Modifier
                .align(Alignment.CenterStart)
                .width(3.dp)
                .height(28.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(accentColor)
        )

        Column(
            modifier = Modifier
                .padding(start = 8.dp)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label.uppercase(),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                color = TextEditorialMuted
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (isActive) {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(ElectricCyan.copy(alpha = pulseDotAlpha))
                    )
                }
                Text(
                    text = status,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (isActive) TextEditorialPrimary else TextEditorialMuted
                )
            }
        }
    }
}

@Composable
fun EditorialTerminalCard(
    macroState: MacroState,
    shizukuStatus: ShizukuStatus,
    hasOverlayPermission: Boolean,
    isAccessibilityServiceOn: Boolean,
    onModeChange: (MacroMode) -> Unit,
    onIntervalChange: (Int) -> Unit,
    onAlphaChange: (Float) -> Unit,
    onToggleA: (Boolean) -> Unit,
    onTogglea: (Boolean) -> Unit,
    onToggleEngine: () -> Unit
) {
    val isRunning = macroState.isOverlayServiceRunning

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("macro_settings_terminal"),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = EditorialCard),
        border = BorderStroke(1.dp, EditorialBorder)
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.spacedBy(22.dp)
        ) {
            // Header Row: "Terminal Configuration"
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Terminal Configuration",
                    fontFamily = FontFamily.Serif,
                    fontStyle = FontStyle.Italic,
                    fontSize = 20.sp,
                    color = TextEditorialPrimary.copy(alpha = 0.95f)
                )

                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(EditorialBorder)
                        .clickable { onToggleEngine() },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isRunning) Icons.Default.Stop else Icons.Default.FlashOn,
                        contentDescription = null,
                        tint = if (isRunning) RedMagicCrimson else ElectricCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            // 1. Execution Mode Segmented Control
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text(
                        text = "Trigger Mode",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextEditorialPrimary
                    )
                    Text(
                        text = if (macroState.mode == MacroMode.HOLD_TO_REPEAT) "Fires while holding button 'A'" else "Toggles on/off with single tap",
                        fontSize = 11.sp,
                        fontStyle = FontStyle.Italic,
                        color = TextEditorialMuted
                    )
                }

                // Pill segmented control
                Row(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(EditorialNoir)
                        .border(1.dp, EditorialBorder, CircleShape)
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    val isHold = macroState.mode == MacroMode.HOLD_TO_REPEAT
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (isHold) ElectricCyan else Color.Transparent)
                            .clickable { onModeChange(MacroMode.HOLD_TO_REPEAT) }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Hold",
                            fontSize = 12.sp,
                            fontWeight = if (isHold) FontWeight.Bold else FontWeight.Medium,
                            color = if (isHold) ElectricCyanDark else TextEditorialMuted
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (!isHold) ElectricCyan else Color.Transparent)
                            .clickable { onModeChange(MacroMode.TAP_TO_REPEAT) }
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "Tap",
                            fontSize = 12.sp,
                            fontWeight = if (!isHold) FontWeight.Bold else FontWeight.Medium,
                            color = if (!isHold) ElectricCyanDark else TextEditorialMuted
                        )
                    }
                }
            }

            // 2. Pulse Interval Section
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val cps = (1000f / macroState.intervalMs).roundToInt()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "Pulse Interval",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextEditorialPrimary
                    )
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "${macroState.intervalMs}",
                            fontSize = 24.sp,
                            fontFamily = FontFamily.Serif,
                            fontStyle = FontStyle.Italic,
                            color = ElectricCyan
                        )
                        Text(
                            text = "ms",
                            fontSize = 11.sp,
                            color = TextEditorialMuted,
                            modifier = Modifier.padding(start = 2.dp, bottom = 3.dp)
                        )
                    }
                }

                Slider(
                    value = macroState.intervalMs.toFloat(),
                    onValueChange = { onIntervalChange(it.roundToInt()) },
                    valueRange = 10f..200f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = ElectricCyan,
                        inactiveTrackColor = EditorialBorder
                    ),
                    modifier = Modifier.testTag("tap_speed_slider")
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "TURBO (10MS)",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextEditorialMono
                    )
                    Text(
                        text = "${cps}X SPEED (${cps} CPS)",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = ElectricCyan.copy(alpha = 0.8f)
                    )
                    Text(
                        text = "CASUAL (200MS)",
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        color = TextEditorialMono
                    )
                }
            }

            // 3. Lens Opacity Section
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                val alphaPct = (macroState.overlayAlpha * 100).toInt()
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.Bottom
                ) {
                    Text(
                        text = "Lens Opacity",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = TextEditorialPrimary
                    )
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(
                            text = "$alphaPct",
                            fontSize = 24.sp,
                            fontFamily = FontFamily.Serif,
                            fontStyle = FontStyle.Italic,
                            color = TextEditorialPrimary
                        )
                        Text(
                            text = "%",
                            fontSize = 11.sp,
                            color = TextEditorialMuted,
                            modifier = Modifier.padding(start = 2.dp, bottom = 3.dp)
                        )
                    }
                }

                Slider(
                    value = macroState.overlayAlpha,
                    onValueChange = { onAlphaChange(it) },
                    valueRange = 0.10f..1.0f,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = TextEditorialPrimary.copy(alpha = 0.4f),
                        inactiveTrackColor = EditorialBorder
                    ),
                    modifier = Modifier.testTag("visibility_alpha_slider")
                )
            }

            // 4. Dual Master 'A' & Target 'a' Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Master 'A' Tile
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(EditorialNoir)
                        .border(
                            BorderStroke(
                                1.dp,
                                if (macroState.isTriggerAVisible) ElectricCyan.copy(alpha = 0.6f) else EditorialBorder
                            ),
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { onToggleA(!macroState.isTriggerAVisible) }
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .border(1.dp, ElectricCyan, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "A",
                                fontFamily = FontFamily.Serif,
                                fontStyle = FontStyle.Italic,
                                fontSize = 20.sp,
                                color = ElectricCyan
                            )
                        }
                        Text(
                            text = "TRIGGER 'A'",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = if (macroState.isTriggerAVisible) TextEditorialPrimary else TextEditorialMuted
                        )
                    }
                }

                // Pointer 'a' Tile
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(20.dp))
                        .background(EditorialNoir)
                        .border(
                            BorderStroke(
                                1.dp,
                                if (macroState.isPointeraVisible) TextEditorialPrimary.copy(alpha = 0.4f) else EditorialBorder
                            ),
                            RoundedCornerShape(20.dp)
                        )
                        .clickable { onTogglea(!macroState.isPointeraVisible) }
                        .padding(14.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .border(1.dp, TextEditorialPrimary.copy(alpha = 0.3f), CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "a",
                                fontFamily = FontFamily.Serif,
                                fontStyle = FontStyle.Italic,
                                fontSize = 20.sp,
                                color = TextEditorialPrimary.copy(alpha = 0.85f)
                            )
                        }
                        Text(
                            text = "TARGET 'a'",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.5.sp,
                            color = if (macroState.isPointeraVisible) TextEditorialPrimary else TextEditorialMuted
                        )
                    }
                }
            }

            // 5. Start / Stop Engine Button
            Button(
                onClick = onToggleEngine,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("launch_macro_floating_button"),
                shape = RoundedCornerShape(20.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRunning) EditorialSurface else ElectricCyan,
                    contentColor = if (isRunning) RedMagicCrimson else ElectricCyanDark
                ),
                border = if (isRunning) BorderStroke(1.dp, RedMagicCrimson) else null
            ) {
                Text(
                    text = if (isRunning) "STOP FLOATING HUD" else "START FLOATING HUD",
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.5.sp,
                    color = if (isRunning) RedMagicCrimson else ElectricCyanDark
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EditorialPresetsCard(
    currentInterval: Int,
    currentMode: MacroMode,
    onSelectPreset: (MacroPreset) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = EditorialCard),
        border = BorderStroke(1.dp, EditorialBorder)
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                text = "Preset Profiles",
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                fontSize = 18.sp,
                color = TextEditorialPrimary.copy(alpha = 0.95f)
            )

            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                MACRO_PRESETS.forEach { preset ->
                    val isSelected = currentInterval == preset.intervalMs && currentMode == preset.mode
                    val borderAnim by animateColorAsState(
                        targetValue = if (isSelected) ElectricCyan else EditorialBorder,
                        label = "border"
                    )

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(EditorialNoir)
                            .border(1.dp, borderAnim, RoundedCornerShape(16.dp))
                            .clickable { onSelectPreset(preset) }
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Column {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (isSelected) ElectricCyan else TextEditorialMuted)
                                )
                                Text(
                                    text = preset.name,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 12.sp,
                                    color = if (isSelected) TextEditorialPrimary else TextEditorialMuted
                                )
                                Text(
                                    text = "${preset.intervalMs}ms",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Serif,
                                    fontStyle = FontStyle.Italic,
                                    color = ElectricCyan
                                )
                            }
                            Text(
                                text = preset.description,
                                fontSize = 10.sp,
                                color = TextEditorialMuted,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EditorialTestArenaCard(
    macroState: MacroState
) {
    var inAppClickCount by remember { mutableLongStateOf(0L) }
    var lastClickTime by remember { mutableLongStateOf(0L) }
    var currentCps by remember { mutableFloatStateOf(0f) }

    LaunchedEffect(macroState.totalClicksCount) {
        if (macroState.totalClicksCount > 0) {
            inAppClickCount = macroState.totalClicksCount
            val now = System.currentTimeMillis()
            if (lastClickTime > 0) {
                val dt = (now - lastClickTime).coerceAtLeast(1L)
                currentCps = (1000f / dt).coerceAtMost(100f)
            }
            lastClickTime = now
        }
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("interactive_test_arena"),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = EditorialCard),
        border = BorderStroke(1.dp, EditorialBorder)
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Benchmark Arena",
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        fontSize = 18.sp,
                        color = TextEditorialPrimary.copy(alpha = 0.95f)
                    )
                    Text(
                        text = "Position target pointer 'a' over target box to test",
                        fontSize = 11.sp,
                        fontStyle = FontStyle.Italic,
                        color = TextEditorialMuted
                    )
                }

                IconButton(
                    onClick = {
                        inAppClickCount = 0
                        currentCps = 0f
                        MacroManager.resetClickCount()
                    }
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "Reset Stats",
                        tint = TextEditorialMuted,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            // Interactive Target Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(130.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(EditorialNoir)
                    .border(
                        BorderStroke(
                            1.dp,
                            Brush.linearGradient(
                                listOf(ElectricCyan.copy(alpha = 0.4f), EditorialBorder)
                            )
                        ),
                        RoundedCornerShape(20.dp)
                    )
                    .clickable {
                        inAppClickCount += 1
                        MacroManager.incrementClickCount()
                    },
                contentAlignment = Alignment.Center
            ) {
                // Background Crosshair lines
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    drawCircle(
                        color = ElectricCyan.copy(alpha = 0.15f),
                        radius = 45.dp.toPx(),
                        style = Stroke(
                            width = 1.5.dp.toPx(),
                            pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f), 0f)
                        )
                    )
                    drawLine(
                        color = ElectricCyan.copy(alpha = 0.15f),
                        start = Offset(cx, 0f),
                        end = Offset(cx, size.height),
                        strokeWidth = 1.dp.toPx()
                    )
                    drawLine(
                        color = ElectricCyan.copy(alpha = 0.15f),
                        start = Offset(0f, cy),
                        end = Offset(size.width, cy),
                        strokeWidth = 1.dp.toPx()
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                ) {
                    Text(
                        text = "$inAppClickCount",
                        fontSize = 32.sp,
                        fontFamily = FontFamily.Serif,
                        fontStyle = FontStyle.Italic,
                        color = if (macroState.isClickingActive) RedMagicCrimson else ElectricCyan
                    )
                    Text(
                        text = "PULSES REGISTERED",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextEditorialMuted,
                        letterSpacing = 1.5.sp
                    )
                    if (currentCps > 0f) {
                        Text(
                            text = "${String.format("%.1f", currentCps)} CPS",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TurboAmber,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
            }

            // Coordinate indicators
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "Trigger 'A': (${macroState.triggerX.toInt()}, ${macroState.triggerY.toInt()})",
                    fontSize = 10.sp,
                    color = TextEditorialMuted,
                    fontFamily = FontFamily.Monospace
                )
                Text(
                    text = "Target 'a': (${macroState.targetX.toInt()}, ${macroState.targetY.toInt()})",
                    fontSize = 10.sp,
                    color = ElectricCyan,
                    fontFamily = FontFamily.Monospace
                )
            }
        }
    }
}

@Composable
fun EditorialGuideCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(32.dp),
        colors = CardDefaults.cardColors(containerColor = EditorialCard),
        border = BorderStroke(1.dp, EditorialBorder)
    ) {
        Column(
            modifier = Modifier.padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "Operation Guide",
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                fontSize = 18.sp,
                color = TextEditorialPrimary.copy(alpha = 0.95f)
            )

            EditorialGuideStepItem(
                stepNum = "I",
                title = "Launch HUD & Position in Edit Mode",
                description = "Open Terminal HUD to unlock draggable handles. Place pointer 'a' over fire/skill button and trigger 'A' under your thumb."
            )
            EditorialGuideStepItem(
                stepNum = "II",
                title = "Lock in Game Mode",
                description = "Close terminal or tap 'Lock Game Mode'. Pointer 'a' becomes completely touch-transparent, allowing full multi-touch gaming control."
            )
            EditorialGuideStepItem(
                stepNum = "III",
                title = "Press Master Button 'A'",
                description = "Hold or tap button 'A' to execute rapid-fire ADB tap injection with zero frame drops or screen freezes."
            )
        }
    }
}

@Composable
fun EditorialGuideStepItem(
    stepNum: String,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(24.dp)
                .clip(CircleShape)
                .background(EditorialNoir)
                .border(1.dp, ElectricCyan.copy(alpha = 0.4f), CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = stepNum,
                fontSize = 10.sp,
                fontFamily = FontFamily.Serif,
                fontStyle = FontStyle.Italic,
                color = ElectricCyan
            )
        }
        Column {
            Text(
                text = title,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold,
                color = TextEditorialPrimary
            )
            Text(
                text = description,
                fontSize = 11.sp,
                color = TextEditorialMuted,
                lineHeight = 15.sp
            )
        }
    }
}

// ==========================================
// Permission & Helper Functions
// ==========================================

fun checkOverlayPermission(context: Context): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(context)
    } else {
        true
    }
}

fun openOverlaySettings(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        try {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:${context.packageName}")
            )
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            val fallbackIntent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION)
            fallbackIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(fallbackIntent)
        }
    }
}

fun checkAccessibilityService(context: Context): Boolean {
    val am = context.getSystemService(Context.ACCESSIBILITY_SERVICE) as AccessibilityManager
    val enabledServices = am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_GENERIC)
    val myServiceName = "${context.packageName}/${MacroAccessibilityService::class.java.canonicalName}"

    if (MacroAccessibilityService.isServiceRunning()) {
        return true
    }

    for (service in enabledServices) {
        if (service.id.equals(myServiceName, ignoreCase = true) ||
            service.resolveInfo.serviceInfo.packageName.equals(context.packageName, ignoreCase = true)
        ) {
            return true
        }
    }
    return false
}

fun openAccessibilitySettings(context: Context) {
    try {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    } catch (e: Exception) {
        Toast.makeText(context, "Could not open Accessibility Settings", Toast.LENGTH_SHORT).show()
    }
}
