package com.example

import android.content.pm.PackageManager
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedWriter
import java.io.OutputStreamWriter

enum class InjectionEngineMode(val label: String, val description: String) {
    SHIZUKU_ADB("Shizuku ADB Shell", "Direct rootless ADB input tap injection. Zero lag & responsive multi-touch."),
    ACCESSIBILITY("Accessibility Gesture", "System accessibility gesture dispatch fallback.")
}

data class ShizukuStatus(
    val isInstalledOrRunning: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val version: Int = -1,
    val isExecutingTapLoop: Boolean = false,
    val lastError: String? = null
)

object ShizukuTapEngine {
    private const val TAG = "ShizukuTapEngine"
    const val SHIZUKU_PERMISSION_REQUEST_CODE = 4002

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var tapJob: Job? = null

    private val _status = MutableStateFlow(ShizukuStatus())
    val status: StateFlow<ShizukuStatus> = _status.asStateFlow()

    // Persistent interactive ADB shell process
    private var shellProcess: Process? = null
    private var shellWriter: BufferedWriter? = null
    private val shellLock = Any()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku binder received")
        updateShizukuState()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.d(TAG, "Shizuku binder dead")
        closeShellProcess()
        _status.update { it.copy(isInstalledOrRunning = false, isPermissionGranted = false) }
    }

    private val requestPermissionResultListener =
        Shizuku.OnRequestPermissionResultListener { requestCode: Int, grantResult: Int ->
            if (requestCode == SHIZUKU_PERMISSION_REQUEST_CODE) {
                val granted = grantResult == PackageManager.PERMISSION_GRANTED
                Log.d(TAG, "Shizuku permission request result: granted=$granted")
                _status.update { it.copy(isPermissionGranted = granted) }
                if (granted) {
                    initShellProcess()
                }
            }
        }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(requestPermissionResultListener)
            updateShizukuState()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Shizuku listeners: ${e.message}", e)
        }
    }

    fun updateShizukuState() {
        try {
            val ping = Shizuku.pingBinder()
            if (ping) {
                val version = Shizuku.getVersion()
                val granted = try {
                    Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                } catch (e: Exception) {
                    false
                }
                _status.update {
                    it.copy(
                        isInstalledOrRunning = true,
                        isPermissionGranted = granted,
                        version = version,
                        lastError = null
                    )
                }
                if (granted && shellProcess == null) {
                    initShellProcess()
                }
            } else {
                _status.update {
                    it.copy(
                        isInstalledOrRunning = false,
                        isPermissionGranted = false,
                        version = -1
                    )
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error checking Shizuku state: ${e.message}")
            _status.update {
                it.copy(
                    isInstalledOrRunning = false,
                    isPermissionGranted = false,
                    lastError = e.message
                )
            }
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder()) {
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                    Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST_CODE)
                } else {
                    _status.update { it.copy(isPermissionGranted = true) }
                    initShellProcess()
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error requesting Shizuku permission: ${e.message}", e)
            _status.update { it.copy(lastError = e.message) }
        }
    }

    private fun initShellProcess() {
        synchronized(shellLock) {
            try {
                if (shellProcess != null) return
                if (!Shizuku.pingBinder()) return
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) return

                Log.d(TAG, "Initializing persistent Shizuku shell process...")
                val process = Shizuku.newProcess(arrayOf("sh"), null, null)
                val writer = BufferedWriter(OutputStreamWriter(process.outputStream))
                shellProcess = process
                shellWriter = writer
                Log.d(TAG, "Shizuku persistent shell process initialized successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Failed to start Shizuku shell process: ${e.message}", e)
                shellProcess = null
                shellWriter = null
                _status.update { it.copy(lastError = "Shell Init Error: ${e.message}") }
            }
        }
    }

    private fun closeShellProcess() {
        synchronized(shellLock) {
            try {
                shellWriter?.write("exit\n")
                shellWriter?.flush()
                shellWriter?.close()
            } catch (_: Exception) {}
            try {
                shellProcess?.destroy()
            } catch (_: Exception) {}
            shellWriter = null
            shellProcess = null
        }
    }

    fun isReadyForAdbInjection(): Boolean {
        return _status.value.isInstalledOrRunning && _status.value.isPermissionGranted
    }

    /**
     * Start the rapid background tapping loop using Shizuku ADB Shell
     */
    fun startRapidTapLoop() {
        if (tapJob?.isActive == true) return

        _status.update { it.copy(isExecutingTapLoop = true) }

        tapJob = engineScope.launch {
            Log.d(TAG, "Starting Shizuku rapid tap loop on Dispatchers.IO")
            try {
                // Ensure shell is ready
                if (shellProcess == null || shellWriter == null) {
                    initShellProcess()
                }

                while (isActive && MacroManager.state.value.isClickingActive) {
                    val state = MacroManager.state.value
                    val targetX = state.targetX.toInt()
                    val targetY = state.targetY.toInt()
                    val intervalMs = state.intervalMs.toLong().coerceAtLeast(10L)

                    val success = injectTap(targetX, targetY)
                    if (success) {
                        MacroManager.incrementClickCount()
                    } else {
                        // Fallback to accessibility if shell write failed
                        MacroAccessibilityService.instance?.dispatchTap(
                            targetX.toFloat(),
                            targetY.toFloat(),
                            state.pressDurationMs
                        )
                        MacroManager.incrementClickCount()
                    }

                    delay(intervalMs)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Exception during tap loop: ${e.message}", e)
            } finally {
                withContext(Dispatchers.Main) {
                    _status.update { it.copy(isExecutingTapLoop = false) }
                }
            }
        }
    }

    /**
     * Stop the rapid tapping loop immediately
     */
    fun stopRapidTapLoop() {
        tapJob?.cancel()
        tapJob = null
        _status.update { it.copy(isExecutingTapLoop = false) }
        Log.d(TAG, "Shizuku rapid tap loop stopped")
    }

    /**
     * Injects a single input tap command directly into the persistent ADB shell
     */
    private fun injectTap(x: Int, y: Int): Boolean {
        synchronized(shellLock) {
            return try {
                if (shellWriter == null || shellProcess == null) {
                    initShellProcess()
                }
                val writer = shellWriter ?: return false
                writer.write("input tap $x $y\n")
                writer.flush()
                true
            } catch (e: Exception) {
                Log.w(TAG, "Error writing to Shizuku shell: ${e.message}")
                closeShellProcess()
                false
            }
        }
    }

    fun destroy() {
        stopRapidTapLoop()
        closeShellProcess()
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(requestPermissionResultListener)
        } catch (_: Exception) {}
    }
}
