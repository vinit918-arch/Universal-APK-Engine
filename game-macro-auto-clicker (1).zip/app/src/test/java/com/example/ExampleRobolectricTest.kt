package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Trigger", appName)
  }

  @Test
  fun `macro state manager initial values`() {
    val state = MacroManager.state.value
    assertNotNull(state)
    assertEquals(MacroMode.HOLD_TO_REPEAT, state.mode)
    assertEquals(30, state.intervalMs)
    assertEquals(0.85f, state.overlayAlpha)
    assertEquals(false, state.isEditMode)
  }

  @Test
  fun `macro state updates interval and mode`() {
    MacroManager.updateInterval(15)
    assertEquals(15, MacroManager.state.value.intervalMs)

    MacroManager.updateMode(MacroMode.TAP_TO_REPEAT)
    assertEquals(MacroMode.TAP_TO_REPEAT, MacroManager.state.value.mode)

    MacroManager.updateAlpha(0.5f)
    assertEquals(0.5f, MacroManager.state.value.overlayAlpha)

    MacroManager.setEditMode(true)
    assertEquals(true, MacroManager.state.value.isEditMode)
    MacroManager.setEditMode(false)
    assertEquals(false, MacroManager.state.value.isEditMode)
  }
}
