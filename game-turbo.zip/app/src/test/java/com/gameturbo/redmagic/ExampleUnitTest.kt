package com.gameturbo.redmagic

import org.junit.Assert.assertEquals
import org.junit.Test

class ExampleUnitTest {
    @Test
    fun addition_isCorrect() {
        assertEquals(4, 2 + 2)
    }

    @Test
    fun permissionCount_isAccurate() {
        val states = AppPermissionStates(
            shizukuGranted = true,
            shizukuRunning = true,
            overlayGranted = true,
            writeSettingsGranted = false,
            storageGranted = false
        )
        assertEquals(2, states.grantedCount)
        assertEquals(4, states.totalCount)
    }
}
