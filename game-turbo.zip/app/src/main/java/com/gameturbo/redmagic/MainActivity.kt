package com.gameturbo.redmagic

import android.Manifest
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import rikka.shizuku.Shizuku

// ---------------------------------------------------------
// Immersive UI Theme Colors & Tokens
// ---------------------------------------------------------
val ImmersiveVoid = Color(0xFF050505)
val ImmersiveCardBg = Color(0xFF121212)
val ImmersiveCardBorder = Color(0xFF222222)
val ImmersiveCardBorderGlow = Color(0x4DEF4444)
val ImmersiveRedPrimary = Color(0xFFDC2626)
val ImmersiveRedAccent = Color(0xFFEF4444)
val ImmersiveRedDark = Color(0xFF7F1D1D)
val ImmersiveGreenAccent = Color(0xFF22C55E)
val ImmersiveAmberAccent = Color(0xFFF59E0B)
val ImmersiveSlate100 = Color(0xFFF1F5F9)
val ImmersiveSlate300 = Color(0xFFCBD5E1)
val ImmersiveSlate400 = Color(0xFF94A3B8)
val ImmersiveSlate600 = Color(0xFF475569)
val ImmersiveSlate800 = Color(0xFF1E293B)
val ImmersiveSlate500 = Color(0xFF64748B)

private val ImmersiveDarkColorScheme = darkColorScheme(
    primary = ImmersiveRedAccent,
    onPrimary = Color.White,
    primaryContainer = ImmersiveRedDark,
    onPrimaryContainer = Color(0xFFFFD9DF),
    surface = ImmersiveCardBg,
    onSurface = ImmersiveSlate100,
    background = ImmersiveVoid,
    onBackground = ImmersiveSlate100,
    outline = ImmersiveCardBorder
)

// ---------------------------------------------------------
// Main Activity
// ---------------------------------------------------------
class MainActivity : ComponentActivity() {

    private val shizukuRequestCode = 9101
    private var isShizukuListenerAdded = false

    private val permissionListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == shizukuRequestCode) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            val msg = if (granted) "Shizuku Shell Access Granted!" else "Shizuku Shell Access Denied"
            Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        try {
            Shizuku.addRequestPermissionResultListener(permissionListener)
            isShizukuListenerAdded = true
        } catch (e: Throwable) {
            isShizukuListenerAdded = false
        }

        setContent {
            MaterialTheme(colorScheme = ImmersiveDarkColorScheme) {
                GameTurboApp()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (isShizukuListenerAdded) {
            try {
                Shizuku.removeRequestPermissionResultListener(permissionListener)
            } catch (e: Throwable) {
                // Ignore binder exceptions on destroy
            }
        }
    }
}

// ---------------------------------------------------------
// Permission State Holder
// ---------------------------------------------------------
data class AppPermissionStates(
    val shizukuGranted: Boolean = false,
    val shizukuRunning: Boolean = false,
    val overlayGranted: Boolean = false,
    val writeSettingsGranted: Boolean = false,
    val storageGranted: Boolean = false
) {
    val totalCount: Int = 4
    val grantedCount: Int
        get() {
            var count = 0
            if (shizukuGranted) count++
            if (overlayGranted) count++
            if (writeSettingsGranted) count++
            if (storageGranted) count++
            return count
        }
    val allCriticalGranted: Boolean
        get() = overlayGranted && writeSettingsGranted && storageGranted
}

// ---------------------------------------------------------
// Root App Navigation & State
// ---------------------------------------------------------
@Composable
fun GameTurboApp() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current

    var permissionStates by remember { mutableStateOf(AppPermissionStates()) }
    var currentScreen by remember { mutableStateOf("permissions") }

    fun refreshPermissions() {
        // 1. Shizuku Check
        var shizukuRunning = false
        var shizukuGranted = false
        try {
            shizukuRunning = Shizuku.pingBinder()
            if (shizukuRunning) {
                if (Shizuku.isPreV11()) {
                    shizukuGranted = ContextCompat.checkSelfPermission(
                        context,
                        "moe.shizuku.manager.permission.API_V23"
                    ) == PackageManager.PERMISSION_GRANTED
                } else {
                    shizukuGranted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
                }
            }
        } catch (e: Throwable) {
            shizukuRunning = false
            shizukuGranted = false
        }

        // 2. Overlay Check
        val overlayGranted = try {
            Settings.canDrawOverlays(context)
        } catch (e: Throwable) {
            false
        }

        // 3. Write Settings Check
        val writeSettingsGranted = try {
            Settings.System.canWrite(context)
        } catch (e: Throwable) {
            false
        }

        // 4. Storage Check
        val storageGranted = try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                Environment.isExternalStorageManager()
            } else {
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.READ_EXTERNAL_STORAGE
                ) == PackageManager.PERMISSION_GRANTED
            }
        } catch (e: Throwable) {
            false
        }

        permissionStates = AppPermissionStates(
            shizukuGranted = shizukuGranted,
            shizukuRunning = shizukuRunning,
            overlayGranted = overlayGranted,
            writeSettingsGranted = writeSettingsGranted,
            storageGranted = storageGranted
        )
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                refreshPermissions()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    LaunchedEffect(Unit) {
        refreshPermissions()
    }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = ImmersiveVoid
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            // Subtle top radial/vertical gradient glow from red-900/20 to transparent
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(260.dp)
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0x337F1D1D),
                                Color(0x157F1D1D),
                                Color.Transparent
                            )
                        )
                    )
            )

            if (currentScreen == "permissions") {
                SetupPermissionsScreen(
                    permissionStates = permissionStates,
                    onRefresh = { refreshPermissions() },
                    onContinueToDashboard = { currentScreen = "dashboard" }
                )
            } else {
                GameTurboDashboardScreen(
                    permissionStates = permissionStates,
                    onBackToPermissions = { currentScreen = "permissions" }
                )
            }
        }
    }
}

// ---------------------------------------------------------
// Screen 1: Setup & Permissions (Immersive UI Design)
// ---------------------------------------------------------
@Composable
fun SetupPermissionsScreen(
    permissionStates: AppPermissionStates,
    onRefresh: () -> Unit,
    onContinueToDashboard: () -> Unit
) {
    val context = LocalContext.current

    val storageLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) {
        onRefresh()
    }

    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets.statusBars,
        bottomBar = {
            ImmersiveFooter(
                permissionStates = permissionStates,
                onContinue = onContinueToDashboard,
                onRefresh = onRefresh
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(16.dp))
                ImmersiveHeader(
                    grantedCount = permissionStates.grantedCount,
                    totalCount = permissionStates.totalCount
                )
                Spacer(modifier = Modifier.height(8.dp))
            }

            // 1. Shizuku Access Card
            item {
                ImmersiveShizukuCard(
                    isGranted = permissionStates.shizukuGranted,
                    isRunning = permissionStates.shizukuRunning,
                    onRequestShizuku = {
                        requestShizukuAccessSafely(context, onRefresh)
                    },
                    onOpenShizukuApp = {
                        openShizukuAppSafely(context)
                    }
                )
            }

            // 2. Display Over Apps Card
            item {
                ImmersivePermissionCard(
                    title = "Display Over Apps",
                    description = "Allows Game Turbo overlay while gaming.",
                    icon = Icons.Default.Layers,
                    isGranted = permissionStates.overlayGranted,
                    testTag = "permission_card_overlay",
                    onAction = { openOverlaySettingsSafely(context) }
                )
            }

            // 3. Write Settings Card
            item {
                ImmersivePermissionCard(
                    title = "Write Settings",
                    description = "Required for auto-brightness lock and DND.",
                    icon = Icons.Default.Tune,
                    isGranted = permissionStates.writeSettingsGranted,
                    testTag = "permission_card_write_settings",
                    onAction = { openWriteSettingsSafely(context) }
                )
            }

            // 4. All Files Access Card
            item {
                ImmersivePermissionCard(
                    title = "All Files Access",
                    description = "For game asset caching and screenshot storage.",
                    icon = Icons.Default.Folder,
                    isGranted = permissionStates.storageGranted,
                    testTag = "permission_card_storage",
                    onAction = { requestStorageAccessSafely(context, storageLauncher) }
                )
            }

            // Capability matrix item
            item {
                Spacer(modifier = Modifier.height(6.dp))
                ImmersiveCapabilityMatrix(permissionStates = permissionStates)
                Spacer(modifier = Modifier.height(120.dp))
            }
        }
    }
}

// ---------------------------------------------------------
// Immersive Header (Exact Match to Design HTML)
// ---------------------------------------------------------
@Composable
fun ImmersiveHeader(grantedCount: Int, totalCount: Int) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("immersive_header")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Red diamond icon badge with white dot (w-8 h-8 bg-red-600 rounded-sm rotate-45)
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .rotate(45f)
                        .clip(RoundedCornerShape(3.dp))
                        .background(ImmersiveRedPrimary)
                        .border(1.dp, ImmersiveRedAccent, RoundedCornerShape(3.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .rotate(-45f)
                            .clip(CircleShape)
                            .background(Color.White)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "REDMAGIC ",
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Italic,
                        letterSpacing = (-0.5).sp
                    )
                    Text(
                        text = "TURBO",
                        color = ImmersiveRedAccent,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        fontStyle = FontStyle.Italic,
                        letterSpacing = (-0.5).sp
                    )
                }
            }

            // Progress Pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0x15FFFFFF))
                    .border(1.dp, Color(0x15FFFFFF), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = "$grantedCount / $totalCount ARMED",
                    color = if (grantedCount == totalCount) ImmersiveGreenAccent else ImmersiveSlate400,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            }
        }

        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "SETUP & PERMISSIONS",
            color = ImmersiveSlate400,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            letterSpacing = 2.sp
        )
    }
}

// ---------------------------------------------------------
// Shizuku Permission Card (Primary Highlight Card)
// ---------------------------------------------------------
@Composable
fun ImmersiveShizukuCard(
    isGranted: Boolean,
    isRunning: Boolean,
    onRequestShizuku: () -> Unit,
    onOpenShizukuApp: () -> Unit
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val dotAlpha by infiniteTransition.animateFloat(
        initialValue = 0.3f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_dot"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("permission_card_shizuku"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ImmersiveCardBg),
        border = BorderStroke(1.dp, if (isGranted) Color(0x15FFFFFF) else ImmersiveCardBorderGlow)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header Row with Title + Pulse Dot & Status Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                (if (isGranted) ImmersiveGreenAccent else ImmersiveRedAccent).copy(
                                    alpha = if (isGranted) 1f else dotAlpha
                                )
                            )
                    )
                    Text(
                        text = "SHIZUKU PERMISSION",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                StatusBadge(isGranted = isGranted)
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "Required for advanced kernel level game optimizations and frame stability.",
                color = ImmersiveSlate400,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Action Buttons Row (Request + Open App)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Red Primary Request Button with bottom shadow line
                Button(
                    onClick = onRequestShizuku,
                    modifier = Modifier
                        .weight(1f)
                        .height(44.dp)
                        .testTag("request_shizuku_button"),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isGranted) ImmersiveSlate800 else ImmersiveRedPrimary,
                        contentColor = if (isGranted) ImmersiveSlate300 else Color.White
                    ),
                    border = if (!isGranted) BorderStroke(1.dp, ImmersiveRedDark) else null
                ) {
                    Text(
                        text = if (isGranted) "SHIZUKU ACTIVE" else "REQUEST SHIZUKU ACCESS",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp,
                        letterSpacing = 1.sp
                    )
                }

                // Secondary Open Shizuku App Button (w-11 h-11 bg-white/5)
                IconButton(
                    onClick = onOpenShizukuApp,
                    modifier = Modifier
                        .size(44.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0x0DFFFFFF))
                        .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(8.dp))
                        .testTag("open_shizuku_app_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.OpenInNew,
                        contentDescription = "Open Shizuku App",
                        tint = ImmersiveSlate300,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------
// Standard Permission Card (Display Over Apps, Write Settings, Storage)
// ---------------------------------------------------------
@Composable
fun ImmersivePermissionCard(
    title: String,
    description: String,
    icon: ImageVector,
    isGranted: Boolean,
    testTag: String,
    onAction: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onAction() }
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ImmersiveCardBg),
        border = BorderStroke(1.dp, Color(0x12FFFFFF))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = if (isGranted) ImmersiveGreenAccent else ImmersiveSlate400,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = title.uppercase(),
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        letterSpacing = 0.5.sp
                    )
                }

                StatusBadge(isGranted = isGranted)
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                color = ImmersiveSlate400,
                fontSize = 12.sp,
                lineHeight = 16.sp
            )
        }
    }
}

// ---------------------------------------------------------
// Status Pill Badge (Granted / Pending)
// ---------------------------------------------------------
@Composable
fun StatusBadge(isGranted: Boolean) {
    val badgeBg = if (isGranted) Color(0x3322C55E) else Color(0x33EF4444)
    val badgeBorder = if (isGranted) Color(0x4D22C55E) else Color(0x4DEF4444)
    val badgeText = if (isGranted) ImmersiveGreenAccent else ImmersiveRedAccent

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(badgeBg)
            .border(1.dp, badgeBorder, RoundedCornerShape(4.dp))
            .padding(horizontal = 8.dp, vertical = 2.dp)
    ) {
        Text(
            text = if (isGranted) "GRANTED" else "PENDING",
            color = badgeText,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )
    }
}

// ---------------------------------------------------------
// Capability Matrix Diagnostics
// ---------------------------------------------------------
@Composable
fun ImmersiveCapabilityMatrix(permissionStates: AppPermissionStates) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = ImmersiveCardBg),
        border = BorderStroke(1.dp, Color(0x0EFFFFFF))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Text(
                text = "ENGINE CAPABILITY MATRIX",
                color = ImmersiveSlate400,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(8.dp))

            ImmersiveMatrixRow("120 FPS Extreme Governor", permissionStates.shizukuGranted || permissionStates.writeSettingsGranted)
            ImmersiveMatrixRow("In-Game Overlay HUD", permissionStates.overlayGranted)
            ImmersiveMatrixRow("RAM Cleaner & Task Killer", permissionStates.shizukuGranted)
            ImmersiveMatrixRow("Ultra Shader & Texture Cache", permissionStates.storageGranted)
        }
    }
}

@Composable
fun ImmersiveMatrixRow(title: String, isReady: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = title, color = ImmersiveSlate300, fontSize = 11.sp)
        Text(
            text = if (isReady) "[ READY ]" else "[ PENDING ]",
            color = if (isReady) ImmersiveGreenAccent else ImmersiveSlate600,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace
        )
    }
}

// ---------------------------------------------------------
// Footer (Exact Match to Design HTML)
// ---------------------------------------------------------
@Composable
fun ImmersiveFooter(
    permissionStates: AppPermissionStates,
    onContinue: () -> Unit,
    onRefresh: () -> Unit
) {
    val isReady = permissionStates.grantedCount >= 1

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 20.dp, vertical = 12.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Gradient hairline divider: from-transparent via-white/10 to-transparent
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(1.dp)
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(
                            Color.Transparent,
                            Color(0x1AFFFFFF),
                            Color.Transparent
                        )
                    )
                )
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Refresh Status Button
            IconButton(
                onClick = onRefresh,
                modifier = Modifier
                    .size(56.dp)
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color(0x0DFFFFFF))
                    .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(16.dp))
                    .testTag("refresh_permissions_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Refresh,
                    contentDescription = "Refresh Status",
                    tint = ImmersiveSlate300
                )
            }

            // Big 56dp (h-14) Continue to Dashboard Button
            Button(
                onClick = onContinue,
                modifier = Modifier
                    .weight(1f)
                    .height(56.dp)
                    .testTag("continue_to_dashboard_button"),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isReady) ImmersiveRedPrimary else ImmersiveSlate800,
                    contentColor = if (isReady) Color.White else ImmersiveSlate500
                ),
                border = BorderStroke(1.dp, if (isReady) ImmersiveRedDark else Color(0x0DFFFFFF))
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text(
                        text = "CONTINUE TO DASHBOARD",
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp,
                        fontSize = 12.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }

        // System caption: SYSTEM: com.gameturbo.redmagic // BUILD 4.0.2
        Text(
            text = "SYSTEM: com.gameturbo.redmagic // BUILD 4.0.2",
            color = ImmersiveSlate600,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = (-0.5).sp
        )
    }
}

// ---------------------------------------------------------
// Screen 2: Game Turbo HUD & Performance Dashboard (Immersive UI)
// ---------------------------------------------------------
@Composable
fun GameTurboDashboardScreen(
    permissionStates: AppPermissionStates,
    onBackToPermissions: () -> Unit
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    var isTurboBoosted by remember { mutableStateOf(false) }
    var selectedProfile by remember { mutableIntStateOf(1) }
    var isOverlayActive by remember { mutableStateOf(permissionStates.overlayGranted) }
    var is4DTouchActive by remember { mutableStateOf(true) }
    var isDndActive by remember { mutableStateOf(true) }
    var ramCleanedState by remember { mutableStateOf(false) }
    var simulatedFps by remember { mutableIntStateOf(120) }

    LaunchedEffect(isTurboBoosted) {
        simulatedFps = if (isTurboBoosted) 144 else 120
    }

    Scaffold(
        containerColor = Color.Transparent,
        contentWindowInsets = WindowInsets.statusBars,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    IconButton(
                        onClick = onBackToPermissions,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0x0DFFFFFF))
                            .border(1.dp, Color(0x1AFFFFFF), RoundedCornerShape(10.dp))
                            .testTag("back_to_permissions_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Setup",
                            tint = Color.White,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "REDMAGIC ",
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Italic,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "TURBO",
                                color = ImmersiveRedAccent,
                                fontWeight = FontWeight.Bold,
                                fontStyle = FontStyle.Italic,
                                fontSize = 16.sp
                            )
                        }
                        Text(
                            text = "PERFORMANCE CONTROL HUB",
                            color = ImmersiveSlate400,
                            fontSize = 10.sp,
                            letterSpacing = 1.sp
                        )
                    }
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (isTurboBoosted) Color(0x33EF4444) else Color(0x3322C55E))
                        .border(1.dp, if (isTurboBoosted) Color(0x4DEF4444) else Color(0x4D22C55E), RoundedCornerShape(4.dp))
                        .padding(horizontal = 8.dp, vertical = 3.dp)
                ) {
                    Text(
                        text = if (isTurboBoosted) "DIABLO BOOST" else "STANDBY",
                        color = if (isTurboBoosted) ImmersiveRedAccent else ImmersiveGreenAccent,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Live Telemetry Gauges Card
            item {
                ImmersiveGaugesCard(
                    isBoosted = isTurboBoosted,
                    fps = simulatedFps,
                    onToggleBoost = {
                        isTurboBoosted = !isTurboBoosted
                        Toast.makeText(
                            context,
                            if (isTurboBoosted) "Diablo Boost Activated: FPS Unlocked!" else "Turbo Standby",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                )
            }

            // Turbo Profiles
            item {
                ImmersiveProfileSelector(
                    selectedProfile = selectedProfile,
                    onSelect = { selectedProfile = it }
                )
            }

            // Hardware Toggles Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = ImmersiveCardBg),
                    border = BorderStroke(1.dp, Color(0x12FFFFFF))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "ACTIVE HARDWARE MODES",
                            color = ImmersiveSlate400,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            fontFamily = FontFamily.Monospace
                        )

                        ImmersiveSwitchRow(
                            title = "In-Game Floating Overlay HUD",
                            subtitle = if (permissionStates.overlayGranted) "Real-time FPS & thermal telemetry" else "Overlay permission required",
                            isChecked = isOverlayActive,
                            onCheckedChange = {
                                if (permissionStates.overlayGranted) {
                                    isOverlayActive = it
                                } else {
                                    openOverlaySettingsSafely(context)
                                }
                            },
                            testTag = "switch_floating_hud"
                        )

                        ImmersiveSwitchRow(
                            title = "4D Touch Haptic Feedback",
                            subtitle = "Synaptic vibration feedback on weapon triggers",
                            isChecked = is4DTouchActive,
                            onCheckedChange = { is4DTouchActive = it },
                            testTag = "switch_4d_haptics"
                        )

                        ImmersiveSwitchRow(
                            title = "Anti-Interference Gaming DND",
                            subtitle = "Block floating banners and incoming calls",
                            isChecked = isDndActive,
                            onCheckedChange = { isDndActive = it },
                            testTag = "switch_dnd"
                        )
                    }
                }
            }

            // RAM Purge Action Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = ImmersiveCardBg),
                    border = BorderStroke(1.dp, Color(0x15FFFFFF))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "RAM PURGE & CACHE CLEAN",
                                color = ImmersiveRedAccent,
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                letterSpacing = 0.5.sp
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = if (ramCleanedState) "Freed 2.8 GB RAM • Cache Cleared" else "38 Background tasks consuming memory",
                                color = if (ramCleanedState) ImmersiveGreenAccent else ImmersiveSlate400,
                                fontSize = 11.sp
                            )
                        }

                        Button(
                            onClick = {
                                coroutineScope.launch {
                                    ramCleanedState = true
                                    Toast.makeText(context, "Purged background tasks! 2.8 GB RAM freed.", Toast.LENGTH_SHORT).show()
                                    delay(4000)
                                    ramCleanedState = false
                                }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = ImmersiveRedPrimary),
                            modifier = Modifier
                                .height(38.dp)
                                .testTag("purge_ram_button")
                        ) {
                            Text("OPTIMIZE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }

            // Game Library Section
            item {
                ImmersiveGameRoster()
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

// ---------------------------------------------------------
// Dashboard Gauges Card (Immersive UI)
// ---------------------------------------------------------
@Composable
fun ImmersiveGaugesCard(
    isBoosted: Boolean,
    fps: Int,
    onToggleBoost: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = ImmersiveCardBg),
        border = BorderStroke(1.dp, if (isBoosted) ImmersiveCardBorderGlow else Color(0x12FFFFFF))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "LIVE TELEMETRY",
                        color = ImmersiveSlate400,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Snapdragon 8 Gen 3",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Button(
                    onClick = onToggleBoost,
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isBoosted) ImmersiveRedPrimary else Color(0x1AFFFFFF)
                    ),
                    modifier = Modifier.testTag("toggle_turbo_boost_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Speed,
                        contentDescription = null,
                        modifier = Modifier.size(16.dp),
                        tint = Color.White
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isBoosted) "BOOST ACTIVE" else "ACTIVATE BOOST",
                        fontWeight = FontWeight.Bold,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ImmersiveGaugeTile(
                    label = "TARGET FPS",
                    value = "$fps",
                    unit = "FPS",
                    color = if (isBoosted) ImmersiveRedAccent else ImmersiveGreenAccent,
                    modifier = Modifier.weight(1f)
                )

                ImmersiveGaugeTile(
                    label = "CPU CLOCK",
                    value = if (isBoosted) "3.36" else "2.80",
                    unit = "GHZ",
                    color = if (isBoosted) ImmersiveAmberAccent else ImmersiveSlate100,
                    modifier = Modifier.weight(1f)
                )

                ImmersiveGaugeTile(
                    label = "THERMAL",
                    value = if (isBoosted) "38.5" else "34.2",
                    unit = "°C",
                    color = if (isBoosted) ImmersiveAmberAccent else ImmersiveGreenAccent,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

@Composable
fun ImmersiveGaugeTile(label: String, value: String, unit: String, color: Color, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x0AFFFFFF))
            .border(1.dp, Color(0x10FFFFFF), RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        Column {
            Text(
                text = label,
                color = ImmersiveSlate400,
                fontSize = 9.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.Bottom) {
                Text(
                    text = value,
                    color = color,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = unit,
                    color = ImmersiveSlate400,
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(bottom = 2.dp)
                )
            }
        }
    }
}

// ---------------------------------------------------------
// Profile Selector
// ---------------------------------------------------------
@Composable
fun ImmersiveProfileSelector(selectedProfile: Int, onSelect: (Int) -> Unit) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            text = "TURBO PROFILES",
            color = ImmersiveSlate400,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp,
            fontFamily = FontFamily.Monospace
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ImmersiveProfileButton(
                title = "ECO",
                desc = "Battery Saver",
                isSelected = selectedProfile == 0,
                color = ImmersiveGreenAccent,
                onClick = { onSelect(0) },
                modifier = Modifier.weight(1f)
            )
            ImmersiveProfileButton(
                title = "DIABLO",
                desc = "Max Power",
                isSelected = selectedProfile == 1,
                color = ImmersiveRedAccent,
                onClick = { onSelect(1) },
                modifier = Modifier.weight(1f)
            )
            ImmersiveProfileButton(
                title = "ESPORTS",
                desc = "Low Latency",
                isSelected = selectedProfile == 2,
                color = ImmersiveSlate100,
                onClick = { onSelect(2) },
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun ImmersiveProfileButton(
    title: String,
    desc: String,
    isSelected: Boolean,
    color: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .background(if (isSelected) color.copy(alpha = 0.15f) else ImmersiveCardBg)
            .border(
                1.dp,
                if (isSelected) color else Color(0x12FFFFFF),
                RoundedCornerShape(10.dp)
            )
            .clickable { onClick() }
            .padding(10.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = title,
                color = if (isSelected) color else Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                letterSpacing = 0.5.sp
            )
            Text(
                text = desc,
                color = ImmersiveSlate400,
                fontSize = 9.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

// ---------------------------------------------------------
// Switch Row
// ---------------------------------------------------------
@Composable
fun ImmersiveSwitchRow(
    title: String,
    subtitle: String,
    isChecked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    testTag: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            Text(text = subtitle, color = ImmersiveSlate400, fontSize = 11.sp)
        }

        Switch(
            checked = isChecked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(testTag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = ImmersiveRedPrimary,
                uncheckedThumbColor = ImmersiveSlate400,
                uncheckedTrackColor = Color(0x1AFFFFFF)
            )
        )
    }
}

// ---------------------------------------------------------
// Game Roster Section
// ---------------------------------------------------------
@Composable
fun ImmersiveGameRoster() {
    val context = LocalContext.current
    val games = listOf(
        "Cyberpunk 2077 Mobile" to "144 FPS UNLOCKED",
        "Apex Legends Turbo" to "LOW LATENCY TOUCH",
        "Genshin Speed Edition" to "GPU SHADER MAX",
        "PUBG RedMagic Pro" to "90 FPS ULTRA"
    )

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "GAME ROSTER",
                color = ImmersiveSlate400,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                fontFamily = FontFamily.Monospace
            )
            Text(
                text = "4 SLOTS READY",
                color = ImmersiveSlate400,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(modifier = Modifier.height(8.dp))

        games.forEach { (gameTitle, profile) ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 3.dp),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = ImmersiveCardBg),
                border = BorderStroke(1.dp, Color(0x0EFFFFFF))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(Color(0x33EF4444)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = null,
                                tint = ImmersiveRedAccent,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        Column {
                            Text(text = gameTitle, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = profile, color = ImmersiveSlate400, fontSize = 9.sp, fontFamily = FontFamily.Monospace)
                        }
                    }

                    Button(
                        onClick = {
                            Toast.makeText(context, "Launching $gameTitle with Turbo Boost!", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(6.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0x15FFFFFF)),
                        border = BorderStroke(1.dp, ImmersiveCardBorderGlow),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("LAUNCH", color = ImmersiveRedAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

// ---------------------------------------------------------
// Crash-Safe Intent & Permission Helpers
// ---------------------------------------------------------
fun requestShizukuAccessSafely(context: Context, onRefresh: () -> Unit) {
    try {
        if (!Shizuku.pingBinder()) {
            Toast.makeText(context, "Shizuku service is not running. Please start Shizuku Manager first.", Toast.LENGTH_LONG).show()
            openShizukuAppSafely(context)
            return
        }

        if (Shizuku.isPreV11()) {
            Toast.makeText(context, "Shizuku version is pre-v11. Please update Shizuku.", Toast.LENGTH_SHORT).show()
            return
        }

        val permission = Shizuku.checkSelfPermission()
        if (permission == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(context, "Shizuku Shell Access is already Granted!", Toast.LENGTH_SHORT).show()
            onRefresh()
        } else {
            Shizuku.requestPermission(9101)
        }
    } catch (e: Throwable) {
        Toast.makeText(context, "Shizuku access request failed: ${e.localizedMessage ?: "Service Unavailable"}", Toast.LENGTH_SHORT).show()
        openShizukuAppSafely(context)
    }
}

fun openShizukuAppSafely(context: Context) {
    try {
        val launchIntent = context.packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
            ?: context.packageManager.getLaunchIntentForPackage("moe.shizuku.redirector")

        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            val marketIntent = Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=moe.shizuku.privileged.api")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(marketIntent)
        }
    } catch (e: ActivityNotFoundException) {
        try {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/guide/setup/")).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(webIntent)
        } catch (e2: Exception) {
            Toast.makeText(context, "Shizuku Manager is not installed.", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Unable to open Shizuku: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}

fun openOverlaySettingsSafely(context: Context) {
    try {
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        try {
            val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e2: Exception) {
            Toast.makeText(context, "Overlay settings screen not available on this device", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Error opening overlay settings: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}

fun openWriteSettingsSafely(context: Context) {
    try {
        val intent = Intent(
            Settings.ACTION_MANAGE_WRITE_SETTINGS,
            Uri.parse("package:${context.packageName}")
        ).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
    } catch (e: ActivityNotFoundException) {
        try {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (e2: Exception) {
            Toast.makeText(context, "System settings modifier not supported on this device", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Error opening write settings: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}

fun requestStorageAccessSafely(
    context: Context,
    storageLauncher: androidx.activity.result.ActivityResultLauncher<Array<String>>
) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(
                    Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                    Uri.parse("package:${context.packageName}")
                ).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (e: ActivityNotFoundException) {
                val intent = Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            }
        } else {
            storageLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            )
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Error opening storage access screen: ${e.localizedMessage}", Toast.LENGTH_SHORT).show()
    }
}
