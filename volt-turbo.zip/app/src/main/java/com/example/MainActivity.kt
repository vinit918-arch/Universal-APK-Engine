package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.components.VoltBottomBar
import com.example.ui.components.VoltNavTab
import com.example.ui.components.VoltTopHeader
import com.example.ui.screens.BoostScreen
import com.example.ui.screens.GamesScreen
import com.example.ui.screens.StatusScreen
import com.example.ui.screens.TogglesScreen
import com.example.ui.theme.VoltBackgroundDark
import com.example.ui.theme.VoltTurboTheme
import com.example.ui.viewmodel.VoltMainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: VoltMainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            val animationsEnabled by viewModel.appAnimationsEnabled.collectAsState()
            val shizukuState by viewModel.shizukuState.collectAsState()
            val toggles by viewModel.toggles.collectAsState()
            val games by viewModel.games.collectAsState()
            val activeSession by viewModel.activeSessionState.collectAsState()

            var currentTab by remember { mutableStateOf(VoltNavTab.GAMES) }

            VoltTurboTheme(animationsEnabled = animationsEnabled) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.radialGradient(
                                colors = listOf(Color(0xFF141424), VoltBackgroundDark, Color(0xFF000000)),
                                radius = 1400f
                            )
                        )
                ) {
                    Scaffold(
                        containerColor = Color.Transparent,
                        topBar = {
                            VoltTopHeader(
                                shizukuState = shizukuState,
                                isSessionActive = activeSession != null,
                                onRestoreAll = { viewModel.restoreSessionAndResetToggles() },
                                modifier = Modifier.statusBarsPadding()
                            )
                        },
                        bottomBar = {
                            VoltBottomBar(
                                currentTab = currentTab,
                                onTabSelected = { currentTab = it }
                            )
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            if (animationsEnabled) {
                                AnimatedContent(
                                    targetState = currentTab,
                                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                                    label = "main_tabs_transition"
                                ) { tab ->
                                    ScreenContent(
                                        tab = tab,
                                        viewModel = viewModel,
                                        activity = this@MainActivity,
                                        shizukuState = shizukuState,
                                        toggles = toggles,
                                        games = games,
                                        activeSession = activeSession,
                                        animationsEnabled = animationsEnabled
                                    )
                                }
                            } else {
                                ScreenContent(
                                    tab = currentTab,
                                    viewModel = viewModel,
                                    activity = this@MainActivity,
                                    shizukuState = shizukuState,
                                    toggles = toggles,
                                    games = games,
                                    activeSession = activeSession,
                                    animationsEnabled = animationsEnabled
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScreenContent(
    tab: VoltNavTab,
    viewModel: VoltMainViewModel,
    activity: ComponentActivity,
    shizukuState: com.example.shizuku.ShizukuState,
    toggles: List<com.example.data.model.SystemToggle>,
    games: List<com.example.data.model.GameItem>,
    activeSession: com.example.data.model.ActiveSessionInfo?,
    animationsEnabled: Boolean
) {
    when (tab) {
        VoltNavTab.TOGGLES -> {
            TogglesScreen(
                toggles = toggles,
                onToggleChange = { id, enabled -> viewModel.toggleSystemSetting(id, enabled) },
                onApplyPreset = { preset -> viewModel.applyPreset(preset) },
                animationsEnabled = animationsEnabled,
                onToggleAnimations = { viewModel.setAppAnimationsEnabled(it) }
            )
        }
        VoltNavTab.GAMES -> {
            GamesScreen(
                games = games,
                activeSession = activeSession,
                onAddGame = { viewModel.addGame(it) },
                onRemoveGame = { viewModel.removeGame(it) },
                onOptimizeGame = { viewModel.markGameOptimized(it) },
                onLaunchGame = { viewModel.launchGameWithOptimizations(it) },
                onRestoreSession = { viewModel.restoreSessionAndResetToggles() },
                onScanApps = { viewModel.scanInstalledApps() }
            )
        }
        VoltNavTab.BOOST -> {
            BoostScreen(
                savedGames = games,
                onLaunchGameWithBoost = { viewModel.launchGameWithOptimizations(it) }
            )
        }
        VoltNavTab.STATUS -> {
            StatusScreen(
                shizukuState = shizukuState,
                animationsEnabled = animationsEnabled,
                onToggleAnimations = { viewModel.setAppAnimationsEnabled(it) },
                onRequestShizukuPermission = { viewModel.requestShizukuPermission(activity) }
            )
        }
    }
}
