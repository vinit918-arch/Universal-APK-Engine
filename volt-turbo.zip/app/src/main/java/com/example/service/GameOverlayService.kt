package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.R
import com.example.data.model.ColorGradingConfig
import com.example.data.model.CrosshairConfig
import com.example.data.repository.SettingsRepository
import com.example.shizuku.ShizukuShellExecutor
import com.example.ui.overlay.CrosshairCanvas
import com.example.ui.overlay.FpsTracker
import com.example.ui.overlay.OverlayLeftPanel
import com.example.ui.overlay.OverlayRightPanel
import com.example.ui.theme.VoltBackgroundDark
import com.example.ui.theme.VoltCyan
import com.example.ui.theme.VoltTurboTheme
import com.example.ui.theme.VoltViolet
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

class GameOverlayService : Service(), LifecycleOwner, SavedStateRegistryOwner {

    companion object {
        private const val TAG = "VoltOverlayService"
        const val OVERLAY_CHANNEL_ID = "volt_overlay_channel"
        const val NOTIFICATION_ID = 2002

        fun startOverlay(context: Context) {
            if (!Settings.canDrawOverlays(context)) return
            val intent = Intent(context, GameOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopOverlay(context: Context) {
            val intent = Intent(context, GameOverlayService::class.java)
            context.stopService(intent)
        }
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var windowManager: WindowManager
    private lateinit var settingsRepo: SettingsRepository

    private var leftOverlayView: ComposeView? = null
    private var rightOverlayView: ComposeView? = null
    private var crosshairOverlayView: ComposeView? = null
    private var colorGradingOverlayView: ComposeView? = null

    private val autoCollapseHandler = Handler(Looper.getMainLooper())
    private var isLeftExpanded = mutableStateOf(false)
    private var isRightExpanded = mutableStateOf(false)

    private val collapseRunnable = Runnable {
        isLeftExpanded.value = false
        isRightExpanded.value = false
        FpsTracker.stopTracking()
        updateWindowTouchFlags()
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        settingsRepo = SettingsRepository(applicationContext)

        createNotificationChannel()
        startForeground(NOTIFICATION_ID, buildOverlayNotification())

        setupOverlayWindows()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                OVERLAY_CHANNEL_ID,
                "Volt Turbo HUD Overlay",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active floating HUD overlay"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildOverlayNotification(): Notification {
        return NotificationCompat.Builder(this, OVERLAY_CHANNEL_ID)
            .setContentTitle("Volt Turbo HUD")
            .setContentText("Edge floating panels and crosshair HUD active")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun resetAutoCollapseTimer() {
        autoCollapseHandler.removeCallbacks(collapseRunnable)
        if (isLeftExpanded.value || isRightExpanded.value) {
            FpsTracker.startTracking()
            autoCollapseHandler.postDelayed(collapseRunnable, 5000)
        } else {
            FpsTracker.stopTracking()
        }
        updateWindowTouchFlags()
    }

    private fun setupOverlayWindows() {
        if (!Settings.canDrawOverlays(this)) return

        val displayMetrics = resources.displayMetrics
        val screenHeight = displayMetrics.heightPixels

        // 1. LEFT OVERLAY VIEW (Tab + Slideout Panel)
        leftOverlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@GameOverlayService)
            setViewTreeSavedStateRegistryOwner(this@GameOverlayService)
            setContent {
                val animsEnabled by settingsRepo.appAnimationsFlow.collectAsState(initial = true)
                val positions by settingsRepo.overlayPositionsFlow.collectAsState(initial = com.example.data.model.OverlayPositions())
                var leftExpanded by remember { isLeftExpanded }
                var yRatio by remember(positions.leftTabYRatio) { mutableFloatStateOf(positions.leftTabYRatio) }

                VoltTurboTheme(animationsEnabled = animsEnabled) {
                    Box(modifier = Modifier.fillMaxHeight()) {
                        // Left Edge Tab
                        if (!leftExpanded) {
                            val offsetY = (screenHeight * yRatio).roundToInt()
                            Box(
                                modifier = Modifier
                                    .offset { IntOffset(0, offsetY) }
                                    .size(width = 28.dp, height = 52.dp)
                                    .clip(RoundedCornerShape(topEnd = 12.dp, bottomEnd = 12.dp))
                                    .background(Color(0xE012121E))
                                    .border(
                                        width = 1.5.dp,
                                        color = VoltCyan,
                                        shape = RoundedCornerShape(topEnd = 12.dp, bottomEnd = 12.dp)
                                    )
                                    .pointerInput(Unit) {
                                        detectDragGestures(
                                            onDragEnd = {
                                                serviceScope.launch {
                                                    settingsRepo.updateTabPosition(isLeft = true, yRatio)
                                                }
                                            },
                                            onDrag = { change, dragAmount ->
                                                change.consume()
                                                val newY = yRatio + (dragAmount.y / screenHeight)
                                                yRatio = newY.coerceIn(0.1f, 0.85f)
                                                resetAutoCollapseTimer()
                                            }
                                        )
                                    }
                                    .clickable {
                                        isLeftExpanded.value = true
                                        isRightExpanded.value = false
                                        resetAutoCollapseTimer()
                                    }
                                    .testTag("left_edge_tab"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.FlashOn,
                                    contentDescription = "Open HUD",
                                    tint = VoltCyan,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Left Expanded Panel
                        if (animsEnabled) {
                            AnimatedVisibility(
                                visible = leftExpanded,
                                enter = slideInHorizontally(initialOffsetX = { -it }) + fadeIn(),
                                exit = slideOutHorizontally(targetOffsetX = { -it }) + fadeOut()
                            ) {
                                OverlayLeftPanel(
                                    sessionStartTime = System.currentTimeMillis(),
                                    onClose = {
                                        isLeftExpanded.value = false
                                        resetAutoCollapseTimer()
                                    },
                                    onRestoreAndExit = {
                                        GameSessionService.restoreAndStop(this@GameOverlayService)
                                    }
                                )
                            }
                        } else {
                            if (leftExpanded) {
                                OverlayLeftPanel(
                                    sessionStartTime = System.currentTimeMillis(),
                                    onClose = {
                                        isLeftExpanded.value = false
                                        resetAutoCollapseTimer()
                                    },
                                    onRestoreAndExit = {
                                        GameSessionService.restoreAndStop(this@GameOverlayService)
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. RIGHT OVERLAY VIEW (Tab + Slideout Visual Tools)
        rightOverlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@GameOverlayService)
            setViewTreeSavedStateRegistryOwner(this@GameOverlayService)
            setContent {
                val animsEnabled by settingsRepo.appAnimationsFlow.collectAsState(initial = true)
                val positions by settingsRepo.overlayPositionsFlow.collectAsState(initial = com.example.data.model.OverlayPositions())
                val crosshairConfig by settingsRepo.crosshairFlow.collectAsState(initial = CrosshairConfig())
                val colorGradingConfig by settingsRepo.colorGradingFlow.collectAsState(initial = ColorGradingConfig())
                var rightExpanded by remember { isRightExpanded }
                var yRatio by remember(positions.rightTabYRatio) { mutableFloatStateOf(positions.rightTabYRatio) }

                VoltTurboTheme(animationsEnabled = animsEnabled) {
                    Box(modifier = Modifier.fillMaxHeight(), contentAlignment = Alignment.TopEnd) {
                        // Right Edge Tab
                        if (!rightExpanded) {
                            val offsetY = (screenHeight * yRatio).roundToInt()
                            Box(
                                modifier = Modifier
                                    .offset { IntOffset(0, offsetY) }
                                    .size(width = 28.dp, height = 52.dp)
                                    .clip(RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp))
                                    .background(Color(0xE012121E))
                                    .border(
                                        width = 1.5.dp,
                                        color = VoltViolet,
                                        shape = RoundedCornerShape(topStart = 12.dp, bottomStart = 12.dp)
                                    )
                                    .pointerInput(Unit) {
                                        detectDragGestures(
                                            onDragEnd = {
                                                serviceScope.launch {
                                                    settingsRepo.updateTabPosition(isLeft = false, yRatio)
                                                }
                                            },
                                            onDrag = { change, dragAmount ->
                                                change.consume()
                                                val newY = yRatio + (dragAmount.y / screenHeight)
                                                yRatio = newY.coerceIn(0.1f, 0.85f)
                                                resetAutoCollapseTimer()
                                            }
                                        )
                                    }
                                    .clickable {
                                        isRightExpanded.value = true
                                        isLeftExpanded.value = false
                                        resetAutoCollapseTimer()
                                    }
                                    .testTag("right_edge_tab"),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Palette,
                                    contentDescription = "Open Visual Tools",
                                    tint = VoltViolet,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }

                        // Right Expanded Panel
                        if (animsEnabled) {
                            AnimatedVisibility(
                                visible = rightExpanded,
                                enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                                exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut()
                            ) {
                                OverlayRightPanel(
                                    crosshairConfig = crosshairConfig,
                                    onCrosshairChange = {
                                        serviceScope.launch { settingsRepo.updateCrosshairConfig(it) }
                                        resetAutoCollapseTimer()
                                    },
                                    colorGradingConfig = colorGradingConfig,
                                    onColorGradingChange = {
                                        serviceScope.launch { settingsRepo.updateColorGradingConfig(it) }
                                        resetAutoCollapseTimer()
                                    },
                                    onTakeScreenshot = {
                                        serviceScope.launch {
                                            val result = ShizukuShellExecutor.execute("screencap -p /sdcard/volt_screenshot_${System.currentTimeMillis()}.png")
                                            Toast.makeText(applicationContext, "Screenshot saved to /sdcard/", Toast.LENGTH_SHORT).show()
                                        }
                                        resetAutoCollapseTimer()
                                    },
                                    onClose = {
                                        isRightExpanded.value = false
                                        resetAutoCollapseTimer()
                                    }
                                )
                            }
                        } else {
                            if (rightExpanded) {
                                OverlayRightPanel(
                                    crosshairConfig = crosshairConfig,
                                    onCrosshairChange = {
                                        serviceScope.launch { settingsRepo.updateCrosshairConfig(it) }
                                        resetAutoCollapseTimer()
                                    },
                                    colorGradingConfig = colorGradingConfig,
                                    onColorGradingChange = {
                                        serviceScope.launch { settingsRepo.updateColorGradingConfig(it) }
                                        resetAutoCollapseTimer()
                                    },
                                    onTakeScreenshot = {
                                        serviceScope.launch {
                                            ShizukuShellExecutor.execute("screencap -p /sdcard/volt_screenshot_${System.currentTimeMillis()}.png")
                                            Toast.makeText(applicationContext, "Screenshot saved to /sdcard/", Toast.LENGTH_SHORT).show()
                                        }
                                        resetAutoCollapseTimer()
                                    },
                                    onClose = {
                                        isRightExpanded.value = false
                                        resetAutoCollapseTimer()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }

        // 3. CROSSHAIR OVERLAY LAYER (Purely visual, strictly non-touchable)
        crosshairOverlayView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@GameOverlayService)
            setViewTreeSavedStateRegistryOwner(this@GameOverlayService)
            setContent {
                val crosshairConfig by settingsRepo.crosshairFlow.collectAsState(initial = CrosshairConfig())
                if (crosshairConfig.enabled) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        CrosshairCanvas(
                            config = crosshairConfig,
                            modifier = Modifier.offset(
                                x = crosshairConfig.offsetX.dp,
                                y = crosshairConfig.offsetY.dp
                            )
                        )
                    }
                }
            }
        }

        // Add Left & Right Views to WindowManager
        val leftParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.START or Gravity.TOP
        }

        val rightParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.END or Gravity.TOP
        }

        // Crosshair Layout Params: strictly NOT_TOUCHABLE & NOT_FOCUSABLE
        val crosshairParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )

        try {
            windowManager.addView(crosshairOverlayView, crosshairParams)
            windowManager.addView(leftOverlayView, leftParams)
            windowManager.addView(rightOverlayView, rightParams)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding overlay views to WindowManager", e)
        }
    }

    private fun updateWindowTouchFlags() {
        // Window flags update if needed
    }

    override fun onDestroy() {
        super.onDestroy()
        autoCollapseHandler.removeCallbacks(collapseRunnable)
        FpsTracker.stopTracking()

        try {
            leftOverlayView?.let { windowManager.removeView(it) }
            rightOverlayView?.let { windowManager.removeView(it) }
            crosshairOverlayView?.let { windowManager.removeView(it) }
            colorGradingOverlayView?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing overlay views", e)
        }

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        serviceScope.cancel()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
