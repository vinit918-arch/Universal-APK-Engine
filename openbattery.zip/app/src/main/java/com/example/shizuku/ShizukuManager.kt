package com.example.shizuku

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku
import java.io.BufferedReader
import java.io.InputStreamReader

private const val TAG = "ShizukuManager"
private const val SHIZUKU_REQ_CODE = 4021

data class ShizukuState(
    val isInstalledOrAlive: Boolean = false,
    val isPermissionGranted: Boolean = false,
    val isExecuting: Boolean = false,
    val lastExecutionOutput: String? = null,
    val lastExecutionTimeMillis: Long? = null,
    val errorMessage: String? = null
)

class ShizukuManager(private val context: Context) {

    private val _state = MutableStateFlow(ShizukuState())
    val state: StateFlow<ShizukuState> = _state.asStateFlow()

    private val binderReceivedListener = Shizuku.OnBinderReceivedListener {
        Log.d(TAG, "Shizuku binder received")
        updateStatus()
    }

    private val binderDeadListener = Shizuku.OnBinderDeadListener {
        Log.d(TAG, "Shizuku binder dead")
        _state.value = _state.value.copy(
            isInstalledOrAlive = false,
            isPermissionGranted = false,
            errorMessage = "Shizuku service stopped or disconnected."
        )
    }

    private val permissionResultListener = Shizuku.OnRequestPermissionResultListener { requestCode, grantResult ->
        if (requestCode == SHIZUKU_REQ_CODE) {
            val isGranted = grantResult == PackageManager.PERMISSION_GRANTED
            Log.d(TAG, "Shizuku permission result: $isGranted")
            _state.value = _state.value.copy(
                isPermissionGranted = isGranted,
                errorMessage = if (isGranted) null else "Shizuku permission was denied."
            )
        }
    }

    init {
        try {
            Shizuku.addBinderReceivedListenerSticky(binderReceivedListener)
            Shizuku.addBinderDeadListener(binderDeadListener)
            Shizuku.addRequestPermissionResultListener(permissionResultListener)
            updateStatus()
        } catch (e: Throwable) {
            Log.e(TAG, "Error initializing Shizuku listeners", e)
            _state.value = _state.value.copy(
                isInstalledOrAlive = false,
                isPermissionGranted = false,
                errorMessage = e.message
            )
        }
    }

    fun updateStatus() {
        try {
            val alive = Shizuku.pingBinder()
            val isVersionSupported = try {
                Shizuku.getVersion() >= 11
            } catch (e: Throwable) {
                false
            }

            val permissionGranted = if (alive && isVersionSupported) {
                Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            } else {
                false
            }

            _state.value = _state.value.copy(
                isInstalledOrAlive = alive,
                isPermissionGranted = permissionGranted,
                errorMessage = if (!alive) {
                    "Shizuku service is not active. Please start Shizuku via Wireless Debugging or Root."
                } else if (!isVersionSupported) {
                    "Shizuku version 11+ is required."
                } else null
            )
        } catch (e: Throwable) {
            Log.w(TAG, "Shizuku ping failed: ${e.message}")
            _state.value = _state.value.copy(
                isInstalledOrAlive = false,
                isPermissionGranted = false,
                errorMessage = "Shizuku not detected: ${e.localizedMessage ?: "Service inactive"}"
            )
        }
    }

    fun requestPermission() {
        try {
            if (Shizuku.pingBinder()) {
                val version = try { Shizuku.getVersion() } catch (e: Throwable) { 0 }
                if (version < 11) {
                    _state.value = _state.value.copy(errorMessage = "Shizuku version $version is unsupported. v11+ required.")
                    return
                }
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    _state.value = _state.value.copy(isPermissionGranted = true, errorMessage = null)
                } else if (Shizuku.shouldShowRequestPermissionRationale()) {
                    _state.value = _state.value.copy(errorMessage = "Please approve Shizuku permission request.")
                    Shizuku.requestPermission(SHIZUKU_REQ_CODE)
                } else {
                    Shizuku.requestPermission(SHIZUKU_REQ_CODE)
                }
            } else {
                _state.value = _state.value.copy(
                    errorMessage = "Cannot request permission: Shizuku service is not running."
                )
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed requesting Shizuku permission", e)
            _state.value = _state.value.copy(errorMessage = "Permission request failed: ${e.message}")
        }
    }

    /**
     * Executes `dumpsys battery` programmatically with Shizuku ADB shell privileges.
     */
    suspend fun executeDumpsysBattery(): Result<String> = withContext(Dispatchers.IO) {
        _state.value = _state.value.copy(isExecuting = true, errorMessage = null)

        try {
            if (!Shizuku.pingBinder()) {
                val err = "Shizuku service is not running. Please start Shizuku via Wireless Debugging or Root."
                _state.value = _state.value.copy(isExecuting = false, errorMessage = err)
                return@withContext Result.failure(IllegalStateException(err))
            }

            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                val err = "Shizuku permission not granted. Tap 'Grant Shizuku Permission' first."
                _state.value = _state.value.copy(isExecuting = false, errorMessage = err)
                return@withContext Result.failure(SecurityException(err))
            }

            // Execute "dumpsys battery" via Shizuku's native binder process reflection
            val newProcessMethod = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            newProcessMethod.isAccessible = true
            val process = newProcessMethod.invoke(
                null,
                arrayOf("dumpsys", "battery"),
                null,
                null
            ) as java.lang.Process

            val output = StringBuilder()
            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                output.appendLine(line)
            }

            val exitCode = process.waitFor()
            reader.close()

            val errorOutput = StringBuilder()
            val errReader = BufferedReader(InputStreamReader(process.errorStream))
            var errLine: String?
            while (errReader.readLine().also { errLine = it } != null) {
                errorOutput.appendLine(errLine)
            }
            errReader.close()

            val resultText = output.toString().trim()

            if (exitCode == 0 && resultText.isNotBlank()) {
                _state.value = _state.value.copy(
                    isExecuting = false,
                    lastExecutionOutput = resultText,
                    lastExecutionTimeMillis = System.currentTimeMillis(),
                    errorMessage = null
                )
                Result.success(resultText)
            } else {
                val err = if (errorOutput.isNotBlank()) errorOutput.toString() else "Command exited with code $exitCode"
                _state.value = _state.value.copy(
                    isExecuting = false,
                    errorMessage = "Execution error: $err"
                )
                Result.failure(RuntimeException(err))
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Shizuku execution failed", e)
            _state.value = _state.value.copy(
                isExecuting = false,
                errorMessage = "Failed to run dumpsys battery: ${e.message}"
            )
            Result.failure(e)
        }
    }

    fun destroy() {
        try {
            Shizuku.removeBinderReceivedListener(binderReceivedListener)
            Shizuku.removeBinderDeadListener(binderDeadListener)
            Shizuku.removeRequestPermissionResultListener(permissionResultListener)
        } catch (e: Throwable) {
            Log.w(TAG, "Error detaching Shizuku listeners", e)
        }
    }
}
